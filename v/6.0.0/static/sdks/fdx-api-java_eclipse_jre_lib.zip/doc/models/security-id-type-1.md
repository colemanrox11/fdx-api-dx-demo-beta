
# Security Id Type 1

CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN

*This model accepts additional fields of type Object.*

## Enumeration

`SecurityIdType1`

## Fields

| Name |
|  --- |
| `Cins` |
| `Cmc` |
| `Cme` |
| `Cusip` |
| `Isin` |
| `Itsa` |
| `Nasdaq` |
| `Sedol` |
| `Sicc` |
| `Valor` |
| `Wkn` |

