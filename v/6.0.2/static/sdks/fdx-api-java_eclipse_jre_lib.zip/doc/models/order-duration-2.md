
# Order Duration 2

This order is good for DAY, GOODTILLCANCEL, IMMEDIATE

*This model accepts additional fields of type Object.*

## Enumeration

`OrderDuration2`

## Fields

| Name |
|  --- |
| `Day` |
| `Goodtillcancel` |
| `Immediate` |

