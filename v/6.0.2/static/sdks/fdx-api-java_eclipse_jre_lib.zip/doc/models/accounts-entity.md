
# Accounts Entity

An optionally paginated array of accounts

*This model accepts additional fields of type Object.*

## Structure

`AccountsEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets | PageMetadata getPage() | setPage(PageMetadata page) |
| `Links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets | PageMetadataLinks getLinks() | setLinks(PageMetadataLinks links) |
| `Accounts` | [`List<AccountsEntityAccounts>`](../../doc/models/containers/accounts-entity-accounts.md) | Optional | This is List of a container for any-of cases. | List<AccountsEntityAccounts> getAccounts() | setAccounts(List<AccountsEntityAccounts> accounts) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accounts": [
    {
      "accountCategory": "Annuity Account entity",
      "accountId": "accountId6",
      "error": {
        "code": "code2",
        "message": "message4",
        "debugMessage": "debugMessage4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "accountType": "SPECIFIEDPENSIONPLAN",
      "accountNumber": "accountNumber6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      },
      "parentAccountId": "parentAccountId8",
      "lineOfBusiness": "lineOfBusiness8",
      "routingTransitNumber": "routingTransitNumber0",
      "balanceType": "ASSET",
      "contact": {
        "emails": [
          "emails1",
          "emails2",
          "emails3"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "holders": [
          {
            "emails": [
              "emails5",
              "emails6"
            ],
            "addresses": [
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              },
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "telephones": [
              {
                "type": "FAX",
                "country": "country0",
                "number": "number4",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "dateOfBirth": "2016-03-13",
            "taxId": "taxId2",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "emails": [
              "emails5",
              "emails6"
            ],
            "addresses": [
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              },
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "telephones": [
              {
                "type": "FAX",
                "country": "country0",
                "number": "number4",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "dateOfBirth": "2016-03-13",
            "taxId": "taxId2",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "payoutType": "DEFERRED",
      "policyProductType": "FIXED",
      "payoutAmount": 63.04,
      "payoutMode": "ANNUALLY",
      "payoutStartDate": "2016-03-13"
    },
    {
      "accountCategory": "Annuity Account entity",
      "accountId": "accountId6",
      "error": {
        "code": "code2",
        "message": "message4",
        "debugMessage": "debugMessage4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "accountType": "SPECIFIEDPENSIONPLAN",
      "accountNumber": "accountNumber6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      },
      "parentAccountId": "parentAccountId8",
      "lineOfBusiness": "lineOfBusiness8",
      "routingTransitNumber": "routingTransitNumber0",
      "balanceType": "ASSET",
      "contact": {
        "emails": [
          "emails1",
          "emails2",
          "emails3"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "holders": [
          {
            "emails": [
              "emails5",
              "emails6"
            ],
            "addresses": [
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              },
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "telephones": [
              {
                "type": "FAX",
                "country": "country0",
                "number": "number4",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "dateOfBirth": "2016-03-13",
            "taxId": "taxId2",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "emails": [
              "emails5",
              "emails6"
            ],
            "addresses": [
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              },
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "telephones": [
              {
                "type": "FAX",
                "country": "country0",
                "number": "number4",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "dateOfBirth": "2016-03-13",
            "taxId": "taxId2",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "payoutType": "DEFERRED",
      "policyProductType": "FIXED",
      "payoutAmount": 63.04,
      "payoutMode": "ANNUALLY",
      "payoutStartDate": "2016-03-13"
    },
    {
      "accountCategory": "Annuity Account entity",
      "accountId": "accountId6",
      "error": {
        "code": "code2",
        "message": "message4",
        "debugMessage": "debugMessage4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "accountType": "SPECIFIEDPENSIONPLAN",
      "accountNumber": "accountNumber6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      },
      "parentAccountId": "parentAccountId8",
      "lineOfBusiness": "lineOfBusiness8",
      "routingTransitNumber": "routingTransitNumber0",
      "balanceType": "ASSET",
      "contact": {
        "emails": [
          "emails1",
          "emails2",
          "emails3"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "holders": [
          {
            "emails": [
              "emails5",
              "emails6"
            ],
            "addresses": [
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              },
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "telephones": [
              {
                "type": "FAX",
                "country": "country0",
                "number": "number4",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "dateOfBirth": "2016-03-13",
            "taxId": "taxId2",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "emails": [
              "emails5",
              "emails6"
            ],
            "addresses": [
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              },
              {
                "line1": "line16",
                "line2": "line28",
                "line3": "line36",
                "city": "city4",
                "region": "region0",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "telephones": [
              {
                "type": "FAX",
                "country": "country0",
                "number": "number4",
                "exampleAdditionalProperty": {
                  "key1": "val1",
                  "key2": "val2"
                }
              }
            ],
            "dateOfBirth": "2016-03-13",
            "taxId": "taxId2",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "payoutType": "DEFERRED",
      "policyProductType": "FIXED",
      "payoutAmount": 63.04,
      "payoutMode": "ANNUALLY",
      "payoutStartDate": "2016-03-13"
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

