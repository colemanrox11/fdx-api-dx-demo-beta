
# Consent Revocation Request Entity

Details of request to revoke consent grant

*This model accepts additional fields of type Object.*

## Structure

`ConsentRevocationRequestEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Reason` | [`ConsentUpdateReason1`](../../doc/models/consent-update-reason-1.md) | Optional | The reason for consent revocation | ConsentUpdateReason1 getReason() | setReason(ConsentUpdateReason1 reason) |
| `Initiator` | [`PartyType2`](../../doc/models/party-type-2.md) | Optional | The party initiating revocation | PartyType2 getInitiator() | setInitiator(PartyType2 initiator) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "reason": "BUSINESS_RULE",
  "initiator": "MERCHANT",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

