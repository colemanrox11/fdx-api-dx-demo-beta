
# Party Group Entity

Entity that allows payment initiation parties to be grouped using
specific business rules. Each payment initiation party can belong to
many groups.

*This model accepts additional fields of type Object.*

## Structure

`PartyGroupEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `GroupId` | `String` | Optional | Unique identifier of a group of payment initiation parties<br><br>**Constraints**: *Maximum Length*: `256` | String getGroupId() | setGroupId(String groupId) |
| `Name` | `String` | Optional | Associated name with the group of payment initiation parties | String getName() | setName(String name) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "groupId": "groupId0",
  "name": "name2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

