
# Content Types

Types of document formats. (Suggested values)

*This model accepts additional fields of type Object.*

## Enumeration

`ContentTypes`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONJSON` |
| `ENUM_APPLICATIONPDF` |
| `ENUM_APPLICATIONZIP` |
| `ENUM_IMAGEGIF` |
| `ENUM_IMAGEJPEG` |
| `ENUM_IMAGEPNG` |
| `ENUM_IMAGETIFF` |

