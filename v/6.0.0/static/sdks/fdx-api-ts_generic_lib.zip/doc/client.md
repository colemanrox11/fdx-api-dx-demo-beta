
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| timeout | `number` | Timeout for API calls.<br>*Default*: `0` |
| httpClientOptions | [`Partial<HttpClientOptions>`](../doc/http-client-options.md) | Stable configurable http client options. |
| unstableHttpClientOptions | `any` | Unstable configurable http client options. |
| logging | [`PartialLoggingOptions`](../doc/partial-logging-options.md) | Logging Configuration to enable logging |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The credential object for bearerAuth |
| taxBasicAuthCredentials | [`TaxBasicAuthCredentials`](auth/basic-authentication.md) | The credential object for taxBasicAuth |

The API client can be initialized as follows:

```ts
import { Client, Environment, LogLevel } from 'fdx-apilib';

const client = new Client({
  bearerAuthCredentials: {
    accessToken: 'AccessToken'
  },
  taxBasicAuthCredentials: {
    username: 'Username',
    password: 'Password'
  },
  timeout: 0,
  environment: Environment.Production,
  logging: {
    logLevel: LogLevel.Info,
    logRequest: {
      logBody: true
    },
    logResponse: {
      logHeaders: true
    }
  },
});
```

## FDX API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| userConsent | Gets UserConsentController |
| accountInformation | Gets AccountInformationController |
| accountStatements | Gets AccountStatementsController |
| accountTransactions | Gets AccountTransactionsController |
| moneyMovement | Gets MoneyMovementController |
| personalInformation | Gets PersonalInformationController |
| rewardProgramCategories | Gets RewardProgramCategoriesController |
| rewardProgramInformation | Gets RewardProgramInformationController |
| eventNotifications | Gets EventNotificationsController |
| fraudNotification | Gets FraudNotificationController |
| meta | Gets MetaController |
| internalTransfers | Gets InternalTransfersController |
| payeeManagement | Gets PayeeManagementController |
| paymentInitiationParties | Gets PaymentInitiationPartiesController |
| payments | Gets PaymentsController |
| recurringPayments | Gets RecurringPaymentsController |
| payrollInformation | Gets PayrollInformationController |
| recipients | Gets RecipientsController |
| submitTaxForms | Gets SubmitTaxFormsController |
| taxForms | Gets TaxFormsController |
| resourceInformation | Gets ResourceInformationController |

