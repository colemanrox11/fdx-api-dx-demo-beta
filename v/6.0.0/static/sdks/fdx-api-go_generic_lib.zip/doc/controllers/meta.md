# Meta

API management and metrics

```go
metaController := client.MetaController()
```

## Class Name

`MetaController`

## Methods

* [Get Availability](../../doc/controllers/meta.md#get-availability)
* [Get Capability](../../doc/controllers/meta.md#get-capability)
* [Get Certification Metrics](../../doc/controllers/meta.md#get-certification-metrics)


# Get Availability

Get information about this API's availability

```go
GetAvailability(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    operationId *models.FdxResourceOperationId) (
    models.ApiResponse[models.AvailabilityListEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operationId` | [`*models.FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AvailabilityListEntity](../../doc/models/availability-list-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch



apiResponse, err := metaController.GetAvailability(ctx, xFapiInteractionId, &fdxApiActorType, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get Capability

Get information about this API's capability

```go
GetCapability(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    operationId *models.FdxResourceOperationId,
    fdxVersion *models.FdxVersion,
    resultType *models.ResultType) (
    models.ApiResponse[models.CapabilityEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operationId` | [`*models.FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |
| `fdxVersion` | [`*models.FdxVersion`](../../doc/models/fdx-version.md) | Query, Optional | Specific FDX version for which to get the capability. Optional |
| `resultType` | [`*models.ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `"lightweight"` |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CapabilityEntity](../../doc/models/capability-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch





resultType := models.ResultType_Lightweight

apiResponse, err := metaController.GetCapability(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil, &resultType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get Certification Metrics

Get certification performance metrics for this implementer's APIs

```go
GetCertificationMetrics(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    operationId *models.FdxResourceOperationId) (
    models.ApiResponse[models.CertificationMetricsEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operationId` | [`*models.FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CertificationMetricsEntity](../../doc/models/certification-metrics-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch



apiResponse, err := metaController.GetCertificationMetrics(ctx, xFapiInteractionId, &fdxApiActorType, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

