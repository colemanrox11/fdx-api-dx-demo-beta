
# Page Metadata

Offset IDs for navigating result sets

*This model accepts additional fields of type Object.*

## Structure

`PageMetadata`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_offset` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific |
| `prev_offset` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific |
| `total_elements` | `Integer` | Optional | Total number of elements |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "nextOffset": "2",
  "prevOffset": "1",
  "totalElements": 3,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

