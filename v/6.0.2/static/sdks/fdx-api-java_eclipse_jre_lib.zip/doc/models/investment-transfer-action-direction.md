
# Investment Transfer Action Direction

Transaction transfer direction

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentTransferActionDirection`

## Fields

| Name |
|  --- |
| `In` |
| `Out` |

