
# Government Issued Id Type 2

Type of the identification

*This model accepts additional fields of type Object.*

## Enumeration

`GovernmentIssuedIdType2`

## Fields

| Name |
|  --- |
| `Driverlicense` |
| `Passport` |

