
# Payment Frequency 1

DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentFrequency1`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

