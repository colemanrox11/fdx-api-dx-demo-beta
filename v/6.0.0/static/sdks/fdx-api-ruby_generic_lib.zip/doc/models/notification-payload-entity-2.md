
# Notification Payload Entity 2

Notification-specific key-value paired data

*This model accepts additional fields of type Object.*

## Structure

`NotificationPayloadEntity2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | ID for the origination entity related to the notification |
| `id_type` | [`NotificationPayloadIdType2`](../../doc/models/notification-payload-id-type-2.md) | Optional | Type of entity causing origination of the notification with the given ID |
| `custom_fields` | [`FiAttributeEntity`](../../doc/models/fi-attribute-entity.md) | Optional | Custom key-value pairs for a notification |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "id": "id0",
  "idType": "PARTY",
  "customFields": {
    "name": "name0",
    "value": "value2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

