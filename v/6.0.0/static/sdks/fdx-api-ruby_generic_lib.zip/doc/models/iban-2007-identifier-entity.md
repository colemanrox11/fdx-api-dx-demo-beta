
# Iban 2007 Identifier Entity

IBAN 2007 account identifier

*This model accepts additional fields of type Object.*

## Structure

`Iban2007IdentifierEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `iban_2007_id` | `String` | Optional | Value of the account identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "iban2007Id": "iban2007Id4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

