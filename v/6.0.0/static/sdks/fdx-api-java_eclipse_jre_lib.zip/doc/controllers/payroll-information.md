# Payroll Information

```java
PayrollInformationController payrollInformationController = client.getPayrollInformationController();
```

## Class Name

`PayrollInformationController`

## Methods

* [Get Payroll Reports](../../doc/controllers/payroll-information.md#get-payroll-reports)
* [Get Payroll Report](../../doc/controllers/payroll-information.md#get-payroll-report)


# Get Payroll Reports

Search for the employee's latest payroll report

```java
CompletableFuture<ApiResponse<PayrollReportListEntity>> getPayrollReportsAsync(
    final UUID xFapiInteractionId,
    final PayrollReportType reportType,
    final FdxApiActorType fdxApiActorType,
    final ResultType resultType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `reportType` | [`PayrollReportType`](../../doc/models/payroll-report-type.md) | Query, Required | Whether to retrieve Verification of Employment ("VOE") or Verification of Income and Employment ("VOIE") reports |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `resultType` | [`ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `ResultType.LIGHTWEIGHT` |

## Server

`Server.PAYROLL`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayrollReportListEntity`](../../doc/models/payroll-report-list-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
PayrollReportType reportType = PayrollReportType.VOE;
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
ResultType resultType = ResultType.LIGHTWEIGHT;

payrollInformationController.getPayrollReportsAsync(xFapiInteractionId, reportType, fdxApiActorType, resultType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payroll Report

Retrieve the employee's specified payroll report

```java
CompletableFuture<ApiResponse<PayrollReportEntity>> getPayrollReportAsync(
    final String reportId,
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportId` | `String` | Template, Required | Specific reportId to retrieve<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.PAYROLL`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayrollReportEntity`](../../doc/models/payroll-report-entity.md).

## Example Usage

```java
String reportId = "reportId6";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

payrollInformationController.getPayrollReportAsync(reportId, xFapiInteractionId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Required input data not sent | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payroll Report with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

