
# Time and Occurrence Based Transfer Limits 3

Limits for outgoing transfers from the account

*This model accepts additional fields of type Object.*

## Structure

`TimeAndOccurrenceBasedTransferLimits3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `day` | [`TimeframeBasedLimitsForAPaymentNetwork5`](../../doc/models/timeframe-based-limits-for-a-payment-network-5.md) | Optional | The transfer limits for the current day |
| `week` | [`TimeframeBasedLimitsForAPaymentNetwork1`](../../doc/models/timeframe-based-limits-for-a-payment-network-1.md) | Optional | The transfer limits for the current week |
| `month` | [`TimeframeBasedLimitsForAPaymentNetwork2`](../../doc/models/timeframe-based-limits-for-a-payment-network-2.md) | Optional | The transfer limits for the current month |
| `year` | [`TimeframeBasedLimitsForAPaymentNetwork3`](../../doc/models/timeframe-based-limits-for-a-payment-network-3.md) | Optional | The transfer limits for the current year |
| `transaction` | [`OccurrenceBasedLimitsForAPaymentNetwork2`](../../doc/models/occurrence-based-limits-for-a-payment-network-2.md) | Optional | The transfer limits taking effect from all the timeframe limits |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "day": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 108.3,
    "transferRemainingAmount": 199.76,
    "maxOccurrence": 168,
    "remainingOccurrence": 46,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "week": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 238.72,
    "transferRemainingAmount": 74.18,
    "maxOccurrence": 102,
    "remainingOccurrence": 32,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "month": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 46.02,
    "transferRemainingAmount": 137.48,
    "maxOccurrence": 172,
    "remainingOccurrence": 218,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "year": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 25.7,
    "transferRemainingAmount": 117.16,
    "maxOccurrence": 156,
    "remainingOccurrence": 234,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "transaction": {
    "transferMaxAmount": 238.5,
    "transferRemainingAmount": 73.96,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

