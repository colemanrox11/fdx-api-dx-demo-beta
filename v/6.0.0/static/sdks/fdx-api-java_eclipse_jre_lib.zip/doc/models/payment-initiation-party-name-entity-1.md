
# Payment Initiation Party Name Entity 1

Name entity associated with the payment initiation party

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyNameEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AliasName` | `String` | Optional | Alias name | String getAliasName() | setAliasName(String aliasName) |
| `Detail` | [`PaymentInitiationPartyNameEntity1Detail`](../../doc/models/containers/payment-initiation-party-name-entity-1-detail.md) | Optional | This is a container for any-of cases. | PaymentInitiationPartyNameEntity1Detail getDetail() | setDetail(PaymentInitiationPartyNameEntity1Detail detail) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "aliasName": "aliasName8",
  "detail": {
    "companyName": "companyName0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

