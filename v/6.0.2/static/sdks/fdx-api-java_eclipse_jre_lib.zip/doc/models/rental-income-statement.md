
# Rental Income Statement

Rental Income Statement for IRS Form 1040 Schedule E

*This model accepts additional fields of type Object.*

## Structure

`RentalIncomeStatement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxYear` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | Integer getTaxYear() | setTaxYear(Integer taxYear) |
| `Corrected` | `Boolean` | Optional | True to indicate this is a corrected tax form | Boolean getCorrected() | setCorrected(Boolean corrected) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the source account. Not the account number<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `TaxFormId` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted.<br><br>**Constraints**: *Maximum Length*: `256` | String getTaxFormId() | setTaxFormId(String taxFormId) |
| `TaxFormDate` | `LocalDate` | Optional | Date of production or delivery of the tax form | LocalDate getTaxFormDate() | setTaxFormDate(LocalDate taxFormDate) |
| `AdditionalInformation` | `String` | Optional | Additional explanation text or content about this tax form | String getAdditionalInformation() | setAdditionalInformation(String additionalInformation) |
| `TaxFormType` | [`TypeFormType1`](../../doc/models/type-form-type-1.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | TypeFormType1 getTaxFormType() | setTaxFormType(TypeFormType1 taxFormType) |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty8 getIssuer() | setIssuer(TaxParty8 issuer) |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty1 getRecipient() | setRecipient(TaxParty1 recipient) |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | List<TaxFormAttribute> getAttributes() | setAttributes(List<TaxFormAttribute> attributes) |
| `Error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this form | Error1 getError() | setError(Error1 error) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `PropertyAddress` | [`Address`](../../doc/models/address.md) | Optional | Box 1a, Physical address of property (street, city, state, ZIP code) | Address getPropertyAddress() | setPropertyAddress(Address propertyAddress) |
| `Rents` | `Double` | Optional | Box 3, Rents received | Double getRents() | setRents(Double rents) |
| `Advertising` | `Double` | Optional | Box 5, Advertising | Double getAdvertising() | setAdvertising(Double advertising) |
| `Auto` | `Double` | Optional | Box 6, Auto and travel | Double getAuto() | setAuto(Double auto) |
| `Cleaning` | `Double` | Optional | Box 7, Cleaning and maintenance | Double getCleaning() | setCleaning(Double cleaning) |
| `Commissions` | `Double` | Optional | Box 8, Commissions | Double getCommissions() | setCommissions(Double commissions) |
| `Insurance` | `Double` | Optional | Box 9, Insurance | Double getInsurance() | setInsurance(Double insurance) |
| `Legal` | `Double` | Optional | Box 10, Legal and other professional fees | Double getLegal() | setLegal(Double legal) |
| `ManagementFees` | `Double` | Optional | Box 11, Management fees | Double getManagementFees() | setManagementFees(Double managementFees) |
| `MortgageInterest` | `Double` | Optional | Box 12, Mortgage interest paid to banks, etc. | Double getMortgageInterest() | setMortgageInterest(Double mortgageInterest) |
| `OtherInterest` | `Double` | Optional | Box 13, Other interest | Double getOtherInterest() | setOtherInterest(Double otherInterest) |
| `Repairs` | `Double` | Optional | Box 14, Repairs | Double getRepairs() | setRepairs(Double repairs) |
| `Supplies` | `Double` | Optional | Box 15, Supplies | Double getSupplies() | setSupplies(Double supplies) |
| `Taxes` | `Double` | Optional | Box 16, Taxes | Double getTaxes() | setTaxes(Double taxes) |
| `Utilities` | `Double` | Optional | Box 17, Utilities | Double getUtilities() | setUtilities(Double utilities) |
| `DepreciationExpense` | `Double` | Optional | Box 18, Depreciation | Double getDepreciationExpense() | setDepreciationExpense(Double depreciationExpense) |
| `OtherExpenses` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 19, Other expenses | List<DescriptionAndAmount> getOtherExpenses() | setOtherExpenses(List<DescriptionAndAmount> otherExpenses) |
| `CapitalExpenditures` | [`List<DateAndAmount>`](../../doc/models/date-and-amount.md) | Optional | Capital expenditures, for use in calculating Depreciation | List<DateAndAmount> getCapitalExpenditures() | setCapitalExpenditures(List<DateAndAmount> capitalExpenditures) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId8",
  "taxFormId": "taxFormId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

