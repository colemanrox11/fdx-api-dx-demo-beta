
# Base Payroll Rate

Provides a person's base pay rate

*This model accepts additional fields of type Object.*

## Structure

`BasePayrollRate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `rate` | [`MonetaryAmount`](../../doc/models/monetary-amount.md) | Required | The amount and currency of the base pay rate of employee |
| `rate_type` | [`PayrollRateType2`](../../doc/models/payroll-rate-type-2.md) | Required | Whether the worker's rate is ANNUAL, DAILY, HOURLY, OTHER |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "rate": {
    "amount": 238.12,
    "currency": "JPY",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "rateType": "ANNUAL",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

