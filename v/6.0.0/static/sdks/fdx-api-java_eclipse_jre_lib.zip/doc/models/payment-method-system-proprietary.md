
# Payment Method System Proprietary

Proprietary identifier of the external clearing system when the payment rail is not part of the ISO 20022 scope

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodSystemProprietary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ExternalClearingSystemIdentification1Proprietary` | `String` | Optional | For few examples where the payment rail is not part of the ISO 20022 scope | String getExternalClearingSystemIdentification1Proprietary() | setExternalClearingSystemIdentification1Proprietary(String externalClearingSystemIdentification1Proprietary) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "externalClearingSystemIdentification1Proprietary": "externalClearingSystemIdentification1Proprietary0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

