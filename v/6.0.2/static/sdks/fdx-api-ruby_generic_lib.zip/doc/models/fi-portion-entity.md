
# Fi Portion Entity

Financial Institution-specific asset allocation

*This model accepts additional fields of type Object.*

## Structure

`FiPortionEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_class` | `String` | Optional | Financial Institution-specific asset class |
| `percent` | `Float` | Optional | Percentage of asset class that falls under this asset |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "assetClass": "assetClass0",
  "percent": 210.02,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

