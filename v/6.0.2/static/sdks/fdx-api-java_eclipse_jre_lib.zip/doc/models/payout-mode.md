
# Payout Mode

Frequency of annuity payments.

| Value | Description |
|-----|-----|
| ANNUALLY | Paid Annually |
| BIWEEKLY | Paid Bi-weekly |
| DAILY | Paid Daily |
| MONTHLY | Paid Monthly |
| SEMIANNUALLY | Paid Semi-annually |
| SEMIMONTHLY | Paid Semi-monthly |

*This model accepts additional fields of type Object.*

## Enumeration

`PayoutMode`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

