
# Payment Initiation Party Contact Method Entity

A contact method for a payment initiation party.

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyContactMethodEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`ContactPreferencesType2`](../../doc/models/contact-preferences-type-2.md) | Optional | Type of the contact preference |
| `address` | [Electronic Address entity](../../doc/models/electronic-address-entity.md) \| [Telephone Number](../../doc/models/telephone-number.md) \| [Address](../../doc/models/address.md) \| nil | Optional | This is a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "FAX",
  "address": {
    "emailAddressText": "emailAddressText4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

