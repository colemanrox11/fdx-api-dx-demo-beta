
# Payment Initiation Party Method Create Response Entity

Registration between a payment initiation party and a Payment Method

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyMethodCreateResponseEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RegistrationId` | `String` | Optional | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` | String getRegistrationId() | setRegistrationId(String registrationId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "registrationId": "registrationId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

