
# Iban 2007 Identifier Entity

IBAN 2007 account identifier

*This model accepts additional fields of type Object.*

## Structure

`Iban2007IdentifierEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Iban2007Id` | `String` | Optional | Value of the account identifier<br><br>**Constraints**: *Maximum Length*: `256` | String getIban2007Id() | setIban2007Id(String iban2007Id) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "iban2007Id": "iban2007Id4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

