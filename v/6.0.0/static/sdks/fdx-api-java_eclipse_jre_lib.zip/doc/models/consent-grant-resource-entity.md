
# Consent Grant Resource Entity

Entity of permissioned resources

*This model accepts additional fields of type Object.*

## Structure

`ConsentGrantResourceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ResourceType` | [`ConsentResourceType3`](../../doc/models/consent-resource-type-3.md) | Required | Type of resource to be permissioned | ConsentResourceType3 getResourceType() | setResourceType(ConsentResourceType3 resourceType) |
| `ResourceId` | `String` | Required | Identifier of resource to be permissioned<br><br>**Constraints**: *Maximum Length*: `256` | String getResourceId() | setResourceId(String resourceId) |
| `DataClusters` | [`List<DataCluster>`](../../doc/models/data-cluster.md) | Required | Names of clusters of data elements permissioned<br><br>**Constraints**: *Minimum Items*: `1` | List<DataCluster> getDataClusters() | setDataClusters(List<DataCluster> dataClusters) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "resourceType": "DOCUMENT",
  "resourceId": "resourceId4",
  "dataClusters": [
    "BILLS"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

