
# Notification Category

Category of Notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationCategory`

## Fields

| Name |
|  --- |
| `Consent` |
| `Fraud` |
| `Maintenance` |
| `NewData` |
| `Security` |

