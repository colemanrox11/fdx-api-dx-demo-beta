
# Coverage Month

Month enumeration used on forms 1095-A and 1095-C

*This model accepts additional fields of type Object.*

## Enumeration

`CoverageMonth`

## Fields

| Name |
|  --- |
| `Annual` |
| `January` |
| `February` |
| `March` |
| `April` |
| `May` |
| `June` |
| `July` |
| `August` |
| `September` |
| `October` |
| `November` |
| `December` |

