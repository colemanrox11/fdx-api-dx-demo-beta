
# Debt Type 2

Debt type. One of COUPON, ZERO

*This model accepts additional fields of type Object.*

## Enumeration

`DebtType2`

## Fields

| Name |
|  --- |
| `COUPON` |
| `ZERO` |

