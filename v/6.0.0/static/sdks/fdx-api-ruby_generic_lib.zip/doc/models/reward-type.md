
# Reward Type

The type of the reward balance.  Example: a reward program awarding "Stars" for purchases would use the `POINTS` reward type.

* `CASHBACK`: Rewards balances enumerated using a monetary amount
* `MILES`: Rewards balances enumerated using distance
* `POINTS`: Default when a reward balance is not of type CASHBACK or MILES

*This model accepts additional fields of type Object.*

## Enumeration

`RewardType`

## Fields

| Name |
|  --- |
| `CASHBACK` |
| `MILES` |
| `POINTS` |

