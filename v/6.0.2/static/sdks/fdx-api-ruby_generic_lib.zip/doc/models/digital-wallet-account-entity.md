
# Digital Wallet Account Entity

Information for a digital wallet account

*This model accepts additional fields of type Object.*

## Structure

`DigitalWalletAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `balance_as_of` | `DateTime` | Optional | As-of date of balances |
| `current_balance` | `Float` | Optional | Balance of funds in account |
| `opening_day_balance` | `Float` | Optional | Day's opening fund balance |
| `available_balance` | `Float` | Optional | Balance of funds available for use |
| `annual_percentage_yield` | `Float` | Optional | Annual Percentage Yield |
| `interest_ytd` | `Float` | Optional | YTD Interest |
| `transactions` | [`Array<DigitalWalletTransactionEntity>`](../../doc/models/digital-wallet-transaction-entity.md) | Optional | Transactions on the digital wallet |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "balanceAsOf": "07/15/2021 14:46:41",
  "accountCategory": "Digital Wallet account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "currentBalance": 63.62,
  "openingDayBalance": 93.94,
  "availableBalance": 29.24,
  "annualPercentageYield": 167.88
}
```

