
# Treasury Management Type

The source of Treasury Management account definition; one of BAI, BTRS, ISO, SWIFT

*This model accepts additional fields of type Object.*

## Enumeration

`TreasuryManagementType`

## Fields

| Name |
|  --- |
| `BAI` |
| `BTRS` |
| `ISO` |
| `SWIFT` |

