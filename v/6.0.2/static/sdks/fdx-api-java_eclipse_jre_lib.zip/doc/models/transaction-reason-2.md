
# Transaction Reason 2

Reason for this transaction; CALL (the debt was called), SELL (the debt was sold), MATURITY (the debt reached maturity)

*This model accepts additional fields of type Object.*

## Enumeration

`TransactionReason2`

## Fields

| Name |
|  --- |
| `Call` |
| `Maturity` |
| `Sell` |

