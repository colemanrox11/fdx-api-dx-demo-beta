
# Recurring Payment Frequency

Defines how often a payment is made relative to the starting day.

* `BIWEEKLY`: Every 14 days
* `TWICEMONTHLY`: Every 15 days
* `WEEKLY`: Every 7 days

*This model accepts additional fields of type Object.*

## Enumeration

`RecurringPaymentFrequency`

## Fields

| Name |
|  --- |
| `Weekly` |
| `Biweekly` |
| `Twicemonthly` |
| `Monthly` |
| `Fourweeks` |
| `Bimonthly` |
| `Quarterly` |
| `Semiannually` |
| `Annually` |

