
# Recipient Request

Used to request a recipient registration. Properties in this structure use 'snake_case' names to match the properties in [IETF RFC 7591](https://datatracker.ietf.org/doc/rfc7591/)

*This model accepts additional fields of type Object.*

## Structure

`RecipientRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ClientName` | `String` | Required | The Data Recipient or Data Recipient Application name displayed by Data Provider during the consent Flow as well as in the Consent Dashboard<br><br>**Constraints**: *Maximum Length*: `256` | String getClientName() | setClientName(String clientName) |
| `Description` | `String` | Optional | A short description of the Data Recipient application | String getDescription() | setDescription(String description) |
| `RedirectUris` | `List<String>` | Required | An array of eligible Redirect URI targets | List<String> getRedirectUris() | setRedirectUris(List<String> redirectUris) |
| `LogoUri` | `String` | Optional | Data Recipient Logo URL location | String getLogoUri() | setLogoUri(String logoUri) |
| `ClientUri` | `String` | Optional | The URI which provides additional information about the Data Recipient | String getClientUri() | setClientUri(String clientUri) |
| `Contacts` | `List<String>` | Optional | Array of strings representing ways to contact individuals responsible for the Data Recipient application | List<String> getContacts() | setContacts(List<String> contacts) |
| `Scope` | `String` | Optional | String form field with a list of data clusters | String getScope() | setScope(String scope) |
| `DurationType` | [`List<ConsentDurationType>`](../../doc/models/consent-duration-type.md) | Optional | The duration of consent for the Data Recipient consumers | List<ConsentDurationType> getDurationType() | setDurationType(List<ConsentDurationType> durationType) |
| `DurationPeriod` | `Integer` | Optional | The maximum consent duration in days for duration_type TIME_BOUND for the Data Recipient, effective from the date of consent | Integer getDurationPeriod() | setDurationPeriod(Integer durationPeriod) |
| `LookbackPeriod` | `Integer` | Optional | The maximum number of days allowed for Data Recipient to obtain in transaction history, effective from the current date | Integer getLookbackPeriod() | setLookbackPeriod(Integer lookbackPeriod) |
| `RegistryReferences` | [`List<RegistryReference>`](../../doc/models/registry-reference.md) | Optional | An array of external registries containing registered entity name, registered entity id and registry fields for the registries where the data recipient is registered | List<RegistryReference> getRegistryReferences() | setRegistryReferences(List<RegistryReference> registryReferences) |
| `Intermediaries` | [`List<Intermediary>`](../../doc/models/intermediary.md) | Optional | An array of the intermediaries for this data recipient | List<Intermediary> getIntermediaries() | setIntermediaries(List<Intermediary> intermediaries) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "client_name": "client_name6",
  "description": "description0",
  "redirect_uris": [
    "redirect_uris3",
    "redirect_uris4",
    "redirect_uris5"
  ],
  "logo_uri": "logo_uri6",
  "client_uri": "client_uri8",
  "contacts": [
    "contacts7",
    "contacts8",
    "contacts9"
  ],
  "scope": "scope2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

