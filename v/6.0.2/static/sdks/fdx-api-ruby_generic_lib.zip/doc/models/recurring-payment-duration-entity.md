
# Recurring Payment Duration Entity

Describes a payment's duration

*This model accepts additional fields of type Object.*

## Structure

`RecurringPaymentDurationEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`RecurringPaymentDurationType2`](../../doc/models/recurring-payment-duration-type-2.md) | Required | Type of duration |
| `number_of_times` | `Float` | Optional | Maximum number of times a payment is to be sent. Required if type is set to NUMBEROFTIMES |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "type": "NOEND",
  "numberOfTimes": 77.06,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

