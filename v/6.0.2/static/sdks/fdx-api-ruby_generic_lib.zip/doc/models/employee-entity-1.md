
# Employee Entity 1

The employee

*This model accepts additional fields of type Object.*

## Structure

`EmployeeEntity1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emails` | `Array<String>` | Optional | Array of the contact email addresses |
| `addresses` | [`Array<DeliveryAddress>`](../../doc/models/delivery-address.md) | Optional | Array of the contact physical addresses |
| `telephones` | [`Array<TelephoneNumber>`](../../doc/models/telephone-number.md) | Optional | Array of the contact telephone numbers |
| `date_of_birth` | `Date` | Optional | The person's date of birth |
| `tax_id` | `String` | Optional | Country specific Tax Id associated with this customer (SIN or NAS in Canada, SSN or TIN in US, etc.) |
| `tax_id_country` | [`Iso3166CountryCode`](../../doc/models/iso-3166-country-code.md) | Optional | Country originating the Customer's taxId element |
| `government_id` | `String` | Optional | A federal (such as passport) or state (such as driver's license) issued identifier |
| `employee_id` | `String` | Optional | Provider's long-term persistent id for the employee<br><br>**Constraints**: *Maximum Length*: `256` |
| `name` | [`IndividualName`](../../doc/models/individual-name.md) | Required | Employee's full name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "dateOfBirth": "2021-07-15",
  "name": {
    "first": "first6",
    "middle": "middle6",
    "last": "last0",
    "suffix": "suffix0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "emails": [
    "emails7",
    "emails8"
  ],
  "addresses": [
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "telephones": [
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "taxId": "taxId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

