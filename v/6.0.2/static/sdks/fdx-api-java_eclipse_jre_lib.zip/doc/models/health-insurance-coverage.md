
# Health Insurance Coverage

Used on Form 1095-A Part III

*This model accepts additional fields of type Object.*

## Structure

`HealthInsuranceCoverage`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EnrollmentPremium` | `Double` | Optional | Monthly enrollment premiums | Double getEnrollmentPremium() | setEnrollmentPremium(Double enrollmentPremium) |
| `SlcspPremium` | `Double` | Optional | Monthly second lowest cost silver plan (SLCSP) premium | Double getSlcspPremium() | setSlcspPremium(Double slcspPremium) |
| `AdvancePremiumTaxCreditPayment` | `Double` | Optional | Monthly advance payment of premium tax credit | Double getAdvancePremiumTaxCreditPayment() | setAdvancePremiumTaxCreditPayment(Double advancePremiumTaxCreditPayment) |
| `Month` | [`CoverageMonth3`](../../doc/models/coverage-month-3.md) | Optional | Month of coverage | CoverageMonth3 getMonth() | setMonth(CoverageMonth3 month) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "enrollmentPremium": 139.74,
  "slcspPremium": 163.34,
  "advancePremiumTaxCreditPayment": 197.06,
  "month": "MAY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

