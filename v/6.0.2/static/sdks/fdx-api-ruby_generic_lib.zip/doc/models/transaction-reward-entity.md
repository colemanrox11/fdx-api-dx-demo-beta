
# Transaction Reward Entity

Rewards earned on a transaction

*This model accepts additional fields of type Object.*

## Structure

`TransactionRewardEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `category_id` | `String` | Optional | Long term persistent identity of the reward category. This ID is mapped to a category definition returned by calling the getRewardProgramCategories operation<br><br>**Constraints**: *Maximum Length*: `256` |
| `accrued` | `Float` | Optional | Reward units accrued on this transaction |
| `adjusted` | `Float` | Optional | Reward units adjusted on this transaction |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "categoryId": "categoryId4",
  "accrued": 156.12,
  "adjusted": 104.46,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

