
# Holding Sub Type

The subtype of an investment holding

*This model accepts additional fields of type Object.*

## Enumeration

`HoldingSubType`

## Fields

| Name |
|  --- |
| `CASH` |
| `MONEYMARKET` |

