
# Payment Network Supported by Account

This provides details required to execute a transaction against the account within the payment network

*This model accepts additional fields of type Object.*

## Structure

`PaymentNetworkSupportedByAccount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BankId` | `String` | Optional | Bank identifier used by the payment network. Typically the 9-digit routing transit number (RTN) associated with the account number at a US institution, or the 3-digit Institution (FID) and 5-digit Transit numbers for Canadian institutions, including leading zeroes | String getBankId() | setBankId(String bankId) |
| `Identifier` | `String` | Optional | The number used to identify the account within the payment network. If identifierType is ACCOUNT_NUMBER, this is the account number; if identifierType is TOKENIZED_ACCOUNT_NUMBER, this is a tokenized account number | String getIdentifier() | setIdentifier(String identifier) |
| `IdentifierType` | [`PaymentNetworkIdentifierType3`](../../doc/models/payment-network-identifier-type-3.md) | Optional | Type of identifier, ACCOUNT_NUMBER or TOKENIZED_ACCOUNT_NUMBER | PaymentNetworkIdentifierType3 getIdentifierType() | setIdentifierType(PaymentNetworkIdentifierType3 identifierType) |
| `Type` | [`PaymentNetworkType2`](../../doc/models/payment-network-type-2.md) | Optional | Type of Canadian or U.S. payment network, CA_ACSS, CA_LVTS, US_ACH, US_CHIPS, US_FEDWIRE, US_RTP | PaymentNetworkType2 getType() | setType(PaymentNetworkType2 type) |
| `TransferIn` | `Boolean` | Optional | Can transfer funds to the account using this information | Boolean getTransferIn() | setTransferIn(Boolean transferIn) |
| `TransferOut` | `Boolean` | Optional | Can transfer funds from the account using this information | Boolean getTransferOut() | setTransferOut(Boolean transferOut) |
| `SupportsRequestForPayment` | `Boolean` | Optional | Can receive Request for Payments | Boolean getSupportsRequestForPayment() | setSupportsRequestForPayment(Boolean supportsRequestForPayment) |
| `TransferLimits` | [`IncomingAndOutgoingTransferLimits2`](../../doc/models/incoming-and-outgoing-transfer-limits-2.md) | Optional | The amount limits for transfers | IncomingAndOutgoingTransferLimits2 getTransferLimits() | setTransferLimits(IncomingAndOutgoingTransferLimits2 transferLimits) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "bankId": "bankId0",
  "identifier": "identifier2",
  "identifierType": "ACCOUNT_NUMBER",
  "type": "US_CHIPS",
  "transferIn": false,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

