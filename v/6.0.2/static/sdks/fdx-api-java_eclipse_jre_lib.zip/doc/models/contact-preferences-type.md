
# Contact Preferences Type

Contact Preferences Type

*This model accepts additional fields of type Object.*

## Enumeration

`ContactPreferencesType`

## Fields

| Name |
|  --- |
| `Cell` |
| `Email` |
| `Fax` |
| `Letter` |
| `Phone` |

