
# Tax Party

Legal entity for issuer or recipient, used across all tax forms

*This model accepts additional fields of type Object.*

## Structure

`TaxParty`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Tin` | `String` | Optional | Issuer or recipient Tax Identification Number. Usually EIN for issuer and SSN for recipient | String getTin() | setTin(String tin) |
| `PartyType` | [`TaxPartyType2`](../../doc/models/tax-party-type-2.md) | Optional | Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient | TaxPartyType2 getPartyType() | setPartyType(TaxPartyType2 partyType) |
| `IndividualName` | [`IndividualName`](../../doc/models/individual-name.md) | Optional | Individual issuer or recipient name | IndividualName getIndividualName() | setIndividualName(IndividualName individualName) |
| `BusinessName` | [`BusinessName`](../../doc/models/business-name.md) | Optional | Business issuer or recipient name | BusinessName getBusinessName() | setBusinessName(BusinessName businessName) |
| `Address` | [`Address`](../../doc/models/address.md) | Optional | Issuer or recipient address | Address getAddress() | setAddress(Address address) |
| `Phone` | [`TelephoneNumberPlusExtension`](../../doc/models/telephone-number-plus-extension.md) | Optional | Issuer or recipient telephone number | TelephoneNumberPlusExtension getPhone() | setPhone(TelephoneNumberPlusExtension phone) |
| `Email` | `String` | Optional | Issuer or recipient email address. (Additional information, not part of IRS forms) | String getEmail() | setEmail(String email) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "tin": "tin6",
  "partyType": "BUSINESS",
  "individualName": {
    "first": "first0",
    "middle": "middle0",
    "last": "last4",
    "suffix": "suffix4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "businessName": {
    "name1": "name18",
    "name2": "name22",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

