
# Reward Type 2

The type of the reward balance - CASHBACK, MILES, POINTS

*This model accepts additional fields of type Object.*

## Enumeration

`RewardType2`

## Fields

| Name |
|  --- |
| `Cashback` |
| `Miles` |
| `Points` |

