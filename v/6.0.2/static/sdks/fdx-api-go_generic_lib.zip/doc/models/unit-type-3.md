
# Unit Type 3

Type of unit. One of SHARES, CURRENCY

*This model accepts additional fields of type interface{}.*

## Enumeration

`UnitType3`

## Fields

| Name |
|  --- |
| `Currency` |
| `Shares` |

