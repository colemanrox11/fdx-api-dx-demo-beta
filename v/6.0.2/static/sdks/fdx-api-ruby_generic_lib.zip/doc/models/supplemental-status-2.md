
# Supplemental Status 2

Supplemental detail of employee's employment status

*This model accepts additional fields of type Object.*

## Enumeration

`SupplementalStatus2`

## Fields

| Name |
|  --- |
| `FURLOUGHED` |
| `LEAVE` |
| `MEDICAL_LEAVE` |
| `MILITARY_LEAVE` |
| `PATERNITY_LEAVE` |
| `QUIT` |
| `RETIRED` |
| `TERMINATED` |
| `VACATION` |

