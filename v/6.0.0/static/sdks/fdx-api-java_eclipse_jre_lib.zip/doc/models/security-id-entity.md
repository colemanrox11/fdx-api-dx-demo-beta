
# Security Id Entity

Unique identifier for a security

*This model accepts additional fields of type Object.*

## Structure

`SecurityIdEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | Security identifier<br><br>**Constraints**: *Maximum Length*: `256` | String getId() | setId(String id) |
| `IdType` | [`SecurityIdType1`](../../doc/models/security-id-type-1.md) | Optional | CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN | SecurityIdType1 getIdType() | setIdType(SecurityIdType1 idType) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "id": "id2",
  "idType": "CMC",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

