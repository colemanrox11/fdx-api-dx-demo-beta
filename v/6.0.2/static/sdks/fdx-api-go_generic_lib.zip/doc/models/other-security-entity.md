
# Other Security Entity

Any other kind of security

*This model accepts additional fields of type interface{}.*

## Structure

`OtherSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TypeDescription` | `*string` | Optional | Description of other security |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "securityCategory": "Other Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "typeDescription": "typeDescription0"
}
```

