# User Consent

```java
UserConsentController userConsentController = client.getUserConsentController();
```

## Class Name

`UserConsentController`

## Methods

* [Get Consent Grant](../../doc/controllers/user-consent.md#get-consent-grant)
* [Revoke Consent Grant](../../doc/controllers/user-consent.md#revoke-consent-grant)
* [Get Consent Revocation](../../doc/controllers/user-consent.md#get-consent-revocation)


# Get Consent Grant

Get a Consent Grant

```java
CompletableFuture<ApiResponse<ConsentGrantEntity>> getConsentGrantAsync(
    final String consentId,
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consentId` | `String` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`ConsentGrantEntity`](../../doc/models/consent-grant-entity.md).

## Example Usage

```java
String consentId = "9585694d3ae58863";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

userConsentController.getConsentGrantAsync(consentId, xFapiInteractionId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "id": "9585694d3ae58863",
  "status": "ACTIVE",
  "parties": [
    {
      "name": "Seedling App",
      "type": "DATA_RECIPIENT",
      "homeUri": "https://www.seedling.com",
      "logoUri": "https://www.seedling.com/assets/seedling-logo.png",
      "registry": "FDX",
      "registeredEntityName": "Oak Tree Holdings, Inc",
      "registeredEntityId": "5493001052I34KDC1O18"
    },
    {
      "name": "Midwest Primary Bank, NA",
      "type": "DATA_PROVIDER",
      "homeUri": "https://www.midwest.com",
      "logoUri": "https://www.midwest.com/81d88112572c.jpg",
      "registry": "GLEIF",
      "registeredEntityName": "Midwest Primary Bank, NA",
      "registeredEntityId": "549300ATG070THRDJ595"
    }
  ],
  "createdTime": "2021-07-03T21:28:10.375Z",
  "expirationTime": "2021-07-03T22:28:10.374Z",
  "durationType": "ONE_TIME",
  "lookbackPeriod": 60,
  "resources": [
    {
      "resourceType": "ACCOUNT",
      "resourceId": "b14e1e714693bc00",
      "dataClusters": [
        "ACCOUNT_DETAILED",
        "TRANSACTIONS",
        "STATEMENTS"
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |


# Revoke Consent Grant

Revoke a Consent Grant

```java
CompletableFuture<ApiResponse<Void>> revokeConsentGrantAsync(
    final String consentId,
    final UUID xFapiInteractionId,
    final ConsentRevocationRequestEntity body,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consentId` | `String` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `body` | [`ConsentRevocationRequestEntity`](../../doc/models/consent-revocation-request-entity.md) | Body, Required | Reason and initiator of revocation |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

`void`

## Example Usage

```java
String consentId = "9585694d3ae58863";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
ConsentRevocationRequestEntity body = new ConsentRevocationRequestEntity.Builder()
    .reason(ConsentUpdateReason1.BUSINESS_RULE)
    .initiator(PartyType2.DATA_ACCESS_PLATFORM)
    .build();


userConsentController.revokeConsentGrantAsync(consentId, xFapiInteractionId, body, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | Forbidden, server understands the request but refuses to authorize it | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Conflict with current state of target resource | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Consent Revocation

Retrieve Consent Revocation record

```java
CompletableFuture<ApiResponse<ConsentRevocationListEntity>> getConsentRevocationAsync(
    final String consentId,
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consentId` | `String` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`ConsentRevocationListEntity`](../../doc/models/consent-revocation-list-entity.md).

## Example Usage

```java
String consentId = "9585694d3ae58863";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

userConsentController.getConsentRevocationAsync(consentId, xFapiInteractionId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

