
# Income Type 2

Type of investment income. One of CGLONG (capital gains-long term), CGSHORT (capital gains-short term), MISC

*This model accepts additional fields of type Object.*

## Enumeration

`IncomeType2`

## Fields

| Name |
|  --- |
| `Cglong` |
| `Cgshort` |
| `Misc` |

