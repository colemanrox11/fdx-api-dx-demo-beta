
# Order Duration

The duration of the order

*This model accepts additional fields of type Object.*

## Enumeration

`OrderDuration`

## Fields

| Name |
|  --- |
| `Day` |
| `Goodtillcancel` |
| `Immediate` |

