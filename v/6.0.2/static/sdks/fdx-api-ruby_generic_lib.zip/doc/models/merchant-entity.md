
# Merchant Entity

Business or person to whom bill payments can be sent for products or services

*This model accepts additional fields of type Object.*

## Structure

`MerchantEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `display_name` | `String` | Optional | User defined name for the merchant. Used by the customer to identify the merchant. Not used by the system to process payments |
| `name` | [`CustomerNameEntity`](../../doc/models/customer-name-entity.md) | Optional | Name of the merchant used to execute the payment |
| `address` | [`DeliveryAddress1`](../../doc/models/delivery-address-1.md) | Optional | Address of the merchant used to execute the payment |
| `phone` | [`TelephoneNumber`](../../doc/models/telephone-number.md) | Optional | Phone number of the merchant used to execute the payment |
| `merchant_account_ids` | `Array<String>` | Optional | Account identifier(s) the customer has with the merchant |
| `payee_id` | `String` | Optional | Persistent unique identifier for a merchant payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `status` | [`PartyStatus3`](../../doc/models/party-status-3.md) | Required | Defines the Merchant's lifecycle |
| `expires_timestamp` | `DateTime` | Optional | Describes when the entity will be automatically deleted. The entity will not go into the "DELETED" state. If this value is null or not provided, the entity will not expire automatically |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "status": "PENDING",
  "expiresTimestamp": "07/15/2021 14:46:41",
  "displayName": "displayName8",
  "name": {
    "first": "first6",
    "middle": "middle6",
    "last": "last0",
    "suffix": "suffix0",
    "prefix": "prefix8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "phone": {
    "type": "BUSINESS",
    "country": "country4",
    "number": "number8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "merchantAccountIds": [
    "merchantAccountIds6",
    "merchantAccountIds7"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

