# Event Notifications

```ruby
event_notifications_controller = client.event_notifications
```

## Class Name

`EventNotificationsController`

## Methods

* [Create Notification Subscription](../../doc/controllers/event-notifications.md#create-notification-subscription)
* [Get Notification Subscription](../../doc/controllers/event-notifications.md#get-notification-subscription)
* [Delete Notification Subscription](../../doc/controllers/event-notifications.md#delete-notification-subscription)
* [Publish Notification](../../doc/controllers/event-notifications.md#publish-notification)
* [Get Notifications](../../doc/controllers/event-notifications.md#get-notifications)


# Create Notification Subscription

Creates notification subscription entry on the server

```ruby
def create_notification_subscription(x_fapi_interaction_id,
                                     fdx_api_actor_type: nil,
                                     body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md) | Body, Optional | Notification subscription |

## Server

`Server::EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

body = NotificationSubscriptionEntity.new(
  type: NotificationType::CONSENT_REVOKED,
  category: NotificationCategory1::CONSENT,
  callback_url: 'https://abc.com/notification',
  subscriber: PartyEntity.new(
    name: 'ABC Inc',
    type: PartyType::DATA_ACCESS_PLATFORM,
    home_uri: 'https://abc.com/logo',
    logo_uri: 'https://abc.com/logo',
    registry: Registry::FDX,
    registered_entity_name: 'ABC',
    registered_entity_id: 'ABC123'
  ),
  effective_date: Date.iso8601('2021-11-24'),
  subscription_id: 'GUID-SubscriptionId1'
)

result = event_notifications_controller.create_notification_subscription(
  x_fapi_interaction_id,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "type": "CONSENT_REVOKED",
  "category": "CONSENT",
  "callbackUrl": "https://abc.com/notification",
  "subscriber": {
    "name": "ABC Inc",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "https://abc.com/logo",
    "logoUri": "https://abc.com/logo",
    "registry": "FDX",
    "registeredEntityName": "ABC",
    "registeredEntityId": "ABC123"
  },
  "effectiveDate": "2021-11-24",
  "subscriptionId": "GUID-SubscriptionId2"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Notification Subscription

Call to get notification subscription

```ruby
def get_notification_subscription(x_fapi_interaction_id,
                                  subscription_id,
                                  fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `subscription_id` | `String` | Template, Required | ID of notification subscription<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

subscription_id = 'subscriptionId0'

fdx_api_actor_type = FdxApiActorType::BATCH

result = event_notifications_controller.get_notification_subscription(
  x_fapi_interaction_id,
  subscription_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "type": "CONSENT_REVOKED",
  "category": "CONSENT",
  "callbackUrl": "https://abc.com/notification",
  "subscriber": {
    "name": "ABC Inc",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "https://abc.com/logo",
    "logoUri": "https://abc.com/logo",
    "registry": "FDX",
    "registeredEntityName": "ABC",
    "registeredEntityId": "ABC123"
  },
  "effectiveDate": "2021-11-24",
  "subscriptionId": "GUID-SubscriptionId2"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Notification Subscription

Delete a notification subscription

```ruby
def delete_notification_subscription(x_fapi_interaction_id,
                                     subscription_id,
                                     fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `subscription_id` | `String` | Template, Required | ID of notification subscription<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

subscription_id = 'subscriptionId0'

fdx_api_actor_type = FdxApiActorType::BATCH

result = event_notifications_controller.delete_notification_subscription(
  x_fapi_interaction_id,
  subscription_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Publish Notification

Publish Notification

```ruby
def publish_notification(x_fapi_interaction_id,
                         fdx_api_actor_type: nil,
                         body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`NotificationEntity`](../../doc/models/notification-entity.md) | Body, Optional | - |

## Server

`Server::EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

body = NotificationEntity.new(
  notification_id: 'req123456-GUID',
  type: NotificationType::CONSENT_REVOKED,
  sent_on: DateTimeHelper.from_rfc3339('2021-07-15T14:46:41.375Z'),
  category: NotificationCategory1::SECURITY,
  publisher: PartyEntity.new(
    name: 'XYZ Inc',
    type: PartyType::DATA_ACCESS_PLATFORM,
    home_uri: 'http://example.com',
    logo_uri: 'http://example.com',
    registry: Registry::FDX,
    registered_entity_name: 'XYZ',
    registered_entity_id: 'xyz1234'
  ),
  notification_payload: NotificationPayloadEntity2.new(
    id: 'ConsentID-1',
    id_type: NotificationPayloadIdType2::CONSENT,
    custom_fields: FiAttributeEntity.new(
      name: 'INITIATOR',
      value: 'INDIVIDUAL'
    )
  ),
  severity: NotificationSeverity2::EMERGENCY,
  priority: NotificationPriority2::HIGH,
  subscriber: PartyEntity.new(
    name: 'ABC Inc',
    type: PartyType::DATA_ACCESS_PLATFORM,
    home_uri: 'http://example.com',
    logo_uri: 'http://example.com',
    registry: Registry::FDX,
    registered_entity_name: 'ABC',
    registered_entity_id: 'ABC123'
  ),
  url: HateoasLink.new(
    href: 'https://api.xyz.com/fdx/v6/consents/ConsentID-1/revocation',
    action: HttpActionType::GET,
    rel: 'consent',
    types: [
      ContentTypes::ENUM_APPLICATIONJSON
    ]
  )
)

result = event_notifications_controller.publish_notification(
  x_fapi_interaction_id,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Notifications

Get Notifications

```ruby
def get_notifications(x_fapi_interaction_id,
                      fdx_api_actor_type: nil,
                      limit: nil,
                      offset: nil,
                      data_recipient_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `data_recipient_id` | `String` | Query, Optional | ID of Data Recipient (DR), omit for all DRs of a Data Access Platform<br><br>**Constraints**: *Maximum Length*: `256` |

## Server

`Server::EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`NotificationsEntity`](../../doc/models/notifications-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = event_notifications_controller.get_notifications(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "notifications": [
    {
      "notificationId": "0a318518-ca16-4e66-1234",
      "type": "RISK",
      "sentOn": "2021-07-15T14:46:41.375Z",
      "category": "FRAUD",
      "severity": "EMERGENCY",
      "priority": "HIGH",
      "publisher": {
        "name": "XYZ Inc",
        "type": "DATA_ACCESS_PLATFORM",
        "homeUri": "http://example.com",
        "logoUri": "http://example.com",
        "registry": "FDX",
        "registeredEntityName": "XYZ",
        "registeredEntityId": "xyz1234"
      },
      "subscriber": {
        "name": "ABC Inc",
        "type": "DATA_ACCESS_PLATFORM",
        "homeUri": "http://example.com",
        "logoUri": "http://example.com",
        "registry": "FDX",
        "registeredEntityName": "ABC",
        "registeredEntityId": "ABC123"
      },
      "notificationPayload": {
        "id": "0a318518-ca16-4e66-be76-865a632ea771",
        "idType": "ACCOUNT"
      },
      "url": {
        "href": "https://api.xyz.com/fdx/v4/notifications?dataRecipientId=FIREFLY",
        "action": "GET",
        "rel": "notification",
        "types": [
          "application/json"
        ]
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

