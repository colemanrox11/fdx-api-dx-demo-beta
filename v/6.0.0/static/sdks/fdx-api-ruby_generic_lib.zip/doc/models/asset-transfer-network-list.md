
# Asset Transfer Network List

An array of asset transfer network details for this account

*This model accepts additional fields of type Object.*

## Structure

`AssetTransferNetworkList`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_transfer_networks` | [`Array<AssetTransferNetwork>`](../../doc/models/asset-transfer-network.md) | Optional | Array of asset transfer networks |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "assetTransferNetworks": [
    {
      "identifier": "identifier0",
      "identifierType": "ACCOUNT_NUMBER",
      "institutionName": "institutionName0",
      "institutionId": "institutionId6",
      "type": "US_DTC",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

