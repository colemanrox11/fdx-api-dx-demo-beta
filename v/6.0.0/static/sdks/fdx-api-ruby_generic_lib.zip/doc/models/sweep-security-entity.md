
# Sweep Security Entity

A sweep security

*This model accepts additional fields of type Object.*

## Structure

`SweepSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `current_balance` | `Float` | Optional | Balance of funds in account |
| `available_balance` | `Float` | Optional | Balance of funds available for use |
| `balance_as_of` | `DateTime` | Optional | As-of date of balances |
| `checks` | `TrueClass \| FalseClass` | Optional | Whether or not checks can be written on the account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "balanceAsOf": "07/15/2021 14:46:41",
  "securityCategory": "Sweep Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "currentBalance": 211.94,
  "availableBalance": 78.44,
  "checks": false
}
```

