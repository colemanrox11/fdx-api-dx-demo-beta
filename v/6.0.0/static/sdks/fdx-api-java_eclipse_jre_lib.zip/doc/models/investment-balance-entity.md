
# Investment Balance Entity

A point-in-time balance of the investment account

*This model accepts additional fields of type Object.*

## Structure

`InvestmentBalanceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BalanceName` | `String` | Optional | Name of the balance | String getBalanceName() | setBalanceName(String balanceName) |
| `BalanceDescription` | `String` | Optional | Description of balance | String getBalanceDescription() | setBalanceDescription(String balanceDescription) |
| `BalanceType` | [`InvestmentBalanceType2`](../../doc/models/investment-balance-type-2.md) | Optional | AMOUNT, PERCENTAGE | InvestmentBalanceType2 getBalanceType() | setBalanceType(InvestmentBalanceType2 balanceType) |
| `BalanceValue` | `Double` | Optional | Value of named balance | Double getBalanceValue() | setBalanceValue(Double balanceValue) |
| `BalanceDate` | `LocalDate` | Optional | Date as of this balance | LocalDate getBalanceDate() | setBalanceDate(LocalDate balanceDate) |
| `Currency` | [`CurrencyEntity2`](../../doc/models/currency-entity-2.md) | Optional | Currency if different from that of account | CurrencyEntity2 getCurrency() | setCurrency(CurrencyEntity2 currency) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "balanceDate": "2021-07-15",
  "balanceName": "balanceName0",
  "balanceDescription": "balanceDescription4",
  "balanceType": "AMOUNT",
  "balanceValue": 27.2,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

