
# Coupon Mature Frequency 2

When coupons mature. One of MONTHLY, QUARTERLY,  SEMIANNUAL, ANNUAL, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`CouponMatureFrequency2`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `MONTHLY` |
| `OTHER` |
| `QUARTERLY` |
| `SEMIANNUAL` |

