
# Employee Entity

Represents an employee

*This model accepts additional fields of type Object.*

## Structure

`EmployeeEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | Array of the contact email addresses | List<String> getEmails() | setEmails(List<String> emails) |
| `Addresses` | [`List<DeliveryAddress>`](../../doc/models/delivery-address.md) | Optional | Array of the contact physical addresses | List<DeliveryAddress> getAddresses() | setAddresses(List<DeliveryAddress> addresses) |
| `Telephones` | [`List<TelephoneNumber>`](../../doc/models/telephone-number.md) | Optional | Array of the contact telephone numbers | List<TelephoneNumber> getTelephones() | setTelephones(List<TelephoneNumber> telephones) |
| `DateOfBirth` | `LocalDate` | Optional | The person's date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `TaxId` | `String` | Optional | Country specific Tax Id associated with this customer (SIN or NAS in Canada, SSN or TIN in US, etc.) | String getTaxId() | setTaxId(String taxId) |
| `TaxIdCountry` | [`Iso3166CountryCode`](../../doc/models/iso-3166-country-code.md) | Optional | Country originating the Customer's taxId element | Iso3166CountryCode getTaxIdCountry() | setTaxIdCountry(Iso3166CountryCode taxIdCountry) |
| `GovernmentId` | `String` | Optional | A federal (such as passport) or state (such as driver's license) issued identifier | String getGovernmentId() | setGovernmentId(String governmentId) |
| `EmployeeId` | `String` | Optional | Provider's long-term persistent id for the employee<br><br>**Constraints**: *Maximum Length*: `256` | String getEmployeeId() | setEmployeeId(String employeeId) |
| `Name` | [`IndividualName`](../../doc/models/individual-name.md) | Required | Employee's full name | IndividualName getName() | setName(IndividualName name) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dateOfBirth": "2021-07-15",
  "name": {
    "first": "first6",
    "middle": "middle6",
    "last": "last0",
    "suffix": "suffix0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "emails": [
    "emails7",
    "emails8",
    "emails9"
  ],
  "addresses": [
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "telephones": [
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "taxId": "taxId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

