
# Balance Type 2

ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance)

*This model accepts additional fields of type Object.*

## Enumeration

`BalanceType2`

## Fields

| Name |
|  --- |
| `Asset` |
| `Liability` |

