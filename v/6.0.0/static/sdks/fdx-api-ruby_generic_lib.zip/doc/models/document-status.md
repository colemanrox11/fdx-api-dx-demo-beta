
# Document Status

Defines the status of a document

*This model accepts additional fields of type Object.*

## Enumeration

`DocumentStatus`

## Fields

| Name |
|  --- |
| `AVAILABLE` |
| `PROCESSING` |
| `FAILED` |

