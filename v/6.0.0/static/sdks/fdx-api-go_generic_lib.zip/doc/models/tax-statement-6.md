
# Tax Statement 6

The full data contents of the document and all its contained forms including the indexing metadata values

*This model accepts additional fields of type interface{}.*

## Structure

`TaxStatement6`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TaxYear` | `*int` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `TaxStatementId` | `*string` | Optional | Long-term persistent id for the tax statement. Depending upon the data provider, this may be the same id as the id on the enclosed tax form(s), or this may be a different id<br><br>**Constraints**: *Maximum Length*: `256` |
| `Issuer` | [`*models.TaxParty6`](../../doc/models/tax-party-6.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmittted on TaxStatement, 'JSON' data type responses if it is the same on all included tax forms |
| `Recipient` | [`*models.TaxParty7`](../../doc/models/tax-party-7.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmittted on TaxStatement, 'JSON' data type responses if it is the same on all included tax forms |
| `TaxDataType` | [`*models.TypeDataType2`](../../doc/models/type-data-type-2.md) | Optional | Whether this `application/json` tax form response contains data in `forms` property (as 'JSON' format) or `pdf` property (as 'BASE64_PDF' format) |
| `Forms` | [`[]models.TaxData`](../../doc/models/tax-data.md) | Optional | The list of data contents for all included tax forms, response should include one of `forms` or `pdf` |
| `Pdf` | `*[]byte` | Optional | PDF version of the tax statement containing all form pages, binary encoded as Base64, response should include one of `pdf` or `forms` |
| `Attributes` | [`[]models.FiAttributeEntity`](../../doc/models/fi-attribute-entity.md) | Optional | Additional tax statement attributes that the provider wishes to include |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxStatementId": "taxStatementId0",
  "issuer": {
    "tin": "tin0",
    "partyType": "BUSINESS",
    "individualName": {
      "first": "first0",
      "middle": "middle0",
      "last": "last4",
      "suffix": "suffix4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "businessName": {
      "name1": "name18",
      "name2": "name22",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "address": {
      "line1": "line18",
      "line2": "line20",
      "line3": "line38",
      "city": "city6",
      "region": "region2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "recipient": {
    "tin": "tin2",
    "partyType": "BUSINESS",
    "individualName": {
      "first": "first0",
      "middle": "middle0",
      "last": "last4",
      "suffix": "suffix4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "businessName": {
      "name1": "name18",
      "name2": "name22",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "address": {
      "line1": "line18",
      "line2": "line20",
      "line3": "line38",
      "city": "city6",
      "region": "region2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "taxDataType": "BASE64_PDF",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

