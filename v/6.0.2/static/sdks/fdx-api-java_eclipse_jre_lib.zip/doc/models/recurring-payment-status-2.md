
# Recurring Payment Status 2

Defines the status of the recurring payment

*This model accepts additional fields of type Object.*

## Enumeration

`RecurringPaymentStatus2`

## Fields

| Name |
|  --- |
| `Cancelled` |
| `Failed` |
| `Processed` |
| `Scheduled` |

