
# Reward Category Entity

Reward category used to calculate rewards on a transaction

*This model accepts additional fields of type Object.*

## Structure

`RewardCategoryEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RewardProgramId` | `String` | Optional | Long term persistent identity of the reward program<br><br>**Constraints**: *Maximum Length*: `256` | String getRewardProgramId() | setRewardProgramId(String rewardProgramId) |
| `CategoryName` | `String` | Optional | Reward category name | String getCategoryName() | setCategoryName(String categoryName) |
| `CategoryId` | `String` | Optional | Long term persistent identity of the reward category<br><br>**Constraints**: *Maximum Length*: `256` | String getCategoryId() | setCategoryId(String categoryId) |
| `Multiplier` | `Double` | Optional | Factor used to calculate rewards accrued<br><br>**Constraints**: `>= 0` | Double getMultiplier() | setMultiplier(Double multiplier) |
| `Description` | `String` | Optional | Description of the reward category | String getDescription() | setDescription(String description) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "rewardProgramId": "rewardProgramId0",
  "categoryName": "categoryName4",
  "categoryId": "categoryId6",
  "multiplier": 61.1,
  "description": "description6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

