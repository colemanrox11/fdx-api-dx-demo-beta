
# Asset Transfer Type 2

Type of asset transfer

*This model accepts additional fields of type Object.*

## Enumeration

`AssetTransferType2`

## Fields

| Name |
|  --- |
| `CA_ATON` |
| `US_ACATS` |
| `US_DTC` |

