
# Order Type 2

Type of order. One of BUY, SELL, BUYTOCOVER, BUYTOOPEN, SELLTOCOVER, SELLTOOPEN,  SELLSHORT, SELLCLOSE

*This model accepts additional fields of type Object.*

## Enumeration

`OrderType2`

## Fields

| Name |
|  --- |
| `Buy` |
| `Buytocover` |
| `Buytoopen` |
| `Sell` |
| `Sellclose` |
| `Sellshort` |
| `Selltocover` |
| `Selltoopen` |

