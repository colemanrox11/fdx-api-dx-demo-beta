
# Reward Program Membership Entity

Details of a single membership in a reward programs

*This model accepts additional fields of type Object.*

## Structure

`RewardProgramMembershipEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountIds` | `List<String>` | Optional | accountIds associated to the reward program<br><br>**Constraints**: *Unique Items Required*, *Maximum Length*: `256` | List<String> getAccountIds() | setAccountIds(List<String> accountIds) |
| `CustomerId` | `String` | Optional | Long-term persistent identity of the associated Customer<br><br>**Constraints**: *Maximum Length*: `256` | String getCustomerId() | setCustomerId(String customerId) |
| `MemberId` | `String` | Optional | Long term persistent identity of the program member<br><br>**Constraints**: *Maximum Length*: `256` | String getMemberId() | setMemberId(String memberId) |
| `MemberNumber` | `String` | Optional | Reward program membership number | String getMemberNumber() | setMemberNumber(String memberNumber) |
| `MemberTier` | `String` | Optional | If the reward program is tiered, member's current tier | String getMemberTier() | setMemberTier(String memberTier) |
| `BusinessOrConsumer` | [`BusinessOrConsumerType1`](../../doc/models/business-or-consumer-type-1.md) | Optional | BUSINESS or CONSUMER membership | BusinessOrConsumerType1 getBusinessOrConsumer() | setBusinessOrConsumer(BusinessOrConsumerType1 businessOrConsumer) |
| `Balances` | [`List<RewardBalanceEntity>`](../../doc/models/reward-balance-entity.md) | Optional | Array of balances<br><br>**Constraints**: *Minimum Items*: `1` | List<RewardBalanceEntity> getBalances() | setBalances(List<RewardBalanceEntity> balances) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountIds": [
    "accountIds1"
  ],
  "customerId": "customerId0",
  "memberId": "memberId6",
  "memberNumber": "memberNumber0",
  "memberTier": "memberTier0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

