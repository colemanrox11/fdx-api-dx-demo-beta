
# Consent Grant Entity

Record of user consent

*This model accepts additional fields of type Object.*

## Structure

`ConsentGrantEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | The persistent identifier of the consent<br><br>**Constraints**: *Maximum Length*: `256` | String getId() | setId(String id) |
| `Status` | [`ConsentGrantStatus3`](../../doc/models/consent-grant-status-3.md) | Optional | The current status of the consent | ConsentGrantStatus3 getStatus() | setStatus(ConsentGrantStatus3 status) |
| `Parties` | [`List<PartyEntity>`](../../doc/models/party-entity.md) | Optional | The non-end user parties participating in the Consent Grant | List<PartyEntity> getParties() | setParties(List<PartyEntity> parties) |
| `CreatedTime` | `LocalDateTime` | Optional | When the consent was initially granted | LocalDateTime getCreatedTime() | setCreatedTime(LocalDateTime createdTime) |
| `ExpirationTime` | `LocalDateTime` | Optional | When the consent grant will become expired | LocalDateTime getExpirationTime() | setExpirationTime(LocalDateTime expirationTime) |
| `UpdatedTime` | `LocalDateTime` | Optional | When the consent grant was updated | LocalDateTime getUpdatedTime() | setUpdatedTime(LocalDateTime updatedTime) |
| `DurationType` | [`ConsentDurationType`](../../doc/models/consent-duration-type.md) | Optional | The type of duration of the consent | ConsentDurationType getDurationType() | setDurationType(ConsentDurationType durationType) |
| `DurationPeriod` | `Integer` | Optional | The consent duration in days from day of original grant | Integer getDurationPeriod() | setDurationPeriod(Integer durationPeriod) |
| `LookbackPeriod` | `Integer` | Optional | Period, in days, for which historical data may be requested; measured from request time, not grant time | Integer getLookbackPeriod() | setLookbackPeriod(Integer lookbackPeriod) |
| `Resources` | [`List<ConsentGrantResourceEntity>`](../../doc/models/consent-grant-resource-entity.md) | Optional | The permissioned resource entities | List<ConsentGrantResourceEntity> getResources() | setResources(List<ConsentGrantResourceEntity> resources) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links for related Consent Grant records | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "createdTime": "07/15/2021 14:46:41",
  "expirationTime": "07/15/2021 14:46:41",
  "updatedTime": "07/15/2021 14:46:41",
  "id": "id6",
  "status": "ACTIVE",
  "parties": [
    {
      "name": "name2",
      "type": "MERCHANT",
      "homeUri": "homeUri4",
      "logoUri": "logoUri0",
      "registry": "FDX",
      "registeredEntityName": "registeredEntityName0",
      "registeredEntityId": "registeredEntityId8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

