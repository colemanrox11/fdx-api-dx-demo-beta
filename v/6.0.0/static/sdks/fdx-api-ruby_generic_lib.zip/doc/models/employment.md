
# Employment

Provides a person's employment details

*This model accepts additional fields of type Object.*

## Structure

`Employment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `employer` | [`EmployerEntity1`](../../doc/models/employer-entity-1.md) | Required | The employer for the job/position |
| `job_title` | `String` | Optional | The title of the job/position |
| `original_hire_date` | `Date` | Optional | The date when employee joined for the first time. |
| `most_recent_hire_date` | `Date` | Optional | The date when employee re-joined most recently. |
| `end_date` | `Date` | Optional | The employment end date |
| `status` | [`ActiveInactiveStatus2`](../../doc/models/active-inactive-status-2.md) | Required | The employee's employment status, ACTIVE or INACTIVE |
| `supplemental_status` | [`SupplementalStatus2`](../../doc/models/supplemental-status-2.md) | Optional | Supplemental detail of employee's employment status |
| `type` | [`EmploymentType2`](../../doc/models/employment-type-2.md) | Optional | The employee's employment type, CONTRACTED, FULL-TIME, OTHER, PART-TIME, SEASONAL, TEMPORARY |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "employer": {
    "employerId": "employerId2",
    "name": {
      "name1": "name10",
      "name2": "name24",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "dbas": [
      "dbas1"
    ],
    "taxId": "taxId8",
    "taxIdCountry": "SK",
    "contacts": {
      "emails": [
        "emails7",
        "emails8",
        "emails9"
      ],
      "addresses": [
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "telephones": [
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "originalHireDate": "2021-07-15",
  "mostRecentHireDate": "2021-07-15",
  "endDate": "2021-07-15",
  "status": "ACTIVE",
  "jobTitle": "jobTitle0",
  "supplementalStatus": "TERMINATED",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

