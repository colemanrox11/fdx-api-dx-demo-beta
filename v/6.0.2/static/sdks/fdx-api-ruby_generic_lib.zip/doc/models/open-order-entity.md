
# Open Order Entity

An open investment transaction order

*This model accepts additional fields of type Object.*

## Structure

`OpenOrderEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `order_id` | `String` | Optional | Long-term persistent identity of the order. Id for this order transaction<br><br>**Constraints**: *Maximum Length*: `256` |
| `security_id` | `String` | Optional | Unique identifier of security |
| `security_id_type` | [`SecurityIdType1`](../../doc/models/security-id-type-1.md) | Optional | CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN |
| `symbol` | `String` | Optional | Market symbol |
| `description` | `String` | Optional | Description of order |
| `units` | `Float` | Optional | Number of units (shares or bonds etc.) |
| `order_type` | [`OrderType2`](../../doc/models/order-type-2.md) | Optional | Type of order. One of BUY, SELL, BUYTOCOVER, BUYTOOPEN, SELLTOCOVER, SELLTOOPEN,  SELLSHORT, SELLCLOSE |
| `order_date` | `Date` | Optional | Order date |
| `unit_price` | `Float` | Optional | Unit price |
| `unit_type` | [`UnitType3`](../../doc/models/unit-type-3.md) | Optional | Type of unit. One of SHARES, CURRENCY |
| `order_duration` | [`OrderDuration2`](../../doc/models/order-duration-2.md) | Optional | This order is good for DAY, GOODTILLCANCEL, IMMEDIATE |
| `sub_account` | [`SubAccountType4`](../../doc/models/sub-account-type-4.md) | Optional | CASH, MARGIN, SHORT, OTHER |
| `limit_price` | `Float` | Optional | Limit price |
| `stop_price` | `Float` | Optional | Stop price |
| `inv_401_k_source` | [`Investment401KSourceType1`](../../doc/models/investment-401-k-source-type-1.md) | Optional | For 401(k) accounts, source of money for this order. PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST. Default if not present is OTHERNONVEST |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "orderDate": "2021-07-15",
  "orderId": "orderId6",
  "securityId": "securityId8",
  "securityIdType": "SEDOL",
  "symbol": "symbol2",
  "description": "description4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

