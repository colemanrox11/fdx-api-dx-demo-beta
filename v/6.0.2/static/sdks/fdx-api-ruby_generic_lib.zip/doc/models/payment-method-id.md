
# Payment Method Id

FI's unique identifier for the method of payment

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_method_id` | `String` | Optional | Unique identifier of the payment method |
| `external_local_instrument_1_code` | `String` | Optional | Unique identifier code of the payment method rail as documented<br>internally to the FI. This is aligned with ISO 20022 pain.001,<br>transaction level |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "paymentMethodId": "paymentMethodId8",
  "externalLocalInstrument1Code": "externalLocalInstrument1Code4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

