
# Call Type 2

Type of next call. One of CALL, PUT, PREFUND, MATURITY

*This model accepts additional fields of type Object.*

## Enumeration

`CallType2`

## Fields

| Name |
|  --- |
| `CALL` |
| `MATURITY` |
| `PREFUND` |
| `PUT` |

