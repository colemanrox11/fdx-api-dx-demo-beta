
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| Environment | `Environment` | The API environment. <br> **Default: `Environment.Production`** |
| Timeout | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| HttpClientConfiguration | [`Action<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Action delegate that configures the HTTP client by using the HttpClientConfiguration.Builder for customizing API call settings.<br>*Default*: `new HttpClient()` |
| LogBuilder | [`LogBuilder`](../doc/log-builder.md) | Represents the logging configuration builder for API calls |
| BearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| TaxBasicAuthCredentials | [`TaxBasicAuthCredentials`](auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |

The API client can be initialized as follows:

```csharp
using FdxApi.Standard;
using FdxApi.Standard.Authentication;
using Microsoft.Extensions.Logging;

FdxApiClient client = new FdxApiClient.Builder()
    .BearerAuthCredentials(
        new BearerAuthModel.Builder(
            "AccessToken"
        )
        .Build())
    .TaxBasicAuthCredentials(
        new TaxBasicAuthModel.Builder(
            "Username",
            "Password"
        )
        .Build())
    .Environment(FdxApi.Standard.Environment.Production)
    .LoggingConfig(config => config
        .LogLevel(LogLevel.Information)
        .RequestConfig(reqConfig => reqConfig.Body(true))
        .ResponseConfig(respConfig => respConfig.Headers(true))
    )
    .Build();
```

## FDX APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| UserConsentController | Gets UserConsentController controller. |
| AccountInformationController | Gets AccountInformationController controller. |
| AccountStatementsController | Gets AccountStatementsController controller. |
| AccountTransactionsController | Gets AccountTransactionsController controller. |
| MoneyMovementController | Gets MoneyMovementController controller. |
| PersonalInformationController | Gets PersonalInformationController controller. |
| RewardProgramCategoriesController | Gets RewardProgramCategoriesController controller. |
| RewardProgramInformationController | Gets RewardProgramInformationController controller. |
| EventNotificationsController | Gets EventNotificationsController controller. |
| FraudNotificationController | Gets FraudNotificationController controller. |
| MetaController | Gets MetaController controller. |
| InternalTransfersController | Gets InternalTransfersController controller. |
| PayeeManagementController | Gets PayeeManagementController controller. |
| PaymentInitiationPartiesController | Gets PaymentInitiationPartiesController controller. |
| PaymentsController | Gets PaymentsController controller. |
| RecurringPaymentsController | Gets RecurringPaymentsController controller. |
| PayrollInformationController | Gets PayrollInformationController controller. |
| RecipientsController | Gets RecipientsController controller. |
| SubmitTaxFormsController | Gets SubmitTaxFormsController controller. |
| TaxFormsController | Gets TaxFormsController controller. |
| ResourceInformationController | Gets ResourceInformationController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](../doc/http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |
| BearerAuthCredentials | Gets the credentials to use with BearerAuth. | [`IBearerAuthCredentials`](auth/oauth-2-bearer-token.md) |
| TaxBasicAuthCredentials | Gets the credentials to use with TaxBasicAuth. | [`ITaxBasicAuthCredentials`](auth/basic-authentication.md) |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Consent)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the FDX APIClient using the values provided for the builder. | `Builder` |

## FDX APIClient Builder Class

Class to build instances of FDX APIClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](../doc/http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |
| `BearerAuthCredentials(Action<BearerAuthModel.Builder> action)` | Sets credentials for BearerAuth. | `Builder` |
| `TaxBasicAuthCredentials(Action<TaxBasicAuthModel.Builder> action)` | Sets credentials for TaxBasicAuth. | `Builder` |

