
# Sweep Security Entity

A sweep security

*This model accepts additional fields of type interface{}.*

## Structure

`SweepSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CurrentBalance` | `*float64` | Optional | Balance of funds in account |
| `AvailableBalance` | `*float64` | Optional | Balance of funds available for use |
| `BalanceAsOf` | `*time.Time` | Optional | As-of date of balances |
| `Checks` | `*bool` | Optional | Whether or not checks can be written on the account |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "balanceAsOf": "07/15/2021 14:46:41",
  "securityCategory": "Sweep Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "currentBalance": 211.94,
  "availableBalance": 78.44,
  "checks": false
}
```

