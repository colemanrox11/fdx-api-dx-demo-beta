# Recipients

Manage recipients

```ruby
recipients_controller = client.recipients
```

## Class Name

`RecipientsController`

## Methods

* [Create Recipient](../../doc/controllers/recipients.md#create-recipient)
* [Get Recipient](../../doc/controllers/recipients.md#get-recipient)
* [Update Recipient](../../doc/controllers/recipients.md#update-recipient)
* [Delete Recipient](../../doc/controllers/recipients.md#delete-recipient)
* [Get Registry Recipients](../../doc/controllers/recipients.md#get-registry-recipients)
* [Get Registry Recipient](../../doc/controllers/recipients.md#get-registry-recipient)


# Create Recipient

Request to Register Recipient by Creating a Recipient Record

```ruby
def create_recipient(x_fapi_interaction_id,
                     fdx_api_actor_type: nil,
                     body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`RecipientRequest`](../../doc/models/recipient-request.md) | Body, Optional | - |

## Server

`Server::RECIPIENTREGISTRATION`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`RecipientProvider`](../../doc/models/recipient-provider.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

body = RecipientRequest.new(
  client_name: 'My Example Client',
  redirect_uris: [
    'https://partner.example/callback'
  ],
  description: 'Recipient Application servicing financial use case requiring permissioned data sharing',
  logo_uri: 'https://client.example.org/logo.png',
  client_uri: 'https://example.net/',
  contacts: [
    'support@example.net'
  ],
  scope: 'ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS',
  duration_type: [
    ConsentDurationType::TIME_BOUND
  ],
  duration_period: 365,
  lookback_period: 365,
  registry_references: [
    RegistryReference.new(
      registered_entity_name: 'Official recipient name',
      registered_entity_id: '4HCHXIURY78NNH6JH',
      registry: Registry::GLEIF
    )
  ],
  intermediaries: [
    Intermediary.new(
      name: 'Data Access Platform Name',
      description: 'Data Access Platform specializing in servicing permissioned data sharing for Data Recipients',
      uri: 'https://partner.example/',
      logo_uri: 'https://partner.example/logo.png',
      contacts: [
        'support@partner.com'
      ],
      registry_references: [
        RegistryReference.new(
          registered_entity_name: 'Data Access Platform listed company Name',
          registered_entity_id: 'JJH7776512TGMEJSG',
          registry: Registry::FDX
        )
      ]
    ),
    Intermediary.new(
      name: 'Digital Service Provider Name',
      description: 'Digital Service Provider to the Recipient',
      uri: 'https://sub-partner-one.example/',
      logo_uri: 'https://sub-partner-one.example/logo.png',
      contacts: [
        'support@sub-partner-one.com'
      ],
      registry_references: [
        RegistryReference.new(
          registered_entity_name: 'Service Provider listed company Name',
          registered_entity_id: '9LUQNDG778LI9D1',
          registry: Registry::GLEIF
        )
      ]
    )
  ]
)

result = recipients_controller.create_recipient(
  x_fapi_interaction_id,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "client_id": "V8tvEkZWhDAdxSaKGUJZ",
  "client_secret": "SpsuwZIxnp8bBEhp5sk1EKiIKTZ4X4DKU",
  "grant_types": [
    "authorization_code",
    "refresh_token"
  ],
  "token_endpoint_auth_method": "private_key_jwt",
  "registration_client_uri": "https://server.example.com/register/V8tvEkZWhDAdxSaKGUJZ",
  "status": "Approved",
  "registration_access_token": "V8tvEkZWhDAdxSaKGUJZ",
  "client_name": "My Example Client",
  "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
  "redirect_uris": [
    "https://partner.example/callback"
  ],
  "logo_uri": "https://client.example.org/logo.png",
  "client_uri": "https://example.net/",
  "contacts": [
    "support@example.net"
  ],
  "scope": "ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS",
  "duration_type": [
    "TIME_BOUND"
  ],
  "duration_period": 365,
  "lookback_period": 365,
  "registry_references": [
    {
      "registered_entity_name": "Official recipient name",
      "registered_entity_id": "4HCHXIURY78NNH6JH",
      "registry": "GLEIF"
    }
  ],
  "intermediaries": [
    {
      "name": "Data Access Platform Name",
      "description": "Data Access Platform specializing in servicing permissioned data sharing for Data Recipients",
      "uri": "https://partner.example/",
      "logo_uri": "https://partner.example/logo.png",
      "contacts": [
        "support@partner.com"
      ],
      "registry_references": [
        {
          "registered_entity_name": "Data Access Platform listed company Name",
          "registered_entity_id": "JJH7776512TGMEJSG",
          "registry": "FDX"
        }
      ]
    },
    {
      "name": "Digital Service Provider Name",
      "description": "Digital Service Provider to the Recipient",
      "uri": "https://sub-partner-one.example/",
      "logo_uri": "https://sub-partner-one.example/logo.png",
      "contacts": [
        "support@sub-partner-one.com"
      ],
      "registry_references": [
        {
          "registered_entity_name": "Service Provider listed company Name",
          "registered_entity_id": "9LUQNDG778LI9D1",
          "registry": "GLEIF"
        }
      ]
    }
  ]
}
```


# Get Recipient

Get a specific recipient data identified with clientId

```ruby
def get_recipient(x_fapi_interaction_id,
                  client_id,
                  fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `client_id` | `String` | Template, Required | Client Identifier. Uniquely identifies a Client<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::RECIPIENTREGISTRATION`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`RecipientProvider`](../../doc/models/recipient-provider.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

client_id = 'clientId6'

fdx_api_actor_type = FdxApiActorType::BATCH

result = recipients_controller.get_recipient(
  x_fapi_interaction_id,
  client_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Update Recipient

Update data for a specific recipient identified with clientId

```ruby
def update_recipient(x_fapi_interaction_id,
                     client_id,
                     fdx_api_actor_type: nil,
                     body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `client_id` | `String` | Template, Required | Client Identifier. Uniquely identifies a Client<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`RecipientRequest`](../../doc/models/recipient-request.md) | Body, Optional | - |

## Server

`Server::RECIPIENTREGISTRATION`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`RecipientProvider`](../../doc/models/recipient-provider.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

client_id = 'clientId6'

body = RecipientRequest.new(
  client_name: 'My Example Client',
  redirect_uris: [
    'https://partner.example/callback'
  ],
  description: 'Recipient Application servicing financial use case requiring permissioned data sharing',
  logo_uri: 'https://client.example.org/logo.png',
  client_uri: 'https://example.net/',
  contacts: [
    'support@example.net'
  ],
  scope: 'ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS',
  duration_type: [
    ConsentDurationType::TIME_BOUND
  ],
  duration_period: 365,
  lookback_period: 365,
  registry_references: [
    RegistryReference.new(
      registered_entity_name: 'Official recipient name',
      registered_entity_id: '4HCHXIURY78NNH6JH',
      registry: Registry::GLEIF
    )
  ],
  intermediaries: [
    Intermediary.new(
      name: 'Data Access Platform Name',
      description: 'Data Access Platform specializing in servicing permissioned data sharing for Data Recipients',
      uri: 'https://partner.example/',
      logo_uri: 'https://partner.example/logo.png',
      contacts: [
        'support@partner.com'
      ],
      registry_references: [
        RegistryReference.new(
          registered_entity_name: 'Data Access Platform listed company Name',
          registered_entity_id: 'JJH7776512TGMEJSG',
          registry: Registry::FDX
        )
      ]
    ),
    Intermediary.new(
      name: 'Digital Service Provider Name',
      description: 'Digital Service Provider to the Recipient',
      uri: 'https://sub-partner-one.example/',
      logo_uri: 'https://sub-partner-one.example/logo.png',
      contacts: [
        'support@sub-partner-one.com'
      ],
      registry_references: [
        RegistryReference.new(
          registered_entity_name: 'Service Provider listed company Name',
          registered_entity_id: '9LUQNDG778LI9D1',
          registry: Registry::GLEIF
        )
      ]
    )
  ]
)

result = recipients_controller.update_recipient(
  x_fapi_interaction_id,
  client_id,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Delete Recipient

Delete data for a specific recipient identified with clientId

```ruby
def delete_recipient(x_fapi_interaction_id,
                     client_id,
                     fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `client_id` | `String` | Template, Required | Client Identifier. Uniquely identifies a Client<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::RECIPIENTREGISTRATION`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

client_id = 'clientId6'

fdx_api_actor_type = FdxApiActorType::BATCH

result = recipients_controller.delete_recipient(
  x_fapi_interaction_id,
  client_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get Registry Recipients

Get recipients

```ruby
def get_registry_recipients(x_fapi_interaction_id,
                            fdx_api_actor_type: nil,
                            offset: nil,
                            limit: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server::REGISTRY`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`RecipientRecordsAtEcosystemRegistry`](../../doc/models/recipient-records-at-ecosystem-registry.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = recipients_controller.get_registry_recipients(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "nextoffset",
    "prevOffset": "prevoffset",
    "total": 5000
  },
  "links": {
    "next": {
      "href": "/recipients?offset=nextoffset"
    },
    "prev": {
      "href": "/recipients?offset=prevoffset"
    }
  },
  "recipients": [
    {
      "recipient_id": "12345",
      "client_name": "My Example Client",
      "redirect_uris": [
        "https://partner.example/callback"
      ],
      "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
      "logo_uri": "https://client.example1.org/logo.png",
      "client_uri": "https://example1.net/",
      "contacts": [
        "support@example1.net"
      ],
      "scope": "ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS",
      "duration_type": [
        "TIME_BOUND"
      ],
      "duration_period": 365,
      "lookback_period": 365,
      "registry_references": [
        {
          "registered_entity_name": "Official recipient name",
          "registered_entity_id": "4HCHXIURY78NNH6JH",
          "registry": "GLEIF"
        }
      ]
    },
    {
      "recipient_id": "23456",
      "client_name": "Another Example Client",
      "redirect_uris": [
        "https://partner.example/callback"
      ],
      "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
      "logo_uri": "https://client.example2.org/logo.png",
      "client_uri": "https://example2.net/",
      "contacts": [
        "support@example2.net"
      ],
      "scope": "ACCOUNT_DETAILED INVESTMENTS",
      "duration_type": [
        "TIME_BOUND"
      ],
      "duration_period": 365,
      "lookback_period": 365,
      "registry_references": [
        {
          "registered_entity_name": "Official recipient name",
          "registered_entity_id": "8XKSJGEU2465KSOGI",
          "registry": "GLEIF"
        }
      ]
    }
  ]
}
```


# Get Registry Recipient

Get a specific recipient

```ruby
def get_registry_recipient(x_fapi_interaction_id,
                           recipient_id,
                           fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `recipient_id` | `String` | Template, Required | Recipient Identifier. Uniquely identifies a Recipient<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::REGISTRY`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`RecipientRecordAtEcosystemRegistry`](../../doc/models/recipient-record-at-ecosystem-registry.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

recipient_id = 'recipientId4'

fdx_api_actor_type = FdxApiActorType::BATCH

result = recipients_controller.get_registry_recipient(
  x_fapi_interaction_id,
  recipient_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "recipient_id": "12345",
  "client_name": "My Example Client",
  "redirect_uris": [
    "https://partner.example/callback"
  ],
  "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
  "logo_uri": "https://client.example.org/logo.png",
  "client_uri": "https://example.net/",
  "contacts": [
    "support@example.net"
  ],
  "scope": "ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS",
  "duration_type": [
    "TIME_BOUND"
  ],
  "duration_period": 365,
  "lookback_period": 365,
  "registry_references": [
    {
      "registered_entity_name": "Official recipient name",
      "registered_entity_id": "4HCHXIURY78NNH6JH",
      "registry": "GLEIF"
    }
  ]
}
```

