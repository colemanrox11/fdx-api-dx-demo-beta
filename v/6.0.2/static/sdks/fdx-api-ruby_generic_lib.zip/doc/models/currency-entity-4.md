
# Currency Entity 4

Account currency

*This model accepts additional fields of type Object.*

## Structure

`CurrencyEntity4`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency_rate` | `Float` | Optional | Currency rate between original and converted currency |
| `currency_code` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | ISO 4217 currency code |
| `original_currency_code` | [`Iso4217CurrencyCode1`](../../doc/models/iso-4217-currency-code-1.md) | Optional | Original ISO 4217 currency code |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "currencyRate": 245.5,
  "currencyCode": "GIP",
  "originalCurrencyCode": "XXX",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

