
# Iso 93622022 Business Identifier Code Entity

[ISO 9362:2022](https://www.swift.com/standards/data-standards/bic-business-identifier-code)
Business Identifier Code for Financial Institutions
(see [whitepaper](https://www.swift.com/swift-resource/14256/download)), supercedes ISO 9362:2014

*This model accepts additional fields of type Object.*

## Structure

`Iso93622022BusinessIdentifierCodeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_id_code_2022` | `String` | Optional | ISO 9362:2022 business identifier code of the financial institution<br><br>**Constraints**: *Maximum Length*: `11` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "businessIdCode2022": "businessIdCode20228",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

