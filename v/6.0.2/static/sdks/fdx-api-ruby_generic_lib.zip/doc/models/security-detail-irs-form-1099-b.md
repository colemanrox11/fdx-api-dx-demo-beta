
# Security Detail Irs Form 1099 B

Tax information for a single security transaction

*This model accepts additional fields of type Object.*

## Structure

`SecurityDetailIrsForm1099B`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `checkbox_on_form_8949` | `String` | Optional | Applicable checkbox on Form 8949 |
| `security_name` | `String` | Optional | Security name |
| `number_of_shares` | `Float` | Optional | Number of shares |
| `sale_description` | `String` | Optional | Box 1a, Description of property |
| `date_acquired` | `Date` | Optional | Box 1b, Date acquired |
| `various_dates_acquired` | `TrueClass \| FalseClass` | Optional | Box 1b, Date acquired Various |
| `date_of_sale` | `Date` | Optional | Box 1c, Date sold or disposed |
| `sales_price` | `Float` | Optional | Box 1d, Proceeds (not price per share) |
| `accrued_market_discount` | `Float` | Optional | Box 1f, Accrued market discount |
| `adjustment_codes` | [`Array<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Other adjustments (code and amount) |
| `cost_basis` | `Float` | Optional | Box 1e, Cost or other basis |
| `corrected_cost_basis` | `Float` | Optional | Corrected cost basis. May be supplied in lieu of adjustmentCode code B. If both adjustmentCodes and correctedCostBasis are supplied, costBasis plus adjustmentCode B should equal correctedCostBasis |
| `wash_sale_loss_disallowed` | `Float` | Optional | Box 1g, Wash sale loss disallowed |
| `long_or_short` | [`PositionType`](../../doc/models/position-type.md) | Optional | Box 2, LONG or SHORT |
| `ordinary` | `TrueClass \| FalseClass` | Optional | Box 2, Ordinary |
| `collectible` | `TrueClass \| FalseClass` | Optional | Box 3, Collectibles |
| `qof` | `TrueClass \| FalseClass` | Optional | Box 3, Qualified Opportunity Fund (QOF) |
| `federal_tax_withheld` | `Float` | Optional | Box 4, Federal income tax withheld |
| `noncovered_security` | `TrueClass \| FalseClass` | Optional | Box 5, Noncovered security |
| `gross_or_net` | [`SaleProceedsType2`](../../doc/models/sale-proceeds-type-2.md) | Optional | Box 6, Reported to IRS: GROSS or NET |
| `loss_not_allowed` | `TrueClass \| FalseClass` | Optional | Box 7, Loss not allowed based on proceeds |
| `basis_reported` | `TrueClass \| FalseClass` | Optional | Box 12, Basis reported to IRS |
| `state_and_local` | [`Array<StateAndLocalTaxWithholding>`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 14-16, State and Local tax withholding |
| `cusip` | `String` | Optional | CUSIP number |
| `foreign_account_tax_compliance` | `TrueClass \| FalseClass` | Optional | Foreign account tax compliance |
| `expired_option` | [`ExpiredOptionType2`](../../doc/models/expired-option-type-2.md) | Optional | To indicate gain or loss resulted from option expiration. If salesPrice (1d, proceeds) is zero, use PURCHASED. If costBasis (1e) is zero, use GRANTED |
| `investment_sale_type` | [`InvestmentSaleType`](../../doc/models/investment-sale-type.md) | Optional | Type of investment sale |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "dateAcquired": "2021-07-15",
  "dateOfSale": "2021-07-15",
  "checkboxOnForm8949": "checkboxOnForm89498",
  "securityName": "securityName6",
  "numberOfShares": 126.44,
  "saleDescription": "saleDescription4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

