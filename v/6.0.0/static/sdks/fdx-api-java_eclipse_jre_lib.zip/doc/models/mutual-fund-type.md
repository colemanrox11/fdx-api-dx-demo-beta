
# Mutual Fund Type

The type of a mutual fund

*This model accepts additional fields of type Object.*

## Enumeration

`MutualFundType`

## Fields

| Name |
|  --- |
| `Closeend` |
| `Openend` |
| `Other` |

