
# Capability Entity

The response object for the API /capability request

*This model accepts additional fields of type Object.*

## Structure

`CapabilityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fdx_versions` | [`Array<FdxVersion>`](../../doc/models/fdx-version.md) | Optional | The FDX schema versions supported by one or more operations |
| `allowed_connections` | `Integer` | Optional | The number of concurrent connections allowed for this client |
| `active_connections` | `Integer` | Optional | The current number of active connections for this client |
| `message_format` | [`MessageFormat2`](../../doc/models/message-format-2.md) | Optional | Defaults to JSON |
| `operations` | [`Array<OperationEntity>`](../../doc/models/operation-entity.md) | Optional | The FDX API endpoints supported |
| `jwks_url` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | The URL to retrieve the JWKS public keys from the data provider, needed to enable payload level encryption above the TLS layer |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "fdxVersions": [
    "V6.2.0",
    "V1.0"
  ],
  "allowedConnections": 30,
  "activeConnections": 28,
  "messageFormat": "JSON",
  "operations": [
    {
      "id": "getRegistryRecipient",
      "availability": {
        "status": "ALIVE",
        "description": "description0",
        "operationId": "getPaymentInitiationParty",
        "plannedAvailability": [
          {
            "status": "MAINTENANCE",
            "description": "description6",
            "startTime": "2016-03-13T12:52:32.123Z",
            "endTime": "2016-03-13T12:52:32.123Z",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "alsoSupported": [
        "getPaymentMethodRegistration",
        "getPaymentsForRecurringPayment"
      ],
      "version": "version8",
      "fdxVersions": [
        "V5.0",
        "V5.0.0",
        "V5.0.1"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

