# Personal Information

```go
personalInformationController := client.PersonalInformationController()
```

## Class Name

`PersonalInformationController`

## Methods

* [Get Account Contact](../../doc/controllers/personal-information.md#get-account-contact)
* [Get Customers](../../doc/controllers/personal-information.md#get-customers)
* [Get Customer Info](../../doc/controllers/personal-information.md#get-customer-info)
* [Get Customer](../../doc/controllers/personal-information.md#get-customer)


# Get Account Contact

Get contact information on the account

```go
GetAccountContact(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    accountId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.AccountContactEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `string` | Template, Required | Account Identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AccountContactEntity](../../doc/models/account-contact-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

accountId := "accountId0"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := personalInformationController.GetAccountContact(ctx, xFapiInteractionId, accountId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Customers

Retrieve account holders related to permissioned accounts

```go
GetCustomers(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    offset *string,
    limit *int) (
    models.ApiResponse[models.CustomersEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CustomersEntity](../../doc/models/customers-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch





apiResponse, err := personalInformationController.GetCustomers(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get Customer Info

Get information about the customer within the authorization scope

```go
GetCustomerInfo(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.CustomerEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CustomerEntity](../../doc/models/customer-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := personalInformationController.GetCustomerInfo(ctx, xFapiInteractionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Get Customer

Retrieve customer information by customer id

```go
GetCustomer(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    customerId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.CustomerEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `customerId` | `string` | Template, Required | Customer Identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.CustomerEntity](../../doc/models/customer-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

customerId := "customerId6"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := personalInformationController.GetCustomer(ctx, xFapiInteractionId, customerId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Customer with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

