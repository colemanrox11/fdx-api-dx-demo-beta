
# Individual Name

First name, middle initial, last name, suffix fields

*This model accepts additional fields of type Object.*

## Structure

`IndividualName`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `String` | Optional | First name |
| `middle` | `String` | Optional | Middle initial |
| `last` | `String` | Optional | Last name |
| `suffix` | `String` | Optional | Generational or academic suffix |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first2",
  "middle": "middle2",
  "last": "last4",
  "suffix": "suffix4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

