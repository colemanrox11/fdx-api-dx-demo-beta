
# Account Bill Pay Status 2

Defines account's ability to participate in bill payments

*This model accepts additional fields of type Object.*

## Enumeration

`AccountBillPayStatus2`

## Fields

| Name |
|  --- |
| `Active` |
| `Available` |
| `NotAvailable` |
| `Pending` |

