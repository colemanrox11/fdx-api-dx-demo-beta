
# Insurance Transaction Entity

An insurance transaction type

*This model accepts additional fields of type Object.*

## Structure

`InsuranceTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_type` | [`InsuranceTransactionType`](../../doc/models/insurance-transaction-type.md) | Optional | The type of an insurance transaction |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountCategory": "Insurance Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "ADJUSTMENT"
}
```

