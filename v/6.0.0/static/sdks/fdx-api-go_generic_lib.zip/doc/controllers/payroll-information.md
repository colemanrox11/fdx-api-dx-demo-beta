# Payroll Information

```go
payrollInformationController := client.PayrollInformationController()
```

## Class Name

`PayrollInformationController`

## Methods

* [Get Payroll Reports](../../doc/controllers/payroll-information.md#get-payroll-reports)
* [Get Payroll Report](../../doc/controllers/payroll-information.md#get-payroll-report)


# Get Payroll Reports

Search for the employee's latest payroll report

```go
GetPayrollReports(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    reportType models.PayrollReportType,
    fdxApiActorType *models.FdxApiActorType,
    resultType *models.ResultType) (
    models.ApiResponse[models.PayrollReportListEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `reportType` | [`models.PayrollReportType`](../../doc/models/payroll-report-type.md) | Query, Required | Whether to retrieve Verification of Employment ("VOE") or Verification of Income and Employment ("VOIE") reports |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `resultType` | [`*models.ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `"lightweight"` |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayrollReportListEntity](../../doc/models/payroll-report-list-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

reportType := models.PayrollReportType_Voe

fdxApiActorType := models.FdxApiActorType_Batch

resultType := models.ResultType_Lightweight

apiResponse, err := payrollInformationController.GetPayrollReports(ctx, xFapiInteractionId, reportType, &fdxApiActorType, &resultType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payroll Report

Retrieve the employee's specified payroll report

```go
GetPayrollReport(
    ctx context.Context,
    reportId string,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PayrollReportEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reportId` | `string` | Template, Required | Specific reportId to retrieve<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayrollReportEntity](../../doc/models/payroll-report-entity.md).

## Example Usage

```go
ctx := context.Background()

reportId := "reportId6"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := payrollInformationController.GetPayrollReport(ctx, reportId, xFapiInteractionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Required input data not sent | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payroll Report with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

