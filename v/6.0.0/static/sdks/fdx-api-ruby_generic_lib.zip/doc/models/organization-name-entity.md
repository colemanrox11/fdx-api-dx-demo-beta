
# Organization Name Entity

Logical grouping of name attributes that are particular to
an Organization type of payment initiation party

*This model accepts additional fields of type Object.*

## Structure

`OrganizationNameEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `company_name` | `String` | Optional | Name value of the organization |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "companyName": "companyName0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

