
# Payroll Rate Type 2

Whether the worker's rate is ANNUAL, DAILY, HOURLY, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollRateType2`

## Fields

| Name |
|  --- |
| `Annual` |
| `Daily` |
| `Hourly` |
| `Other` |

