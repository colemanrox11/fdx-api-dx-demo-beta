
# Payroll Frequency Type 2

The frequency of payments

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollFrequencyType2`

## Fields

| Name |
|  --- |
| `ANNUALLY` |
| `BI_WEEKLY` |
| `DAILY` |
| `EVERY_2_6_WEEKS` |
| `EVERY_4_WEEKS` |
| `EVERY_5_2_WEEKS` |
| `MONTHLY` |
| `QUARTERLY` |
| `SEMI_ANNUALLY` |
| `SEMI_MONTHLY` |
| `WEEKLY` |

