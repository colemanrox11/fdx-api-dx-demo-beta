# Payments

Manage payments

```go
paymentsController := client.PaymentsController()
```

## Class Name

`PaymentsController`

## Methods

* [Search for Payments](../../doc/controllers/payments.md#search-for-payments)
* [Schedule Payment](../../doc/controllers/payments.md#schedule-payment)
* [Get Payment](../../doc/controllers/payments.md#get-payment)
* [Update Payment](../../doc/controllers/payments.md#update-payment)
* [Cancel Payment](../../doc/controllers/payments.md#cancel-payment)


# Search for Payments

Search for payments

```go
SearchForPayments(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    updatedSince *string,
    offset *string,
    limit *int) (
    models.ApiResponse[models.PaymentsEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `*string` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentsEntity](../../doc/models/payments-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch







apiResponse, err := paymentsController.SearchForPayments(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "next-offset-123-xyz",
    "prevOffset": "prev-offset-456-abc",
    "totalElements": 100
  },
  "updates": {
    "nextUpdateId": "next-update-id-456-krl"
  },
  "links": {
    "next": {
      "href": "/payments?offset=next-offset-123-xyz"
    },
    "prev": {
      "href": "/payments?offset=prev-offset-456-abc"
    },
    "updates": {
      "href": "/payments?updatedSince=next-update-id-456-krl"
    }
  },
  "payments": [
    {
      "fromAccountId": "ACCOUNT-123",
      "toPayeeId": "PAYEE-ABC",
      "amount": 10.99,
      "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
      "dueDate": "2021-08-17",
      "paymentId": "PAYMENT-213",
      "recurringPaymentId": "RECURRING-PAYMENT-485",
      "processedTimestamp": "2021-03-15T13:29:19+0000",
      "startedProcessingTimestamp": "2021-03-14T13:29:19+0000",
      "status": "PROCESSED",
      "links": [
        {
          "href": "/recurring-payment/RECURRING-PAYMENT-485",
          "rel": "recurringPayment"
        }
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Schedule Payment

Schedule a payment

```go
SchedulePayment(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PaymentForUpdateEntity1) (
    models.ApiResponse[models.PaymentEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PaymentForUpdateEntity1`](../../doc/models/payment-for-update-entity-1.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentEntity](../../doc/models/payment-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

idempotencyKey := "idempotency-key4"



body := models.PaymentForUpdateEntity1{
    FromAccountId:         "ACCOUNT-123",
    ToPayeeId:             "PAYEE-ABC",
    Amount:                float64(10.99),
    MerchantAccountId:     models.ToPointer("MERCHANT-ACCOUNT-ID-0001"),
    DueDate:               parseTime(models.DEFAULT_DATE, "2021-08-17", func(err error) { log.Fatalln(err) }),
}

apiResponse, err := paymentsController.SchedulePayment(ctx, xFapiInteractionId, idempotencyKey, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "paymentId": "PAYMENT-213",
  "status": "SCHEDULED"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Request is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested payment is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`PaymentEntityErrorException`](../../doc/models/payment-entity-error-exception.md) |
| 422 | Account type not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment

Get a payment

```go
GetPayment(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PaymentEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentId` | `string` | Template, Required | Payment Identifier. Uniquely identifies a payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentEntity](../../doc/models/payment-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentId := "paymentId2"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := paymentsController.GetPayment(ctx, xFapiInteractionId, paymentId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "paymentId": "PAYMENT-213",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "processedTimestamp": "2021-03-15T13:29:19+0000",
  "startedProcessingTimestamp": "2021-03-14T13:29:19+0000",
  "status": "PROCESSED",
  "links": [
    {
      "href": "/recurring-payment/RECURRING-PAYMENT-854",
      "rel": "recurringPayment"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | A payment with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment

Update a payment

```go
UpdatePayment(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentId string,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PaymentForUpdateEntity2) (
    models.ApiResponse[models.PaymentEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentId` | `string` | Template, Required | Payment Identifier. Uniquely identifies a payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PaymentForUpdateEntity2`](../../doc/models/payment-for-update-entity-2.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentEntity](../../doc/models/payment-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentId := "paymentId2"

idempotencyKey := "idempotency-key4"



body := models.PaymentForUpdateEntity2{
    FromAccountId:         "ACCOUNT-890",
    ToPayeeId:             "PAYEE-XYZ",
    Amount:                float64(5),
    DueDate:               parseTime(models.DEFAULT_DATE, "2021-08-30", func(err error) { log.Fatalln(err) }),
}

apiResponse, err := paymentsController.UpdatePayment(ctx, xFapiInteractionId, paymentId, idempotencyKey, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "paymentId": "PAYMENT-213",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "processedTimestamp": "2021-03-15T13:29:19+0000",
  "startedProcessingTimestamp": "2021-03-14T13:29:19+0000",
  "status": "PROCESSED",
  "links": [
    {
      "href": "/recurring-payment/RECURRING-PAYMENT-548",
      "rel": "recurringPayment"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Request is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested payment change is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`PaymentEntityErrorException`](../../doc/models/payment-entity-error-exception.md) |
| 422 | Account type not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Cancel Payment

Cancel a payment

```go
CancelPayment(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PaymentEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentId` | `string` | Template, Required | Payment Identifier. Uniquely identifies a payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentEntity](../../doc/models/payment-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentId := "paymentId2"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := paymentsController.CancelPayment(ctx, xFapiInteractionId, paymentId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "paymentId": "PAYMENT-213",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "cancelledTimestamp": "2021-03-14T13:29:19+0000",
  "status": "CANCELLED",
  "links": [
    {
      "href": "/recurring-payment/RECURRING-PAYMENT-845",
      "rel": "recurringPayment"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Payment cannot be modified or cancelled at this time. Likely due to the state that it is in | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | A payment with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

