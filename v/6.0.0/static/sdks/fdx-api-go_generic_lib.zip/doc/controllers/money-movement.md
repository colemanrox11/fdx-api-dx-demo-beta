# Money Movement

```go
moneyMovementController := client.MoneyMovementController()
```

## Class Name

`MoneyMovementController`

## Methods

* [Get Account Asset Transfer Networks](../../doc/controllers/money-movement.md#get-account-asset-transfer-networks)
* [Get Account Payment Networks](../../doc/controllers/money-movement.md#get-account-payment-networks)


# Get Account Asset Transfer Networks

...

```go
GetAccountAssetTransferNetworks(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    accountId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.AssetTransferNetworkList],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `string` | Template, Required | Account Identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AssetTransferNetworkList](../../doc/models/asset-transfer-network-list.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

accountId := "accountId0"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := moneyMovementController.GetAccountAssetTransferNetworks(ctx, xFapiInteractionId, accountId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "assetTransferNetworks": [
    {
      "identifier": "121000358",
      "identifierType": "ACCOUNT_NUMBER",
      "institutionName": "US Investments",
      "institutionId": "1234567890",
      "type": "US_ACATS",
      "jointAccount": true
    }
  ]
}
```


# Get Account Payment Networks

Get payment networks supported by the account

```go
GetAccountPaymentNetworks(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    accountId string,
    fdxApiActorType *models.FdxApiActorType,
    offset *string,
    limit *int) (
    models.ApiResponse[models.ArrayOfAccountPaymentNetworks],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `string` | Template, Required | Account Identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ArrayOfAccountPaymentNetworks](../../doc/models/array-of-account-payment-networks.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

accountId := "accountId0"

fdxApiActorType := models.FdxApiActorType_Batch





apiResponse, err := moneyMovementController.GetAccountPaymentNetworks(ctx, xFapiInteractionId, accountId, &fdxApiActorType, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "totalElements": 1
  },
  "paymentNetworks": [
    {
      "bankId": "121000358",
      "identifier": "1234567890",
      "identifierType": "ACCOUNT_NUMBER",
      "type": "US_ACH",
      "transferIn": true,
      "transferOut": true,
      "transferLimits": {
        "out": {
          "day": {
            "resetsOn": "2023-08-09T00:00:00.000Z",
            "transferMaxAmount": 10000.0,
            "transferRemainingAmount": 8356.0,
            "maxOccurrence": 6,
            "remainingOccurrence": 5
          },
          "month": {
            "resetsOn": "2023-09-01T00:00:00.000Z",
            "transferMaxAmount": 50000.0,
            "transferRemainingAmount": 35200.0
          },
          "transaction": {
            "transferMaxAmount": 5000.0,
            "transferRemainingAmount": 4990.0
          }
        }
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

