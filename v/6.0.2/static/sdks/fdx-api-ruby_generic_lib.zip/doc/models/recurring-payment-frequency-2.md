
# Recurring Payment Frequency 2

Defines how often the payment repeats

*This model accepts additional fields of type Object.*

## Enumeration

`RecurringPaymentFrequency2`

## Fields

| Name |
|  --- |
| `WEEKLY` |
| `BIWEEKLY` |
| `TWICEMONTHLY` |
| `MONTHLY` |
| `FOURWEEKS` |
| `BIMONTHLY` |
| `QUARTERLY` |
| `SEMIANNUALLY` |
| `ANNUALLY` |

