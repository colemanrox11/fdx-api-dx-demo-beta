
# Payment Generic Account Entity

Payment Generic Account information

*This model accepts additional fields of type Object.*

## Structure

`PaymentGenericAccountEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_number` | `String` | Optional | Unique identifier of the account number<br><br>**Constraints**: *Maximum Length*: `256` |
| `account_type` | [`AccountType`](../../doc/models/account-type.md) | Optional | Account type |
| `name` | `String` | Optional | Account name |
| `currency_code` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | ISO 4217 currency code |
| `id` | [IBAN 2007 Identifier entity](../../doc/models/iban-2007-identifier-entity.md) \| [Generic Account Identification entity](../../doc/models/generic-account-identification-entity.md) \| nil | Optional | This is a container for any-of cases. |
| `branch` | [`BranchEntity1`](../../doc/models/branch-entity-1.md) | Optional | Branch details associated with this account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountNumber": "accountNumber0",
  "accountType": "SPECIFIEDPENSIONPLAN",
  "name": "name2",
  "currencyCode": "PGK",
  "id": {
    "iban2007Id": "iban2007Id4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

