
# Month Abbreviation 1

Month

*This model accepts additional fields of type Object.*

## Enumeration

`MonthAbbreviation1`

## Fields

| Name |
|  --- |
| `Jan` |
| `Feb` |
| `Mar` |
| `Apr` |
| `May` |
| `Jun` |
| `Jul` |
| `Aug` |
| `Sep` |
| `Oct` |
| `Nov` |
| `Dec` |

