
# Policy Product Type 2

The type of annuity product, e.g. Fixed or Variable

*This model accepts additional fields of type Object.*

## Enumeration

`PolicyProductType2`

## Fields

| Name |
|  --- |
| `FIXED` |
| `VARIABLE` |

