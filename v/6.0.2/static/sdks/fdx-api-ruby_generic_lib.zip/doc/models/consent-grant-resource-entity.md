
# Consent Grant Resource Entity

Entity of permissioned resources

*This model accepts additional fields of type Object.*

## Structure

`ConsentGrantResourceEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resource_type` | [`ConsentResourceType3`](../../doc/models/consent-resource-type-3.md) | Required | Type of resource to be permissioned |
| `resource_id` | `String` | Required | Identifier of resource to be permissioned<br><br>**Constraints**: *Maximum Length*: `256` |
| `data_clusters` | [`Array<DataCluster>`](../../doc/models/data-cluster.md) | Required | Names of clusters of data elements permissioned<br><br>**Constraints**: *Minimum Items*: `1` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "resourceType": "DOCUMENT",
  "resourceId": "resourceId4",
  "dataClusters": [
    "BILLS"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

