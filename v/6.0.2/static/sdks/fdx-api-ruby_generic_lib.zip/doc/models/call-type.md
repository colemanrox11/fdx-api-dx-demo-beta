
# Call Type

The call type for a stock option

*This model accepts additional fields of type Object.*

## Enumeration

`CallType`

## Fields

| Name |
|  --- |
| `CALL` |
| `MATURITY` |
| `PREFUND` |
| `PUT` |

