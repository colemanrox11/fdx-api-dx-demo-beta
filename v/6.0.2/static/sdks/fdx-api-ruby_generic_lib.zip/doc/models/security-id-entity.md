
# Security Id Entity

Unique identifier for a security

*This model accepts additional fields of type Object.*

## Structure

`SecurityIdEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | Security identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `id_type` | [`SecurityIdType1`](../../doc/models/security-id-type-1.md) | Optional | CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "id": "id2",
  "idType": "CMC",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

