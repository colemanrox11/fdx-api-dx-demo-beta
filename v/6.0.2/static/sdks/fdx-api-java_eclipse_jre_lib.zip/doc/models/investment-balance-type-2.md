
# Investment Balance Type 2

AMOUNT, PERCENTAGE

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentBalanceType2`

## Fields

| Name |
|  --- |
| `Amount` |
| `Percentage` |

