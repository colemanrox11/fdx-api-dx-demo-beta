
# State Code

State two-digit code

*This model accepts additional fields of type Object.*

## Enumeration

`StateCode`

## Fields

| Name |
|  --- |
| `Aa` |
| `Ae` |
| `Ak` |
| `Al` |
| `Ap` |
| `Ar` |
| `As` |
| `Az` |
| `Ca` |
| `Co` |
| `Ct` |
| `Dc` |
| `De` |
| `Fl` |
| `Fm` |
| `Ga` |
| `Gu` |
| `Hi` |
| `Ia` |
| `Id` |
| `Il` |
| `In` |
| `Ks` |
| `Ky` |
| `La` |
| `Ma` |
| `Md` |
| `Me` |
| `Mh` |
| `Mi` |
| `Mn` |
| `Mo` |
| `Mp` |
| `Ms` |
| `Mt` |
| `Nc` |
| `Nd` |
| `Ne` |
| `Nh` |
| `Nj` |
| `Nm` |
| `Nv` |
| `Ny` |
| `Oh` |
| `Ok` |
| `Or` |
| `Pa` |
| `Pr` |
| `Pw` |
| `Ri` |
| `Sc` |
| `Sd` |
| `Tn` |
| `Tx` |
| `Ut` |
| `Va` |
| `Vi` |
| `Vt` |
| `Wa` |
| `Wi` |
| `Wv` |
| `Wy` |

