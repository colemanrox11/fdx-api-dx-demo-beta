
# Commercial Balance Entity

A specific treasury management defined balance

*This model accepts additional fields of type Object.*

## Structure

`CommercialBalanceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CommercialCode` | [`CommercialCodeEntity1`](../../doc/models/commercial-code-entity-1.md) | Optional | The code for a specific treasury management defined field | CommercialCodeEntity1 getCommercialCode() | setCommercialCode(CommercialCodeEntity1 commercialCode) |
| `Amount` | `Double` | Optional | The treasury management balance amount | Double getAmount() | setAmount(Double amount) |
| `Memo` | `String` | Optional | Memo field for the treasury management balance amount | String getMemo() | setMemo(String memo) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "commercialCode": {
    "type": "ISO",
    "code": "code6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "amount": 62.36,
  "memo": "memo8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

