
# Direct Deposit Entity

Direct deposit details

*This model accepts additional fields of type Object.*

## Structure

`DirectDepositEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `direct_deposit_id` | `String` | Optional | Unique identifier of the direct deposit configuration<br><br>**Constraints**: *Maximum Length*: `256` |
| `registration_type_code` | `String` | Optional | Type code of a registration for a direct deposit account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "directDepositId": "directDepositId2",
  "registrationTypeCode": "registrationTypeCode0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

