
# Hateoas Link

REST application constraint (Hypermedia As The Engine Of Application State)

*This model accepts additional fields of type Object.*

## Structure

`HateoasLink`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `href` | `String` | Required | URL to invoke the action on the resource |
| `action` | [`HttpActionType`](../../doc/models/http-action-type.md) | Optional | HTTP Method to use for the request |
| `rel` | `String` | Optional | Relation of this link to its containing entity, as defined by and with many example relation values at [IETF RFC5988](https://datatracker.ietf.org/doc/html/rfc5988) |
| `types` | [`Array<ContentTypes>`](../../doc/models/content-types.md) | Optional | Content-types that can be used in the Accept header |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "href": "https://api.fi.com/fdx/v4/accounts/12345",
  "action": "POST",
  "rel": "rel0",
  "types": [
    "image/jpeg"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

