
# Tax Data

Tax data container for API requests and responses

*This model accepts additional fields of type Object.*

## Structure

`TaxData`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_income_statement` | [`BusinessIncomeStatement`](../../doc/models/business-income-statement.md) | Optional | Business Income Statement for IRS Form 1040 Schedule C |
| `cryptocurrency_tax_statement` | [`CryptocurrencyTaxStatementList1`](../../doc/models/cryptocurrency-tax-statement-list-1.md) | Optional | Cryptocurrency Tax Statement list |
| `farm_income_statement` | [`FarmIncomeStatement`](../../doc/models/farm-income-statement.md) | Optional | Farm Income Statement for IRS Form 1040 Schedule F |
| `farm_rental_income_statement` | [`FarmRentalIncomeStatement`](../../doc/models/farm-rental-income-statement.md) | Optional | Farm Rental Income Statement for IRS Form 4835 |
| `rental_income_statement` | [`RentalIncomeStatement`](../../doc/models/rental-income-statement.md) | Optional | Rental Income Statement for IRS Form 1040 Schedule E |
| `royalty_income_statement` | [`RoyaltyIncomeStatement`](../../doc/models/royalty-income-statement.md) | Optional | Royalty Income Statement for IRS Form 1040 Schedule E |
| `tax_1041_k_1` | [`Form1041K11`](../../doc/models/form-1041-k11.md) | Optional | Beneficiary's Share of Income, Deductions, Credits, etc. |
| `tax_1042_s` | [`Form1042S1`](../../doc/models/form-1042-s1.md) | Optional | Foreign Person's U.S. Source Income Subject to Withholding |
| `tax_1065_k_1` | [`Form1065K11`](../../doc/models/form-1065-k11.md) | Optional | Partner's Share of Income, Deductions, Credits, etc. |
| `tax_1095_a` | [`Form1095A1`](../../doc/models/form-1095-a1.md) | Optional | Health Insurance Marketplace Statement |
| `tax_1095_b` | [`Form1095B1`](../../doc/models/form-1095-b1.md) | Optional | Health Coverage |
| `tax_1095_c` | [`Form1095C1`](../../doc/models/form-1095-c1.md) | Optional | Employer-Provided Health Insurance Offer and Coverage |
| `tax_1097_btc` | [`Form1097Btc1`](../../doc/models/form-1097-btc-1.md) | Optional | Bond Tax Credit |
| `tax_1098` | [`Form10981`](../../doc/models/form-10981.md) | Optional | Mortgage Interest Statement |
| `tax_1098_c` | [`Form1098C1`](../../doc/models/form-1098-c1.md) | Optional | Contributions of Motor Vehicles, Boats, and Airplanes |
| `tax_1098_e` | [`Form1098E1`](../../doc/models/form-1098-e1.md) | Optional | Student Loan Interest Statement |
| `tax_1098_ma` | [`Form1098Ma1`](../../doc/models/form-1098-ma-1.md) | Optional | Mortgage Assistance Payments |
| `tax_1098_q` | [`Form1098Q1`](../../doc/models/form-1098-q1.md) | Optional | Qualifying Longevity Annuity Contract Information |
| `tax_1098_t` | [`Form1098T1`](../../doc/models/form-1098-t1.md) | Optional | Tuition Statement |
| `tax_1099_a` | [`Form1099A1`](../../doc/models/form-1099-a1.md) | Optional | Acquisition or Abandonment of Secured Property |
| `tax_1099_b` | [`Form1099B1`](../../doc/models/form-1099-b1.md) | Optional | Proceeds From Broker and Barter Exchange Transactions |
| `tax_1099_c` | [`Form1099C1`](../../doc/models/form-1099-c1.md) | Optional | Cancellation of Debt |
| `tax_1099_cap` | [`Form1099Cap1`](../../doc/models/form-1099-cap-1.md) | Optional | Changes in Corporate Control and Capital Structure |
| `tax_1099_consolidated_statement` | [`Form1099ConsolidatedStatement1`](../../doc/models/form-1099-consolidated-statement-1.md) | Optional | Consolidated Statement for combined IRS Form 1099s |
| `tax_1099_div` | [`Form1099Div1`](../../doc/models/form-1099-div-1.md) | Optional | Dividends and Distributions |
| `tax_1099_g` | [`Form1099G1`](../../doc/models/form-1099-g1.md) | Optional | Certain Government Payments |
| `tax_1099_h` | [`Form1099H1`](../../doc/models/form-1099-h1.md) | Optional | Health Coverage Tax Credit (HCTC) Advance Payments |
| `tax_1099_int` | [`Form1099Int1`](../../doc/models/form-1099-int-1.md) | Optional | Interest Income |
| `tax_1099_k` | [`Form1099K1`](../../doc/models/form-1099-k1.md) | Optional | Merchant Card and Third-Party Network Payments |
| `tax_1099_ls` | [`Form1099Ls1`](../../doc/models/form-1099-ls-1.md) | Optional | Reportable Life Insurance Sale |
| `tax_1099_ltc` | [`Form1099Ltc1`](../../doc/models/form-1099-ltc-1.md) | Optional | Long-Term Care and Accelerated Death Benefits |
| `tax_1099_misc` | [`Form1099Misc1`](../../doc/models/form-1099-misc-1.md) | Optional | Miscellaneous Income |
| `tax_1099_nec` | [`Form1099Nec1`](../../doc/models/form-1099-nec-1.md) | Optional | Nonemployee Compensation |
| `tax_1099_oid` | [`Form1099Oid1`](../../doc/models/form-1099-oid-1.md) | Optional | Original Issue Discount |
| `tax_1099_patr` | [`Form1099Patr1`](../../doc/models/form-1099-patr-1.md) | Optional | Taxable Distributions Received From Cooperatives |
| `tax_1099_q` | [`Form1099Q1`](../../doc/models/form-1099-q1.md) | Optional | Payments From Qualified Education Programs |
| `tax_1099_qa` | [`Form1099Qa1`](../../doc/models/form-1099-qa-1.md) | Optional | Distributions From ABLE Accounts |
| `tax_1099_r` | [`Form1099R1`](../../doc/models/form-1099-r1.md) | Optional | Distributions from Pensions, Annuities, Retirement or Profit-Sharing Plans, IRAs, Insurance Contracts, etc. |
| `tax_1099_s` | [`Form1099S1`](../../doc/models/form-1099-s1.md) | Optional | Proceeds From Real Estate Transactions |
| `tax_1099_sa` | [`Form1099Sa1`](../../doc/models/form-1099-sa-1.md) | Optional | Distributions From an HSA, Archer MSA, or Medicare Advantage MSA |
| `tax_1099_sb` | [`Form1099Sb1`](../../doc/models/form-1099-sb-1.md) | Optional | Seller's Investment in Life Insurance Contract |
| `tax_1120_sk_1` | [`Form1120SK11`](../../doc/models/form-1120-sk11.md) | Optional | Shareholder's Share of Income, Deductions, Credits, etc. |
| `tax_2439` | [`Form24391`](../../doc/models/form-24391.md) | Optional | Notice to Shareholder of Undistributed Long-Term Capital Gains |
| `tax_3921` | [`Form39211`](../../doc/models/form-39211.md) | Optional | Exercise of an Incentive Stock Option Under Section 422(b) |
| `tax_3922` | [`Form39221`](../../doc/models/form-39221.md) | Optional | Transfer of Stock Acquired Through an Employee Stock Purchase Plan under Section 423(c) |
| `tax_5227_k_1` | [`Form1041K1`](../../doc/models/form-1041-k1.md) | Optional | Split-Interest Trust Beneficiary's schedule K-1 |
| `tax_5498` | [`Form54981`](../../doc/models/form-54981.md) | Optional | IRA Contribution Information |
| `tax_5498_esa` | [`Form5498Esa1`](../../doc/models/form-5498-esa-1.md) | Optional | Coverdell ESA Contribution Information |
| `tax_5498_qa` | [`Form5498Qa1`](../../doc/models/form-5498-qa-1.md) | Optional | ABLE Account Contribution Information |
| `tax_5498_sa` | [`Form5498Sa1`](../../doc/models/form-5498-sa-1.md) | Optional | HSA, Archer MSA, or Medicare Advantage MSA Information |
| `tax_w_2` | [`FormW24`](../../doc/models/form-w24.md) | Optional | Wage and Tax Statement |
| `tax_w_2_c` | [`FormW2C2`](../../doc/models/form-w2-c2.md) | Optional | IRS form W-2c, Corrected Wage and Tax Statement |
| `tax_w_2_g` | [`FormW2G2`](../../doc/models/form-w2-g2.md) | Optional | Certain Gambling Winnings |
| `tax_refund_direct_deposit` | [`TaxRefundDirectDeposit2`](../../doc/models/tax-refund-direct-deposit-2.md) | Optional | Tax refund direct deposit information |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "businessIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId4",
    "taxFormId": "taxFormId2",
    "taxFormDate": "2016-03-13",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "cryptocurrencyTaxStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId2",
    "taxFormId": "taxFormId0",
    "taxFormDate": "2016-03-13",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "farmIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId4",
    "taxFormId": "taxFormId2",
    "taxFormDate": "2016-03-13",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "farmRentalIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId8",
    "taxFormId": "taxFormId6",
    "taxFormDate": "2016-03-13",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "rentalIncomeStatement": {
    "taxYear": 2018,
    "corrected": false,
    "accountId": "accountId8",
    "taxFormId": "taxFormId6",
    "taxFormDate": "2016-03-13",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

