
# Line of Credit Transaction Entity

A line of credit transaction

*This model accepts additional fields of type Object.*

## Structure

`LineOfCreditTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionType` | [`LineOfCreditTransactionType2`](../../doc/models/line-of-credit-transaction-type-2.md) | Optional | CHECK, WITHDRAWAL, PAYMENT, FEE, ADJUSTMENT, INTEREST, PURCHASE | LineOfCreditTransactionType2 getTransactionType() | setTransactionType(LineOfCreditTransactionType2 transactionType) |
| `CheckNumber` | `Integer` | Optional | Check number | Integer getCheckNumber() | setCheckNumber(Integer checkNumber) |
| `PaymentDetails` | [`PaymentDetailsEntity`](../../doc/models/payment-details-entity.md) | Optional | Breakdown of payment details | PaymentDetailsEntity getPaymentDetails() | setPaymentDetails(PaymentDetailsEntity paymentDetails) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountCategory": "Line of Credit Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "FEE",
  "checkNumber": 8,
  "paymentDetails": {
    "principalAmount": 147.58,
    "interestAmount": 32.1,
    "insuranceAmount": 96.02,
    "escrowAmount": 117.32,
    "pmiAmount": 250.6,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  }
}
```

