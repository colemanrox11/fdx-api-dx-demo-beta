
# Notification Priority

Priority of notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationPriority`

## Fields

| Name |
|  --- |
| `HIGH` |
| `MEDIUM` |
| `LOW` |

