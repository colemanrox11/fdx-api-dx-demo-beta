
# Contact Preferences Type 2

Type of the contact preference

*This model accepts additional fields of type Object.*

## Enumeration

`ContactPreferencesType2`

## Fields

| Name |
|  --- |
| `CELL` |
| `EMAIL` |
| `FAX` |
| `LETTER` |
| `PHONE` |

