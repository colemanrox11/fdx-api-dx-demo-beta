
# Holding Entity

A holding in an investment account

*This model accepts additional fields of type Object.*

## Structure

`HoldingEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `holding_id` | `String` | Optional | Long term persistent identity of the holding<br><br>**Constraints**: *Maximum Length*: `256` |
| `security_ids` | [`Array<SecurityIdEntity>`](../../doc/models/security-id-entity.md) | Optional | Unique identifiers for the security |
| `holding_name` | `String` | Optional | Holding name or security name |
| `holding_type` | [`HoldingType2`](../../doc/models/holding-type-2.md) | Optional | ANNUITY, BOND, CD, DIGITALASSET, MUTUALFUND, OPTION, OTHER, STOCK |
| `holding_sub_type` | [`HoldingSubType2`](../../doc/models/holding-sub-type-2.md) | Optional | MONEYMARKET, CASH |
| `position_type` | [`PositionType1`](../../doc/models/position-type-1.md) | Optional | LONG, SHORT |
| `held_in_account` | [`HeldInAccount2`](../../doc/models/held-in-account-2.md) | Optional | Sub-account CASH, MARGIN, SHORT, OTHER |
| `description` | `String` | Optional | The description of the holding |
| `symbol` | `String` | Optional | Ticker / Market symbol |
| `original_purchase_date` | `Date` | Optional | Date of original purchase |
| `purchased_price` | `Float` | Optional | Price of holding at the time of purchase |
| `current_amortization_factor` | `Float` | Optional | Ranges from 0.0 - 1.0 indicates the adjustment to the calculation of the market value. 'currentUnitPrice * quantity * currentAmortizationFactor =  marketValue'<br><br>**Default**: `1`<br><br>**Constraints**: `>= 0`, `<= 1` |
| `current_unit_price` | `Float` | Optional | Current unit price |
| `change_in_price` | `Float` | Optional | Change in current price compared to previous day's close |
| `current_unit_price_date` | `Date` | Optional | Current unit price as of date |
| `units` | `Float` | Optional | Required for stock, mutual funds. Number of shares (with decimals) |
| `market_value` | `Float` | Optional | Market value at the time of data retrieved |
| `face_value` | `Float` | Optional | Required for bonds. Face value at the time of data retrieved |
| `average_cost` | `TrueClass \| FalseClass` | Optional | Cost is average of all purchases for holding |
| `cash_account` | `TrueClass \| FalseClass` | Optional | If true, indicates that this holding is used to maintain proceeds from sales, dividends, and other cash postings to the investment account |
| `rate` | `Float` | Optional | For CDs, bonds, and other rate based holdings |
| `expiration_date` | `Date` | Optional | For CDs, bonds, and other time-based holdings |
| `inv_401_k_source` | [`Investment401KSourceType4`](../../doc/models/investment-401-k-source-type-4.md) | Optional | Source for money for this security. One of PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST |
| `currency` | [`CurrencyEntity1`](../../doc/models/currency-entity-1.md) | Optional | Currency information if it is different from Account entity |
| `asset_classes` | [`Array<PortionEntity>`](../../doc/models/portion-entity.md) | Optional | Percent breakdown by asset class |
| `fi_asset_classes` | [`Array<FiPortionEntity>`](../../doc/models/fi-portion-entity.md) | Optional | Percent breakdown by FI-specific asset class percentage breakdown |
| `fi_attributes` | [`Array<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes |
| `tax_lots` | [`Array<TaxLotEntity>`](../../doc/models/tax-lot-entity.md) | Optional | Breakdown by tax lot |
| `digital_units` | `String` | Optional | Specify units to full precision with unlimited digits after decimal point |
| `security` | [Debt Security entity](../../doc/models/debt-security-entity.md) \| [Mutual Fund Security entity](../../doc/models/mutual-fund-security-entity.md) \| [Option Security entity](../../doc/models/option-security-entity.md) \| [Other Security entity](../../doc/models/other-security-entity.md) \| [Stock Security entity](../../doc/models/stock-security-entity.md) \| [Sweep Security entity](../../doc/models/sweep-security-entity.md) \| nil | Optional | This is a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "originalPurchaseDate": "2021-07-15",
  "currentAmortizationFactor": 1,
  "currentUnitPriceDate": "2021-07-15",
  "expirationDate": "2021-07-15",
  "holdingId": "holdingId0",
  "securityIds": [
    {
      "id": "id6",
      "idType": "CINS",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "holdingName": "holdingName6",
  "holdingType": "ANNUITY",
  "holdingSubType": "CASH",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

