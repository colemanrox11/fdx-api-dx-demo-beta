
# Content Types

Types of document formats. (Suggested values)

*This model accepts additional fields of type Object.*

## Enumeration

`ContentTypes`

## Fields

| Name |
|  --- |
| `EnumApplicationjson` |
| `EnumApplicationpdf` |
| `EnumApplicationzip` |
| `EnumImagegif` |
| `EnumImagejpeg` |
| `EnumImagepng` |
| `EnumImagetiff` |

