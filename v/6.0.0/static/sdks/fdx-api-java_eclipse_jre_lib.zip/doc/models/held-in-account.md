
# Held in Account

The type of holdings of an investment account

*This model accepts additional fields of type Object.*

## Enumeration

`HeldInAccount`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `Other` |
| `MShort` |

