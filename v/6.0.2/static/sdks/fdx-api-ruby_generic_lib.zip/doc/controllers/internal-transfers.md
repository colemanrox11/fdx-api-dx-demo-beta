# Internal Transfers

```ruby
internal_transfers_controller = client.internal_transfers
```

## Class Name

`InternalTransfersController`

## Methods

* [Search for Transfers](../../doc/controllers/internal-transfers.md#search-for-transfers)
* [Request Account Transfer](../../doc/controllers/internal-transfers.md#request-account-transfer)
* [Get Transfer](../../doc/controllers/internal-transfers.md#get-transfer)
* [Cancel Transfer](../../doc/controllers/internal-transfers.md#cancel-transfer)


# Search for Transfers

Search for transfers

```ruby
def search_for_transfers(x_fapi_interaction_id,
                         fdx_api_actor_type: nil,
                         updated_since: nil,
                         offset: nil,
                         limit: nil,
                         search_start_transfer_date: nil,
                         search_end_transfer_date: nil,
                         search_from_account_ids: nil,
                         search_to_account_ids: nil,
                         search_statuses: nil,
                         search_transfer_ids: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updated_since` | `String` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |
| `search_start_transfer_date` | `Date` | Query, Optional | Start time for use in retrieval of transfers by transfer date |
| `search_end_transfer_date` | `Date` | Query, Optional | End time for use in retrieval of transfers by transfer date |
| `search_from_account_ids` | `Array<String>` | Query, Optional | Search for transfers by source account |
| `search_to_account_ids` | `Array<String>` | Query, Optional | Search for transfers by source account |
| `search_statuses` | [`Array<PaymentStatus>`](../../doc/models/payment-status.md) | Query, Optional | Search for transfers by source account |
| `search_transfer_ids` | `Array<String>` | Query, Optional | Search for transfers by id |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TransfersEntity`](../../doc/models/transfers-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

search_start_transfer_date = Date.iso8601('2021-07-15')

search_end_transfer_date = Date.iso8601('2021-07-15')

result = internal_transfers_controller.search_for_transfers(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type,
  search_start_transfer_date: search_start_transfer_date,
  search_end_transfer_date: search_end_transfer_date
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Request Account Transfer

Create a transfer between accounts

```ruby
def request_account_transfer(x_fapi_interaction_id,
                             idempotency_key,
                             fdx_api_actor_type: nil,
                             body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `idempotency_key` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`TransferForCreateEntity1`](../../doc/models/transfer-for-create-entity-1.md) | Body, Optional | Data of the transfer request |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TransferEntity`](../../doc/models/transfer-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

idempotency_key = 'idempotency-key4'

body = TransferForCreateEntity1.new(
  transfer_id: 'MY-TRANSFER-ID',
  from_account_id: 'ACCOUNT-123',
  to_account_id: 'ACCOUNT-456',
  amount: 100,
  memo: 'FDX Transfer Example',
  payment_details: PaymentDetailsEntity.new(
    principal_amount: 75,
    interest_amount: 10,
    insurance_amount: 5,
    escrow_amount: 5,
    pmi_amount: 5,
    fees_amount: 0
  )
)

result = internal_transfers_controller.request_account_transfer(
  x_fapi_interaction_id,
  idempotency_key,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Source account does not have sufficient funds | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Account not authorized for transfer | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested transfer is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate transfer request | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Transfer

Get a transfer been accounts

```ruby
def get_transfer(x_fapi_interaction_id,
                 transfer_id,
                 fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `transfer_id` | `String` | Template, Required | Transfer identifier |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TransferEntity`](../../doc/models/transfer-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

transfer_id = 'transferId8'

fdx_api_actor_type = FdxApiActorType::BATCH

result = internal_transfers_controller.get_transfer(
  x_fapi_interaction_id,
  transfer_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```


# Cancel Transfer

Cancel a transfer between accounts

```ruby
def cancel_transfer(x_fapi_interaction_id,
                    transfer_id,
                    fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `transfer_id` | `String` | Template, Required | Transfer identifier |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TransferEntity`](../../doc/models/transfer-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

transfer_id = 'transferId8'

fdx_api_actor_type = FdxApiActorType::BATCH

result = internal_transfers_controller.cancel_transfer(
  x_fapi_interaction_id,
  transfer_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```

