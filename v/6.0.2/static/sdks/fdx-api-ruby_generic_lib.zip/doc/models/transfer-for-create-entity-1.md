
# Transfer for Create Entity 1

Data of the transfer request

*This model accepts additional fields of type Object.*

## Structure

`TransferForCreateEntity1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transfer_id` | `String` | Optional | Client generated, long-term persistent identity of the transfer action. This ID should be maintained and returned by institution<br><br>**Constraints**: *Maximum Length*: `256` |
| `from_account_id` | `String` | Optional | Long-term persistent identity of the source account<br><br>**Constraints**: *Maximum Length*: `256` |
| `to_account_id` | `String` | Optional | Long-term persistent identity of the destination account<br><br>**Constraints**: *Maximum Length*: `256` |
| `amount` | `Float` | Optional | Positive amount of money to be transferred |
| `memo` | `String` | Optional | User-entered reason for transfer<br><br>**Constraints**: *Maximum Length*: `255` |
| `payment_details` | [`PaymentDetailsEntity`](../../doc/models/payment-details-entity.md) | Optional | Payment details |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "transferId": "transferId8",
  "fromAccountId": "fromAccountId4",
  "toAccountId": "toAccountId0",
  "amount": 112.62,
  "memo": "memo4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

