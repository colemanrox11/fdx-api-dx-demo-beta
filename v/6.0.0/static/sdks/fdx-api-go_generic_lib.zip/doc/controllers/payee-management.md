# Payee Management

```go
payeeManagementController := client.PayeeManagementController()
```

## Class Name

`PayeeManagementController`

## Methods

* [Search for Payees](../../doc/controllers/payee-management.md#search-for-payees)
* [Create Payee](../../doc/controllers/payee-management.md#create-payee)
* [Get Payee](../../doc/controllers/payee-management.md#get-payee)
* [Update Payee](../../doc/controllers/payee-management.md#update-payee)
* [Delete Payee](../../doc/controllers/payee-management.md#delete-payee)


# Search for Payees

Search for payees

```go
SearchForPayees(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    updatedSince *string,
    offset *string,
    limit *int) (
    models.ApiResponse[models.PayeesEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `*string` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayeesEntity](../../doc/models/payees-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch







apiResponse, err := payeeManagementController.SearchForPayees(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "next-offset-123-xyz",
    "prevOffset": "prev-offset-456-abc",
    "totalElements": 100
  },
  "updates": {
    "nextUpdateId": "next-update-id-456-krl"
  },
  "links": {
    "next": {
      "href": "/payees?offset=next-offset-123-xyz"
    },
    "prev": {
      "href": "/payees?offset=prev-offset-456-abc"
    },
    "updates": {
      "href": "/payees?updatedSince=next-update-id-456-krl"
    }
  },
  "payees": [
    {
      "merchant": {
        "displayName": "My Cell Phone Biller",
        "name": {
          "company": "US Cellular"
        },
        "address": {
          "line1": "10 Cellular way",
          "city": "New York",
          "region": "NY",
          "postalCode": "10001"
        },
        "phone": {
          "type": "CELL",
          "country": "+1",
          "number": "2013329944"
        },
        "payeeId": "payee-1001",
        "merchantAccountIds": [
          "999900008888"
        ],
        "status": "ACTIVE",
        "expiresTimestamp": "2025-03-15T13:29:19+0000"
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Create Payee

Create a payee

```go
CreatePayee(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PayeeForUpdateEntity1) (
    models.ApiResponse[models.PayeeEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PayeeForUpdateEntity1`](../../doc/models/payee-for-update-entity-1.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayeeEntity](../../doc/models/payee-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

idempotencyKey := "idempotency-key4"



body := models.PayeeForUpdateEntity1{
    Merchant:              models.MerchantForUpdateEntity1{
        DisplayName:           models.ToPointer("My Cell Phone Biller"),
        Name:                  models.ToPointer(models.CustomerNameEntity{
            First:                 models.ToPointer("Junie"),
            Middle:                models.ToPointer("B"),
            Last:                  models.ToPointer("Jones"),
            Suffix:                models.ToPointer("Jr"),
            Prefix:                models.ToPointer("Ms"),
            Company:               models.ToPointer("US Cellular"),
        }),
        Address:               models.ToPointer(models.DeliveryAddress1{
            Line1:                 models.ToPointer("10 Cellular way"),
            City:                  models.ToPointer("New York"),
            Region:                models.ToPointer("NY"),
            PostalCode:            models.ToPointer("10001"),
        }),
        Phone:                 models.ToPointer(models.TelephoneNumber{
            Type:                  models.ToPointer(models.TelephoneNumberType_Business),
            Country:               models.ToPointer("+1"),
            Number:                models.ToPointer("2013329944"),
        }),
        MerchantAccountIds:    []string{
            "999900008888",
        },
    },
}

apiResponse, err := payeeManagementController.CreatePayee(ctx, xFapiInteractionId, idempotencyKey, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Duplicate Request | [`PayeeEntityErrorException`](../../doc/models/payee-entity-error-exception.md) |


# Get Payee

Get a payee

```go
GetPayee(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    payeeId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PayeeEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `payeeId` | `string` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayeeEntity](../../doc/models/payee-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

payeeId := "payeeId8"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := payeeManagementController.GetPayee(ctx, xFapiInteractionId, payeeId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payee

Used to update an existing payee. The payee type must match the existing payee. This call updates the payee's fields to the values provided. If a field is not provided, the payee's field is not updated

```go
UpdatePayee(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    payeeId string,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PayeeForUpdateEntity) (
    models.ApiResponse[models.PayeeEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `payeeId` | `string` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PayeeForUpdateEntity`](../../doc/models/payee-for-update-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayeeEntity](../../doc/models/payee-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

payeeId := "payeeId8"

idempotencyKey := "idempotency-key4"



body := models.PayeeForUpdateEntity{
    Merchant:              models.MerchantForUpdateEntity1{
        DisplayName:           models.ToPointer("My Business Cell Phone Biller"),
    },
}

apiResponse, err := payeeManagementController.UpdatePayee(ctx, xFapiInteractionId, payeeId, idempotencyKey, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`PayeeEntityErrorException`](../../doc/models/payee-entity-error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payee

Delete a payee

```go
DeletePayee(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    payeeId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PayeeEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `payeeId` | `string` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PayeeEntity](../../doc/models/payee-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

payeeId := "payeeId8"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := payeeManagementController.DeletePayee(ctx, xFapiInteractionId, payeeId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "status": "DELETED"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Payee cannot be modified or deleted | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

