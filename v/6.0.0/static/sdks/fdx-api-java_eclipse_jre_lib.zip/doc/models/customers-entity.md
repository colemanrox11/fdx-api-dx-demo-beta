
# Customers Entity

List of customers

*This model accepts additional fields of type Object.*

## Structure

`CustomersEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Information required to paginate results | PageMetadata getPage() | setPage(PageMetadata page) |
| `Links` | [`PageMetadataLinks1`](../../doc/models/page-metadata-links-1.md) | Optional | Links used to paginate results | PageMetadataLinks1 getLinks() | setLinks(PageMetadataLinks1 links) |
| `Customers` | [`List<CustomerEntity>`](../../doc/models/customer-entity.md) | Optional | Array of customers | List<CustomerEntity> getCustomers() | setCustomers(List<CustomerEntity> customers) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "customers": [
    {
      "emails": [
        "emails1",
        "emails2"
      ],
      "addresses": [
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "telephones": [
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "dateOfBirth": "2016-03-13",
      "taxId": "taxId8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

