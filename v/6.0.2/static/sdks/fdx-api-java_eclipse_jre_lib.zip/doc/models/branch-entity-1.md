
# Branch Entity 1

Branch details associated with this account

*This model accepts additional fields of type Object.*

## Structure

`BranchEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BranchId` | `String` | Optional | Branch number | String getBranchId() | setBranchId(String branchId) |
| `Name` | `String` | Optional | Name of the branch | String getName() | setName(String name) |
| `Locations` | [`List<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Location of the branch | List<PaymentDeliveryAddressEntity> getLocations() | setLocations(List<PaymentDeliveryAddressEntity> locations) |
| `FinancialInstitution` | [`FinancialInstitutionEntity2`](../../doc/models/financial-institution-entity-2.md) | Optional | Financial institution associated with the branch | FinancialInstitutionEntity2 getFinancialInstitution() | setFinancialInstitution(FinancialInstitutionEntity2 financialInstitution) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "branchId": "branchId2",
  "name": "name0",
  "locations": [
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "financialInstitution": {
    "name": "name0",
    "fiId": {
      "bicFIDec2014Id": "bicFIDec2014Id2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "locations": [
      {
        "type": "HOME",
        "address": {
          "emailAddressText": "emailAddressText4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "HOME",
        "address": {
          "emailAddressText": "emailAddressText4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

