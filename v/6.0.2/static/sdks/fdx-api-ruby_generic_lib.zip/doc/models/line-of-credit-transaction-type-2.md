
# Line of Credit Transaction Type 2

CHECK, WITHDRAWAL, PAYMENT, FEE, ADJUSTMENT, INTEREST, PURCHASE

*This model accepts additional fields of type Object.*

## Enumeration

`LineOfCreditTransactionType2`

## Fields

| Name |
|  --- |
| `ADJUSTMENT` |
| `CHECK` |
| `FEE` |
| `INTEREST` |
| `PAYMENT` |
| `PURCHASE` |
| `WITHDRAWAL` |

