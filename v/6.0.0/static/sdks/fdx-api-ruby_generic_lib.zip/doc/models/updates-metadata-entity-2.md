
# Updates Metadata Entity 2

Update IDs for retrieving updates since query

*This model accepts additional fields of type Object.*

## Structure

`UpdatesMetadataEntity2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_update_id` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "nextUpdateId": "nextUpdateId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

