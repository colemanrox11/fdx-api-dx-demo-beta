
# Account Status

The status of an account

*This model accepts additional fields of type Object.*

## Enumeration

`AccountStatus`

## Fields

| Name |
|  --- |
| `CLOSED` |
| `DELINQUENT` |
| `NEGATIVECURRENTBALANCE` |
| `OPEN` |
| `PAID` |
| `PENDINGCLOSE` |
| `PENDINGOPEN` |
| `RESTRICTED` |

