
# Bills Entity

The payments due on an account

*This model accepts additional fields of type Object.*

## Structure

`BillsEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total_payment_due` | `Float` | Optional | Total payment due or next payment due.  Monthly payment due for loans |
| `minimum_payment_due` | `Float` | Optional | The minimum amount which is due |
| `due_date` | `Date` | Optional | The date that the payment is due |
| `auto_pay_enabled` | `TrueClass \| FalseClass` | Optional | Whether the user's bill is paid automatically |
| `auto_pay_amount` | `Float` | Optional | The amount of money the user has set to autopay this bill |
| `auto_pay_date` | `Date` | Optional | The date the autopayment is set to trigger for this bill |
| `past_due_amount` | `Float` | Optional | The amount that the user should have already paid. The value is negative if user owes money |
| `last_payment_amount` | `Float` | Optional | The amount of the most recent payment |
| `last_payment_date` | `Date` | Optional | The date of most recent payment |
| `statement_balance` | `Float` | Optional | The amount of the last statement.  The value is negative if the user owes money |
| `statement_date` | `Date` | Optional | The date the statement was issued |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "dueDate": "2021-07-15",
  "autoPayDate": "2021-07-15",
  "lastPaymentDate": "2021-07-15",
  "statementDate": "2021-07-15",
  "totalPaymentDue": 96.96,
  "minimumPaymentDue": 121.4,
  "autoPayEnabled": false,
  "autoPayAmount": 131.44,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

