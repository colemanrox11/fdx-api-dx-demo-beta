
# Currency Entity 2

Currency if different from that of account

*This model accepts additional fields of type Object.*

## Structure

`CurrencyEntity2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency_rate` | `Float` | Optional | Currency rate between original and converted currency |
| `currency_code` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | ISO 4217 currency code |
| `original_currency_code` | [`Iso4217CurrencyCode1`](../../doc/models/iso-4217-currency-code-1.md) | Optional | Original ISO 4217 currency code |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "currencyRate": 13.12,
  "currencyCode": "IDR",
  "originalCurrencyCode": "AMD",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

