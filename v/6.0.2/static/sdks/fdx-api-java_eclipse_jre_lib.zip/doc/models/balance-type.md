
# Balance Type

Type of balance for the account.

* `ASSET`: Positive transaction amount increases balance
* `LIABILITY`: Positive transaction amount decreases balance

*This model accepts additional fields of type Object.*

## Enumeration

`BalanceType`

## Fields

| Name |
|  --- |
| `Asset` |
| `Liability` |

