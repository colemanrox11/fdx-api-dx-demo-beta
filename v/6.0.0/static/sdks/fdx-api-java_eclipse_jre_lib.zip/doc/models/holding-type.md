
# Holding Type

The type of an investment holding

| Value | Description |
|-----|-----|
| ANNUITY | Financial product that pays out a fixed stream of payments |
| BOND | Debt security as a loan to a government, agency or company, repaid with interest |
| CD | Certificate of Deposit, a savings account with a fixed rate and term |
| DIGITALASSET | Digital representation of an asset or right that is stored and transferred on a digital network such as the internet or a blockchain |
| MUTUALFUND | Pooled collection of assets invested in stocks, bonds, and other securities |
| OPTION | The right to buy a specific number of stock shares at a pre-set price |
| OTHER | Another type of holding not listed here |
| STOCK | A share in the ownership of a company |

*This model accepts additional fields of type Object.*

## Enumeration

`HoldingType`

## Fields

| Name |
|  --- |
| `Annuity` |
| `Bond` |
| `Cd` |
| `Digitalasset` |
| `Mutualfund` |
| `Option` |
| `Other` |
| `Stock` |

