
# Fdx Resource Operation Id 1

Operation ID (e.g. name) of this API

*This model accepts additional fields of type Object.*

## Enumeration

`FdxResourceOperationId1`

## Fields

| Name |
|  --- |
| `GetConsentGrant` |
| `GetConsentRevocation` |
| `RevokeConsentGrant` |
| `GetAccount` |
| `GetAccountAssetTransferNetworks` |
| `GetAccountContact` |
| `GetAccountPaymentNetworks` |
| `GetAccountStatement` |
| `GetAccountTransactionImages` |
| `GetRewardProgram` |
| `GetRewardProgramCategories` |
| `SearchForAccounts` |
| `SearchForAccountStatements` |
| `SearchForAccountTransactions` |
| `SearchRewardPrograms` |
| `GetCustomer` |
| `GetCustomerInfo` |
| `GetCustomers` |
| `CreateNotificationSubscription` |
| `DeleteNotificationSubscription` |
| `GetNotifications` |
| `GetNotificationSubscription` |
| `PublishNotification` |
| `ReportSuspectedFraudIncident` |
| `GetAvailability` |
| `GetCapability` |
| `GetCertificationMetrics` |
| `CancelPayment` |
| `CancelRecurringPayment` |
| `CancelTransfer` |
| `CreatePayee` |
| `CreatePaymentInitiationParty` |
| `CreatePaymentMethod` |
| `DeletePayee` |
| `DeletePaymentInitiationParty` |
| `DeletePaymentMethodRegistration` |
| `GetPayee` |
| `GetPayment` |
| `GetPaymentInitiationParty` |
| `GetPaymentMethodRegistration` |
| `GetPaymentsForRecurringPayment` |
| `GetRecurringPayment` |
| `GetTransfer` |
| `ListPaymentInitiationParties` |
| `RequestAccountTransfer` |
| `SchedulePayment` |
| `ScheduleRecurringPayment` |
| `SearchForPayees` |
| `SearchForPayments` |
| `SearchForRecurringPayments` |
| `SearchForTransfers` |
| `UpdatePayee` |
| `UpdatePayment` |
| `UpdatePaymentInitiationParty` |
| `UpdatePaymentMethodRegistration` |
| `UpdateRecurringPayment` |
| `GetPayrollReport` |
| `GetPayrollReports` |
| `CreateRecipient` |
| `DeleteRecipient` |
| `GetRecipient` |
| `UpdateRecipient` |
| `GetRegistryRecipient` |
| `GetRegistryRecipients` |
| `CreateTaxForm` |
| `GetTaxForm` |
| `SearchForTaxForms` |
| `UpdateTaxForm` |
| `GetResource` |
| `GetResources` |

