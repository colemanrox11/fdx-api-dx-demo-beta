
# Notification Subscription Entity

Provides the fields of a notification subscription

*This model accepts additional fields of type Object.*

## Structure

`NotificationSubscriptionEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`NotificationType`](../../doc/models/notification-type.md) | Required | Type of notification | NotificationType getType() | setType(NotificationType type) |
| `Category` | [`NotificationCategory1`](../../doc/models/notification-category-1.md) | Required | Category of notification | NotificationCategory1 getCategory() | setCategory(NotificationCategory1 category) |
| `CallbackUrl` | `String` | Required | Callback URL. Previous callback URL will be updated with latest. | String getCallbackUrl() | setCallbackUrl(String callbackUrl) |
| `Subscriber` | [`PartyEntity`](../../doc/models/party-entity.md) | Required | The Party who is subscribing to the notification | PartyEntity getSubscriber() | setSubscriber(PartyEntity subscriber) |
| `EffectiveDate` | `LocalDate` | Optional | Effective date of notification | LocalDate getEffectiveDate() | setEffectiveDate(LocalDate effectiveDate) |
| `SubscriptionId` | `String` | Optional | Subscription id of notification | String getSubscriptionId() | setSubscriptionId(String subscriptionId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "BALANCE",
  "category": "CONSENT",
  "callbackUrl": "callbackUrl6",
  "subscriber": {
    "name": "name0",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "homeUri4",
    "logoUri": "logoUri8",
    "registry": "FDX",
    "registeredEntityName": "registeredEntityName8",
    "registeredEntityId": "registeredEntityId0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "effectiveDate": "2021-07-15",
  "subscriptionId": "subscriptionId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

