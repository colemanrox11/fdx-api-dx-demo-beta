# Submit Tax Forms

```go
submitTaxFormsController := client.SubmitTaxFormsController()
```

## Class Name

`SubmitTaxFormsController`

## Methods

* [Create Tax Form](../../doc/controllers/submit-tax-forms.md#create-tax-form)
* [Update Tax Form](../../doc/controllers/submit-tax-forms.md#update-tax-form)


# Create Tax Form

Submit the data for a specific tax document

```go
CreateTaxForm(
    ctx context.Context,
    authorization string,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    body *models.TaxStatement1) (
    models.ApiResponse[models.TaxStatement2],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `string` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.TaxStatement1`](../../doc/models/tax-statement-1.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.TaxStatement2](../../doc/models/tax-statement-2.md).

## Example Usage

```go
ctx := context.Background()

authorization := "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

body := models.TaxStatement1{
    TaxYear:               models.ToPointer(2023),
}

apiResponse, err := submitTaxFormsController.CreateTaxForm(ctx, authorization, xFapiInteractionId, &fdxApiActorType, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Tax Form type is not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Tax Form

Update tax document. Allows you to upload and replace binaries or json document

```go
UpdateTaxForm(
    ctx context.Context,
    taxFormId string,
    authorization string,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    body *models.TaxStatement6) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `taxFormId` | `string` | Template, Required | The unique ID for this tax form or tax statement<br><br>**Constraints**: *Maximum Length*: `256` |
| `authorization` | `string` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.TaxStatement6`](../../doc/models/tax-statement-6.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

taxFormId := "taxFormId2"

authorization := "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

body := models.TaxStatement6{
    TaxYear:               models.ToPointer(2023),
}

resp, err := submitTaxFormsController.UpdateTaxForm(ctx, taxFormId, authorization, xFapiInteractionId, &fdxApiActorType, &body)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 415 | Server does not support the content type uploaded | [`ErrorException`](../../doc/models/error-exception.md) |

