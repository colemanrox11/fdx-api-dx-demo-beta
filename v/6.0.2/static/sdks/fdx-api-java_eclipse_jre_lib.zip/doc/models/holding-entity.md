
# Holding Entity

A holding in an investment account

*This model accepts additional fields of type Object.*

## Structure

`HoldingEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `HoldingId` | `String` | Optional | Long term persistent identity of the holding<br><br>**Constraints**: *Maximum Length*: `256` | String getHoldingId() | setHoldingId(String holdingId) |
| `SecurityIds` | [`List<SecurityIdEntity>`](../../doc/models/security-id-entity.md) | Optional | Unique identifiers for the security | List<SecurityIdEntity> getSecurityIds() | setSecurityIds(List<SecurityIdEntity> securityIds) |
| `HoldingName` | `String` | Optional | Holding name or security name | String getHoldingName() | setHoldingName(String holdingName) |
| `HoldingType` | [`HoldingType2`](../../doc/models/holding-type-2.md) | Optional | ANNUITY, BOND, CD, DIGITALASSET, MUTUALFUND, OPTION, OTHER, STOCK | HoldingType2 getHoldingType() | setHoldingType(HoldingType2 holdingType) |
| `HoldingSubType` | [`HoldingSubType2`](../../doc/models/holding-sub-type-2.md) | Optional | MONEYMARKET, CASH | HoldingSubType2 getHoldingSubType() | setHoldingSubType(HoldingSubType2 holdingSubType) |
| `PositionType` | [`PositionType1`](../../doc/models/position-type-1.md) | Optional | LONG, SHORT | PositionType1 getPositionType() | setPositionType(PositionType1 positionType) |
| `HeldInAccount` | [`HeldInAccount2`](../../doc/models/held-in-account-2.md) | Optional | Sub-account CASH, MARGIN, SHORT, OTHER | HeldInAccount2 getHeldInAccount() | setHeldInAccount(HeldInAccount2 heldInAccount) |
| `Description` | `String` | Optional | The description of the holding | String getDescription() | setDescription(String description) |
| `Symbol` | `String` | Optional | Ticker / Market symbol | String getSymbol() | setSymbol(String symbol) |
| `OriginalPurchaseDate` | `LocalDate` | Optional | Date of original purchase | LocalDate getOriginalPurchaseDate() | setOriginalPurchaseDate(LocalDate originalPurchaseDate) |
| `PurchasedPrice` | `Double` | Optional | Price of holding at the time of purchase | Double getPurchasedPrice() | setPurchasedPrice(Double purchasedPrice) |
| `CurrentAmortizationFactor` | `Double` | Optional | Ranges from 0.0 - 1.0 indicates the adjustment to the calculation of the market value. 'currentUnitPrice * quantity * currentAmortizationFactor =  marketValue'<br><br>**Default**: `1d`<br><br>**Constraints**: `>= 0`, `<= 1` | Double getCurrentAmortizationFactor() | setCurrentAmortizationFactor(Double currentAmortizationFactor) |
| `CurrentUnitPrice` | `Double` | Optional | Current unit price | Double getCurrentUnitPrice() | setCurrentUnitPrice(Double currentUnitPrice) |
| `ChangeInPrice` | `Double` | Optional | Change in current price compared to previous day's close | Double getChangeInPrice() | setChangeInPrice(Double changeInPrice) |
| `CurrentUnitPriceDate` | `LocalDate` | Optional | Current unit price as of date | LocalDate getCurrentUnitPriceDate() | setCurrentUnitPriceDate(LocalDate currentUnitPriceDate) |
| `Units` | `Double` | Optional | Required for stock, mutual funds. Number of shares (with decimals) | Double getUnits() | setUnits(Double units) |
| `MarketValue` | `Double` | Optional | Market value at the time of data retrieved | Double getMarketValue() | setMarketValue(Double marketValue) |
| `FaceValue` | `Double` | Optional | Required for bonds. Face value at the time of data retrieved | Double getFaceValue() | setFaceValue(Double faceValue) |
| `AverageCost` | `Boolean` | Optional | Cost is average of all purchases for holding | Boolean getAverageCost() | setAverageCost(Boolean averageCost) |
| `CashAccount` | `Boolean` | Optional | If true, indicates that this holding is used to maintain proceeds from sales, dividends, and other cash postings to the investment account | Boolean getCashAccount() | setCashAccount(Boolean cashAccount) |
| `Rate` | `Double` | Optional | For CDs, bonds, and other rate based holdings | Double getRate() | setRate(Double rate) |
| `ExpirationDate` | `LocalDate` | Optional | For CDs, bonds, and other time-based holdings | LocalDate getExpirationDate() | setExpirationDate(LocalDate expirationDate) |
| `Inv401KSource` | [`Investment401KSourceType4`](../../doc/models/investment-401-k-source-type-4.md) | Optional | Source for money for this security. One of PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST | Investment401KSourceType4 getInv401KSource() | setInv401KSource(Investment401KSourceType4 inv401KSource) |
| `Currency` | [`CurrencyEntity1`](../../doc/models/currency-entity-1.md) | Optional | Currency information if it is different from Account entity | CurrencyEntity1 getCurrency() | setCurrency(CurrencyEntity1 currency) |
| `AssetClasses` | [`List<PortionEntity>`](../../doc/models/portion-entity.md) | Optional | Percent breakdown by asset class | List<PortionEntity> getAssetClasses() | setAssetClasses(List<PortionEntity> assetClasses) |
| `FiAssetClasses` | [`List<FiPortionEntity>`](../../doc/models/fi-portion-entity.md) | Optional | Percent breakdown by FI-specific asset class percentage breakdown | List<FiPortionEntity> getFiAssetClasses() | setFiAssetClasses(List<FiPortionEntity> fiAssetClasses) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `TaxLots` | [`List<TaxLotEntity>`](../../doc/models/tax-lot-entity.md) | Optional | Breakdown by tax lot | List<TaxLotEntity> getTaxLots() | setTaxLots(List<TaxLotEntity> taxLots) |
| `DigitalUnits` | `String` | Optional | Specify units to full precision with unlimited digits after decimal point | String getDigitalUnits() | setDigitalUnits(String digitalUnits) |
| `Security` | [`HoldingEntitySecurity`](../../doc/models/containers/holding-entity-security.md) | Optional | This is a container for any-of cases. | HoldingEntitySecurity getSecurity() | setSecurity(HoldingEntitySecurity security) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "originalPurchaseDate": "2021-07-15",
  "currentAmortizationFactor": 1,
  "currentUnitPriceDate": "2021-07-15",
  "expirationDate": "2021-07-15",
  "holdingId": "holdingId0",
  "securityIds": [
    {
      "id": "id6",
      "idType": "CINS",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "holdingName": "holdingName6",
  "holdingType": "ANNUITY",
  "holdingSubType": "CASH",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

