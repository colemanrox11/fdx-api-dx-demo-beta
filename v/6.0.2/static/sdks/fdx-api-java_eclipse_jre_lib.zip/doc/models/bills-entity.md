
# Bills Entity

The payments due on an account

*This model accepts additional fields of type Object.*

## Structure

`BillsEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TotalPaymentDue` | `Double` | Optional | Total payment due or next payment due.  Monthly payment due for loans | Double getTotalPaymentDue() | setTotalPaymentDue(Double totalPaymentDue) |
| `MinimumPaymentDue` | `Double` | Optional | The minimum amount which is due | Double getMinimumPaymentDue() | setMinimumPaymentDue(Double minimumPaymentDue) |
| `DueDate` | `LocalDate` | Optional | The date that the payment is due | LocalDate getDueDate() | setDueDate(LocalDate dueDate) |
| `AutoPayEnabled` | `Boolean` | Optional | Whether the user's bill is paid automatically | Boolean getAutoPayEnabled() | setAutoPayEnabled(Boolean autoPayEnabled) |
| `AutoPayAmount` | `Double` | Optional | The amount of money the user has set to autopay this bill | Double getAutoPayAmount() | setAutoPayAmount(Double autoPayAmount) |
| `AutoPayDate` | `LocalDate` | Optional | The date the autopayment is set to trigger for this bill | LocalDate getAutoPayDate() | setAutoPayDate(LocalDate autoPayDate) |
| `PastDueAmount` | `Double` | Optional | The amount that the user should have already paid. The value is negative if user owes money | Double getPastDueAmount() | setPastDueAmount(Double pastDueAmount) |
| `LastPaymentAmount` | `Double` | Optional | The amount of the most recent payment | Double getLastPaymentAmount() | setLastPaymentAmount(Double lastPaymentAmount) |
| `LastPaymentDate` | `LocalDate` | Optional | The date of most recent payment | LocalDate getLastPaymentDate() | setLastPaymentDate(LocalDate lastPaymentDate) |
| `StatementBalance` | `Double` | Optional | The amount of the last statement.  The value is negative if the user owes money | Double getStatementBalance() | setStatementBalance(Double statementBalance) |
| `StatementDate` | `LocalDate` | Optional | The date the statement was issued | LocalDate getStatementDate() | setStatementDate(LocalDate statementDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dueDate": "2021-07-15",
  "autoPayDate": "2021-07-15",
  "lastPaymentDate": "2021-07-15",
  "statementDate": "2021-07-15",
  "totalPaymentDue": 96.96,
  "minimumPaymentDue": 121.4,
  "autoPayEnabled": false,
  "autoPayAmount": 131.44,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

