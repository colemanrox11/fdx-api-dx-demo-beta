
# Sub Account Type 4

CASH, MARGIN, SHORT, OTHER

*This model accepts additional fields of type interface{}.*

## Enumeration

`SubAccountType4`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `Other` |
| `Short` |

