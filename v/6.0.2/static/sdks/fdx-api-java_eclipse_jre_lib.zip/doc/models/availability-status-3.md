
# Availability Status 3

Status of API availability

*This model accepts additional fields of type Object.*

## Enumeration

`AvailabilityStatus3`

## Fields

| Name |
|  --- |
| `Alive` |
| `Partial` |
| `Maintenance` |
| `Down` |

