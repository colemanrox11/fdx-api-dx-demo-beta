
# Generic Account Identification Entity

Generic account identifier entity

*This model accepts additional fields of type Object.*

## Structure

`GenericAccountIdentificationEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Account identifier<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `IssuerName` | `String` | Optional | Name of the issuer | String getIssuerName() | setIssuerName(String issuerName) |
| `IdScheme` | [`GenericAccountIdentificationEntityIdScheme`](../../doc/models/containers/generic-account-identification-entity-id-scheme.md) | Optional | This is a container for any-of cases. | GenericAccountIdentificationEntityIdScheme getIdScheme() | setIdScheme(GenericAccountIdentificationEntityIdScheme idScheme) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountId": "accountId4",
  "issuerName": "issuerName8",
  "idScheme": {
    "idCode": "idCode2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

