
# Basic Auth Credentials 1

The Basic Authentication credentials to retrieve a tax form

*This model accepts additional fields of type Object.*

## Structure

`BasicAuthCredentials1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_year` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `tax_form_type` | [`TypeFormType1`](../../doc/models/type-form-type-1.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" |
| `id` | `String` | Optional | Confidential and unique identifier of the tax form<br><br>**Constraints**: *Maximum Length*: `256` |
| `passcode` | `String` | Optional | Unique, randomized and restricted password for this document<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormType": "Tax1099H",
  "id": "id0",
  "passcode": "passcode4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

