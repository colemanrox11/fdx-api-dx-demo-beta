
# Notification Category

Category of Notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationCategory`

## Fields

| Name |
|  --- |
| `CONSENT` |
| `FRAUD` |
| `MAINTENANCE` |
| `NEW_DATA` |
| `SECURITY` |

