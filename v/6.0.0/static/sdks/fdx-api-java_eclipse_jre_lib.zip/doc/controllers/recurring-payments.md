# Recurring Payments

```java
RecurringPaymentsController recurringPaymentsController = client.getRecurringPaymentsController();
```

## Class Name

`RecurringPaymentsController`

## Methods

* [Search for Recurring Payments](../../doc/controllers/recurring-payments.md#search-for-recurring-payments)
* [Schedule Recurring Payment](../../doc/controllers/recurring-payments.md#schedule-recurring-payment)
* [Get Recurring Payment](../../doc/controllers/recurring-payments.md#get-recurring-payment)
* [Update Recurring Payment](../../doc/controllers/recurring-payments.md#update-recurring-payment)
* [Cancel Recurring Payment](../../doc/controllers/recurring-payments.md#cancel-recurring-payment)
* [Get Payments for Recurring Payment](../../doc/controllers/recurring-payments.md#get-payments-for-recurring-payment)


# Search for Recurring Payments

Search for recurring payments

```java
CompletableFuture<ApiResponse<RecurringPaymentsEntity>> searchForRecurringPaymentsAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final String updatedSince,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `String` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RecurringPaymentsEntity`](../../doc/models/recurring-payments-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

recurringPaymentsController.searchForRecurringPaymentsAsync(xFapiInteractionId, fdxApiActorType, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "next-offset-123-xyz",
    "prevOffset": "prev-offset-456-abc",
    "totalElements": 100
  },
  "updates": {
    "nextUpdateId": "next-update-id-456-krl"
  },
  "links": {
    "next": {
      "href": "/recurring-payments?offset=next-offset-123-xyz"
    },
    "prev": {
      "href": "/recurring-payments?offset=prev-offset-456-abc"
    },
    "updates": {
      "href": "/recurring-payments?updatedSince=next-update-id-456-krl"
    }
  },
  "recurringPayments": [
    {
      "frequency": "MONTHLY",
      "duration": {
        "type": "NUMBEROFTIMES",
        "numberOfTimes": 12
      },
      "fromAccountId": "ACCOUNT-123",
      "toPayeeId": "PAYEE-ABC",
      "amount": 10.99,
      "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
      "dueDate": "2021-08-17",
      "recurringPaymentId": "RECURRING-PAYMENT-485",
      "cancelledTimestamp": "2021-03-14T13:29:19+0000",
      "status": "CANCELLED"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Schedule Recurring Payment

Schedule a recurring payment

```java
CompletableFuture<ApiResponse<RecurringPaymentEntity>> scheduleRecurringPaymentAsync(
    final UUID xFapiInteractionId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final RecurringPaymentForUpdateEntity1 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`RecurringPaymentForUpdateEntity1`](../../doc/models/recurring-payment-for-update-entity-1.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RecurringPaymentEntity`](../../doc/models/recurring-payment-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String idempotencyKey = "idempotency-key4";
RecurringPaymentForUpdateEntity1 body = new RecurringPaymentForUpdateEntity1.Builder(
    RecurringPaymentFrequency2.MONTHLY,
    "ACCOUNT-123",
    "PAYEE-ABC",
    10.99D,
    DateTimeHelper.fromSimpleDate("2021-08-17")
)
.duration(new RecurringPaymentDurationEntity2.Builder(
        RecurringPaymentDurationType2.NUMBEROFTIMES
    )
    .numberOfTimes(12D)
    .build())
.merchantAccountId("MERCHANT-ACCOUNT-ID-0001")
.build();

recurringPaymentsController.scheduleRecurringPaymentAsync(xFapiInteractionId, idempotencyKey, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "frequency": "MONTHLY",
  "duration": {
    "type": "NUMBEROFTIMES",
    "numberOfTimes": 12
  },
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "status": "SCHEDULED"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Request is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested payment is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`RecurringPaymentEntityErrorException`](../../doc/models/recurring-payment-entity-error-exception.md) |
| 422 | Account type not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Recurring Payment

Get a recurring payment

```java
CompletableFuture<ApiResponse<RecurringPaymentEntity>> getRecurringPaymentAsync(
    final UUID xFapiInteractionId,
    final String recurringPaymentId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `recurringPaymentId` | `String` | Template, Required | Recurring Payment Identifier. Uniquely identifies a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RecurringPaymentEntity`](../../doc/models/recurring-payment-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String recurringPaymentId = "recurringPaymentId2";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

recurringPaymentsController.getRecurringPaymentAsync(xFapiInteractionId, recurringPaymentId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "frequency": "MONTHLY",
  "duration": {
    "type": "NUMBEROFTIMES",
    "numberOfTimes": 12
  },
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "status": "SCHEDULED"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | A recurring payment with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Recurring Payment

Update a recurring payment

```java
CompletableFuture<ApiResponse<RecurringPaymentEntity>> updateRecurringPaymentAsync(
    final UUID xFapiInteractionId,
    final String recurringPaymentId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final RecurringPaymentForUpdateEntity2 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `recurringPaymentId` | `String` | Template, Required | Recurring Payment Identifier. Uniquely identifies a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`RecurringPaymentForUpdateEntity2`](../../doc/models/recurring-payment-for-update-entity-2.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RecurringPaymentEntity`](../../doc/models/recurring-payment-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String recurringPaymentId = "recurringPaymentId2";
String idempotencyKey = "idempotency-key4";
RecurringPaymentForUpdateEntity2 body = new RecurringPaymentForUpdateEntity2.Builder(
    RecurringPaymentFrequency2.MONTHLY,
    "ACCOUNT-890",
    "PAYEE-XYZ",
    5D,
    DateTimeHelper.fromSimpleDate("2021-08-30")
)
.duration(new RecurringPaymentDurationEntity2.Builder(
        RecurringPaymentDurationType2.NUMBEROFTIMES
    )
    .numberOfTimes(12D)
    .build())
.build();

recurringPaymentsController.updateRecurringPaymentAsync(xFapiInteractionId, recurringPaymentId, idempotencyKey, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "frequency": "MONTHLY",
  "duration": {
    "type": "NUMBEROFTIMES",
    "numberOfTimes": 12
  },
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "status": "SCHEDULED"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Request is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested recurring payment change is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`RecurringPaymentEntityErrorException`](../../doc/models/recurring-payment-entity-error-exception.md) |
| 422 | Account type not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Cancel Recurring Payment

Cancel a recurring payment

```java
CompletableFuture<ApiResponse<RecurringPaymentEntity>> cancelRecurringPaymentAsync(
    final UUID xFapiInteractionId,
    final String recurringPaymentId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `recurringPaymentId` | `String` | Template, Required | Recurring Payment Identifier. Uniquely identifies a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RecurringPaymentEntity`](../../doc/models/recurring-payment-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String recurringPaymentId = "recurringPaymentId2";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

recurringPaymentsController.cancelRecurringPaymentAsync(xFapiInteractionId, recurringPaymentId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "frequency": "MONTHLY",
  "duration": {
    "type": "NUMBEROFTIMES",
    "numberOfTimes": 12
  },
  "fromAccountId": "ACCOUNT-123",
  "toPayeeId": "PAYEE-ABC",
  "amount": 10.99,
  "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
  "dueDate": "2021-08-17",
  "recurringPaymentId": "RECURRING-PAYMENT-485",
  "cancelledTimestamp": "2021-03-14T13:29:19+0000",
  "status": "CANCELLED"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Recurring payment cannot be modified or cancelled at this time. Likely due to the state that it is in | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | A recurring payment with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payments for Recurring Payment

Search for payments associated with the recurring payment

```java
CompletableFuture<ApiResponse<PaymentsEntity>> getPaymentsForRecurringPaymentAsync(
    final UUID xFapiInteractionId,
    final String recurringPaymentId,
    final FdxApiActorType fdxApiActorType,
    final String updatedSince,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `recurringPaymentId` | `String` | Template, Required | Recurring Payment Identifier. Uniquely identifies a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `String` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaymentsEntity`](../../doc/models/payments-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String recurringPaymentId = "recurringPaymentId2";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

recurringPaymentsController.getPaymentsForRecurringPaymentAsync(xFapiInteractionId, recurringPaymentId, fdxApiActorType, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "next-offset-123-xyz",
    "prevOffset": "prev-offset-456-abc",
    "totalElements": 100
  },
  "updates": {
    "nextUpdateId": "next-update-id-456-krl"
  },
  "links": {
    "next": {
      "href": "/recurring-payment/RECURRING-PAYMENT-485/payments?offset=next-offset-123-xyz"
    },
    "prev": {
      "href": "/recurring-payment/RECURRING-PAYMENT-485/payments?offset=prev-offset-456-abc"
    },
    "updates": {
      "href": "/recurring-payment/RECURRING-PAYMENT-485/payments?updatedSince=next-update-id-456-krl"
    }
  },
  "payments": [
    {
      "fromAccountId": "ACCOUNT-123",
      "toPayeeId": "PAYEE-ABC",
      "amount": 10.99,
      "merchantAccountId": "MERCHANT-ACCOUNT-ID-0001",
      "dueDate": "2021-08-17",
      "paymentId": "PAYMENT-213",
      "recurringPaymentId": "RECURRING-PAYMENT-485",
      "processedTimestamp": "2021-03-15T13:29:19+0000",
      "startedProcessingTimestamp": "2021-03-14T13:29:19+0000",
      "status": "PROCESSED",
      "links": [
        {
          "href": "/recurring-payment/RECURRING-PAYMENT-458",
          "rel": "recurringPayment"
        }
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | A recurring payment with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

