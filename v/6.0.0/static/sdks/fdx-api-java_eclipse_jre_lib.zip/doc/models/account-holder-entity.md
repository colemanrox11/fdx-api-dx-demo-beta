
# Account Holder Entity

Extends `Customer` and adds a `relationship` field to define the customer's relationship with an account

*This model accepts additional fields of type Object.*

## Structure

`AccountHolderEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | Array of the contact email addresses | List<String> getEmails() | setEmails(List<String> emails) |
| `Addresses` | [`List<DeliveryAddress>`](../../doc/models/delivery-address.md) | Optional | Array of the contact physical addresses | List<DeliveryAddress> getAddresses() | setAddresses(List<DeliveryAddress> addresses) |
| `Telephones` | [`List<TelephoneNumber>`](../../doc/models/telephone-number.md) | Optional | Array of the contact telephone numbers | List<TelephoneNumber> getTelephones() | setTelephones(List<TelephoneNumber> telephones) |
| `DateOfBirth` | `LocalDate` | Optional | The person's date of birth | LocalDate getDateOfBirth() | setDateOfBirth(LocalDate dateOfBirth) |
| `TaxId` | `String` | Optional | Country specific Tax Id associated with this customer (SIN or NAS in Canada, SSN or TIN in US, etc.) | String getTaxId() | setTaxId(String taxId) |
| `TaxIdCountry` | [`Iso3166CountryCode1`](../../doc/models/iso-3166-country-code-1.md) | Optional | Country originating the Customer's taxId element | Iso3166CountryCode1 getTaxIdCountry() | setTaxIdCountry(Iso3166CountryCode1 taxIdCountry) |
| `GovernmentId` | `String` | Optional | A federal (such as passport) or state (such as driver's license) issued identifier | String getGovernmentId() | setGovernmentId(String governmentId) |
| `CustomerId` | `String` | Optional | Long-term persistent identity of the customer. This identity must be unique to the owning institution<br><br>**Constraints**: *Maximum Length*: `256` | String getCustomerId() | setCustomerId(String customerId) |
| `Type` | [`BusinessOrConsumerType`](../../doc/models/business-or-consumer-type.md) | Optional | Type of entity. One of BUSINESS or CONSUMER | BusinessOrConsumerType getType() | setType(BusinessOrConsumerType type) |
| `Name` | [`CustomerNameEntity`](../../doc/models/customer-name-entity.md) | Optional | The customer's name | CustomerNameEntity getName() | setName(CustomerNameEntity name) |
| `BusinessCustomer` | [`BusinessCustomerEntity`](../../doc/models/business-customer-entity.md) | Optional | The business customer information, only used if 'type' is 'BUSINESS'. | BusinessCustomerEntity getBusinessCustomer() | setBusinessCustomer(BusinessCustomerEntity businessCustomer) |
| `CustomerStartDate` | `LocalDate` | Optional | The customer's start date at the financial institution | LocalDate getCustomerStartDate() | setCustomerStartDate(LocalDate customerStartDate) |
| `LastActivityDate` | `LocalDate` | Optional | The customer's date of last account activity at the financial institution | LocalDate getLastActivityDate() | setLastActivityDate(LocalDate lastActivityDate) |
| `Accounts` | [`List<CustomerToAccountRelationshipEntity>`](../../doc/models/customer-to-account-relationship-entity.md) | Optional | List of accounts related to this customer | List<CustomerToAccountRelationshipEntity> getAccounts() | setAccounts(List<CustomerToAccountRelationshipEntity> accounts) |
| `Relationship` | [`AccountHolderRelationship1`](../../doc/models/account-holder-relationship-1.md) | Optional | Customer's relationship to the account | AccountHolderRelationship1 getRelationship() | setRelationship(AccountHolderRelationship1 relationship) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dateOfBirth": "2021-07-15",
  "customerStartDate": "2021-07-15",
  "lastActivityDate": "2021-07-15",
  "emails": [
    "emails9",
    "emails0"
  ],
  "addresses": [
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "telephones": [
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "taxId": "taxId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

