
# Consent Revocation List Entity

List of consent grant revocation requests

*This model accepts additional fields of type Object.*

## Structure

`ConsentRevocationListEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Revocations` | [`List<ConsentRevocationEntity>`](../../doc/models/consent-revocation-entity.md) | Optional | The list of revocation requests | List<ConsentRevocationEntity> getRevocations() | setRevocations(List<ConsentRevocationEntity> revocations) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "revocations": [
    {
      "status": "REVOKED",
      "reason": "BUSINESS_RULE",
      "initiator": "DATA_RECIPIENT",
      "updatedTime": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "status": "REVOKED",
      "reason": "BUSINESS_RULE",
      "initiator": "DATA_RECIPIENT",
      "updatedTime": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "status": "REVOKED",
      "reason": "BUSINESS_RULE",
      "initiator": "DATA_RECIPIENT",
      "updatedTime": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

