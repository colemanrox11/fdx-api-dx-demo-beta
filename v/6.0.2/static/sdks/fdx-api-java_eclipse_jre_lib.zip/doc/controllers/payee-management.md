# Payee Management

```java
PayeeManagementController payeeManagementController = client.getPayeeManagementController();
```

## Class Name

`PayeeManagementController`

## Methods

* [Search for Payees](../../doc/controllers/payee-management.md#search-for-payees)
* [Create Payee](../../doc/controllers/payee-management.md#create-payee)
* [Get Payee](../../doc/controllers/payee-management.md#get-payee)
* [Update Payee](../../doc/controllers/payee-management.md#update-payee)
* [Delete Payee](../../doc/controllers/payee-management.md#delete-payee)


# Search for Payees

Search for payees

```java
CompletableFuture<ApiResponse<PayeesEntity>> searchForPayeesAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final String updatedSince,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `String` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayeesEntity`](../../doc/models/payees-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

payeeManagementController.searchForPayeesAsync(xFapiInteractionId, fdxApiActorType, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "next-offset-123-xyz",
    "prevOffset": "prev-offset-456-abc",
    "totalElements": 100
  },
  "updates": {
    "nextUpdateId": "next-update-id-456-krl"
  },
  "links": {
    "next": {
      "href": "/payees?offset=next-offset-123-xyz"
    },
    "prev": {
      "href": "/payees?offset=prev-offset-456-abc"
    },
    "updates": {
      "href": "/payees?updatedSince=next-update-id-456-krl"
    }
  },
  "payees": [
    {
      "merchant": {
        "displayName": "My Cell Phone Biller",
        "name": {
          "company": "US Cellular"
        },
        "address": {
          "line1": "10 Cellular way",
          "city": "New York",
          "region": "NY",
          "postalCode": "10001"
        },
        "phone": {
          "type": "CELL",
          "country": "+1",
          "number": "2013329944"
        },
        "payeeId": "payee-1001",
        "merchantAccountIds": [
          "999900008888"
        ],
        "status": "ACTIVE",
        "expiresTimestamp": "2025-03-15T13:29:19+0000"
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Create Payee

Create a payee

```java
CompletableFuture<ApiResponse<PayeeEntity>> createPayeeAsync(
    final UUID xFapiInteractionId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final PayeeForUpdateEntity1 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PayeeForUpdateEntity1`](../../doc/models/payee-for-update-entity-1.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String idempotencyKey = "idempotency-key4";
PayeeForUpdateEntity1 body = new PayeeForUpdateEntity1.Builder(
    new MerchantForUpdateEntity1.Builder()
        .displayName("My Cell Phone Biller")
        .name(new CustomerNameEntity.Builder()
            .first("Junie")
            .middle("B")
            .last("Jones")
            .suffix("Jr")
            .prefix("Ms")
            .company("US Cellular")
            .build())
        .address(new DeliveryAddress1.Builder()
            .line1("10 Cellular way")
            .city("New York")
            .region("NY")
            .postalCode("10001")
            .build())
        .phone(new TelephoneNumber.Builder()
            .type(TelephoneNumberType.BUSINESS)
            .country("+1")
            .number("2013329944")
            .build())
        .merchantAccountIds(Arrays.asList(
            "999900008888"
        ))
        .build()
)
.build();

payeeManagementController.createPayeeAsync(xFapiInteractionId, idempotencyKey, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Duplicate Request | [`PayeeEntityErrorException`](../../doc/models/payee-entity-error-exception.md) |


# Get Payee

Get a payee

```java
CompletableFuture<ApiResponse<PayeeEntity>> getPayeeAsync(
    final UUID xFapiInteractionId,
    final String payeeId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `payeeId` | `String` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String payeeId = "payeeId8";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

payeeManagementController.getPayeeAsync(xFapiInteractionId, payeeId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payee

Used to update an existing payee. The payee type must match the existing payee. This call updates the payee's fields to the values provided. If a field is not provided, the payee's field is not updated

```java
CompletableFuture<ApiResponse<PayeeEntity>> updatePayeeAsync(
    final UUID xFapiInteractionId,
    final String payeeId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final PayeeForUpdateEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `payeeId` | `String` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PayeeForUpdateEntity`](../../doc/models/payee-for-update-entity.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String payeeId = "payeeId8";
String idempotencyKey = "idempotency-key4";
PayeeForUpdateEntity body = new PayeeForUpdateEntity.Builder(
    new MerchantForUpdateEntity1.Builder()
        .displayName("My Business Cell Phone Biller")
        .build()
)
.build();

payeeManagementController.updatePayeeAsync(xFapiInteractionId, payeeId, idempotencyKey, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`PayeeEntityErrorException`](../../doc/models/payee-entity-error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payee

Delete a payee

```java
CompletableFuture<ApiResponse<PayeeEntity>> deletePayeeAsync(
    final UUID xFapiInteractionId,
    final String payeeId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `payeeId` | `String` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String payeeId = "payeeId8";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

payeeManagementController.deletePayeeAsync(xFapiInteractionId, payeeId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "status": "DELETED"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Payee cannot be modified or deleted | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

