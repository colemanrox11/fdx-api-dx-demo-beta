
# Availability Entity

Response object for /availability API

*This model accepts additional fields of type Object.*

## Structure

`AvailabilityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`AvailabilityStatus3`](../../doc/models/availability-status-3.md) | Optional | Status of API availability |
| `description` | `String` | Optional | Description of availability status |
| `operation_id` | [`FdxResourceOperationId3`](../../doc/models/fdx-resource-operation-id-3.md) | Optional | Operation ID (e.g. name) for this Availability |
| `planned_availability` | [`Array<PlannedAvailabilityEntity>`](../../doc/models/planned-availability-entity.md) | Optional | Provider's plan for API availability |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "status": "ALIVE",
  "description": "description4",
  "operationId": "getCertificationMetrics",
  "plannedAvailability": [
    {
      "status": "MAINTENANCE",
      "description": "description6",
      "startTime": "2016-03-13T12:52:32.123Z",
      "endTime": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "status": "MAINTENANCE",
      "description": "description6",
      "startTime": "2016-03-13T12:52:32.123Z",
      "endTime": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "status": "MAINTENANCE",
      "description": "description6",
      "startTime": "2016-03-13T12:52:32.123Z",
      "endTime": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

