
# Payment Initiation Parties Entity

Payment initiation party summaries

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartiesEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets | PageMetadata getPage() | setPage(PageMetadata page) |
| `Links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets | PageMetadataLinks getLinks() | setLinks(PageMetadataLinks links) |
| `PaymentInitiationParties` | [`List<PaymentInitiationPartySummaryEntity>`](../../doc/models/payment-initiation-party-summary-entity.md) | Optional | Payment initiation party summaries | List<PaymentInitiationPartySummaryEntity> getPaymentInitiationParties() | setPaymentInitiationParties(List<PaymentInitiationPartySummaryEntity> paymentInitiationParties) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "paymentInitiationParties": [
    {
      "paymentInitiationPartyId": "paymentInitiationPartyId6",
      "name": {
        "aliasName": "aliasName2",
        "detail": {
          "companyName": "companyName0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

