
# Updates Metadata Entity

Change IDs for synchronizable result sets

*This model accepts additional fields of type Object.*

## Structure

`UpdatesMetadataEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `next_update_id` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "nextUpdateId": "nextUpdateId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

