
# Investment Sale Type

Type of investment sale

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentSaleType`

## Fields

| Name |
|  --- |
| `CRYPTOCURRENCY` |
| `EMPLOYEE_STOCK_PURCHASE_PLAN` |
| `INCENTIVE_STOCK_OPTION` |
| `NONQUALIFIED_STOCK_OPTIONS` |
| `OTHER` |
| `RESTRICTED_STOCK` |
| `RESTRICTED_STOCK_UNITS` |

