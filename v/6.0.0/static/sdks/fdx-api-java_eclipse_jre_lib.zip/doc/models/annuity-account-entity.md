
# Annuity Account Entity

An annuity account type

*This model accepts additional fields of type Object.*

## Structure

`AnnuityAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PayoutType` | [`PayoutType2`](../../doc/models/payout-type-2.md) | Optional | Indicates type of payout such as immediate or deferred | PayoutType2 getPayoutType() | setPayoutType(PayoutType2 payoutType) |
| `PolicyProductType` | [`PolicyProductType2`](../../doc/models/policy-product-type-2.md) | Optional | The type of annuity product, e.g. Fixed or Variable | PolicyProductType2 getPolicyProductType() | setPolicyProductType(PolicyProductType2 policyProductType) |
| `PayoutAmount` | `Double` | Optional | Amount paid out, based on mode frequency | Double getPayoutAmount() | setPayoutAmount(Double payoutAmount) |
| `PayoutMode` | [`PayoutMode2`](../../doc/models/payout-mode-2.md) | Optional | Frequency of annuity payments | PayoutMode2 getPayoutMode() | setPayoutMode(PayoutMode2 payoutMode) |
| `PayoutStartDate` | `LocalDate` | Optional | Date the payout starts | LocalDate getPayoutStartDate() | setPayoutStartDate(LocalDate payoutStartDate) |
| `PayoutEndDate` | `LocalDate` | Optional | Date the payout ends | LocalDate getPayoutEndDate() | setPayoutEndDate(LocalDate payoutEndDate) |
| `NumberModalPayouts` | `Integer` | Optional | Total number of payouts | Integer getNumberModalPayouts() | setNumberModalPayouts(Integer numberModalPayouts) |
| `SurrenderValue` | `Double` | Optional | Cash surrender value (net) available if contract is surrendered | Double getSurrenderValue() | setSurrenderValue(Double surrenderValue) |
| `PayoutChangePercentage` | `Double` | Optional | Percentage of the accumulated value to be paid to the payee each year; used exclusive of payoutChangeAmount | Double getPayoutChangePercentage() | setPayoutChangePercentage(Double payoutChangePercentage) |
| `PayoutChangeAmount` | `Double` | Optional | Incremental modal amount (positive or negative) by which the payout amount will be changed; used exclusive of payoutPercentage | Double getPayoutChangeAmount() | setPayoutChangeAmount(Double payoutChangeAmount) |
| `PeriodCertainType` | [`PeriodCertainType2`](../../doc/models/period-certain-type-2.md) | Optional | The number of modal periods comprising the duration of the certain period of an annuity payout | PeriodCertainType2 getPeriodCertainType() | setPeriodCertainType(PeriodCertainType2 periodCertainType) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "payoutStartDate": "2021-07-15",
  "payoutEndDate": "2021-07-15",
  "accountCategory": "Annuity Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "payoutType": "DEFERRED",
  "policyProductType": "FIXED",
  "payoutAmount": 63.04,
  "payoutMode": "ANNUALLY"
}
```

