
# Domicile Entity 1

The country and region of the account's legal jurisdiction

*This model accepts additional fields of type Object.*

## Structure

`DomicileEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Region` | `String` | Optional | Country sub-division; state or province or territory<br><br>**Constraints**: *Maximum Length*: `64` | String getRegion() | setRegion(String region) |
| `Country` | [`Iso3166CountryCode2`](../../doc/models/iso-3166-country-code-2.md) | Optional | ISO 3166 Country Code | Iso3166CountryCode2 getCountry() | setCountry(Iso3166CountryCode2 country) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "region": "region6",
  "country": "NG",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

