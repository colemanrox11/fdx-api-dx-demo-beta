
# Coupon Mature Frequency

The frequency of a bond's coupon maturity

*This model accepts additional fields of type Object.*

## Enumeration

`CouponMatureFrequency`

## Fields

| Name |
|  --- |
| `Annual` |
| `Monthly` |
| `Other` |
| `Quarterly` |
| `Semiannual` |

