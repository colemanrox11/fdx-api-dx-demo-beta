
# Organization Name Entity

Logical grouping of name attributes that are particular to
an Organization type of payment initiation party

*This model accepts additional fields of type Object.*

## Structure

`OrganizationNameEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CompanyName` | `String` | Optional | Name value of the organization | String getCompanyName() | setCompanyName(String companyName) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "companyName": "companyName0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

