
# Electronic Address Entity

Electronic address details

*This model accepts additional fields of type Object.*

## Structure

`ElectronicAddressEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `email_address_text` | `String` | Optional | Value of the email address |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "emailAddressText": "emailAddressText4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

