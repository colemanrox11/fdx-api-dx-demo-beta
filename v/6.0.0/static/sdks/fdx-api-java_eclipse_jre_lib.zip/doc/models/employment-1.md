
# Employment 1

The employee's employment

*This model accepts additional fields of type Object.*

## Structure

`Employment1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Employer` | [`EmployerEntity1`](../../doc/models/employer-entity-1.md) | Required | The employer for the job/position | EmployerEntity1 getEmployer() | setEmployer(EmployerEntity1 employer) |
| `JobTitle` | `String` | Optional | The title of the job/position | String getJobTitle() | setJobTitle(String jobTitle) |
| `OriginalHireDate` | `LocalDate` | Optional | The date when employee joined for the first time. | LocalDate getOriginalHireDate() | setOriginalHireDate(LocalDate originalHireDate) |
| `MostRecentHireDate` | `LocalDate` | Optional | The date when employee re-joined most recently. | LocalDate getMostRecentHireDate() | setMostRecentHireDate(LocalDate mostRecentHireDate) |
| `EndDate` | `LocalDate` | Optional | The employment end date | LocalDate getEndDate() | setEndDate(LocalDate endDate) |
| `Status` | [`ActiveInactiveStatus2`](../../doc/models/active-inactive-status-2.md) | Required | The employee's employment status, ACTIVE or INACTIVE | ActiveInactiveStatus2 getStatus() | setStatus(ActiveInactiveStatus2 status) |
| `SupplementalStatus` | [`SupplementalStatus2`](../../doc/models/supplemental-status-2.md) | Optional | Supplemental detail of employee's employment status | SupplementalStatus2 getSupplementalStatus() | setSupplementalStatus(SupplementalStatus2 supplementalStatus) |
| `Type` | [`EmploymentType2`](../../doc/models/employment-type-2.md) | Optional | The employee's employment type, CONTRACTED, FULL-TIME, OTHER, PART-TIME, SEASONAL, TEMPORARY | EmploymentType2 getType() | setType(EmploymentType2 type) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "employer": {
    "employerId": "employerId2",
    "name": {
      "name1": "name10",
      "name2": "name24",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "dbas": [
      "dbas1"
    ],
    "taxId": "taxId8",
    "taxIdCountry": "SK",
    "contacts": {
      "emails": [
        "emails7",
        "emails8",
        "emails9"
      ],
      "addresses": [
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "telephones": [
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "originalHireDate": "2021-07-15",
  "mostRecentHireDate": "2021-07-15",
  "endDate": "2021-07-15",
  "status": "ACTIVE",
  "jobTitle": "jobTitle8",
  "supplementalStatus": "MEDICAL_LEAVE",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

