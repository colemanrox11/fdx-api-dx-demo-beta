
# Recurring Payment Entity

A recurring payment. Financial institution is free to adjust the payment date to accommodate weekends and holidays

*This model accepts additional fields of type Object.*

## Structure

`RecurringPaymentEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Frequency` | [`RecurringPaymentFrequency2`](../../doc/models/recurring-payment-frequency-2.md) | Required | Defines how often the payment repeats | RecurringPaymentFrequency2 getFrequency() | setFrequency(RecurringPaymentFrequency2 frequency) |
| `Duration` | [`RecurringPaymentDurationEntity2`](../../doc/models/recurring-payment-duration-entity-2.md) | Optional | Defines how long the payment repeats for | RecurringPaymentDurationEntity2 getDuration() | setDuration(RecurringPaymentDurationEntity2 duration) |
| `FromAccountId` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` | String getFromAccountId() | setFromAccountId(String fromAccountId) |
| `ToPayeeId` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` | String getToPayeeId() | setToPayeeId(String toPayeeId) |
| `Amount` | `double` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` | double getAmount() | setAmount(double amount) |
| `MerchantAccountId` | `String` | Optional | User's account identifier with the merchant | String getMerchantAccountId() | setMerchantAccountId(String merchantAccountId) |
| `DueDate` | `LocalDate` | Required | Date that the funds are scheduled to be delivered | LocalDate getDueDate() | setDueDate(LocalDate dueDate) |
| `RecurringPaymentId` | `String` | Optional | Uniquely identifies a recurring payment. Used within the API to reference a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` | String getRecurringPaymentId() | setRecurringPaymentId(String recurringPaymentId) |
| `ScheduledTimestamp` | `LocalDateTime` | Optional | When the recurring payment was scheduled | LocalDateTime getScheduledTimestamp() | setScheduledTimestamp(LocalDateTime scheduledTimestamp) |
| `CancelledTimestamp` | `LocalDateTime` | Optional | When the recurring payment was cancelled | LocalDateTime getCancelledTimestamp() | setCancelledTimestamp(LocalDateTime cancelledTimestamp) |
| `ProcessedTimestamp` | `LocalDateTime` | Optional | When the last payment executed | LocalDateTime getProcessedTimestamp() | setProcessedTimestamp(LocalDateTime processedTimestamp) |
| `FailedTimestamp` | `LocalDateTime` | Optional | When the recurring payment failed | LocalDateTime getFailedTimestamp() | setFailedTimestamp(LocalDateTime failedTimestamp) |
| `Status` | [`RecurringPaymentStatus2`](../../doc/models/recurring-payment-status-2.md) | Required | Defines the status of the recurring payment | RecurringPaymentStatus2 getStatus() | setStatus(RecurringPaymentStatus2 status) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "frequency": "MONTHLY",
  "fromAccountId": "fromAccountId8",
  "toPayeeId": "toPayeeId2",
  "amount": 140.36,
  "dueDate": "2021-07-15",
  "scheduledTimestamp": "07/15/2021 14:46:41",
  "cancelledTimestamp": "07/15/2021 14:46:41",
  "processedTimestamp": "07/15/2021 14:46:41",
  "failedTimestamp": "07/15/2021 14:46:41",
  "status": "PROCESSED",
  "duration": {
    "type": "NOEND",
    "numberOfTimes": 181.2,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "merchantAccountId": "merchantAccountId2",
  "recurringPaymentId": "recurringPaymentId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

