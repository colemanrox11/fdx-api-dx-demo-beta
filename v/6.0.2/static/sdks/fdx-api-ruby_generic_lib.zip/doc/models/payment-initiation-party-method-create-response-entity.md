
# Payment Initiation Party Method Create Response Entity

Registration between a payment initiation party and a Payment Method

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyMethodCreateResponseEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registration_id` | `String` | Optional | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "registrationId": "registrationId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

