
# Coverage Month 1

Month

*This model accepts additional fields of type Object.*

## Enumeration

`CoverageMonth1`

## Fields

| Name |
|  --- |
| `Annual` |
| `January` |
| `February` |
| `March` |
| `April` |
| `May` |
| `June` |
| `July` |
| `August` |
| `September` |
| `October` |
| `November` |
| `December` |

