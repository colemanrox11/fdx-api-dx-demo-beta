
# Notification Severity 2

Notification severity

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationSeverity2`

## Fields

| Name |
|  --- |
| `Emergency` |
| `Alert` |
| `Warning` |
| `Notice` |
| `Info` |

