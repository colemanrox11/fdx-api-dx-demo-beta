
# Sub Account Type 4

CASH, MARGIN, SHORT, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`SubAccountType4`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `Other` |
| `MShort` |

