
# Customer Name Entity

The customer's name

*This model accepts additional fields of type Object.*

## Structure

`CustomerNameEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `first` | `String` | Optional | First name |
| `middle` | `String` | Optional | Middle initial |
| `last` | `String` | Optional | Last name |
| `suffix` | `String` | Optional | Generational or academic suffix |
| `prefix` | `String` | Optional | Name prefix, e.g. Mr. |
| `company` | `String` | Optional | Company name |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "first": "first2",
  "middle": "middle2",
  "last": "last6",
  "suffix": "suffix6",
  "prefix": "prefix4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

