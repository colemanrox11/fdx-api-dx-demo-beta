
# Order Type

The type of the order

*This model accepts additional fields of type Object.*

## Enumeration

`OrderType`

## Fields

| Name |
|  --- |
| `BUY` |
| `BUYTOCOVER` |
| `BUYTOOPEN` |
| `SELL` |
| `SELLCLOSE` |
| `SELLSHORT` |
| `SELLTOCOVER` |
| `SELLTOOPEN` |

