
# Government Issued Party Identification Entity

Government issued identification document that is used to uniquely
identify a person or business

*This model accepts additional fields of type Object.*

## Structure

`GovernmentIssuedPartyIdentificationEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id_number` | `String` | Optional | Identification number<br><br>**Constraints**: *Maximum Length*: `256` |
| `issued_date` | `String` | Optional | Issued date |
| `expiry_date` | `String` | Optional | Expiry date |
| `type` | [`GovernmentIssuedIdType2`](../../doc/models/government-issued-id-type-2.md) | Optional | Type of the identification |
| `issuing_country_name` | `String` | Optional | Name of the issuing country |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "idNumber": "idNumber2",
  "issuedDate": "issuedDate4",
  "expiryDate": "expiryDate4",
  "type": "DRIVERLICENSE",
  "issuingCountryName": "issuingCountryName0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

