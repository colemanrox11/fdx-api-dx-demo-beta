
# Consent Duration Type

The type of duration of the consent

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentDurationType`

## Fields

| Name |
|  --- |
| `OneTime` |
| `Persistent` |
| `TimeBound` |

