
# Registry Reference

Used for registry references. Properties in this structure use 'snake_case' names to match the properties in [IETF RFC 7591](https://datatracker.ietf.org/doc/rfc7591/)

*This model accepts additional fields of type Object.*

## Structure

`RegistryReference`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `registered_entity_name` | `String` | Optional | The legal company name for the intermediary |
| `registered_entity_id` | `String` | Optional | An ID representing the intermediary that can be looked up from a legal identity registry source |
| `registry` | [`Registry`](../../doc/models/registry.md) | Optional | The Registry source |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "registered_entity_name": "registered_entity_name0",
  "registered_entity_id": "registered_entity_id0",
  "registry": "ICANN",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

