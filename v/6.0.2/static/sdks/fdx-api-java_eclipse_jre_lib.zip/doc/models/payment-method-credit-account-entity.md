
# Payment Method Credit Account Entity

A payment initiation party's payment method that credits an account

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodCreditAccountEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountRegistrationId` | `String` | Optional | Unique identifier of the registration of the destination account to the<br>payment method associated with a particular payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountRegistrationId() | setAccountRegistrationId(String accountRegistrationId) |
| `DirectDeposit` | [`DirectDepositEntity`](../../doc/models/direct-deposit-entity.md) | Optional | Direct deposit details | DirectDepositEntity getDirectDeposit() | setDirectDeposit(DirectDepositEntity directDeposit) |
| `DestinationAccount` | [`PaymentGenericAccountEntity1`](../../doc/models/payment-generic-account-entity-1.md) | Optional | Destination account details | PaymentGenericAccountEntity1 getDestinationAccount() | setDestinationAccount(PaymentGenericAccountEntity1 destinationAccount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountRegistrationId": "accountRegistrationId8",
  "directDeposit": {
    "directDepositId": "directDepositId8",
    "registrationTypeCode": "registrationTypeCode6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "destinationAccount": {
    "accountNumber": "accountNumber0",
    "accountType": "VARIABLEANNUITY",
    "name": "name2",
    "currencyCode": "NAD",
    "id": {
      "iban2007Id": "iban2007Id4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

