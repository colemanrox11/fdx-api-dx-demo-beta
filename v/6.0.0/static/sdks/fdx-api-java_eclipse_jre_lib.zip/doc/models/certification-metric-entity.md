
# Certification Metric Entity

A single certification performance metric

*This model accepts additional fields of type Object.*

## Structure

`CertificationMetricEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ReportStartTimestamp` | `LocalDateTime` | Optional | When the reported metrics period began | LocalDateTime getReportStartTimestamp() | setReportStartTimestamp(LocalDateTime reportStartTimestamp) |
| `ReportEndTimestamp` | `LocalDateTime` | Optional | When the reported metrics period ended | LocalDateTime getReportEndTimestamp() | setReportEndTimestamp(LocalDateTime reportEndTimestamp) |
| `MetricsName` | `String` | Optional | Any provider descriptive name for the measurement. Optional, can be omitted if operationIds are returned | String getMetricsName() | setMetricsName(String metricsName) |
| `OperationIds` | [`List<FdxResourceOperationId>`](../../doc/models/fdx-resource-operation-id.md) | Optional | One or more Operation IDs for which these metrics apply. Optional, can be omitted if metricsName is returned | List<FdxResourceOperationId> getOperationIds() | setOperationIds(List<FdxResourceOperationId> operationIds) |
| `ResponseTimeAverage` | `Double` | Optional | The self-reported average response time in milliseconds for all combined data responses | Double getResponseTimeAverage() | setResponseTimeAverage(Double responseTimeAverage) |
| `AverageUpTime` | `Double` | Optional | See the Certification Performance section that describes how this measurement will be calculated, defines the % of availability during the measurement | Double getAverageUpTime() | setAverageUpTime(Double averageUpTime) |
| `ReportTimestamp` | `LocalDateTime` | Optional | Time when these performance and availability metrics were created | LocalDateTime getReportTimestamp() | setReportTimestamp(LocalDateTime reportTimestamp) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "reportStartTimestamp": "07/15/2021 14:46:41",
  "reportEndTimestamp": "07/15/2021 14:46:41",
  "reportTimestamp": "07/15/2021 14:46:41",
  "metricsName": "metricsName2",
  "operationIds": [
    "getPaymentsForRecurringPayment",
    "getRecurringPayment"
  ],
  "responseTimeAverage": 130.24,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

