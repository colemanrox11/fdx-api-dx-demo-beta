
# Fdx Oauth Token Introspection Response

FDX response enabling transport of ConsentGrant details extended from [JSON Web Token (JWT) Profile for OAuth 2.0 Access Tokens](https://datatracker.ietf.org/doc/html/rfc9068)

*This model accepts additional fields of type Object.*

## Structure

`FdxOauthTokenIntrospectionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Active` | `Boolean` | Optional | Flag indicating whether 'ConsentGrant' is active | Boolean getActive() | setActive(Boolean active) |
| `Iss` | `String` | Optional | Issuer claim 'iss' identifies the principal that issued the JWT. Contains a [StringOrURI](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value | String getIss() | setIss(String iss) |
| `Sub` | `String` | Optional | Subject claim 'sub' identifies the principal that is the subject of the JWT. Contains a [StringOrURI](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value | String getSub() | setSub(String sub) |
| `Aud` | `String` | Optional | Audience claim 'aud' identifies the recipients for whom the JWT is intended. May be a single StringOrURI value or an array of [StringOrURI](https://datatracker.ietf.org/doc/html/rfc7519#section-2) values | String getAud() | setAud(String aud) |
| `Exp` | `Double` | Optional | Expiration Time claim 'exp' identifies the time on or after which the JWT MUST NOT be accepted Contains a number which is a [NumericDate](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value | Double getExp() | setExp(Double exp) |
| `Iat` | `Double` | Optional | Issued At claim 'iat' identifies the time at which the JWT was issued. Contains a number which is a [NumericDate](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value | Double getIat() | setIat(Double iat) |
| `Jti` | `String` | Optional | JWT ID claim 'jti' provides a unique identifier for the JWT. Contains a case-sensitive string value | String getJti() | setJti(String jti) |
| `ClientId` | `String` | Optional | The unique client identifier for the Data Recipient granted the consent | String getClientId() | setClientId(String clientId) |
| `Scope` | `String` | Optional | Space-delimited array of any number of scopes from those in FdxOauthScope, plus 'openid' and 'offline_access' | String getScope() | setScope(String scope) |
| `FdxConsentId` | `String` | Optional | Unique ID for a consent grant<br><br>**Constraints**: *Maximum Length*: `256` | String getFdxConsentId() | setFdxConsentId(String fdxConsentId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "active": false,
  "iss": "iss2",
  "sub": "sub8",
  "aud": "aud2",
  "exp": 158.14,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

