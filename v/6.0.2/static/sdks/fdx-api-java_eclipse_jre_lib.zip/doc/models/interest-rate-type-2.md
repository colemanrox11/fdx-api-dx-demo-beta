
# Interest Rate Type 2

FIXED or VARIABLE

*This model accepts additional fields of type Object.*

## Enumeration

`InterestRateType2`

## Fields

| Name |
|  --- |
| `Fixed` |
| `Variable` |

