
# Merchant Entity 1

When payee is a merchant, typically a business from which goods or services are rendered, this field will be populated

*This model accepts additional fields of type Object.*

## Structure

`MerchantEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DisplayName` | `String` | Optional | User defined name for the merchant. Used by the customer to identify the merchant. Not used by the system to process payments | String getDisplayName() | setDisplayName(String displayName) |
| `Name` | [`CustomerNameEntity`](../../doc/models/customer-name-entity.md) | Optional | Name of the merchant used to execute the payment | CustomerNameEntity getName() | setName(CustomerNameEntity name) |
| `Address` | [`DeliveryAddress1`](../../doc/models/delivery-address-1.md) | Optional | Address of the merchant used to execute the payment | DeliveryAddress1 getAddress() | setAddress(DeliveryAddress1 address) |
| `Phone` | [`TelephoneNumber`](../../doc/models/telephone-number.md) | Optional | Phone number of the merchant used to execute the payment | TelephoneNumber getPhone() | setPhone(TelephoneNumber phone) |
| `MerchantAccountIds` | `List<String>` | Optional | Account identifier(s) the customer has with the merchant | List<String> getMerchantAccountIds() | setMerchantAccountIds(List<String> merchantAccountIds) |
| `PayeeId` | `String` | Optional | Persistent unique identifier for a merchant payee<br><br>**Constraints**: *Maximum Length*: `256` | String getPayeeId() | setPayeeId(String payeeId) |
| `Status` | [`PartyStatus3`](../../doc/models/party-status-3.md) | Required | Defines the Merchant's lifecycle | PartyStatus3 getStatus() | setStatus(PartyStatus3 status) |
| `ExpiresTimestamp` | `LocalDateTime` | Optional | Describes when the entity will be automatically deleted. The entity will not go into the "DELETED" state. If this value is null or not provided, the entity will not expire automatically | LocalDateTime getExpiresTimestamp() | setExpiresTimestamp(LocalDateTime expiresTimestamp) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "status": "PENDING",
  "expiresTimestamp": "07/15/2021 14:46:41",
  "displayName": "displayName4",
  "name": {
    "first": "first6",
    "middle": "middle6",
    "last": "last0",
    "suffix": "suffix0",
    "prefix": "prefix8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "phone": {
    "type": "BUSINESS",
    "country": "country4",
    "number": "number8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "merchantAccountIds": [
    "merchantAccountIds0",
    "merchantAccountIds1"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

