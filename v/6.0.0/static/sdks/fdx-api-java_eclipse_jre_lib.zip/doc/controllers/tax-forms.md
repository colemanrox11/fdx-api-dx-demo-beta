# Tax Forms

```java
TaxFormsController taxFormsController = client.getTaxFormsController();
```

## Class Name

`TaxFormsController`

## Methods

* [Search for Tax Forms](../../doc/controllers/tax-forms.md#search-for-tax-forms)
* [Get Tax Form](../../doc/controllers/tax-forms.md#get-tax-form)


# Search for Tax Forms

Get the full lists of tax document data and tax form images available for a specific year for the current authorized customer

```java
CompletableFuture<ApiResponse<TaxStatementList>> searchForTaxFormsAsync(
    final String authorization,
    final UUID xFapiInteractionId,
    final String accept,
    final FdxApiActorType fdxApiActorType,
    final String accountId,
    final Integer taxYear,
    final List<TypeFormType> taxForms,
    final TypeDataType taxDataType,
    final ResultType resultType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `accept` | `String` | Header, Required | Use the [Accept HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Accept) to indicate one or more content types to request for the search result response. Use `application/json` to request data, `application/pdf`, `application/zip` or `image/*` MIME-types to request images. In comma-separated array format using values typically from './fdxapi.components.yaml#/components/schemas/ContentTypes' enumeration. Use in combination with TaxDataTypeQuery parameter to request `application/json` responses in 'JSON' or 'BASE64_PDF' format for tax form data |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `accountId` | `String` | Query, Optional | Account Identifier for use in searching or authorization. Optional |
| `taxYear` | `Integer` | Query, Optional | Tax year in which to search for tax forms. Optional<br><br>**Constraints**: `>= 2018`, `<= 2050` |
| `taxForms` | [`List<TypeFormType>`](../../doc/models/type-form-type.md) | Query, Optional | One or more tax form type enums for the specific documents being requested. Comma separated |
| `taxDataType` | [`TypeDataType`](../../doc/models/type-data-type.md) | Query, Optional | Use taxDataType to request `application/json` tax form data response in 'JSON' or 'BASE64_PDF' format. Omit if either format is acceptable. Used in combination with AcceptHeader requesting `application/json` response |
| `resultType` | [`ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `ResultType.LIGHTWEIGHT` |

## Server

`Server.USTAX`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TaxStatementList`](../../doc/models/tax-statement-list.md).

## Example Usage

```java
String authorization = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String accept = "Accept: application/json";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
Integer taxYear = 2023;
ResultType resultType = ResultType.LIGHTWEIGHT;

taxFormsController.searchForTaxFormsAsync(authorization, xFapiInteractionId, accept, fdxApiActorType, null, taxYear, null, null, resultType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "statements": [
    {
      "taxYear": 2020,
      "taxStatementId": "9876987698769876",
      "attributes": [
        {
          "name": "federalTaxWithheld",
          "value": "4014.00"
        }
      ],
      "taxDataType": "JSON",
      "forms": [
        {
          "tax1099Div": {
            "taxYear": 2020,
            "taxFormId": "9876987698769876",
            "taxFormDate": "2021-03-30",
            "additionalInformation": "FDX v6.0",
            "taxFormType": "Tax1099Div"
          }
        }
      ]
    },
    {
      "taxYear": 2020,
      "taxStatementId": "6543654365436543",
      "attributes": [
        {
          "name": "federalTaxWithheld",
          "value": "4011.00"
        }
      ],
      "taxDataType": "JSON",
      "forms": [
        {
          "tax1099Int": {
            "taxYear": 2020,
            "taxFormId": "6543654365436543",
            "taxFormDate": "2021-03-30",
            "additionalInformation": "FDX v6.0",
            "taxFormType": "Tax1099Int"
          }
        }
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Request is invalid or parameter values are not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Tax Form not Found | [`ErrorException`](../../doc/models/error-exception.md) |
| 406 | Content Type not Supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Tax forms are not currently available for this account or this year | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Tax Form

Get the form image or TaxStatement as json for a single tax document for the customer. Use [HTTP Accept request-header](https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html) to specify desired content types. See `AcceptHeader` definition for typical values

```java
CompletableFuture<ApiResponse<TaxStatement4>> getTaxFormAsync(
    final String taxFormId,
    final String authorization,
    final UUID xFapiInteractionId,
    final String accept,
    final FdxApiActorType fdxApiActorType,
    final TypeDataType taxDataType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `taxFormId` | `String` | Template, Required | The unique ID for this tax form or tax statement<br><br>**Constraints**: *Maximum Length*: `256` |
| `authorization` | `String` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `accept` | `String` | Header, Required | Use the [Accept HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Accept) to indicate one or more content types to request for the search result response. Use `application/json` to request data, `application/pdf`, `application/zip` or `image/*` MIME-types to request images. In comma-separated array format using values typically from './fdxapi.components.yaml#/components/schemas/ContentTypes' enumeration. Use in combination with TaxDataTypeQuery parameter to request `application/json` responses in 'JSON' or 'BASE64_PDF' format for tax form data |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `taxDataType` | [`TypeDataType`](../../doc/models/type-data-type.md) | Query, Optional | Use taxDataType to request `application/json` tax form data response in 'JSON' or 'BASE64_PDF' format. Omit if either format is acceptable. Used in combination with AcceptHeader requesting `application/json` response |

## Server

`Server.USTAX`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TaxStatement4`](../../doc/models/tax-statement-4.md).

## Example Usage

```java
String taxFormId = "taxFormId2";
String authorization = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String accept = "Accept: application/json";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

taxFormsController.getTaxFormAsync(taxFormId, authorization, xFapiInteractionId, accept, fdxApiActorType, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "taxYear": 2020,
  "taxStatementId": "1234123412341234",
  "attributes": [
    {
      "name": "Total tax withheld",
      "value": "8025.00"
    }
  ],
  "issuer": {
    "tin": "12-3456789",
    "partyType": "BUSINESS",
    "businessName": {
      "name1": "Financial Data Exchange"
    },
    "address": {
      "line1": "12020 Sunrise Valley Dr",
      "line2": "Suite 230",
      "city": "Reston",
      "region": "VA",
      "postalCode": "20191",
      "country": "US"
    },
    "phone": {
      "number": "8885551212"
    }
  },
  "recipient": {
    "tin": "xxx-xx-1234",
    "partyType": "INDIVIDUAL",
    "individualName": {
      "first": "Kris",
      "middle": "Q",
      "last": "Public"
    },
    "address": {
      "line1": "1 Main St",
      "city": "Melrose",
      "region": "NY",
      "postalCode": "12121",
      "country": "US"
    }
  },
  "taxDataType": "JSON",
  "forms": [
    {
      "tax1099Div": {
        "taxYear": 2020,
        "taxFormId": "9876987698769876",
        "taxFormDate": "2021-03-30",
        "additionalInformation": "FDX v6.0",
        "taxFormType": "Tax1099Div",
        "foreignAccountTaxCompliance": false,
        "accountNumber": "111-5555555",
        "ordinaryDividends": 1107.0,
        "qualifiedDividends": 1208.0,
        "totalCapitalGain": 2109.0,
        "unrecaptured1250Gain": 2210.0,
        "section1202Gain": 2311.0,
        "collectiblesGain": 2412.0,
        "nonTaxableDistribution": 3013.0,
        "federalTaxWithheld": 4014.0,
        "section199ADividends": 5015.0,
        "investmentExpenses": 6016.0,
        "foreignTaxPaid": 7017.0,
        "foreignCountry": "Mexico",
        "cashLiquidation": 9019.0,
        "nonCashLiquidation": 10020.0,
        "taxExemptInterestDividend": 11021.0,
        "specifiedPabInterestDividend": 12022.0,
        "stateAndLocal": [
          {
            "stateCode": "NY",
            "state": {
              "taxWithheld": 15023.0,
              "taxId": "14-000023"
            }
          }
        ]
      }
    },
    {
      "tax1099Int": {
        "taxYear": 2020,
        "taxFormId": "6543654365436543",
        "taxFormDate": "2021-03-30",
        "additionalInformation": "FDX v6.0",
        "taxFormType": "Tax1099Int",
        "foreignAccountTaxCompliance": false,
        "accountNumber": "111-5555555",
        "payerRtn": "007007007",
        "interestIncome": 1008.0,
        "earlyWithdrawalPenalty": 2009.0,
        "usBondInterest": 3010.0,
        "federalTaxWithheld": 4011.0,
        "investmentExpenses": 5012.0,
        "foreignTaxPaid": 6013.0,
        "foreignCountry": "Canada",
        "taxExemptInterest": 8015.0,
        "specifiedPabInterest": 9016.0,
        "marketDiscount": 10017.0,
        "bondPremium": 11018.0,
        "usBondPremium": 12019.0,
        "taxExemptBondPremium": 13020.0,
        "cusipNumber": "CUSIP",
        "stateAndLocal": [
          {
            "stateCode": "NY",
            "state": {
              "taxWithheld": 17022.0,
              "taxId": "15-000022"
            }
          }
        ]
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Account ID is required for searching or validating authorization | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Tax Form for provided Tax Form ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 406 | Content Type not Supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Tax forms are not currently available for this account or this year | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

