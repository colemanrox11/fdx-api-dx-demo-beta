
# Document Status 2

Availability status of statement

*This model accepts additional fields of type Object.*

## Enumeration

`DocumentStatus2`

## Fields

| Name |
|  --- |
| `Available` |
| `Processing` |
| `Failed` |

