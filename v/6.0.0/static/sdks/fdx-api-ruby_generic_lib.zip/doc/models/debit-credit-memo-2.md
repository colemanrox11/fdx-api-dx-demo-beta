
# Debit Credit Memo 2

DEBIT, CREDIT, MEMO

*This model accepts additional fields of type Object.*

## Enumeration

`DebitCreditMemo2`

## Fields

| Name |
|  --- |
| `CREDIT` |
| `DEBIT` |
| `MEMO` |

