
# Deposit Transaction Entity

A transaction on a deposit account type

*This model accepts additional fields of type Object.*

## Structure

`DepositTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_type` | [`DepositTransactionType2`](../../doc/models/deposit-transaction-type-2.md) | Optional | CHECK, WITHDRAWAL, TRANSFER, POSDEBIT, ATMWITHDRAWAL, BILLPAYMENT, FEE, DEPOSIT, ADJUSTMENT, INTEREST, DIVIDEND, DIRECTDEPOSIT, ATMDEPOSIT, POSCREDIT |
| `payee` | `String` | Optional | Payee name<br><br>**Constraints**: *Maximum Length*: `255` |
| `check_number` | `Integer` | Optional | Check number |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountCategory": "Deposit Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "ADJUSTMENT",
  "payee": "payee6",
  "checkNumber": 204
}
```

