
# Policy Premium Term Type

Payment terms for insurance premiums

*This model accepts additional fields of type interface{}.*

## Enumeration

`PolicyPremiumTermType`

## Fields

| Name |
|  --- |
| `Annual` |
| `Monthly` |

