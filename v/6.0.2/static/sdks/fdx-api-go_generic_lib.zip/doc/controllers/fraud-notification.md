# Fraud Notification

```go
fraudNotificationController := client.FraudNotificationController()
```

## Class Name

`FraudNotificationController`


# Report Suspected Fraud Incident

Notify Data Provider of suspected fraud

```go
ReportSuspectedFraudIncident(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    body *models.SuspectedFraudIncidentEntity) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.SuspectedFraudIncidentEntity`](../../doc/models/suspected-fraud-incident-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")



body := models.SuspectedFraudIncidentEntity{
    Type:                  models.ToPointer("RISK"),
    SuspectedIncidentId:   models.ToPointer("0a318518-ca16-4e66-be76-865a632ea771"),
    Reporter:              models.ToPointer(models.PartyEntity{
        Name:                  "ABC Inc",
        Type:                  models.PartyType_DataAccessPlatform,
        HomeUri:               models.ToPointer("http://example.com"),
        LogoUri:               models.ToPointer("http://example.com"),
        Registry:              models.ToPointer(models.Registry_Fdx),
        RegisteredEntityName:  models.ToPointer("ABC"),
        RegisteredEntityId:    models.ToPointer("ABC123"),
    }),
}

resp, err := fraudNotificationController.ReportSuspectedFraudIncident(ctx, xFapiInteractionId, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

