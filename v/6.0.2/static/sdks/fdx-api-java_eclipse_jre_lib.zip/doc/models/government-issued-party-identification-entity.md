
# Government Issued Party Identification Entity

Government issued identification document that is used to uniquely
identify a person or business

*This model accepts additional fields of type Object.*

## Structure

`GovernmentIssuedPartyIdentificationEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdNumber` | `String` | Optional | Identification number<br><br>**Constraints**: *Maximum Length*: `256` | String getIdNumber() | setIdNumber(String idNumber) |
| `IssuedDate` | `String` | Optional | Issued date | String getIssuedDate() | setIssuedDate(String issuedDate) |
| `ExpiryDate` | `String` | Optional | Expiry date | String getExpiryDate() | setExpiryDate(String expiryDate) |
| `Type` | [`GovernmentIssuedIdType2`](../../doc/models/government-issued-id-type-2.md) | Optional | Type of the identification | GovernmentIssuedIdType2 getType() | setType(GovernmentIssuedIdType2 type) |
| `IssuingCountryName` | `String` | Optional | Name of the issuing country | String getIssuingCountryName() | setIssuingCountryName(String issuingCountryName) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "idNumber": "idNumber2",
  "issuedDate": "issuedDate4",
  "expiryDate": "expiryDate4",
  "type": "DRIVERLICENSE",
  "issuingCountryName": "issuingCountryName0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

