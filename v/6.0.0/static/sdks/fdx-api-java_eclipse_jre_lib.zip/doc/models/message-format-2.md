
# Message Format 2

Defaults to JSON

*This model accepts additional fields of type Object.*

## Enumeration

`MessageFormat2`

## Fields

| Name |
|  --- |
| `Json` |

