
# Form 1120 SK1

Shareholder's Share of Income, Deductions, Credits, etc., from Corporation (boxes A-B as issuer) to Shareholder (boxes E-F as recipient)

*This model accepts additional fields of type Object.*

## Structure

`Form1120SK1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxYear` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | Integer getTaxYear() | setTaxYear(Integer taxYear) |
| `Corrected` | `Boolean` | Optional | True to indicate this is a corrected tax form | Boolean getCorrected() | setCorrected(Boolean corrected) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the source account. Not the account number<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `TaxFormId` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted.<br><br>**Constraints**: *Maximum Length*: `256` | String getTaxFormId() | setTaxFormId(String taxFormId) |
| `TaxFormDate` | `LocalDate` | Optional | Date of production or delivery of the tax form | LocalDate getTaxFormDate() | setTaxFormDate(LocalDate taxFormDate) |
| `AdditionalInformation` | `String` | Optional | Additional explanation text or content about this tax form | String getAdditionalInformation() | setAdditionalInformation(String additionalInformation) |
| `TaxFormType` | [`TypeFormType1`](../../doc/models/type-form-type-1.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | TypeFormType1 getTaxFormType() | setTaxFormType(TypeFormType1 taxFormType) |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty8 getIssuer() | setIssuer(TaxParty8 issuer) |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty1 getRecipient() | setRecipient(TaxParty1 recipient) |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | List<TaxFormAttribute> getAttributes() | setAttributes(List<TaxFormAttribute> attributes) |
| `Error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this form | Error1 getError() | setError(Error1 error) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `FinalK1` | `Boolean` | Optional | Final K-1 | Boolean getFinalK1() | setFinalK1(Boolean finalK1) |
| `AmendedK1` | `Boolean` | Optional | Amended K-1 | Boolean getAmendedK1() | setAmendedK1(Boolean amendedK1) |
| `FiscalYearBegin` | `LocalDate` | Optional | Fiscal year begin date | LocalDate getFiscalYearBegin() | setFiscalYearBegin(LocalDate fiscalYearBegin) |
| `FiscalYearEnd` | `LocalDate` | Optional | Fiscal year end date | LocalDate getFiscalYearEnd() | setFiscalYearEnd(LocalDate fiscalYearEnd) |
| `IrsCenter` | `String` | Optional | Box C, IRS Center where corporation filed return | String getIrsCenter() | setIrsCenter(String irsCenter) |
| `CorporationBeginningShares` | `Double` | Optional | Box D, Corporation's total number of shares, Beginning of tax year | Double getCorporationBeginningShares() | setCorporationBeginningShares(Double corporationBeginningShares) |
| `CorporationEndingShares` | `Double` | Optional | Box D, Corporation's total number of shares, End of tax year | Double getCorporationEndingShares() | setCorporationEndingShares(Double corporationEndingShares) |
| `PercentOwnership` | `Double` | Optional | Box G, Current year allocation percentage | Double getPercentOwnership() | setPercentOwnership(Double percentOwnership) |
| `BeginningShares` | `Double` | Optional | Box H, Shareholder's number of shares, Beginning of tax year | Double getBeginningShares() | setBeginningShares(Double beginningShares) |
| `EndingShares` | `Double` | Optional | Box H, Shareholder's number of shares, End of tax year | Double getEndingShares() | setEndingShares(Double endingShares) |
| `BeginningLoans` | `Double` | Optional | Box I, Loans from shareholder, Beginning of tax year | Double getBeginningLoans() | setBeginningLoans(Double beginningLoans) |
| `EndingLoans` | `Double` | Optional | Box I, Loans from shareholder, Ending of tax year | Double getEndingLoans() | setEndingLoans(Double endingLoans) |
| `OrdinaryIncome` | `Double` | Optional | Box 1, Ordinary business income (loss) | Double getOrdinaryIncome() | setOrdinaryIncome(Double ordinaryIncome) |
| `NetRentalRealEstateIncome` | `Double` | Optional | Box 2, Net rental real estate income (loss) | Double getNetRentalRealEstateIncome() | setNetRentalRealEstateIncome(Double netRentalRealEstateIncome) |
| `OtherRentalIncome` | `Double` | Optional | Box 3, Other net rental income (loss) | Double getOtherRentalIncome() | setOtherRentalIncome(Double otherRentalIncome) |
| `InterestIncome` | `Double` | Optional | Box 4, Interest income | Double getInterestIncome() | setInterestIncome(Double interestIncome) |
| `OrdinaryDividends` | `Double` | Optional | Box 5a, Ordinary dividends | Double getOrdinaryDividends() | setOrdinaryDividends(Double ordinaryDividends) |
| `QualifiedDividends` | `Double` | Optional | Box 5b, Qualified dividends | Double getQualifiedDividends() | setQualifiedDividends(Double qualifiedDividends) |
| `Royalties` | `Double` | Optional | Box 6, Royalties | Double getRoyalties() | setRoyalties(Double royalties) |
| `NetShortTermGain` | `Double` | Optional | Box 7, Net short-term capital gain (loss) | Double getNetShortTermGain() | setNetShortTermGain(Double netShortTermGain) |
| `NetLongTermGain` | `Double` | Optional | Box 8a, Net long-term capital gain (loss) | Double getNetLongTermGain() | setNetLongTermGain(Double netLongTermGain) |
| `CollectiblesGain` | `Double` | Optional | Box 8b, Collectibles (28%) gain (loss) | Double getCollectiblesGain() | setCollectiblesGain(Double collectiblesGain) |
| `Unrecaptured1250Gain` | `Double` | Optional | Box 8c, Unrecaptured section 1250 gain | Double getUnrecaptured1250Gain() | setUnrecaptured1250Gain(Double unrecaptured1250Gain) |
| `Net1231Gain` | `Double` | Optional | Box 9, Net section 1231 gain (loss) | Double getNet1231Gain() | setNet1231Gain(Double net1231Gain) |
| `OtherIncome` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 10, Other income (loss) | List<CodeAndAmount> getOtherIncome() | setOtherIncome(List<CodeAndAmount> otherIncome) |
| `Section179Deduction` | `Double` | Optional | Box 11, Section 179 deduction | Double getSection179Deduction() | setSection179Deduction(Double section179Deduction) |
| `OtherDeductions` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 12, Other deductions | List<CodeAndAmount> getOtherDeductions() | setOtherDeductions(List<CodeAndAmount> otherDeductions) |
| `Credits` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 13, Credits | List<CodeAndAmount> getCredits() | setCredits(List<CodeAndAmount> credits) |
| `ScheduleK3` | `Boolean` | Optional | Box 14, Schedule K-3 is attached | Boolean getScheduleK3() | setScheduleK3(Boolean scheduleK3) |
| `AmtItems` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 15, Alternative minimum tax (AMT) items | List<CodeAndAmount> getAmtItems() | setAmtItems(List<CodeAndAmount> amtItems) |
| `BasisItems` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 16, Items affecting shareholder basis | List<CodeAndAmount> getBasisItems() | setBasisItems(List<CodeAndAmount> basisItems) |
| `OtherInfo` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 17, Other information | List<CodeAndAmount> getOtherInfo() | setOtherInfo(List<CodeAndAmount> otherInfo) |
| `MultipleAtRiskActivities` | `Boolean` | Optional | Box 18, More than one activity for at-risk purposes | Boolean getMultipleAtRiskActivities() | setMultipleAtRiskActivities(Boolean multipleAtRiskActivities) |
| `MultiplePassiveActivities` | `Boolean` | Optional | Box 19, More than one activity for passive activity purposes | Boolean getMultiplePassiveActivities() | setMultiplePassiveActivities(Boolean multiplePassiveActivities) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "fiscalYearBegin": "2021-07-15",
  "fiscalYearEnd": "2021-07-15",
  "corrected": false,
  "accountId": "accountId6",
  "taxFormId": "taxFormId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

