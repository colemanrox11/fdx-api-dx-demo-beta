
# Transfer for Create Entity 1

Data of the transfer request

*This model accepts additional fields of type Object.*

## Structure

`TransferForCreateEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransferId` | `String` | Optional | Client generated, long-term persistent identity of the transfer action. This ID should be maintained and returned by institution<br><br>**Constraints**: *Maximum Length*: `256` | String getTransferId() | setTransferId(String transferId) |
| `FromAccountId` | `String` | Optional | Long-term persistent identity of the source account<br><br>**Constraints**: *Maximum Length*: `256` | String getFromAccountId() | setFromAccountId(String fromAccountId) |
| `ToAccountId` | `String` | Optional | Long-term persistent identity of the destination account<br><br>**Constraints**: *Maximum Length*: `256` | String getToAccountId() | setToAccountId(String toAccountId) |
| `Amount` | `Double` | Optional | Positive amount of money to be transferred | Double getAmount() | setAmount(Double amount) |
| `Memo` | `String` | Optional | User-entered reason for transfer<br><br>**Constraints**: *Maximum Length*: `255` | String getMemo() | setMemo(String memo) |
| `PaymentDetails` | [`PaymentDetailsEntity`](../../doc/models/payment-details-entity.md) | Optional | Payment details | PaymentDetailsEntity getPaymentDetails() | setPaymentDetails(PaymentDetailsEntity paymentDetails) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "transferId": "transferId8",
  "fromAccountId": "fromAccountId4",
  "toAccountId": "toAccountId0",
  "amount": 112.62,
  "memo": "memo4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

