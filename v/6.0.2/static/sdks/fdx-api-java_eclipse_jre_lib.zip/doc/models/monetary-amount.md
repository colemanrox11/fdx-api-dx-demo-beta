
# Monetary Amount

The amount and currency of the base pay rate of employee

*This model accepts additional fields of type Object.*

## Structure

`MonetaryAmount`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Amount` | `double` | Required | The monetary amount | double getAmount() | setAmount(double amount) |
| `Currency` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | Currency code of the monetary amount | Iso4217CurrencyCode getCurrency() | setCurrency(Iso4217CurrencyCode currency) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "amount": 167.22,
  "currency": "TRY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

