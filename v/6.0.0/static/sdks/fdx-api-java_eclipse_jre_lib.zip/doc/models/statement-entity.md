
# Statement Entity

An account statement

*This model accepts additional fields of type Object.*

## Structure

`StatementEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Corresponds to accountId in Account entity<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `StatementId` | `String` | Optional | Long-term persistent identity of the statement<br><br>**Constraints**: *Maximum Length*: `256` | String getStatementId() | setStatementId(String statementId) |
| `StatementDate` | `LocalDate` | Optional | Date of the statement | LocalDate getStatementDate() | setStatementDate(LocalDate statementDate) |
| `Description` | `String` | Optional | Description of statement | String getDescription() | setDescription(String description) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | The links to retrieve this account statement, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `Status` | [`DocumentStatus2`](../../doc/models/document-status-2.md) | Optional | Availability status of statement | DocumentStatus2 getStatus() | setStatus(DocumentStatus2 status) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "statementDate": "2021-07-15",
  "accountId": "accountId8",
  "statementId": "statementId2",
  "description": "description8",
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

