
# Individual Name

First name, middle initial, last name, suffix fields

*This model accepts additional fields of type Object.*

## Structure

`IndividualName`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `First` | `String` | Optional | First name | String getFirst() | setFirst(String first) |
| `Middle` | `String` | Optional | Middle initial | String getMiddle() | setMiddle(String middle) |
| `Last` | `String` | Optional | Last name | String getLast() | setLast(String last) |
| `Suffix` | `String` | Optional | Generational or academic suffix | String getSuffix() | setSuffix(String suffix) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "first": "first2",
  "middle": "middle2",
  "last": "last4",
  "suffix": "suffix4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

