
# Asset Transfer Network List

An array of asset transfer network details for this account

*This model accepts additional fields of type Object.*

## Structure

`AssetTransferNetworkList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetTransferNetworks` | [`List<AssetTransferNetwork>`](../../doc/models/asset-transfer-network.md) | Optional | Array of asset transfer networks | List<AssetTransferNetwork> getAssetTransferNetworks() | setAssetTransferNetworks(List<AssetTransferNetwork> assetTransferNetworks) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "assetTransferNetworks": [
    {
      "identifier": "identifier0",
      "identifierType": "ACCOUNT_NUMBER",
      "institutionName": "institutionName0",
      "institutionId": "institutionId6",
      "type": "US_DTC",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

