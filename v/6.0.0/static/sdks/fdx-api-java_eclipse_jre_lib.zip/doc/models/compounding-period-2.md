
# Compounding Period 2

DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY

*This model accepts additional fields of type Object.*

## Enumeration

`CompoundingPeriod2`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

