
# Payment for Update Entity 1

The data of the Payment to be scheduled

*This model accepts additional fields of type Object.*

## Structure

`PaymentForUpdateEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FromAccountId` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` | String getFromAccountId() | setFromAccountId(String fromAccountId) |
| `ToPayeeId` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` | String getToPayeeId() | setToPayeeId(String toPayeeId) |
| `Amount` | `double` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` | double getAmount() | setAmount(double amount) |
| `MerchantAccountId` | `String` | Optional | User's account identifier with the merchant | String getMerchantAccountId() | setMerchantAccountId(String merchantAccountId) |
| `DueDate` | `LocalDate` | Required | Date that the funds are scheduled to be delivered | LocalDate getDueDate() | setDueDate(LocalDate dueDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "fromAccountId": "fromAccountId2",
  "toPayeeId": "toPayeeId6",
  "amount": 138.6,
  "dueDate": "2021-07-15",
  "merchantAccountId": "merchantAccountId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

