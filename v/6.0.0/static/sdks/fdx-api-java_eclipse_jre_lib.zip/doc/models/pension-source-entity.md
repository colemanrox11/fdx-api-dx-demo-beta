
# Pension Source Entity

The source of pension funds

*This model accepts additional fields of type Object.*

## Structure

`PensionSourceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DisplayName` | `String` | Optional | Name of the source | String getDisplayName() | setDisplayName(String displayName) |
| `Amount` | `Double` | Optional | Benefit Amount | Double getAmount() | setAmount(Double amount) |
| `PaymentOption` | `String` | Optional | Form of payment | String getPaymentOption() | setPaymentOption(String paymentOption) |
| `AsOfDate` | `LocalDate` | Optional | Date benefit was calculated | LocalDate getAsOfDate() | setAsOfDate(LocalDate asOfDate) |
| `Frequency` | [`PaymentFrequency3`](../../doc/models/payment-frequency-3.md) | Optional | ANNUALLY, BIWEEKLY, DAILY, MONTHLY, SEMIANNUALLY, SEMIMONTHLY, WEEKLY | PaymentFrequency3 getFrequency() | setFrequency(PaymentFrequency3 frequency) |
| `StartDate` | `LocalDate` | Optional | Assumed retirement date. As of date amount is payable | LocalDate getStartDate() | setStartDate(LocalDate startDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "asOfDate": "2021-07-15",
  "startDate": "2021-07-15",
  "displayName": "displayName6",
  "amount": 39.82,
  "paymentOption": "paymentOption2",
  "frequency": "DAILY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

