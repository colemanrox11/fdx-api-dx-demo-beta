
# Account Type

Account type

*This model accepts additional fields of type Object.*

## Enumeration

`AccountType`

## Fields

| Name |
|  --- |
| `Enum401A` |
| `Enum401K` |
| `Enum403B` |
| `Enum529` |
| `Annuity` |
| `Autoloan` |
| `Brokerageproduct` |
| `Cd` |
| `Charge` |
| `Checking` |
| `Commercialdeposit` |
| `Commercialinvestment` |
| `Commerciallineofcredit` |
| `Commercialloan` |
| `Coverdell` |
| `Creditcard` |
| `Deferredprofitsharingplan` |
| `Definedbenefit` |
| `Digitalasset` |
| `Digitalwallet` |
| `Escrow` |
| `Esop` |
| `Fixedannuity` |
| `Guardian` |
| `Homeequityloan` |
| `Homelineofcredit` |
| `Individualpensionplan` |
| `Installment` |
| `Institutionaltrust` |
| `Investmentaccount` |
| `Ira` |
| `Keogh` |
| `Lifeincomefund` |
| `Lineofcredit` |
| `Loan` |
| `Lockedinretirementaccount` |
| `Lockedinretirementincomefund` |
| `Lockedinretirementsavingsplan` |
| `Longtermdisability` |
| `Militaryloan` |
| `Moneymarket` |
| `Mortgage` |
| `Nonqualifiedplan` |
| `Otherdeposit` |
| `Otherinvestment` |
| `Personalloan` |
| `Pooledregisteredpensionplan` |
| `Prepaid` |
| `Prescribedregisteredretirementincomefund` |
| `Registereddisabilitysavingsplan` |
| `Registerededucationsavingsplan` |
| `Registeredpensionplan` |
| `Registeredretirementincomefund` |
| `Registeredretirementsavingsplan` |
| `Restrictedlifeincomefund` |
| `Restrictedlockedinsavingsplan` |
| `Rollover` |
| `Roth` |
| `Sarsep` |
| `Savings` |
| `Shorttermdisability` |
| `Smbloan` |
| `Specifiedpensionplan` |
| `Studentloan` |
| `Taxable` |
| `Taxfreesavingsaccount` |
| `Tda` |
| `Term` |
| `Trust` |
| `Ugma` |
| `Universallife` |
| `Utma` |
| `Variableannuity` |
| `Wholelife` |

