
# Investment Sale Type

Type of investment sale

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentSaleType`

## Fields

| Name |
|  --- |
| `Cryptocurrency` |
| `EmployeeStockPurchasePlan` |
| `IncentiveStockOption` |
| `NonqualifiedStockOptions` |
| `Other` |
| `RestrictedStock` |
| `RestrictedStockUnits` |

