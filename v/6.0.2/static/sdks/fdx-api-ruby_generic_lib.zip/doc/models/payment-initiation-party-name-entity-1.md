
# Payment Initiation Party Name Entity 1

Name entity associated with the payment initiation party

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyNameEntity1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `alias_name` | `String` | Optional | Alias name |
| `detail` | [Organization Name entity](../../doc/models/organization-name-entity.md) \| [Individual name](../../doc/models/individual-name.md) \| nil | Optional | This is a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "aliasName": "aliasName8",
  "detail": {
    "companyName": "companyName0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

