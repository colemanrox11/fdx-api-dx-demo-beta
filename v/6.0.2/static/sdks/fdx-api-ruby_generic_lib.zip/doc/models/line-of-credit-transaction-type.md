
# Line of Credit Transaction Type

The type of a line of credit transaction

*This model accepts additional fields of type Object.*

## Enumeration

`LineOfCreditTransactionType`

## Fields

| Name |
|  --- |
| `ADJUSTMENT` |
| `CHECK` |
| `FEE` |
| `INTEREST` |
| `PAYMENT` |
| `PURCHASE` |
| `WITHDRAWAL` |

