# Meta

API management and metrics

```ruby
meta_controller = client.meta
```

## Class Name

`MetaController`

## Methods

* [Get Availability](../../doc/controllers/meta.md#get-availability)
* [Get Capability](../../doc/controllers/meta.md#get-capability)
* [Get Certification Metrics](../../doc/controllers/meta.md#get-certification-metrics)


# Get Availability

Get information about this API's availability

```ruby
def get_availability(x_fapi_interaction_id,
                     fdx_api_actor_type: nil,
                     operation_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operation_id` | [`FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |

## Server

`Server::META`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`AvailabilityListEntity`](../../doc/models/availability-list-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = meta_controller.get_availability(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get Capability

Get information about this API's capability

```ruby
def get_capability(x_fapi_interaction_id,
                   fdx_api_actor_type: nil,
                   operation_id: nil,
                   fdx_version: nil,
                   result_type: ResultType::LIGHTWEIGHT)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operation_id` | [`FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |
| `fdx_version` | [`FdxVersion`](../../doc/models/fdx-version.md) | Query, Optional | Specific FDX version for which to get the capability. Optional |
| `result_type` | [`ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `ResultType::LIGHTWEIGHT` |

## Server

`Server::META`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`CapabilityEntity`](../../doc/models/capability-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result_type = ResultType::LIGHTWEIGHT

result = meta_controller.get_capability(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type,
  result_type: result_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get Certification Metrics

Get certification performance metrics for this implementer's APIs

```ruby
def get_certification_metrics(x_fapi_interaction_id,
                              fdx_api_actor_type: nil,
                              operation_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operation_id` | [`FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |

## Server

`Server::META`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`CertificationMetricsEntity`](../../doc/models/certification-metrics-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = meta_controller.get_certification_metrics(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

