
# Coverage Month 3

Month of coverage

*This model accepts additional fields of type Object.*

## Enumeration

`CoverageMonth3`

## Fields

| Name |
|  --- |
| `Annual` |
| `January` |
| `February` |
| `March` |
| `April` |
| `May` |
| `June` |
| `July` |
| `August` |
| `September` |
| `October` |
| `November` |
| `December` |

