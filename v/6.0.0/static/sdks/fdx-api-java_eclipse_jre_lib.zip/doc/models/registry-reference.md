
# Registry Reference

Used for registry references. Properties in this structure use 'snake_case' names to match the properties in [IETF RFC 7591](https://datatracker.ietf.org/doc/rfc7591/)

*This model accepts additional fields of type Object.*

## Structure

`RegistryReference`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RegisteredEntityName` | `String` | Optional | The legal company name for the intermediary | String getRegisteredEntityName() | setRegisteredEntityName(String registeredEntityName) |
| `RegisteredEntityId` | `String` | Optional | An ID representing the intermediary that can be looked up from a legal identity registry source | String getRegisteredEntityId() | setRegisteredEntityId(String registeredEntityId) |
| `Registry` | [`Registry`](../../doc/models/registry.md) | Optional | The Registry source | Registry getRegistry() | setRegistry(Registry registry) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "registered_entity_name": "registered_entity_name0",
  "registered_entity_id": "registered_entity_id0",
  "registry": "ICANN",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

