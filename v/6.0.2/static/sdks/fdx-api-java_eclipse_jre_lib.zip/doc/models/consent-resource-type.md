
# Consent Resource Type

Resource for which data may be permissioned; can be extended to support additional types of resources

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentResourceType`

## Fields

| Name |
|  --- |
| `Account` |
| `Customer` |
| `Document` |

