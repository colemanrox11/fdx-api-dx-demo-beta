
# Income

Provides a person's employment income details. Applicable only for VOIE (Verification of Income and Employment) data retrieval

*This model accepts additional fields of type Object.*

## Structure

`Income`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BaseRate` | [`BasePayrollRate1`](../../doc/models/base-payroll-rate-1.md) | Optional | The employee's base payroll rate | BasePayrollRate1 getBaseRate() | setBaseRate(BasePayrollRate1 baseRate) |
| `PayrollFrequency` | [`PayrollFrequencyType2`](../../doc/models/payroll-frequency-type-2.md) | Required | The frequency of payments | PayrollFrequencyType2 getPayrollFrequency() | setPayrollFrequency(PayrollFrequencyType2 payrollFrequency) |
| `LatestPayDate` | `LocalDate` | Optional | The date of employee's most recent pay | LocalDate getLatestPayDate() | setLatestPayDate(LocalDate latestPayDate) |
| `LatestPayPeriodEndDate` | `LocalDate` | Optional | The end date of employee's most recent pay period | LocalDate getLatestPayPeriodEndDate() | setLatestPayPeriodEndDate(LocalDate latestPayPeriodEndDate) |
| `AnnualPay` | [`PaymentAmounts1`](../../doc/models/payment-amounts-1.md) | Optional | Year-to-date pay for current year and total annual pay for previous years | PaymentAmounts1 getAnnualPay() | setAnnualPay(PaymentAmounts1 annualPay) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "payrollFrequency": "DAILY",
  "latestPayDate": "2021-07-15",
  "latestPayPeriodEndDate": "2021-07-15",
  "baseRate": {
    "rate": {
      "amount": 238.12,
      "currency": "JPY",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "rateType": "HOURLY",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "annualPay": {
    "year": 218,
    "grossPay": {
      "total": {
        "amount": 71.32,
        "currency": "DOP",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "base": {
        "amount": 221.48,
        "currency": "TJS",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "bonus": {
        "amount": 28.78,
        "currency": "MMK",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "commission": {
        "amount": 19.08,
        "currency": "ISK",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "overtime": {
        "amount": 44.08,
        "currency": "XTS",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "otherEarnings": [
        {
          "amount": 117.02,
          "currency": "MDL",
          "name": "name0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "amount": 117.02,
          "currency": "MDL",
          "name": "name0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "netPay": {
      "amount": 9.88,
      "currency": "BBD",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

