
# Notification Payload Entity 2

Notification-specific key-value paired data

*This model accepts additional fields of type Object.*

## Structure

`NotificationPayloadEntity2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | `String` | Optional | ID for the origination entity related to the notification | String getId() | setId(String id) |
| `IdType` | [`NotificationPayloadIdType2`](../../doc/models/notification-payload-id-type-2.md) | Optional | Type of entity causing origination of the notification with the given ID | NotificationPayloadIdType2 getIdType() | setIdType(NotificationPayloadIdType2 idType) |
| `CustomFields` | [`FiAttributeEntity`](../../doc/models/fi-attribute-entity.md) | Optional | Custom key-value pairs for a notification | FiAttributeEntity getCustomFields() | setCustomFields(FiAttributeEntity customFields) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "id": "id0",
  "idType": "PARTY",
  "customFields": {
    "name": "name0",
    "value": "value2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

