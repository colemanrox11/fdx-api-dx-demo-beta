
# Secured

How the option is secured

*This model accepts additional fields of type Object.*

## Enumeration

`Secured`

## Fields

| Name |
|  --- |
| `COVERED` |
| `NAKED` |

