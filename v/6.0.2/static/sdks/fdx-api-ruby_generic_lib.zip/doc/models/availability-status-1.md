
# Availability Status 1

API availability status for this time period

*This model accepts additional fields of type Object.*

## Enumeration

`AvailabilityStatus1`

## Fields

| Name |
|  --- |
| `ALIVE` |
| `PARTIAL` |
| `MAINTENANCE` |
| `DOWN` |

