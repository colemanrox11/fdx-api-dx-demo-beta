
# Consent Duration Type

The type of duration of the consent

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentDurationType`

## Fields

| Name |
|  --- |
| `ONE_TIME` |
| `PERSISTENT` |
| `TIME_BOUND` |

