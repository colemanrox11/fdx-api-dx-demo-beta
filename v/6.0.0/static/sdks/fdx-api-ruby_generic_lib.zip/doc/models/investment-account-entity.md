
# Investment Account Entity

An investment account type and information such as balances, transactions, holdings and privileges

*This model accepts additional fields of type Object.*

## Structure

`InvestmentAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `balance_as_of` | `DateTime` | Optional | As-of date for balances |
| `allowed_check_writing` | `TrueClass \| FalseClass` | Optional | Check writing privileges |
| `allowed_option_trade` | `TrueClass \| FalseClass` | Optional | Allowed to trade options |
| `current_value` | `Float` | Optional | Total current value of all investments |
| `holdings` | [`Array<HoldingEntity>`](../../doc/models/holding-entity.md) | Optional | Holdings in the investment account |
| `open_orders` | [`Array<OpenOrderEntity>`](../../doc/models/open-order-entity.md) | Optional | Open orders in the investment account |
| `contribution` | [`Array<ContributionEntity>`](../../doc/models/contribution-entity.md) | Optional | Describes how new contributions are distributed among the available securities |
| `vesting` | [`Array<VestingEntity>`](../../doc/models/vesting-entity.md) | Optional | Provides the past, present, and future vesting schedule and percentages |
| `investment_loans` | [`Array<InvestmentLoanEntity>`](../../doc/models/investment-loan-entity.md) | Optional | Investment loans in the account |
| `available_cash_balance` | `Float` | Optional | Cash balance across all sub-accounts. Should include sweep funds |
| `margin` | `TrueClass \| FalseClass` | Optional | Margin trading is allowed |
| `margin_balance` | `Float` | Optional | Margin balance |
| `short_balance` | `Float` | Optional | Short balance |
| `rollover_amount` | `Float` | Optional | Rollover amount |
| `employer_name` | `String` | Optional | Name of the employer in investment 401k Plan |
| `broker_id` | `String` | Optional | Unique identifier FI |
| `plan_id` | `String` | Optional | Plan number for Investment 401k plan |
| `calendar_year_for_401_k` | `Integer` | Optional | The calendar year for this 401k account |
| `balance_list` | [`Array<InvestmentBalanceEntity>`](../../doc/models/investment-balance-entity.md) | Optional | List of balances. Aggregate of name value pairs |
| `daily_change` | `Float` | Optional | Daily change |
| `percentage_change` | `Float` | Optional | Percentage change |
| `transactions` | [`Array<InvestmentTransactionEntity>`](../../doc/models/investment-transaction-entity.md) | Optional | Transactions on the investment account |
| `pension_source` | [`Array<PensionSourceEntity>`](../../doc/models/pension-source-entity.md) | Optional | Pension sources in the investment account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "balanceAsOf": "07/15/2021 14:46:41",
  "accountCategory": "Investment Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "allowedCheckWriting": false,
  "allowedOptionTrade": false,
  "currentValue": 30.32,
  "holdings": [
    {
      "holdingId": "holdingId6",
      "securityIds": [
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "holdingName": "holdingName2",
      "holdingType": "MUTUALFUND",
      "holdingSubType": "CASH",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ]
}
```

