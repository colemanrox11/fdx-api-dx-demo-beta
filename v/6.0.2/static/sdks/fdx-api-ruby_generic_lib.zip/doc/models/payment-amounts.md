
# Payment Amounts

Year to date amounts for current and previous years

*This model accepts additional fields of type Object.*

## Structure

`PaymentAmounts`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `total` | [`MonetaryAmount1`](../../doc/models/monetary-amount-1.md) | Required | Total gross pay for covered period |
| `base` | [`MonetaryAmount2`](../../doc/models/monetary-amount-2.md) | Optional | Base pay part of Gross pay for covered period |
| `bonus` | [`MonetaryAmount3`](../../doc/models/monetary-amount-3.md) | Optional | Bonus pay for covered period |
| `commission` | [`MonetaryAmount4`](../../doc/models/monetary-amount-4.md) | Optional | Commission for covered period |
| `overtime` | [`MonetaryAmount5`](../../doc/models/monetary-amount-5.md) | Optional | Overtime pay for covered period |
| `other_earnings` | [`Array<OtherMonetaryAmount>`](../../doc/models/other-monetary-amount.md) | Optional | Other earnings received in covered period |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "total": {
    "amount": 71.32,
    "currency": "DOP",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "base": {
    "amount": 221.48,
    "currency": "TJS",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "bonus": {
    "amount": 28.78,
    "currency": "MMK",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "commission": {
    "amount": 19.08,
    "currency": "ISK",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "overtime": {
    "amount": 44.08,
    "currency": "XTS",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "otherEarnings": [
    {
      "amount": 117.02,
      "currency": "MDL",
      "name": "name0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

