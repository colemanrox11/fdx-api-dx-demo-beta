
# Investment Transaction Type

The type of an investment transaction

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentTransactionType`

## Fields

| Name |
|  --- |
| `ADJUSTMENT` |
| `AIRDROP` |
| `ATM` |
| `CASH` |
| `CHECK` |
| `CLOSURE` |
| `CLOSUREOPT` |
| `CONTRIBUTION` |
| `DEP` |
| `DEPOSIT` |
| `DIRECTDEBIT` |
| `DIRECTDEP` |
| `DIV` |
| `DIVIDEND` |
| `DIVIDENDREINVEST` |
| `EXPENSE` |
| `FEE` |
| `FORKED` |
| `INCOME` |
| `INTEREST` |
| `INVEXPENSE` |
| `JRNLFUND` |
| `JRNLSEC` |
| `MARGININTEREST` |
| `MINED` |
| `OPTIONEXERCISE` |
| `OPTIONEXPIRATION` |
| `OTHER` |
| `PAYMENT` |
| `POS` |
| `PURCHASED` |
| `PURCHASEDTOCOVER` |
| `PURCHASETOCLOSE` |
| `PURCHASETOOPEN` |
| `REINVESTOFINCOME` |
| `REPEATPMT` |
| `RETURNOFCAPITAL` |
| `SOLD` |
| `SOLDTOCLOSE` |
| `SOLDTOOPEN` |
| `SPLIT` |
| `SRVCHG` |
| `STAKED` |
| `TRANSFER` |
| `WITHDRAWAL` |
| `XFER` |

