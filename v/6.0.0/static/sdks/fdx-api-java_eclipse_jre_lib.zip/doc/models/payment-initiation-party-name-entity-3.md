
# Payment Initiation Party Name Entity 3

Details of the name

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyNameEntity3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AliasName` | `String` | Optional | Alias name | String getAliasName() | setAliasName(String aliasName) |
| `Detail` | [`PaymentInitiationPartyNameEntity3Detail`](../../doc/models/containers/payment-initiation-party-name-entity-3-detail.md) | Optional | This is a container for any-of cases. | PaymentInitiationPartyNameEntity3Detail getDetail() | setDetail(PaymentInitiationPartyNameEntity3Detail detail) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "aliasName": "aliasName4",
  "detail": {
    "companyName": "companyName0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

