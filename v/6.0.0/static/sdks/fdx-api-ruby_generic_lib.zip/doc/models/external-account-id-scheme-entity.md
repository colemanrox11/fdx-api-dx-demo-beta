
# External Account Id Scheme Entity

External account identification scheme

*This model accepts additional fields of type Object.*

## Structure

`ExternalAccountIdSchemeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id_code` | `String` | Optional | Identification code<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "idCode": "idCode2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

