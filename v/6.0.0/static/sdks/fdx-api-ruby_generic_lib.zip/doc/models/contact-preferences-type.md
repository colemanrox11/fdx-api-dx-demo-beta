
# Contact Preferences Type

Contact Preferences Type

*This model accepts additional fields of type Object.*

## Enumeration

`ContactPreferencesType`

## Fields

| Name |
|  --- |
| `CELL` |
| `EMAIL` |
| `FAX` |
| `LETTER` |
| `PHONE` |

