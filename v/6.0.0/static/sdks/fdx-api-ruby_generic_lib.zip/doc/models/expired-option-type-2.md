
# Expired Option Type 2

To indicate gain or loss resulted from option expiration. If salesPrice (1d, proceeds) is zero, use PURCHASED. If costBasis (1e) is zero, use GRANTED

*This model accepts additional fields of type Object.*

## Enumeration

`ExpiredOptionType2`

## Fields

| Name |
|  --- |
| `GRANTED` |
| `PURCHASED` |

