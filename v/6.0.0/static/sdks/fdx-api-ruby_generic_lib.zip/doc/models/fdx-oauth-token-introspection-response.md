
# Fdx Oauth Token Introspection Response

FDX response enabling transport of ConsentGrant details extended from [JSON Web Token (JWT) Profile for OAuth 2.0 Access Tokens](https://datatracker.ietf.org/doc/html/rfc9068)

*This model accepts additional fields of type Object.*

## Structure

`FdxOauthTokenIntrospectionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `active` | `TrueClass \| FalseClass` | Optional | Flag indicating whether 'ConsentGrant' is active |
| `iss` | `String` | Optional | Issuer claim 'iss' identifies the principal that issued the JWT. Contains a [StringOrURI](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value |
| `sub` | `String` | Optional | Subject claim 'sub' identifies the principal that is the subject of the JWT. Contains a [StringOrURI](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value |
| `aud` | `String` | Optional | Audience claim 'aud' identifies the recipients for whom the JWT is intended. May be a single StringOrURI value or an array of [StringOrURI](https://datatracker.ietf.org/doc/html/rfc7519#section-2) values |
| `exp` | `Float` | Optional | Expiration Time claim 'exp' identifies the time on or after which the JWT MUST NOT be accepted Contains a number which is a [NumericDate](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value |
| `iat` | `Float` | Optional | Issued At claim 'iat' identifies the time at which the JWT was issued. Contains a number which is a [NumericDate](https://datatracker.ietf.org/doc/html/rfc7519#section-2) value |
| `jti` | `String` | Optional | JWT ID claim 'jti' provides a unique identifier for the JWT. Contains a case-sensitive string value |
| `client_id` | `String` | Optional | The unique client identifier for the Data Recipient granted the consent |
| `scope` | `String` | Optional | Space-delimited array of any number of scopes from those in FdxOauthScope, plus 'openid' and 'offline_access' |
| `fdx_consent_id` | `String` | Optional | Unique ID for a consent grant<br><br>**Constraints**: *Maximum Length*: `256` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "active": false,
  "iss": "iss2",
  "sub": "sub8",
  "aud": "aud2",
  "exp": 158.14,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

