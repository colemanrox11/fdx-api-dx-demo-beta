
# Investment Transfer Action Direction 2

Transfer direction

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentTransferActionDirection2`

## Fields

| Name |
|  --- |
| `In` |
| `Out` |

