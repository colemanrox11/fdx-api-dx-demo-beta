
# Intermediary

Data Access Platform, Service Provider, or any other entity in the data sharing chain between a Data Provider to a Data Recipient. Properties in this structure use 'snake_case' names to match the properties in [IETF RFC 7591](https://datatracker.ietf.org/doc/rfc7591/)

*This model accepts additional fields of type Object.*

## Structure

`Intermediary`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of intermediary party | String getName() | setName(String name) |
| `Description` | `String` | Optional | A short description of the intermediary | String getDescription() | setDescription(String description) |
| `Uri` | `String` | Optional | A URL string of a web page providing information about the intermediary | String getUri() | setUri(String uri) |
| `LogoUri` | `String` | Optional | A URL string that references a logo for this intermediary | String getLogoUri() | setLogoUri(String logoUri) |
| `Contacts` | `List<String>` | Optional | Array of strings representing ways to contact people responsible for this intermediary | List<String> getContacts() | setContacts(List<String> contacts) |
| `RegistryReferences` | [`List<RegistryReference>`](../../doc/models/registry-reference.md) | Optional | Registry references for this intermediary | List<RegistryReference> getRegistryReferences() | setRegistryReferences(List<RegistryReference> registryReferences) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "name": "name4",
  "description": "description4",
  "uri": "uri8",
  "logo_uri": "logo_uri0",
  "contacts": [
    "contacts1",
    "contacts2",
    "contacts3"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

