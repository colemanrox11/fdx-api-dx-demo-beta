
# Income Type

The type of income of an investment transaction

*This model accepts additional fields of type Object.*

## Enumeration

`IncomeType`

## Fields

| Name |
|  --- |
| `CGLONG` |
| `CGSHORT` |
| `MISC` |

