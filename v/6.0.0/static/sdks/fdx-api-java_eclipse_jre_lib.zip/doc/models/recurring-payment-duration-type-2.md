
# Recurring Payment Duration Type 2

Type of duration

*This model accepts additional fields of type Object.*

## Enumeration

`RecurringPaymentDurationType2`

## Fields

| Name |
|  --- |
| `Noend` |
| `Numberoftimes` |

