
# Payment Network Identifier Type 1

Type of identifier

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentNetworkIdentifierType1`

## Fields

| Name |
|  --- |
| `AccountNumber` |
| `TokenizedAccountNumber` |

