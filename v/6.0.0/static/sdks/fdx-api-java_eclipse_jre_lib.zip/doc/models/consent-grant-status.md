
# Consent Grant Status

Current status of Consent Grant

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentGrantStatus`

## Fields

| Name |
|  --- |
| `Active` |
| `Expired` |
| `Revoked` |

