
# Investment Account Entity

An investment account type and information such as balances, transactions, holdings and privileges

*This model accepts additional fields of type interface{}.*

## Structure

`InvestmentAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceAsOf` | `*time.Time` | Optional | As-of date for balances |
| `AllowedCheckWriting` | `*bool` | Optional | Check writing privileges |
| `AllowedOptionTrade` | `*bool` | Optional | Allowed to trade options |
| `CurrentValue` | `*float64` | Optional | Total current value of all investments |
| `Holdings` | [`[]models.HoldingEntity`](../../doc/models/holding-entity.md) | Optional | Holdings in the investment account |
| `OpenOrders` | [`[]models.OpenOrderEntity`](../../doc/models/open-order-entity.md) | Optional | Open orders in the investment account |
| `Contribution` | [`[]models.ContributionEntity`](../../doc/models/contribution-entity.md) | Optional | Describes how new contributions are distributed among the available securities |
| `Vesting` | [`[]models.VestingEntity`](../../doc/models/vesting-entity.md) | Optional | Provides the past, present, and future vesting schedule and percentages |
| `InvestmentLoans` | [`[]models.InvestmentLoanEntity`](../../doc/models/investment-loan-entity.md) | Optional | Investment loans in the account |
| `AvailableCashBalance` | `*float64` | Optional | Cash balance across all sub-accounts. Should include sweep funds |
| `Margin` | `*bool` | Optional | Margin trading is allowed |
| `MarginBalance` | `*float64` | Optional | Margin balance |
| `ShortBalance` | `*float64` | Optional | Short balance |
| `RolloverAmount` | `*float64` | Optional | Rollover amount |
| `EmployerName` | `*string` | Optional | Name of the employer in investment 401k Plan |
| `BrokerId` | `*string` | Optional | Unique identifier FI |
| `PlanId` | `*string` | Optional | Plan number for Investment 401k plan |
| `CalendarYearFor401K` | `*int` | Optional | The calendar year for this 401k account |
| `BalanceList` | [`[]models.InvestmentBalanceEntity`](../../doc/models/investment-balance-entity.md) | Optional | List of balances. Aggregate of name value pairs |
| `DailyChange` | `*float64` | Optional | Daily change |
| `PercentageChange` | `*float64` | Optional | Percentage change |
| `Transactions` | [`[]models.InvestmentTransactionEntityInterface`](../../doc/models/investment-transaction-entity.md) | Optional | Transactions on the investment account |
| `PensionSource` | [`[]models.PensionSourceEntity`](../../doc/models/pension-source-entity.md) | Optional | Pension sources in the investment account |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "balanceAsOf": "07/15/2021 14:46:41",
  "accountCategory": "Investment Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13T12:52:32.123Z",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13T12:52:32.123Z",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "allowedCheckWriting": false,
  "allowedOptionTrade": false,
  "currentValue": 30.32,
  "holdings": [
    {
      "holdingId": "holdingId6",
      "securityIds": [
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "holdingName": "holdingName2",
      "holdingType": "MUTUALFUND",
      "holdingSubType": "CASH",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ]
}
```

