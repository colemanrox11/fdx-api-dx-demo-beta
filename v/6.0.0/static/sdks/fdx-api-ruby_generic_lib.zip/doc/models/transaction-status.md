
# Transaction Status

The status of a transaction

*This model accepts additional fields of type Object.*

## Enumeration

`TransactionStatus`

## Fields

| Name |
|  --- |
| `AUTHORIZATION` |
| `MEMO` |
| `PENDING` |
| `POSTED` |

