
# Payment Method System Code

Unique identifier code of the external clearing system. Aligned with ISO 20022 pacs.008 group level

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodSystemCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `external_clearing_system_identification_1_code` | `String` | Optional | Unique identifier code of the external clearing system.<br>This is aligned with ISO 20022 pacs.008 group level. It can be<br>used to send the payment rail for the payment. ISO has already<br>listed codes in the fields which indicates the payment rail like<br>"ACH" for ACH, "ACS" for EFT Payments, "LVT" for Canada LVTS,<br>"LYX" for Lynx Canada, etc. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "externalClearingSystemIdentification1Code": "externalClearingSystemIdentification1Code4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

