
# Stock Type

The type of a stock instrument

*This model accepts additional fields of type Object.*

## Enumeration

`StockType`

## Fields

| Name |
|  --- |
| `COMMON` |
| `CONVERTIBLE` |
| `OTHER` |
| `PREFERRED` |

