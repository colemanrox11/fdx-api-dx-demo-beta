
# Account Descriptor Entity

This descriptor provides minimal information about the account for use in lightweight arrays

*This model accepts additional fields of type Object.*

## Structure

`AccountDescriptorEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountCategory` | `String` | Optional | - | String getAccountCategory() | setAccountCategory(String accountCategory) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the account, though not an account number. This identity must be unique to the owning institution<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `Error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this account | Error1 getError() | setError(Error1 error) |
| `AccountType` | [`AccountType`](../../doc/models/account-type.md) | Optional | Account type | AccountType getAccountType() | setAccountType(AccountType accountType) |
| `AccountNumber` | `String` | Optional | Full account number for the end user for this account at the owning institution. If not masked this is sensitive data which should only be exchanged if encrypted. For detailed information on implementing encryption see "Part 4 End to End Encryption" of the FDX API Security Model document in the Security section of the latest FDX Release download | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `AccountNumberDisplay` | `String` | Optional | Account display number for the end user's handle at the owning institution. This is to be displayed by the Interface Provider | String getAccountNumberDisplay() | setAccountNumberDisplay(String accountNumberDisplay) |
| `ProductName` | `String` | Optional | Marketed product name for this account. Used in UIs to assist in account selection | String getProductName() | setProductName(String productName) |
| `Nickname` | `String` | Optional | Name given by the user. Used in UIs to assist in account selection | String getNickname() | setNickname(String nickname) |
| `Status` | [`AccountStatus2`](../../doc/models/account-status-2.md) | Optional | Account status. Suggested values are: OPEN, CLOSED, PENDINGOPEN, PENDINGCLOSE, PAID, DELINQUENT, NEGATIVECURRENTBALANCE, RESTRICTED | AccountStatus2 getStatus() | setStatus(AccountStatus2 status) |
| `Description` | `String` | Optional | Description of account | String getDescription() | setDescription(String description) |
| `AccountOpenDate` | `LocalDate` | Optional | Account opening date | LocalDate getAccountOpenDate() | setAccountOpenDate(LocalDate accountOpenDate) |
| `AccountCloseDate` | `LocalDate` | Optional | Account closing date | LocalDate getAccountCloseDate() | setAccountCloseDate(LocalDate accountCloseDate) |
| `Currency` | [`CurrencyEntity4`](../../doc/models/currency-entity-4.md) | Optional | Account currency | CurrencyEntity4 getCurrency() | setCurrency(CurrencyEntity4 currency) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of Financial institution-specific attributes | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "balanceAsOf": "2016-03-13T12:52:32.123Z",
  "principalBalance": 32.64,
  "escrowBalance": 61.1,
  "originalPrincipal": 9.42,
  "originatingDate": "2016-03-13"
}
```

