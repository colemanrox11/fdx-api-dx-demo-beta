
# Sale Proceeds Type 2

Box 6, Reported to IRS: GROSS or NET

*This model accepts additional fields of type Object.*

## Enumeration

`SaleProceedsType2`

## Fields

| Name |
|  --- |
| `Gross` |
| `Net` |

