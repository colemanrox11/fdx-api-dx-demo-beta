
# Local Tax Withholding

Income in a locality and its tax withholding

*This model accepts additional fields of type Object.*

## Structure

`LocalTaxWithholding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxWithheld` | `Double` | Optional | Amount of local income tax withheld | Double getTaxWithheld() | setTaxWithheld(Double taxWithheld) |
| `LocalityName` | `String` | Optional | Locality name | String getLocalityName() | setLocalityName(String localityName) |
| `Income` | `Double` | Optional | Income amount for local tax purposes | Double getIncome() | setIncome(Double income) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxWithheld": 97.82,
  "localityName": "localityName0",
  "income": 162.16,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

