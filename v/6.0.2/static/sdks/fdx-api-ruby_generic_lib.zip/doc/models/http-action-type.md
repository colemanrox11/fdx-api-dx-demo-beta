
# Http Action Type

HTTP Method to use for the request

*This model accepts additional fields of type Object.*

## Enumeration

`HttpActionType`

## Fields

| Name |
|  --- |
| `DELETE` |
| `GET` |
| `PATCH` |
| `POST` |
| `PUT` |

