
# Reward Balance Entity

Reward program balance

*This model accepts additional fields of type Object.*

## Structure

`RewardBalanceEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name used to denominate the balance |
| `type` | [`RewardType2`](../../doc/models/reward-type-2.md) | Optional | The type of the reward balance - CASHBACK, MILES, POINTS |
| `balance` | `Float` | Optional | Total units available for redemption at time of download |
| `accrued_ytd` | `Float` | Optional | Total units accrued in the current program year at time of download<br><br>**Constraints**: `>= 0` |
| `redeemed_ytd` | `Float` | Optional | Total units redeemed in the current program year at time of download<br><br>**Constraints**: `>= 0` |
| `qualifying` | `TrueClass \| FalseClass` | Optional | Balance used for qualifying purposes<br><br>**Default**: `false` |
| `fi_attributes` | [`Array<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "qualifying": false,
  "name": "name6",
  "type": "CASHBACK",
  "balance": 78.5,
  "accruedYtd": 44.46,
  "redeemedYtd": 192.66,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

