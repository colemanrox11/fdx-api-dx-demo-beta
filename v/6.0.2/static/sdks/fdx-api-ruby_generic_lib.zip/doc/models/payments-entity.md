
# Payments Entity

A list of payments

*This model accepts additional fields of type Object.*

## Structure

`PaymentsEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets |
| `updates` | [`UpdatesMetadataEntity2`](../../doc/models/updates-metadata-entity-2.md) | Optional | Update IDs for retrieving updates since query |
| `links` | [`SynchronizableArrayLinksEntity2`](../../doc/models/synchronizable-array-links-entity-2.md) | Optional | Resource URLs for navigating result sets |
| `payments` | [`Array<PaymentEntity>`](../../doc/models/payment-entity.md) | Required | Payments retrieved by the operation |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "payments": [
    {
      "fromAccountId": "fromAccountId6",
      "toPayeeId": "toPayeeId0",
      "amount": 160.74,
      "dueDate": "2021-07-15",
      "paymentId": "paymentId4",
      "scheduledTimestamp": "07/15/2021 14:46:41",
      "processedTimestamp": "07/15/2021 14:46:41",
      "failedTimestamp": "07/15/2021 14:46:41",
      "cancelledTimestamp": "07/15/2021 14:46:41",
      "startedProcessingTimestamp": "07/15/2021 14:46:41",
      "status": "CANCELLED",
      "merchantAccountId": "merchantAccountId0",
      "recurringPaymentId": "recurringPaymentId4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "updates": {
    "nextUpdateId": "nextUpdateId4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "updates": {
      "href": "href2",
      "action": "PATCH",
      "rel": "rel6",
      "types": [
        "image/jpeg"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

