
# Transfer Entity

A single transfer of money. Refer to Transfers for a list of multiple transfers.

*This model accepts additional fields of type Object.*

## Structure

`TransferEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransferId` | `String` | Optional | Client generated, long-term persistent identity of the transfer action. This ID should be maintained and returned by institution<br><br>**Constraints**: *Maximum Length*: `256` | String getTransferId() | setTransferId(String transferId) |
| `FromAccountId` | `String` | Optional | Long-term persistent identity of the source account<br><br>**Constraints**: *Maximum Length*: `256` | String getFromAccountId() | setFromAccountId(String fromAccountId) |
| `ToAccountId` | `String` | Optional | Long-term persistent identity of the destination account<br><br>**Constraints**: *Maximum Length*: `256` | String getToAccountId() | setToAccountId(String toAccountId) |
| `Amount` | `Double` | Optional | Positive amount of money to be transferred | Double getAmount() | setAmount(Double amount) |
| `Memo` | `String` | Optional | User-entered reason for transfer<br><br>**Constraints**: *Maximum Length*: `255` | String getMemo() | setMemo(String memo) |
| `PaymentDetails` | [`PaymentDetailsEntity`](../../doc/models/payment-details-entity.md) | Optional | Payment details | PaymentDetailsEntity getPaymentDetails() | setPaymentDetails(PaymentDetailsEntity paymentDetails) |
| `ReferenceId` | `String` | Optional | Long-term persistent identifier for transfer attempt<br><br>**Constraints**: *Maximum Length*: `256` | String getReferenceId() | setReferenceId(String referenceId) |
| `Status` | [`PaymentStatus1`](../../doc/models/payment-status-1.md) | Optional | CANCELLED, FAILED, NOFUNDS, PROCESSED, PROCESSING, SCHEDULED | PaymentStatus1 getStatus() | setStatus(PaymentStatus1 status) |
| `TransferTime` | `LocalDateTime` | Optional | Date of transfer attempt | LocalDateTime getTransferTime() | setTransferTime(LocalDateTime transferTime) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "transferTime": "07/15/2021 14:46:41",
  "transferId": "transferId6",
  "fromAccountId": "fromAccountId2",
  "toAccountId": "toAccountId2",
  "amount": 204.6,
  "memo": "memo2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

