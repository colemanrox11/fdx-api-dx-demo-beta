
# Payment Frequency 3

ANNUALLY, BIWEEKLY, DAILY, MONTHLY, SEMIANNUALLY, SEMIMONTHLY, WEEKLY

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentFrequency3`

## Fields

| Name |
|  --- |
| `ANNUALLY` |
| `BIWEEKLY` |
| `DAILY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `SEMIMONTHLY` |
| `WEEKLY` |

