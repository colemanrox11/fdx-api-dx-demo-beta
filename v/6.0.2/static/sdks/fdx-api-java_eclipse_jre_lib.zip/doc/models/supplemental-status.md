
# Supplemental Status

Additional information about ACTIVE/INACTIVE employment status

*This model accepts additional fields of type Object.*

## Enumeration

`SupplementalStatus`

## Fields

| Name |
|  --- |
| `Furloughed` |
| `Leave` |
| `MedicalLeave` |
| `MilitaryLeave` |
| `PaternityLeave` |
| `Quit` |
| `Retired` |
| `Terminated` |
| `Vacation` |

