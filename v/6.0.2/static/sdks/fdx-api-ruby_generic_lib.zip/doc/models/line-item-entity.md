
# Line Item Entity

A line item within a transaction

*This model accepts additional fields of type Object.*

## Structure

`LineItemEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `description` | `String` | Optional | The description of the line item |
| `amount` | `Float` | Optional | The amount of money attributable to this line item |
| `check_number` | `Integer` | Optional | Check number |
| `memo` | `String` | Optional | Secondary item description<br><br>**Constraints**: *Maximum Length*: `255` |
| `reference` | `String` | Optional | A reference number |
| `image_ids` | `Array<String>` | Optional | Array of image identifiers (unique to transaction) used to retrieve images of check or transaction receipt |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links (unique to this Transaction) used to retrieve images of checks or transaction receipts, or invoke other APIs |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "description": "description4",
  "amount": 66.76,
  "checkNumber": 104,
  "memo": "memo8",
  "reference": "reference0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

