
# State Tax Withholding

Income in a state and its tax withholding

*This model accepts additional fields of type Object.*

## Structure

`StateTaxWithholding`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxWithheld` | `Double` | Optional | Amount of state income tax withheld | Double getTaxWithheld() | setTaxWithheld(Double taxWithheld) |
| `TaxId` | `String` | Optional | Filer's state tax id | String getTaxId() | setTaxId(String taxId) |
| `Income` | `Double` | Optional | Income amount for state tax purposes | Double getIncome() | setIncome(Double income) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxWithheld": 48.38,
  "taxId": "taxId0",
  "income": 15.96,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

