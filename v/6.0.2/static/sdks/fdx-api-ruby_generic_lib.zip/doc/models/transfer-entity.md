
# Transfer Entity

A single transfer of money. Refer to Transfers for a list of multiple transfers.

*This model accepts additional fields of type Object.*

## Structure

`TransferEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transfer_id` | `String` | Optional | Client generated, long-term persistent identity of the transfer action. This ID should be maintained and returned by institution<br><br>**Constraints**: *Maximum Length*: `256` |
| `from_account_id` | `String` | Optional | Long-term persistent identity of the source account<br><br>**Constraints**: *Maximum Length*: `256` |
| `to_account_id` | `String` | Optional | Long-term persistent identity of the destination account<br><br>**Constraints**: *Maximum Length*: `256` |
| `amount` | `Float` | Optional | Positive amount of money to be transferred |
| `memo` | `String` | Optional | User-entered reason for transfer<br><br>**Constraints**: *Maximum Length*: `255` |
| `payment_details` | [`PaymentDetailsEntity`](../../doc/models/payment-details-entity.md) | Optional | Payment details |
| `reference_id` | `String` | Optional | Long-term persistent identifier for transfer attempt<br><br>**Constraints**: *Maximum Length*: `256` |
| `status` | [`PaymentStatus1`](../../doc/models/payment-status-1.md) | Optional | CANCELLED, FAILED, NOFUNDS, PROCESSED, PROCESSING, SCHEDULED |
| `transfer_time` | `DateTime` | Optional | Date of transfer attempt |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "transferTime": "07/15/2021 14:46:41",
  "transferId": "transferId6",
  "fromAccountId": "fromAccountId2",
  "toAccountId": "toAccountId2",
  "amount": 204.6,
  "memo": "memo2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

