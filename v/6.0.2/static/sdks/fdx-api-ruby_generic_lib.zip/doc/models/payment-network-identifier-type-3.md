
# Payment Network Identifier Type 3

Type of identifier, ACCOUNT_NUMBER or TOKENIZED_ACCOUNT_NUMBER

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentNetworkIdentifierType3`

## Fields

| Name |
|  --- |
| `ACCOUNT_NUMBER` |
| `TOKENIZED_ACCOUNT_NUMBER` |

