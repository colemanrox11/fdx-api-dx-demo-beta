
# Recurring Payment Duration Entity

Describes a payment's duration

*This model accepts additional fields of type Object.*

## Structure

`RecurringPaymentDurationEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`RecurringPaymentDurationType2`](../../doc/models/recurring-payment-duration-type-2.md) | Required | Type of duration | RecurringPaymentDurationType2 getType() | setType(RecurringPaymentDurationType2 type) |
| `NumberOfTimes` | `Double` | Optional | Maximum number of times a payment is to be sent. Required if type is set to NUMBEROFTIMES | Double getNumberOfTimes() | setNumberOfTimes(Double numberOfTimes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "NOEND",
  "numberOfTimes": 77.06,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

