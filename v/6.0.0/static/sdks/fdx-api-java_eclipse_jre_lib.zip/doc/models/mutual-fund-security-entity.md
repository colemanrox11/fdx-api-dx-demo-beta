
# Mutual Fund Security Entity

A mutual fund

*This model accepts additional fields of type Object.*

## Structure

`MutualFundSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MutualFundType` | [`MutualFundType2`](../../doc/models/mutual-fund-type-2.md) | Optional | Mutual fund type. One of OPENEND, CLOSEEND, OTHER | MutualFundType2 getMutualFundType() | setMutualFundType(MutualFundType2 mutualFundType) |
| `UnitsStreet` | `Double` | Optional | Units in the FI's street name, positive quantity | Double getUnitsStreet() | setUnitsStreet(Double unitsStreet) |
| `UnitsUser` | `Double` | Optional | Units in user's name directly, positive  quantity | Double getUnitsUser() | setUnitsUser(Double unitsUser) |
| `ReinvestDividends` | `Boolean` | Optional | Reinvest dividends | Boolean getReinvestDividends() | setReinvestDividends(Boolean reinvestDividends) |
| `ReinvestCapitalGains` | `Boolean` | Optional | Reinvest capital gains | Boolean getReinvestCapitalGains() | setReinvestCapitalGains(Boolean reinvestCapitalGains) |
| `Yield` | `Double` | Optional | Current yield reported as portion of the fund's assets | Double getYield() | setYield(Double yield) |
| `YieldAsOfDate` | `LocalDate` | Optional | As-of date for yield value | LocalDate getYieldAsOfDate() | setYieldAsOfDate(LocalDate yieldAsOfDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "yieldAsOfDate": "2021-07-15",
  "securityCategory": "Mutual Fund Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "mutualFundType": "OTHER",
  "unitsStreet": 19.58,
  "unitsUser": 190.5,
  "reinvestDividends": false,
  "reinvestCapitalGains": false
}
```

