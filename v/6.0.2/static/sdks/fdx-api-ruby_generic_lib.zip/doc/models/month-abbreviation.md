
# Month Abbreviation

Used by MonthAmount

*This model accepts additional fields of type Object.*

## Enumeration

`MonthAbbreviation`

## Fields

| Name |
|  --- |
| `JAN` |
| `FEB` |
| `MAR` |
| `APR` |
| `MAY` |
| `JUN` |
| `JUL` |
| `AUG` |
| `SEP` |
| `OCT` |
| `NOV` |
| `DEC` |

