
# Form 1042 S

Foreign Person's U.S. Source Income Subject to Withholding, from WithholdingAgent (boxes 12a-i) to Recipient (boxes 13a-j, 13l as form1042Recipient)

*This model accepts additional fields of type Object.*

## Structure

`Form1042S`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxYear` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | Integer getTaxYear() | setTaxYear(Integer taxYear) |
| `Corrected` | `Boolean` | Optional | True to indicate this is a corrected tax form | Boolean getCorrected() | setCorrected(Boolean corrected) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the source account. Not the account number<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `TaxFormId` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted.<br><br>**Constraints**: *Maximum Length*: `256` | String getTaxFormId() | setTaxFormId(String taxFormId) |
| `TaxFormDate` | `LocalDate` | Optional | Date of production or delivery of the tax form | LocalDate getTaxFormDate() | setTaxFormDate(LocalDate taxFormDate) |
| `AdditionalInformation` | `String` | Optional | Additional explanation text or content about this tax form | String getAdditionalInformation() | setAdditionalInformation(String additionalInformation) |
| `TaxFormType` | [`TypeFormType1`](../../doc/models/type-form-type-1.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | TypeFormType1 getTaxFormType() | setTaxFormType(TypeFormType1 taxFormType) |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty8 getIssuer() | setIssuer(TaxParty8 issuer) |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty1 getRecipient() | setRecipient(TaxParty1 recipient) |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | List<TaxFormAttribute> getAttributes() | setAttributes(List<TaxFormAttribute> attributes) |
| `Error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this form | Error1 getError() | setError(Error1 error) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `FormId` | `String` | Optional | Unique form identifier | String getFormId() | setFormId(String formId) |
| `Amended` | `Boolean` | Optional | Amended | Boolean getAmended() | setAmended(Boolean amended) |
| `AmendmentNumber` | `Integer` | Optional | Amendment number | Integer getAmendmentNumber() | setAmendmentNumber(Integer amendmentNumber) |
| `IncomeTypeCode` | `String` | Optional | Box 1, Income code | String getIncomeTypeCode() | setIncomeTypeCode(String incomeTypeCode) |
| `GrossIncome` | `Double` | Optional | Box 2, Gross income | Double getGrossIncome() | setGrossIncome(Double grossIncome) |
| `ChapterIndicator` | `String` | Optional | Box 3, Chapter indicator | String getChapterIndicator() | setChapterIndicator(String chapterIndicator) |
| `Ch3ExemptionCode` | `String` | Optional | Box 3a, Exemption code | String getCh3ExemptionCode() | setCh3ExemptionCode(String ch3ExemptionCode) |
| `Ch3TaxRate` | `Double` | Optional | Box 3b, Tax rate | Double getCh3TaxRate() | setCh3TaxRate(Double ch3TaxRate) |
| `Ch4ExemptionCode` | `String` | Optional | Box 4a, Exemption code | String getCh4ExemptionCode() | setCh4ExemptionCode(String ch4ExemptionCode) |
| `Ch4TaxRate` | `Double` | Optional | Box 4b, Tax rate | Double getCh4TaxRate() | setCh4TaxRate(Double ch4TaxRate) |
| `WithholdingAllowance` | `Double` | Optional | Box 5, Withholding allowance | Double getWithholdingAllowance() | setWithholdingAllowance(Double withholdingAllowance) |
| `NetIncome` | `Double` | Optional | Box 6, Net income | Double getNetIncome() | setNetIncome(Double netIncome) |
| `FederalTaxWithheld` | `Double` | Optional | Box 7a, Federal tax withheld | Double getFederalTaxWithheld() | setFederalTaxWithheld(Double federalTaxWithheld) |
| `EscrowProceduresApplied` | `Boolean` | Optional | Box 7b, Check if federal tax withheld was not deposited with the IRS because escrow procedures were applied | Boolean getEscrowProceduresApplied() | setEscrowProceduresApplied(Boolean escrowProceduresApplied) |
| `SubsequentYear` | `Boolean` | Optional | Box 7c, Check if withholding occurred in subsequent year with respect to a partnership interest | Boolean getSubsequentYear() | setSubsequentYear(Boolean subsequentYear) |
| `OtherAgentsTaxWithheld` | `Double` | Optional | Box 8, Tax withheld by other agents | Double getOtherAgentsTaxWithheld() | setOtherAgentsTaxWithheld(Double otherAgentsTaxWithheld) |
| `RecipientRepaidAmount` | `Double` | Optional | Box 9, Overwithheld tax repaid to recipient pursuant to adjustment procedures | Double getRecipientRepaidAmount() | setRecipientRepaidAmount(Double recipientRepaidAmount) |
| `TotalTaxWithholdingCredit` | `Double` | Optional | Box 10, Total withholding credit | Double getTotalTaxWithholdingCredit() | setTotalTaxWithholdingCredit(Double totalTaxWithholdingCredit) |
| `WithholdingAgentTaxPaid` | `Double` | Optional | Box 11, Tax paid by withholding agent (amounts not withheld) | Double getWithholdingAgentTaxPaid() | setWithholdingAgentTaxPaid(Double withholdingAgentTaxPaid) |
| `WithholdingAgent` | [`Form1042SAgent1`](../../doc/models/form-1042-s-agent-1.md) | Optional | Boxes 12a-i, Withholding agent | Form1042SAgent1 getWithholdingAgent() | setWithholdingAgent(Form1042SAgent1 withholdingAgent) |
| `Form1042Recipient` | [`Form1042SRecipient1`](../../doc/models/form-1042-s-recipient-1.md) | Optional | Boxes 13a-j, 13l, Recipient for Form 1042-S | Form1042SRecipient1 getForm1042Recipient() | setForm1042Recipient(Form1042SRecipient1 form1042Recipient) |
| `AccountNumber` | `String` | Optional | Box 13k, Recipient account number | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `Primary` | [`Form1042SAgent2`](../../doc/models/form-1042-s-agent-2.md) | Optional | Boxes 14a-b, Primary Withholding Agent | Form1042SAgent2 getPrimary() | setPrimary(Form1042SAgent2 primary) |
| `ProrataBasisReporting` | `Boolean` | Optional | Box 15, Check if pro-rata basis reporting | Boolean getProrataBasisReporting() | setProrataBasisReporting(Boolean prorataBasisReporting) |
| `Intermediary` | [`Form1042SAgent3`](../../doc/models/form-1042-s-agent-3.md) | Optional | Boxes 15a-i, Intermediary or flow thru entity | Form1042SAgent3 getIntermediary() | setIntermediary(Form1042SAgent3 intermediary) |
| `Payer` | [`Form1042SAgent4`](../../doc/models/form-1042-s-agent-4.md) | Optional | Boxes 16a-e, Payer | Form1042SAgent4 getPayer() | setPayer(Form1042SAgent4 payer) |
| `StateAndLocal` | [`StateAndLocalTaxWithholding1`](../../doc/models/state-and-local-tax-withholding-1.md) | Optional | Box 17, State and Local tax withholding | StateAndLocalTaxWithholding1 getStateAndLocal() | setStateAndLocal(StateAndLocalTaxWithholding1 stateAndLocal) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId6",
  "taxFormId": "taxFormId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

