
# Position Type 1

LONG, SHORT

*This model accepts additional fields of type interface{}.*

## Enumeration

`PositionType1`

## Fields

| Name |
|  --- |
| `Long` |
| `Short` |

