
# Position Type

The type of an investment position

*This model accepts additional fields of type Object.*

## Enumeration

`PositionType`

## Fields

| Name |
|  --- |
| `LONG` |
| `SHORT` |

