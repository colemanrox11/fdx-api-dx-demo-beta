
# Debt Class 2

Classification of debt. One of TREASURY, MUNICIPAL, CORPORATE, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`DebtClass2`

## Fields

| Name |
|  --- |
| `CORPORATE` |
| `MUNICIPAL` |
| `OTHER` |
| `TREASURY` |

