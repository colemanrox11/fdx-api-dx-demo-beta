
# Investment 401 K Source Type 2

Source of money. One of PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST

*This model accepts additional fields of type Object.*

## Enumeration

`Investment401KSourceType2`

## Fields

| Name |
|  --- |
| `AFTERTAX` |
| `MATCH` |
| `OTHERNONVEST` |
| `OTHERVEST` |
| `PRETAX` |
| `PROFITSHARING` |
| `ROLLOVER` |

