
# Account Bill Pay Status

Indicates bill pay capabilities for an account.

* `ACTIVE`: Can be used for bill payment
* `AVAILABLE`: Account can be requested for bill payment
* `NOT_AVAILABLE`: Account cannot participate in bill payment
* `PENDING`: Account requested for bill payment, but not available yet

*This model accepts additional fields of type Object.*

## Enumeration

`AccountBillPayStatus`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `AVAILABLE` |
| `NOT_AVAILABLE` |
| `PENDING` |

