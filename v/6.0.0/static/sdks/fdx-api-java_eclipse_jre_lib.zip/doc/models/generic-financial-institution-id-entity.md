
# Generic Financial Institution Id Entity

Generic financial institution identifier entity

*This model accepts additional fields of type Object.*

## Structure

`GenericFinancialInstitutionIdEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FiId` | `String` | Optional | Financial institution identifier<br><br>**Constraints**: *Maximum Length*: `256` | String getFiId() | setFiId(String fiId) |
| `IssuerName` | `String` | Optional | Issuer name | String getIssuerName() | setIssuerName(String issuerName) |
| `IdScheme` | [`GenericFinancialInstitutionIdEntityIdScheme`](../../doc/models/containers/generic-financial-institution-id-entity-id-scheme.md) | Optional | This is a container for any-of cases. | GenericFinancialInstitutionIdEntityIdScheme getIdScheme() | setIdScheme(GenericFinancialInstitutionIdEntityIdScheme idScheme) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "fiId": "fiId4",
  "issuerName": "issuerName0",
  "idScheme": {
    "idCode": "idCode6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

