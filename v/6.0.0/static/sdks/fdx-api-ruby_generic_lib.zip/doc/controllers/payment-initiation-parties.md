# Payment Initiation Parties

```ruby
payment_initiation_parties_controller = client.payment_initiation_parties
```

## Class Name

`PaymentInitiationPartiesController`

## Methods

* [Create Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#create-payment-initiation-party)
* [List Payment Initiation Parties](../../doc/controllers/payment-initiation-parties.md#list-payment-initiation-parties)
* [Get Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#get-payment-initiation-party)
* [Update Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#update-payment-initiation-party)
* [Delete Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#delete-payment-initiation-party)
* [Create Payment Method](../../doc/controllers/payment-initiation-parties.md#create-payment-method)
* [Get Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#get-payment-method-registration)
* [Delete Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#delete-payment-method-registration)
* [Update Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#update-payment-method-registration)


# Create Payment Initiation Party

Create a payment initiation party associated with a customer profile

```ruby
def create_payment_initiation_party(x_fapi_interaction_id,
                                    idempotency_key,
                                    fdx_api_actor_type: nil,
                                    body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `idempotency_key` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md) | Body, Optional | - |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PaymentInitiationPartyCreateResponseEntity`](../../doc/models/payment-initiation-party-create-response-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

idempotency_key = 'idempotency-key4'

fdx_api_actor_type = FdxApiActorType::BATCH

body = PaymentInitiationPartyEntity.new(
  name: 'name6',
  type: PartyType::MERCHANT,
  expires_timestamp: DateTimeHelper.from_rfc3339('07/15/2021 14:46:41')
)

result = payment_initiation_parties_controller.create_payment_initiation_party(
  x_fapi_interaction_id,
  idempotency_key,
  fdx_api_actor_type: fdx_api_actor_type,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# List Payment Initiation Parties

Retrieve the payment initiation parties associated with a customer profile

```ruby
def list_payment_initiation_parties(x_fapi_interaction_id,
                                    fdx_api_actor_type: nil,
                                    offset: nil,
                                    limit: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PaymentInitiationPartiesEntity`](../../doc/models/payment-initiation-parties-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.list_payment_initiation_parties(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment Initiation Party

Retrieve the payment initiation party details by ID

```ruby
def get_payment_initiation_party(x_fapi_interaction_id,
                                 payment_initiation_party_id,
                                 fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.get_payment_initiation_party(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment Initiation Party

Update the payment initiation party associated with a customer profile

```ruby
def update_payment_initiation_party(x_fapi_interaction_id,
                                    payment_initiation_party_id,
                                    idempotency_key,
                                    fdx_api_actor_type: nil,
                                    body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotency_key` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md) | Body, Optional | - |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

idempotency_key = 'idempotency-key4'

fdx_api_actor_type = FdxApiActorType::BATCH

body = PaymentInitiationPartyEntity.new(
  name: 'name6',
  type: PartyType::MERCHANT,
  expires_timestamp: DateTimeHelper.from_rfc3339('07/15/2021 14:46:41')
)

result = payment_initiation_parties_controller.update_payment_initiation_party(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  idempotency_key,
  fdx_api_actor_type: fdx_api_actor_type,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payment Initiation Party

Remove the payment initiation party associated with a customer profile

```ruby
def delete_payment_initiation_party(x_fapi_interaction_id,
                                    payment_initiation_party_id,
                                    fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.delete_payment_initiation_party(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Create Payment Method

Registration of a payment initiation party to a payment method

```ruby
def create_payment_method(x_fapi_interaction_id,
                          payment_initiation_party_id,
                          idempotency_key,
                          fdx_api_actor_type: nil,
                          body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotency_key` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Body, Optional | - |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PaymentInitiationPartyMethodCreateResponseEntity`](../../doc/models/payment-initiation-party-method-create-response-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

idempotency_key = 'idempotency-key4'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.create_payment_method(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  idempotency_key,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment Method Registration

Retrieve the details of a payment method registered with a payment initiation party

```ruby
def get_payment_method_registration(x_fapi_interaction_id,
                                    payment_initiation_party_id,
                                    payment_method_registration_id,
                                    fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `payment_method_registration_id` | `String` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

payment_method_registration_id = 'paymentMethodRegistrationId4'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.get_payment_method_registration(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  payment_method_registration_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payment Method Registration

Remove the registered payment method from a payment initiation party

```ruby
def delete_payment_method_registration(x_fapi_interaction_id,
                                       payment_initiation_party_id,
                                       payment_method_registration_id,
                                       fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `payment_method_registration_id` | `String` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

payment_method_registration_id = 'paymentMethodRegistrationId4'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.delete_payment_method_registration(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  payment_method_registration_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment Method Registration

Update the payment method registration associated with payment initiation party

```ruby
def update_payment_method_registration(x_fapi_interaction_id,
                                       payment_initiation_party_id,
                                       payment_method_registration_id,
                                       fdx_api_actor_type: nil,
                                       body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payment_initiation_party_id` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `payment_method_registration_id` | `String` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Body, Optional | - |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payment_initiation_party_id = 'paymentInitiationPartyId8'

payment_method_registration_id = 'paymentMethodRegistrationId4'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payment_initiation_parties_controller.update_payment_method_registration(
  x_fapi_interaction_id,
  payment_initiation_party_id,
  payment_method_registration_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

