
# External Account Id Scheme Entity

External account identification scheme

*This model accepts additional fields of type Object.*

## Structure

`ExternalAccountIdSchemeEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdCode` | `String` | Optional | Identification code<br><br>**Constraints**: *Maximum Length*: `256` | String getIdCode() | setIdCode(String idCode) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "idCode": "idCode2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

