
# Party Status

Defines the party lifecycle.

* `ACTIVE`: Party is ready to participate in money movement
* `DELETED`: Party has been deleted and will not move into any other state
* `PENDING`: Party is not yet ready to participate in money movement
* `REJECTED`: Party was found to be invalid and cannot participate in money movement

*This model accepts additional fields of type Object.*

## Enumeration

`PartyStatus`

## Fields

| Name |
|  --- |
| `Active` |
| `Deleted` |
| `Pending` |
| `Rejected` |

