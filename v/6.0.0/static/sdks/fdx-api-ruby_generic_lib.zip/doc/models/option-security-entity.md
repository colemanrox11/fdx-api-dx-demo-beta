
# Option Security Entity

An option

*This model accepts additional fields of type Object.*

## Structure

`OptionSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `secured` | [`Secured2`](../../doc/models/secured-2.md) | Optional | How the option is secured. One of NAKED, COVERED |
| `option_type` | [`OptionType2`](../../doc/models/option-type-2.md) | Optional | Option type. One of PUT, CALL |
| `strike_price` | `Float` | Optional | Strike price / Unit price |
| `expire_date` | `Date` | Optional | Expiration date of option |
| `shares_per_contract` | `Float` | Optional | Shares per contract |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "expireDate": "2021-07-15",
  "securityCategory": "Option Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "secured": "COVERED",
  "optionType": "CALL",
  "strikePrice": 190.26,
  "sharesPerContract": 151.06
}
```

