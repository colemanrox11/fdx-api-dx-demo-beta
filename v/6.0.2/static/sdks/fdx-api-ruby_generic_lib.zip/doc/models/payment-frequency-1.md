
# Payment Frequency 1

DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentFrequency1`

## Fields

| Name |
|  --- |
| `ANNUALLY` |
| `BIWEEKLY` |
| `DAILY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `SEMIMONTHLY` |
| `WEEKLY` |

