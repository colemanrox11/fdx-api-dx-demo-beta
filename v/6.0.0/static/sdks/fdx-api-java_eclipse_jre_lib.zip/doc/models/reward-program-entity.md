
# Reward Program Entity

Reward program detail

*This model accepts additional fields of type Object.*

## Structure

`RewardProgramEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RewardProgramId` | `String` | Optional | Long term persistent identity of the reward program<br><br>**Constraints**: *Maximum Length*: `256` | String getRewardProgramId() | setRewardProgramId(String rewardProgramId) |
| `ProgramName` | `String` | Optional | Name of reward program | String getProgramName() | setProgramName(String programName) |
| `ProgramUrl` | `String` | Optional | URL of reward program | String getProgramUrl() | setProgramUrl(String programUrl) |
| `Memberships` | [`List<RewardProgramMembershipEntity>`](../../doc/models/reward-program-membership-entity.md) | Optional | Array of reward memberships | List<RewardProgramMembershipEntity> getMemberships() | setMemberships(List<RewardProgramMembershipEntity> memberships) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "rewardProgramId": "rewardProgramId2",
  "programName": "programName4",
  "programUrl": "programUrl6",
  "memberships": [
    {
      "accountIds": [
        "accountIds7",
        "accountIds8"
      ],
      "customerId": "customerId6",
      "memberId": "memberId2",
      "memberNumber": "memberNumber6",
      "memberTier": "memberTier6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "accountIds": [
        "accountIds7",
        "accountIds8"
      ],
      "customerId": "customerId6",
      "memberId": "memberId2",
      "memberNumber": "memberNumber6",
      "memberTier": "memberTier6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "accountIds": [
        "accountIds7",
        "accountIds8"
      ],
      "customerId": "customerId6",
      "memberId": "memberId2",
      "memberNumber": "memberNumber6",
      "memberTier": "memberTier6",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "fiAttributes": [
    {
      "name": "name6",
      "value": "value8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

