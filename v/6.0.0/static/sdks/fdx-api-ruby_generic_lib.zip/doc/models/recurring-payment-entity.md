
# Recurring Payment Entity

A recurring payment. Financial institution is free to adjust the payment date to accommodate weekends and holidays

*This model accepts additional fields of type Object.*

## Structure

`RecurringPaymentEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `frequency` | [`RecurringPaymentFrequency2`](../../doc/models/recurring-payment-frequency-2.md) | Required | Defines how often the payment repeats |
| `duration` | [`RecurringPaymentDurationEntity2`](../../doc/models/recurring-payment-duration-entity-2.md) | Optional | Defines how long the payment repeats for |
| `from_account_id` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `to_payee_id` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `amount` | `Float` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` |
| `merchant_account_id` | `String` | Optional | User's account identifier with the merchant |
| `due_date` | `Date` | Required | Date that the funds are scheduled to be delivered |
| `recurring_payment_id` | `String` | Optional | Uniquely identifies a recurring payment. Used within the API to reference a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `scheduled_timestamp` | `DateTime` | Optional | When the recurring payment was scheduled |
| `cancelled_timestamp` | `DateTime` | Optional | When the recurring payment was cancelled |
| `processed_timestamp` | `DateTime` | Optional | When the last payment executed |
| `failed_timestamp` | `DateTime` | Optional | When the recurring payment failed |
| `status` | [`RecurringPaymentStatus2`](../../doc/models/recurring-payment-status-2.md) | Required | Defines the status of the recurring payment |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "frequency": "MONTHLY",
  "fromAccountId": "fromAccountId8",
  "toPayeeId": "toPayeeId2",
  "amount": 140.36,
  "dueDate": "2021-07-15",
  "scheduledTimestamp": "07/15/2021 14:46:41",
  "cancelledTimestamp": "07/15/2021 14:46:41",
  "processedTimestamp": "07/15/2021 14:46:41",
  "failedTimestamp": "07/15/2021 14:46:41",
  "status": "PROCESSED",
  "duration": {
    "type": "NOEND",
    "numberOfTimes": 181.2,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "merchantAccountId": "merchantAccountId2",
  "recurringPaymentId": "recurringPaymentId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

