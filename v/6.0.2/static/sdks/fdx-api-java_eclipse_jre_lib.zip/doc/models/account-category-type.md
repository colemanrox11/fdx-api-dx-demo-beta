
# Account Category Type

The category of account

*This model accepts additional fields of type Object.*

## Enumeration

`AccountCategoryType`

## Fields

| Name |
|  --- |
| `AnnuityAccount` |
| `CommercialAccount` |
| `DepositAccount` |
| `DigitalWallet` |
| `InsuranceAccount` |
| `InvestmentAccount` |
| `LoanAccount` |
| `LocAccount` |

