
# Recurring Payment Status

Defines the recurring payment lifecycle

* `CANCELLED`: Recurring Payment was cancelled by the user
* `FAILED`: Recurring Payment failed. For example: fraud, invalid payee, source account was closed etc.
* `PROCESSED`: The scheduled duration of the recurrence has completed
* `SCHEDULED`: Recurring Payment has been scheduled

*This model accepts additional fields of type Object.*

## Enumeration

`RecurringPaymentStatus`

## Fields

| Name |
|  --- |
| `Cancelled` |
| `Failed` |
| `Processed` |
| `Scheduled` |

