
# Account Entity

An abstract account entity that concrete account entities extend

*This model accepts additional fields of type Object.*

## Structure

`AccountEntity`

## Inherits From

[`AccountDescriptorEntity`](../../doc/models/account-descriptor-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `parent_account_id` | `String` | Optional | Long-term persistent identity of the parent account. This is used to group accounts<br><br>**Constraints**: *Maximum Length*: `256` |
| `line_of_business` | `String` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. |
| `routing_transit_number` | `String` | Optional | The routing transit number (RTN) associated with the account number at the owning institution. This also serves as the 3-digit Institution (FID) and 5-digit Transit numbers for Canadian institutions, including leading zeroes |
| `balance_type` | [`BalanceType2`](../../doc/models/balance-type-2.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) |
| `contact` | [`AccountContactEntity2`](../../doc/models/account-contact-entity-2.md) | Optional | Contact information associated with this account |
| `interest_rate` | `Float` | Optional | Interest Rate of Account |
| `interest_rate_type` | [`InterestRateType2`](../../doc/models/interest-rate-type-2.md) | Optional | FIXED or VARIABLE |
| `interest_rate_as_of` | `DateTime` | Optional | Date of account's interest rate |
| `prior_interest_rate` | `Float` | Optional | Previous Interest Rate of Account |
| `interest_rate_index` | `String` | Optional | Variable rate index name such as EONIA, EURIBOR, EURREPO, FEFUND, LIBOR, PRIME, SOFR, SONIA, etc. |
| `early_penalty_flag` | `TrueClass \| FalseClass` | Optional | Flag that indicates if there is an early penalty for withdrawal/payoff |
| `transfer_in` | `TrueClass \| FalseClass` | Optional | Account is eligible for incoming transfers |
| `transfer_out` | `TrueClass \| FalseClass` | Optional | Account is eligible for outgoing transfers |
| `bill_pay_status` | [`AccountBillPayStatus2`](../../doc/models/account-bill-pay-status-2.md) | Optional | Defines account's ability to participate in bill payments |
| `micr_number` | `String` | Optional | MICR Number<br><br>**Constraints**: *Maximum Length*: `64` |
| `last_activity_date` | `Date` | Optional | Date that last transaction occurred on account |
| `reward_program_id` | `String` | Optional | Long-term persistent identity of rewards program associated with this account<br><br>**Constraints**: *Maximum Length*: `256` |
| `transactions_included` | `TrueClass \| FalseClass` | Optional | Default is false. If present and true, a call to retrieve transactions will not return any further details about this account. This is an optimization that allows an FDX API server to return transactions and account details in a single call |
| `domicile` | [`DomicileEntity1`](../../doc/models/domicile-entity-1.md) | Optional | The country and region of the account's legal jurisdiction |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "accountCategory": "Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  }
}
```

