
# Notification Priority 2

Notification priority

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationPriority2`

## Fields

| Name |
|  --- |
| `High` |
| `Medium` |
| `Low` |

