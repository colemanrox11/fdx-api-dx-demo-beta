
# Account Status 2

Account status. Suggested values are: OPEN, CLOSED, PENDINGOPEN, PENDINGCLOSE, PAID, DELINQUENT, NEGATIVECURRENTBALANCE, RESTRICTED

*This model accepts additional fields of type Object.*

## Enumeration

`AccountStatus2`

## Fields

| Name |
|  --- |
| `CLOSED` |
| `DELINQUENT` |
| `NEGATIVECURRENTBALANCE` |
| `OPEN` |
| `PAID` |
| `PENDINGCLOSE` |
| `PENDINGOPEN` |
| `RESTRICTED` |

