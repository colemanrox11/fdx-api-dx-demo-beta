
# Reward Balance Entity

Reward program balance

*This model accepts additional fields of type Object.*

## Structure

`RewardBalanceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name used to denominate the balance | String getName() | setName(String name) |
| `Type` | [`RewardType2`](../../doc/models/reward-type-2.md) | Optional | The type of the reward balance - CASHBACK, MILES, POINTS | RewardType2 getType() | setType(RewardType2 type) |
| `Balance` | `Double` | Optional | Total units available for redemption at time of download | Double getBalance() | setBalance(Double balance) |
| `AccruedYtd` | `Double` | Optional | Total units accrued in the current program year at time of download<br><br>**Constraints**: `>= 0` | Double getAccruedYtd() | setAccruedYtd(Double accruedYtd) |
| `RedeemedYtd` | `Double` | Optional | Total units redeemed in the current program year at time of download<br><br>**Constraints**: `>= 0` | Double getRedeemedYtd() | setRedeemedYtd(Double redeemedYtd) |
| `Qualifying` | `Boolean` | Optional | Balance used for qualifying purposes<br><br>**Default**: `false` | Boolean getQualifying() | setQualifying(Boolean qualifying) |
| `FiAttributes` | [`List<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes | List<FiAttributeEntity> getFiAttributes() | setFiAttributes(List<FiAttributeEntity> fiAttributes) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "qualifying": false,
  "name": "name6",
  "type": "CASHBACK",
  "balance": 78.5,
  "accruedYtd": 44.46,
  "redeemedYtd": 192.66,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

