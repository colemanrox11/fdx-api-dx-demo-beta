
# Period Certain Type 2

The number of modal periods comprising the duration of the certain period of an annuity payout

*This model accepts additional fields of type Object.*

## Enumeration

`PeriodCertainType2`

## Fields

| Name |
|  --- |
| `ENUM_5_YEAR` |
| `ENUM_10_YEAR` |
| `ENUM_20_YEAR` |
| `ENUM_30_YEAR` |
| `NONE` |

