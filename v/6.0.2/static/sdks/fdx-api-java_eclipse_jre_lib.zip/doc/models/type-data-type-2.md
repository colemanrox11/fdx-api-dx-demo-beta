
# Type Data Type 2

Whether this `application/json` tax form response contains data in `forms` property (as 'JSON' format) or `pdf` property (as 'BASE64_PDF' format)

*This model accepts additional fields of type Object.*

## Enumeration

`TypeDataType2`

## Fields

| Name |
|  --- |
| `Base64Pdf` |
| `Json` |

