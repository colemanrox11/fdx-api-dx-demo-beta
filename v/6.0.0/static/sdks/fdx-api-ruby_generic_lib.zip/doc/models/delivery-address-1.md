
# Delivery Address 1

Address of the merchant used to execute the payment

*This model accepts additional fields of type Object.*

## Structure

`DeliveryAddress1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `line_1` | `String` | Optional | Address line 1<br><br>**Constraints**: *Maximum Length*: `64` |
| `line_2` | `String` | Optional | Address line 2<br><br>**Constraints**: *Maximum Length*: `64` |
| `line_3` | `String` | Optional | Address line 3<br><br>**Constraints**: *Maximum Length*: `64` |
| `city` | `String` | Optional | City<br><br>**Constraints**: *Maximum Length*: `64` |
| `region` | `String` | Optional | State, Province, Territory, Canton or Prefecture. From [Universal Postal Union](https://www.upu.int/en/Postal-Solutions/Programmes-Services/Addressing-Solutions#addressing-s42-standard) as of 2-26-2020, [S42 International Address Standards](https://www.upu.int/UPU/media/upu/documents/PostCode/S42_International-Addressing-Standards.pdf). For U.S. addresses can be 2-character code from '#/components/schemas/StateCode'<br><br>**Constraints**: *Maximum Length*: `64` |
| `postal_code` | `String` | Optional | Postal code<br><br>**Constraints**: *Maximum Length*: `16` |
| `country` | [`Iso3166CountryCode`](../../doc/models/iso-3166-country-code.md) | Optional | Country code |
| `type` | [`DeliveryAddressType`](../../doc/models/delivery-address-type.md) | Optional | Type of address location. One of BUSINESS, DELIVERY, HOME, MAILING |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "line1": "line18",
  "line2": "line20",
  "line3": "line38",
  "city": "city4",
  "region": "region2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

