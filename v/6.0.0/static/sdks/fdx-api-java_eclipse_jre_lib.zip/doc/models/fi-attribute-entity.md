
# Fi Attribute Entity

Financial Institution provider-specific attribute

*This model accepts additional fields of type Object.*

## Structure

`FiAttributeEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of attribute | String getName() | setName(String name) |
| `Value` | `String` | Optional | Value of attribute | String getValue() | setValue(String value) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "name": "name0",
  "value": "value2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

