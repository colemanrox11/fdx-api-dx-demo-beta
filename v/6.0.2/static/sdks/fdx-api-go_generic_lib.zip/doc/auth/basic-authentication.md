
# Basic Authentication



Documentation for accessing and setting credentials for TaxBasicAuth.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| username | `string` | The username to use with basic authentication | `WithUsername` | `Username()` |
| password | `string` | The password to use with basic authentication | `WithPassword` | `Password()` |



**Note:** Required auth credentials can be set using `WithTaxBasicAuthCredentials()` by providing a credentials instance with `NewTaxBasicAuthCredentials()` in the configuration initialization and accessed using the `TaxBasicAuthCredentials()` method in the configuration instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```go
package main

import (
    "fdxApi"
)

func main() {
    client := fdxApi.NewClient(
    fdxApi.CreateConfiguration(
            fdxApi.WithTaxBasicAuthCredentials(
                fdxApi.NewTaxBasicAuthCredentials(
                    "Username",
                    "Password",
                ),
            ),
        ),
    )
}
```


