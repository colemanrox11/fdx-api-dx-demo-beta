
# Operation Entity

Definition of a supported API for the /capability response object

*This model accepts additional fields of type Object.*

## Structure

`OperationEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | [`FdxResourceOperationId1`](../../doc/models/fdx-resource-operation-id-1.md) | Optional | Operation ID (e.g. name) of this API |
| `availability` | [`AvailabilityEntity1`](../../doc/models/availability-entity-1.md) | Optional | Whether and how this API is currently supported |
| `also_supported` | [`Array<FdxResourceOperationId>`](../../doc/models/fdx-resource-operation-id.md) | Optional | Additional FDX API endpoints supported at this API, e.g. Transactions within Accounts, or TxImages within Transactions |
| `version` | `String` | Optional | Data provider's implementation version number for this operation, which is unrelated to the FDX API version |
| `fdx_versions` | [`Array<FdxVersion>`](../../doc/models/fdx-version.md) | Optional | FDX schema versions supported at this endpoint |
| `cut_off_time` | `DateTime` | Optional | Cut off time for same-day execution of activity request submitted to this API. Alternatively, the as-of time when EOD account balances are typically set |
| `link` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | General HATEOAS link for this API, specifying supported action (GET, POST, etc) and contentTypes (application/json, image/png, etc), but without any path parameter values |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "cutOffTime": "07/15/2021 14:46:41",
  "id": "createRecipient",
  "availability": {
    "status": "ALIVE",
    "description": "description0",
    "operationId": "getPaymentInitiationParty",
    "plannedAvailability": [
      {
        "status": "MAINTENANCE",
        "description": "description6",
        "startTime": "2016-03-13T12:52:32.123Z",
        "endTime": "2016-03-13T12:52:32.123Z",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "alsoSupported": [
    "deletePaymentMethodRegistration",
    "getPayee"
  ],
  "version": "version4",
  "fdxVersions": [
    "V5.2.0",
    "V5.2.1",
    "V5.2.2"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

