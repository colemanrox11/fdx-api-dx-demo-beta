
# Payment Initiation Party Entity

Party details for FI payment initiation. Each payment initiation party
will have a separate entry per FI customer, for example we
might have multiple payment initiation parties that represent the same
physical person; since they are registered for separate
customers they will have separate entries.

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Required | Human recognizable common name | String getName() | setName(String name) |
| `Type` | [`PartyType`](../../doc/models/party-type.md) | Required | Extensible string enum identifying the type of the party | PartyType getType() | setType(PartyType type) |
| `HomeUri` | `String` | Optional | URI for party, where an end user could learn more about the company or application involved in the data sharing chain | String getHomeUri() | setHomeUri(String homeUri) |
| `LogoUri` | `String` | Optional | URI for a logo asset to be displayed to the end user | String getLogoUri() | setLogoUri(String logoUri) |
| `Registry` | [`Registry`](../../doc/models/registry.md) | Optional | The registry containing the party's registration with name and id: FDX, GLEIF, ICANN, PRIVATE | Registry getRegistry() | setRegistry(Registry registry) |
| `RegisteredEntityName` | `String` | Optional | Registered name of party | String getRegisteredEntityName() | setRegisteredEntityName(String registeredEntityName) |
| `RegisteredEntityId` | `String` | Optional | Registered id of party | String getRegisteredEntityId() | setRegisteredEntityId(String registeredEntityId) |
| `PartyGroups` | [`List<PartyGroupEntity>`](../../doc/models/party-group-entity.md) | Optional | The PartyGroups to which this initiation party belongs.<br>Optional, can be omitted if party belongs to no groups. | List<PartyGroupEntity> getPartyGroups() | setPartyGroups(List<PartyGroupEntity> partyGroups) |
| `PaymentInitiationPartyName` | [`PaymentInitiationPartyNameEntity1`](../../doc/models/payment-initiation-party-name-entity-1.md) | Optional | Name entity associated with the payment initiation party | PaymentInitiationPartyNameEntity1 getPaymentInitiationPartyName() | setPaymentInitiationPartyName(PaymentInitiationPartyNameEntity1 paymentInitiationPartyName) |
| `GovernmentIssuedPartyIds` | [`List<GovernmentIssuedPartyIdentificationEntity>`](../../doc/models/government-issued-party-identification-entity.md) | Optional | Government-issued identification documents that are<br>used to uniquely identify this payment initiation party | List<GovernmentIssuedPartyIdentificationEntity> getGovernmentIssuedPartyIds() | setGovernmentIssuedPartyIds(List<GovernmentIssuedPartyIdentificationEntity> governmentIssuedPartyIds) |
| `PaymentMethods` | [`List<PaymentInitiationPartyToPaymentMethodEntity>`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Optional | Registrations between this payment initiation party and its payment methods | List<PaymentInitiationPartyToPaymentMethodEntity> getPaymentMethods() | setPaymentMethods(List<PaymentInitiationPartyToPaymentMethodEntity> paymentMethods) |
| `Locations` | [`List<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Delivery addresses associated with this payment initiation party | List<PaymentDeliveryAddressEntity> getLocations() | setLocations(List<PaymentDeliveryAddressEntity> locations) |
| `ExpiresTimestamp` | `LocalDateTime` | Optional | Describes when the entity will be automatically deleted. The entity<br>will not go into the "DELETED" state. If this value is null or not<br>provided, the entity will not expire automatically | LocalDateTime getExpiresTimestamp() | setExpiresTimestamp(LocalDateTime expiresTimestamp) |
| `Status` | [`PartyStatus1`](../../doc/models/party-status-1.md) | Optional | Current status of the payment initiation party entry | PartyStatus1 getStatus() | setStatus(PartyStatus1 status) |
| `ContactPreferences` | [`List<PaymentInitiationPartyContactMethodEntity>`](../../doc/models/payment-initiation-party-contact-method-entity.md) | Optional | Contact methods for this payment initiation party | List<PaymentInitiationPartyContactMethodEntity> getContactPreferences() | setContactPreferences(List<PaymentInitiationPartyContactMethodEntity> contactPreferences) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "name": "name4",
  "type": "DATA_ACCESS_PLATFORM",
  "expiresTimestamp": "07/15/2021 14:46:41",
  "homeUri": "homeUri8",
  "logoUri": "logoUri2",
  "registry": "ICANN",
  "registeredEntityName": "registeredEntityName2",
  "registeredEntityId": "registeredEntityId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

