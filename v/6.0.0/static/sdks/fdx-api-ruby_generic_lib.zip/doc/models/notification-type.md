
# Notification Type

Type of notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationType`

## Fields

| Name |
|  --- |
| `BALANCE` |
| `CONSENT_REVOKED` |
| `CONSENT_UPDATED` |
| `CUSTOM` |
| `PLANNED_OUTAGE` |
| `RISK` |
| `SERVICE` |

