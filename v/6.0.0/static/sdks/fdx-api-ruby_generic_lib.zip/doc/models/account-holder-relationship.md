
# Account Holder Relationship

Type of relationship to the account

*This model accepts additional fields of type Object.*

## Enumeration

`AccountHolderRelationship`

## Fields

| Name |
|  --- |
| `AUTHORIZED_USER` |
| `BUSINESS` |
| `FOR_BENEFIT_OF` |
| `FOR_BENEFIT_OF_PRIMARY` |
| `FOR_BENEFIT_OF_PRIMARY_JOINT_RESTRICTED` |
| `FOR_BENEFIT_OF_SECONDARY` |
| `FOR_BENEFIT_OF_SECONDARY_JOINT_RESTRICTED` |
| `FOR_BENEFIT_OF_SOLE_OWNER_RESTRICTED` |
| `POWER_OF_ATTORNEY` |
| `PRIMARY` |
| `PRIMARY_BORROWER` |
| `PRIMARY_JOINT` |
| `PRIMARY_JOINT_TENANTS` |
| `SECONDARY` |
| `SECONDARY_BORROWER` |
| `SECONDARY_JOINT` |
| `SECONDARY_JOINT_TENANTS` |
| `SOLE_OWNER` |
| `TRUSTEE` |
| `UNIFORM_TRANSFER_TO_MINOR` |

