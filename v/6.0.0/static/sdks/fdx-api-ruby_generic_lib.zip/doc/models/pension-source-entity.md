
# Pension Source Entity

The source of pension funds

*This model accepts additional fields of type Object.*

## Structure

`PensionSourceEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `display_name` | `String` | Optional | Name of the source |
| `amount` | `Float` | Optional | Benefit Amount |
| `payment_option` | `String` | Optional | Form of payment |
| `as_of_date` | `Date` | Optional | Date benefit was calculated |
| `frequency` | [`PaymentFrequency3`](../../doc/models/payment-frequency-3.md) | Optional | ANNUALLY, BIWEEKLY, DAILY, MONTHLY, SEMIANNUALLY, SEMIMONTHLY, WEEKLY |
| `start_date` | `Date` | Optional | Assumed retirement date. As of date amount is payable |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "asOfDate": "2021-07-15",
  "startDate": "2021-07-15",
  "displayName": "displayName6",
  "amount": 39.82,
  "paymentOption": "paymentOption2",
  "frequency": "DAILY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

