
# Payment Initiation Party Summary Entity

Summary of a payment initiation party

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartySummaryEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentInitiationPartyId` | `String` | Optional | Unique identifier of a payment initiation party | String getPaymentInitiationPartyId() | setPaymentInitiationPartyId(String paymentInitiationPartyId) |
| `Name` | [`PaymentInitiationPartyNameEntity3`](../../doc/models/payment-initiation-party-name-entity-3.md) | Optional | Details of the name | PaymentInitiationPartyNameEntity3 getName() | setName(PaymentInitiationPartyNameEntity3 name) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "paymentInitiationPartyId": "paymentInitiationPartyId6",
  "name": {
    "aliasName": "aliasName2",
    "detail": {
      "companyName": "companyName0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

