
# Annuity Account Entity

An annuity account type

*This model accepts additional fields of type Object.*

## Structure

`AnnuityAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payout_type` | [`PayoutType2`](../../doc/models/payout-type-2.md) | Optional | Indicates type of payout such as immediate or deferred |
| `policy_product_type` | [`PolicyProductType2`](../../doc/models/policy-product-type-2.md) | Optional | The type of annuity product, e.g. Fixed or Variable |
| `payout_amount` | `Float` | Optional | Amount paid out, based on mode frequency |
| `payout_mode` | [`PayoutMode2`](../../doc/models/payout-mode-2.md) | Optional | Frequency of annuity payments |
| `payout_start_date` | `Date` | Optional | Date the payout starts |
| `payout_end_date` | `Date` | Optional | Date the payout ends |
| `number_modal_payouts` | `Integer` | Optional | Total number of payouts |
| `surrender_value` | `Float` | Optional | Cash surrender value (net) available if contract is surrendered |
| `payout_change_percentage` | `Float` | Optional | Percentage of the accumulated value to be paid to the payee each year; used exclusive of payoutChangeAmount |
| `payout_change_amount` | `Float` | Optional | Incremental modal amount (positive or negative) by which the payout amount will be changed; used exclusive of payoutPercentage |
| `period_certain_type` | [`PeriodCertainType2`](../../doc/models/period-certain-type-2.md) | Optional | The number of modal periods comprising the duration of the certain period of an annuity payout |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "payoutStartDate": "2021-07-15",
  "payoutEndDate": "2021-07-15",
  "accountCategory": "Annuity Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "payoutType": "DEFERRED",
  "policyProductType": "FIXED",
  "payoutAmount": 63.04,
  "payoutMode": "ANNUALLY"
}
```

