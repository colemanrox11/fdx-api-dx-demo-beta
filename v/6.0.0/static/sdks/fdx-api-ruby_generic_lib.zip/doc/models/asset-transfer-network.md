
# Asset Transfer Network

Information required to facilitate asset transfer from this account

*This model accepts additional fields of type Object.*

## Structure

`AssetTransferNetwork`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `identifier` | `String` | Optional | The number used to identify the account within the asset transfer network. If identifierType is ACCOUNT_NUMBER, this is the account number; if identifierType is TOKENIZED_ACCOUNT_NUMBER, this is a tokenized account number |
| `identifier_type` | [`PaymentNetworkIdentifierType1`](../../doc/models/payment-network-identifier-type-1.md) | Optional | Type of identifier |
| `institution_name` | `String` | Optional | The name of the institution holding the account |
| `institution_id` | `String` | Optional | Institution identifier used by the asset transfer network ie. the Depository Trust and Clearing Corporation code for the institution holding the account |
| `type` | [`AssetTransferType2`](../../doc/models/asset-transfer-type-2.md) | Optional | Type of asset transfer |
| `joint_account` | `TrueClass \| FalseClass` | Optional | Whether this account has joint owners |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "identifier": "identifier0",
  "identifierType": "ACCOUNT_NUMBER",
  "institutionName": "institutionName0",
  "institutionId": "institutionId6",
  "type": "CA_ATON",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

