# Fraud Notification

```ruby
fraud_notification_controller = client.fraud_notification
```

## Class Name

`FraudNotificationController`


# Report Suspected Fraud Incident

Notify Data Provider of suspected fraud

```ruby
def report_suspected_fraud_incident(x_fapi_interaction_id,
                                    fdx_api_actor_type: nil,
                                    body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`SuspectedFraudIncidentEntity`](../../doc/models/suspected-fraud-incident-entity.md) | Body, Optional | - |

## Server

`Server::FRAUD`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

body = SuspectedFraudIncidentEntity.new(
  type: 'RISK',
  suspected_incident_id: '0a318518-ca16-4e66-be76-865a632ea771',
  reporter: PartyEntity.new(
    name: 'ABC Inc',
    type: PartyType::DATA_ACCESS_PLATFORM,
    home_uri: 'http://example.com',
    logo_uri: 'http://example.com',
    registry: Registry::FDX,
    registered_entity_name: 'ABC',
    registered_entity_id: 'ABC123'
  )
)

result = fraud_notification_controller.report_suspected_fraud_incident(
  x_fapi_interaction_id,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

