
# Monetary Amount 3

Bonus pay for covered period

*This model accepts additional fields of type Object.*

## Structure

`MonetaryAmount3`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `Float` | Required | The monetary amount |
| `currency` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | Currency code of the monetary amount |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "amount": 2.12,
  "currency": "AFN",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

