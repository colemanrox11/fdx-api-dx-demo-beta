
# Interest Rate Type

The type of interest rate

*This model accepts additional fields of type Object.*

## Enumeration

`InterestRateType`

## Fields

| Name |
|  --- |
| `Fixed` |
| `Variable` |

