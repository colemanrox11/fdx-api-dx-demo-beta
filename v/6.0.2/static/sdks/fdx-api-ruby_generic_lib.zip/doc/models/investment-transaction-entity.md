
# Investment Transaction Entity

Specific transaction information

*This model accepts additional fields of type Object.*

## Structure

`InvestmentTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_type` | [`InvestmentTransactionType2`](../../doc/models/investment-transaction-type-2.md) | Optional | PURCHASED, SOLD, PURCHASEDTOCOVER, ADJUSTMENT, PURCHASETOOPEN, PURCHASETOCLOSE, SOLDTOOPEN, SOLDTOCLOSE, INTEREST, MARGININTEREST, REINVESTOFINCOME, RETURNOFCAPITAL, TRANSFER, CONTRIBUTION, FEE, OPTIONEXERCISE, OPTIONEXPIRATION, DIVIDEND, DIVIDENDREINVEST, SPLIT, CLOSURE, INCOME, EXPENSE, CLOSUREOPT, INVEXPENSE, JRNLSEC, JRNLFUND, OTHER, DIV, SRVCHG, DEP, DEPOSIT, ATM, POS, XFER, CHECK, PAYMENT, CASH, DIRECTDEP, DIRECTDEBIT, REPEATPMT |
| `shares` | `Float` | Optional | Required for stock, mutual funds. Number of shares (with decimals). Negative numbers indicate securities are being removed from the account |
| `face_value` | `Float` | Optional | Cash value for bonds |
| `price` | `Float` | Optional | Unit purchase price |
| `security_id` | `String` | Optional | Unique identifier of security |
| `security_id_type` | [`SecurityIdType1`](../../doc/models/security-id-type-1.md) | Optional | CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN |
| `security_type` | [`SecurityType2`](../../doc/models/security-type-2.md) | Optional | BOND, DEBT, DIGITALASSET, MUTUALFUND, OPTION, OTHER, STOCK, SWEEP |
| `symbol` | `String` | Optional | Ticker symbol |
| `markup` | `Float` | Optional | Portion of unit price that is attributed to the dealer markup |
| `commission` | `Float` | Optional | Transaction commission |
| `taxes` | `Float` | Optional | Taxes on the trade |
| `fees` | `Float` | Optional | Fees applied to the trade |
| `load` | `Float` | Optional | Load on the transaction |
| `inv_401_k_source` | [`Investment401KSourceType2`](../../doc/models/investment-401-k-source-type-2.md) | Optional | Source of money. One of PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST |
| `confirmation_number` | `String` | Optional | Confirmation number of the transaction |
| `fractional_cash` | `Float` | Optional | Cash for fractional units (used for stock splits) |
| `income_type` | [`IncomeType2`](../../doc/models/income-type-2.md) | Optional | Type of investment income. One of CGLONG (capital gains-long term), CGSHORT (capital gains-short term), MISC |
| `old_units` | `Float` | Optional | Number of shares before split |
| `split_ratio_numerator` | `Float` | Optional | Split ratio numerator |
| `split_ratio_denominator` | `Float` | Optional | Split ratio denominator |
| `new_units` | `Float` | Optional | Number of shares after split |
| `sub_account_sec` | [`SubAccountType1`](../../doc/models/sub-account-type-1.md) | Optional | Sub-account security Type. One of CASH, MARGIN, SHORT, OTHERS |
| `sub_account_fund` | [`SubAccountType2`](../../doc/models/sub-account-type-2.md) | Optional | From which account money came in. One of CASH, MARGIN, SHORT, OTHERS |
| `loan_id` | `String` | Optional | For 401k accounts only. This indicates the transaction was due to a loan or a loan repayment |
| `loan_principal` | `Float` | Optional | How much loan pre-payment is principal |
| `loan_interest` | `Float` | Optional | How much loan pre-payment is interest |
| `payroll_date` | `Date` | Optional | The date for the 401k transaction was obtained in payroll |
| `prior_year_contrib` | `TrueClass \| FalseClass` | Optional | Indicates this buy was made using prior year's contribution |
| `withholding` | `Float` | Optional | Federal tax withholding |
| `tax_exempt` | `TrueClass \| FalseClass` | Optional | Tax-exempt transaction |
| `gain` | `Float` | Optional | For sales |
| `state_withholding` | `Float` | Optional | State tax withholding |
| `penalty` | `Float` | Optional | Indicates amount withheld due to a penalty |
| `running_balance` | `Float` | Optional | Running balance of the position |
| `unit_price` | `Float` | Optional | Price per commonly-quoted unit. Does not include markup/markdown, unitprice. Share price for stocks, mutual funds, and others. Percentage of par for bonds. Per share (not contract) for options |
| `units` | `Float` | Optional | For security-based actions other than stock splits, quantity. Shares for stocks, mutual funds, and others. Face value for bonds. Contracts for options |
| `unit_type` | [`UnitType1`](../../doc/models/unit-type-1.md) | Optional | SHARES, CURRENCY |
| `transaction_reason` | [`TransactionReason2`](../../doc/models/transaction-reason-2.md) | Optional | Reason for this transaction; CALL (the debt was called), SELL (the debt was sold), MATURITY (the debt reached maturity) |
| `accrued_interest` | `Float` | Optional | Accrued interest |
| `transfer_action` | [`InvestmentTransferActionDirection2`](../../doc/models/investment-transfer-action-direction-2.md) | Optional | Transfer direction |
| `position_type` | [`PositionType1`](../../doc/models/position-type-1.md) | Optional | LONG, SHORT |
| `digital_units` | `String` | Optional | Full precision unit number, unlimited digits after decimal point |
| `settlement_timestamp` | `DateTime` | Optional | When the trade settled |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "postedTimestamp": "07/15/2021 14:46:41",
  "transactionTimestamp": "07/15/2021 14:46:41",
  "payrollDate": "2021-07-15",
  "settlementTimestamp": "07/15/2021 14:46:41",
  "accountCategory": "Investment Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "ADJUSTMENT",
  "shares": 55.78,
  "faceValue": 10.94,
  "price": 166.68,
  "securityId": "securityId0"
}
```

