
# Sub Account Type

The subtype of an account

*This model accepts additional fields of type Object.*

## Enumeration

`SubAccountType`

## Fields

| Name |
|  --- |
| `Cash` |
| `Margin` |
| `Other` |
| `MShort` |

