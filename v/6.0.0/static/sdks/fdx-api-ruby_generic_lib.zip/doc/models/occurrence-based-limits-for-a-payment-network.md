
# Occurrence Based Limits for a Payment Network

This provides the occurrence-based limits applied to the account within the payment network

*This model accepts additional fields of type Object.*

## Structure

`OccurrenceBasedLimitsForAPaymentNetwork`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transfer_max_amount` | `Float` | Optional | Maximum limit of funds that can be transferred to/from the account using the timeframe limits |
| `transfer_remaining_amount` | `Float` | Optional | Remaining value of the maximum limit of funds that can be transferred to/from the account using the timeframe limits |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "transferMaxAmount": 142.14,
  "transferRemainingAmount": 233.6,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

