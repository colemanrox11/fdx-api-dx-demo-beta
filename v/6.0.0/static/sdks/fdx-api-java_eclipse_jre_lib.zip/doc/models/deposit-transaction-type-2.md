
# Deposit Transaction Type 2

CHECK, WITHDRAWAL, TRANSFER, POSDEBIT, ATMWITHDRAWAL, BILLPAYMENT, FEE, DEPOSIT, ADJUSTMENT, INTEREST, DIVIDEND, DIRECTDEPOSIT, ATMDEPOSIT, POSCREDIT

*This model accepts additional fields of type Object.*

## Enumeration

`DepositTransactionType2`

## Fields

| Name |
|  --- |
| `Adjustment` |
| `Atmdeposit` |
| `Atmwithdrawal` |
| `Billpayment` |
| `Check` |
| `Deposit` |
| `Directdeposit` |
| `Dividend` |
| `Fee` |
| `Interest` |
| `Poscredit` |
| `Posdebit` |
| `Transfer` |
| `Withdrawal` |

