
# Form 1042 S Agent 3

Boxes 15a-i, Intermediary or flow thru entity

*This model accepts additional fields of type Object.*

## Structure

`Form1042SAgent3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Tin` | `String` | Optional | Issuer or recipient Tax Identification Number. Usually EIN for issuer and SSN for recipient | String getTin() | setTin(String tin) |
| `PartyType` | [`TaxPartyType2`](../../doc/models/tax-party-type-2.md) | Optional | Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient | TaxPartyType2 getPartyType() | setPartyType(TaxPartyType2 partyType) |
| `IndividualName` | [`IndividualName`](../../doc/models/individual-name.md) | Optional | Individual issuer or recipient name | IndividualName getIndividualName() | setIndividualName(IndividualName individualName) |
| `BusinessName` | [`BusinessName`](../../doc/models/business-name.md) | Optional | Business issuer or recipient name | BusinessName getBusinessName() | setBusinessName(BusinessName businessName) |
| `Address` | [`Address`](../../doc/models/address.md) | Optional | Issuer or recipient address | Address getAddress() | setAddress(Address address) |
| `Phone` | [`TelephoneNumberPlusExtension`](../../doc/models/telephone-number-plus-extension.md) | Optional | Issuer or recipient telephone number | TelephoneNumberPlusExtension getPhone() | setPhone(TelephoneNumberPlusExtension phone) |
| `Email` | `String` | Optional | Issuer or recipient email address. (Additional information, not part of IRS forms) | String getEmail() | setEmail(String email) |
| `Ch3StatusCode` | `String` | Optional | Ch. 3 status code,<br><br>* Box 12b, Withholding Agent,<br>* Box 13f, Recipient,<br>* Box 15b, Intermediary or flow-through entity,<br>* Box 16d, Payer | String getCh3StatusCode() | setCh3StatusCode(String ch3StatusCode) |
| `Ch4StatusCode` | `String` | Optional | Ch. 4 status code,<br><br>* Box 12c, Withholding Agent,<br>* Box 13g, Recipient,<br>* Box 15c, Intermediary or flow-through entity,<br>* Box 16e, Payer | String getCh4StatusCode() | setCh4StatusCode(String ch4StatusCode) |
| `Giin` | `String` | Optional | Agent's Global Intermediary Identification Number (GIIN),<br><br>* Box 12e, Withholding Agent,<br>* Box 13h, Recipient,<br>* Box 15e, Intermediary or flow-through entity,<br>* Box 16c, Payer | String getGiin() | setGiin(String giin) |
| `ForeignTin` | `String` | Optional | Foreign tax identification number, if any,<br><br>* Box 12g, Withholding Agent,<br>* Box 13i, Recipient,<br>* Box 15g, Intermediary or flow-through entity | String getForeignTin() | setForeignTin(String foreignTin) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "tin": "tin0",
  "partyType": "BUSINESS",
  "individualName": {
    "first": "first0",
    "middle": "middle0",
    "last": "last4",
    "suffix": "suffix4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "businessName": {
    "name1": "name18",
    "name2": "name22",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

