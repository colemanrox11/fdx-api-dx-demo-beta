
# Fi Attribute Entity

Financial Institution provider-specific attribute

*This model accepts additional fields of type Object.*

## Structure

`FiAttributeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name of attribute |
| `value` | `String` | Optional | Value of attribute |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name0",
  "value": "value2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

