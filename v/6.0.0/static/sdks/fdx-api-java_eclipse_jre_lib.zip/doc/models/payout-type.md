
# Payout Type

Indicates a type of payout such as immediate or deferred.

| Value | Description |
|-----|-----|
| DEFERRED | Deferred payout starts at a predetermined date in the future |
| IMMEDIATE | Immediate payout begins paying out shortly after the annuity is purchased |

*This model accepts additional fields of type Object.*

## Enumeration

`PayoutType`

## Fields

| Name |
|  --- |
| `Deferred` |
| `Immediate` |

