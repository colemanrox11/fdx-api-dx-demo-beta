
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpClientConfig | [`Consumer<HttpClientConfiguration.Builder>`](../doc/http-client-configuration-builder.md) | Set up Http Client Configuration instance. |
| loggingConfig | [`Consumer<ApiLoggingConfiguration.Builder>`](../doc/api-logging-configuration-builder.md) | Set up Logging Configuration instance. |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| taxBasicAuthCredentials | [`TaxBasicAuthCredentials`](auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |

The API client can be initialized as follows:

```java
import java.io.IOException;
import net.apigee.financialdataexchangeprod.Environment;
import net.apigee.financialdataexchangeprod.FdxApiClient;
import net.apigee.financialdataexchangeprod.authentication.BearerAuthModel;
import net.apigee.financialdataexchangeprod.authentication.TaxBasicAuthModel;
import net.apigee.financialdataexchangeprod.exceptions.ApiException;
import net.apigee.financialdataexchangeprod.http.response.ApiResponse;
import org.slf4j.event.Level;

FdxApiClient client = new FdxApiClient.Builder()
    .loggingConfig(builder -> builder
            .level(Level.DEBUG)
            .requestConfig(logConfigBuilder -> logConfigBuilder.body(true))
            .responseConfig(logConfigBuilder -> logConfigBuilder.headers(true)))
    .httpClientConfig(configBuilder -> configBuilder
            .timeout(0))
    .bearerAuthCredentials(new BearerAuthModel.Builder(
            "AccessToken"
        )
        .build())
    .taxBasicAuthCredentials(new TaxBasicAuthModel.Builder(
            "Username",
            "Password"
        )
        .build())
    .environment(Environment.PRODUCTION)
    .build();
```

## FDX APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description | Return Type |
|  --- | --- | --- |
| `getUserConsentController()` | Provides access to UserConsent controller. | `UserConsentController` |
| `getAccountInformationController()` | Provides access to AccountInformation controller. | `AccountInformationController` |
| `getAccountStatementsController()` | Provides access to AccountStatements controller. | `AccountStatementsController` |
| `getAccountTransactionsController()` | Provides access to AccountTransactions controller. | `AccountTransactionsController` |
| `getMoneyMovementController()` | Provides access to MoneyMovement controller. | `MoneyMovementController` |
| `getPersonalInformationController()` | Provides access to PersonalInformation controller. | `PersonalInformationController` |
| `getRewardProgramCategoriesController()` | Provides access to RewardProgramCategories controller. | `RewardProgramCategoriesController` |
| `getRewardProgramInformationController()` | Provides access to RewardProgramInformation controller. | `RewardProgramInformationController` |
| `getEventNotificationsController()` | Provides access to EventNotifications controller. | `EventNotificationsController` |
| `getFraudNotificationController()` | Provides access to FraudNotification controller. | `FraudNotificationController` |
| `getMetaController()` | Provides access to Meta controller. | `MetaController` |
| `getInternalTransfersController()` | Provides access to InternalTransfers controller. | `InternalTransfersController` |
| `getPayeeManagementController()` | Provides access to PayeeManagement controller. | `PayeeManagementController` |
| `getPaymentInitiationPartiesController()` | Provides access to PaymentInitiationParties controller. | `PaymentInitiationPartiesController` |
| `getPaymentsController()` | Provides access to Payments controller. | `PaymentsController` |
| `getRecurringPaymentsController()` | Provides access to RecurringPayments controller. | `RecurringPaymentsController` |
| `getPayrollInformationController()` | Provides access to PayrollInformation controller. | `PayrollInformationController` |
| `getRecipientsController()` | Provides access to Recipients controller. | `RecipientsController` |
| `getSubmitTaxFormsController()` | Provides access to SubmitTaxForms controller. | `SubmitTaxFormsController` |
| `getTaxFormsController()` | Provides access to TaxForms controller. | `TaxFormsController` |
| `getResourceInformationController()` | Provides access to ResourceInformation controller. | `ResourceInformationController` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `shutdown()` | Shutdown the underlying HttpClient instance. | `void` |
| `getEnvironment()` | Current API environment. | `Environment` |
| `getHttpClient()` | The HTTP Client instance to use for making HTTP requests. | `HttpClient` |
| `getHttpClientConfig()` | Http Client Configuration instance. | [`ReadonlyHttpClientConfiguration`](../doc/http-client-configuration.md) |
| `getLoggingConfig()` | Logging Configuration instance. | [`ReadonlyLoggingConfiguration`](../doc/api-logging-configuration.md) |
| `getBearerAuthCredentials()` | The credentials to use with BearerAuth. | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) |
| `getTaxBasicAuthCredentials()` | The credentials to use with TaxBasicAuth. | [`TaxBasicAuthCredentials`](auth/basic-authentication.md) |
| `getBaseUri(Server server)` | Get base URI by current environment | `String` |
| `getBaseUri()` | Get base URI by current environment | `String` |

