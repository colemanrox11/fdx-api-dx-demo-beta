
# Loan Transaction Type 2

PAYMENT, FEE, ADJUSTMENT, INTEREST

*This model accepts additional fields of type Object.*

## Enumeration

`LoanTransactionType2`

## Fields

| Name |
|  --- |
| `Adjustment` |
| `DoubleUpPayment` |
| `Fee` |
| `Interest` |
| `LumpSumPayment` |
| `Payment` |
| `Payoff` |
| `SkipPayment` |

