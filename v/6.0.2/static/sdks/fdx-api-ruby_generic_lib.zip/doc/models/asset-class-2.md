
# Asset Class 2

The asset class for this allocation

*This model accepts additional fields of type Object.*

## Enumeration

`AssetClass2`

## Fields

| Name |
|  --- |
| `DOMESTICBOND` |
| `INTLBOND` |
| `INTLSTOCK` |
| `LARGESTOCK` |
| `MONEYMARKET` |
| `OTHER` |
| `SMALLSTOCK` |

