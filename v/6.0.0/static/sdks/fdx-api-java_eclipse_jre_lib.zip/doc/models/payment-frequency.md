
# Payment Frequency

The frequency of payments

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentFrequency`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

