
# Occurrence Based Limits for a Payment Network 2

The transfer limits taking effect from all the timeframe limits

*This model accepts additional fields of type Object.*

## Structure

`OccurrenceBasedLimitsForAPaymentNetwork2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transfer_max_amount` | `Float` | Optional | Maximum limit of funds that can be transferred to/from the account using the timeframe limits |
| `transfer_remaining_amount` | `Float` | Optional | Remaining value of the maximum limit of funds that can be transferred to/from the account using the timeframe limits |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "transferMaxAmount": 109.44,
  "transferRemainingAmount": 200.9,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

