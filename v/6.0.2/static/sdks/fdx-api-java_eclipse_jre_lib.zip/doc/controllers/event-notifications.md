# Event Notifications

```java
EventNotificationsController eventNotificationsController = client.getEventNotificationsController();
```

## Class Name

`EventNotificationsController`

## Methods

* [Create Notification Subscription](../../doc/controllers/event-notifications.md#create-notification-subscription)
* [Get Notification Subscription](../../doc/controllers/event-notifications.md#get-notification-subscription)
* [Delete Notification Subscription](../../doc/controllers/event-notifications.md#delete-notification-subscription)
* [Publish Notification](../../doc/controllers/event-notifications.md#publish-notification)
* [Get Notifications](../../doc/controllers/event-notifications.md#get-notifications)


# Create Notification Subscription

Creates notification subscription entry on the server

```java
CompletableFuture<ApiResponse<NotificationSubscriptionEntity>> createNotificationSubscriptionAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final NotificationSubscriptionEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md) | Body, Optional | Notification subscription |

## Server

`Server.EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
NotificationSubscriptionEntity body = new NotificationSubscriptionEntity.Builder(
    NotificationType.CONSENT_REVOKED,
    NotificationCategory1.CONSENT,
    "https://abc.com/notification",
    new PartyEntity.Builder(
        "ABC Inc",
        PartyType.DATA_ACCESS_PLATFORM
    )
    .homeUri("https://abc.com/logo")
    .logoUri("https://abc.com/logo")
    .registry(Registry.FDX)
    .registeredEntityName("ABC")
    .registeredEntityId("ABC123")
    .build()
)
.effectiveDate(DateTimeHelper.fromSimpleDate("2021-11-24"))
.subscriptionId("GUID-SubscriptionId1")
.build();

eventNotificationsController.createNotificationSubscriptionAsync(xFapiInteractionId, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "type": "CONSENT_REVOKED",
  "category": "CONSENT",
  "callbackUrl": "https://abc.com/notification",
  "subscriber": {
    "name": "ABC Inc",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "https://abc.com/logo",
    "logoUri": "https://abc.com/logo",
    "registry": "FDX",
    "registeredEntityName": "ABC",
    "registeredEntityId": "ABC123"
  },
  "effectiveDate": "2021-11-24",
  "subscriptionId": "GUID-SubscriptionId2"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Notification Subscription

Call to get notification subscription

```java
CompletableFuture<ApiResponse<NotificationSubscriptionEntity>> getNotificationSubscriptionAsync(
    final UUID xFapiInteractionId,
    final String subscriptionId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `subscriptionId` | `String` | Template, Required | ID of notification subscription<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String subscriptionId = "subscriptionId0";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

eventNotificationsController.getNotificationSubscriptionAsync(xFapiInteractionId, subscriptionId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "type": "CONSENT_REVOKED",
  "category": "CONSENT",
  "callbackUrl": "https://abc.com/notification",
  "subscriber": {
    "name": "ABC Inc",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "https://abc.com/logo",
    "logoUri": "https://abc.com/logo",
    "registry": "FDX",
    "registeredEntityName": "ABC",
    "registeredEntityId": "ABC123"
  },
  "effectiveDate": "2021-11-24",
  "subscriptionId": "GUID-SubscriptionId2"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Notification Subscription

Delete a notification subscription

```java
CompletableFuture<ApiResponse<Void>> deleteNotificationSubscriptionAsync(
    final UUID xFapiInteractionId,
    final String subscriptionId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `subscriptionId` | `String` | Template, Required | ID of notification subscription<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.EVENTNOTIFICATIONS`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String subscriptionId = "subscriptionId0";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

eventNotificationsController.deleteNotificationSubscriptionAsync(xFapiInteractionId, subscriptionId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Publish Notification

Publish Notification

```java
CompletableFuture<ApiResponse<Void>> publishNotificationAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final NotificationEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`NotificationEntity`](../../doc/models/notification-entity.md) | Body, Optional | - |

## Server

`Server.EVENTNOTIFICATIONS`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
NotificationEntity body = new NotificationEntity.Builder(
    "req123456-GUID",
    NotificationType.CONSENT_REVOKED,
    DateTimeHelper.fromRfc8601DateTime("2021-07-15T14:46:41.375Z"),
    NotificationCategory1.SECURITY,
    new PartyEntity.Builder(
        "XYZ Inc",
        PartyType.DATA_ACCESS_PLATFORM
    )
    .homeUri("http://example.com")
    .logoUri("http://example.com")
    .registry(Registry.FDX)
    .registeredEntityName("XYZ")
    .registeredEntityId("xyz1234")
    .build(),
    new NotificationPayloadEntity2.Builder()
        .id("ConsentID-1")
        .idType(NotificationPayloadIdType2.CONSENT)
        .customFields(new FiAttributeEntity.Builder()
            .name("INITIATOR")
            .value("INDIVIDUAL")
            .build())
        .build()
)
.severity(NotificationSeverity2.EMERGENCY)
.priority(NotificationPriority2.HIGH)
.subscriber(new PartyEntity.Builder(
        "ABC Inc",
        PartyType.DATA_ACCESS_PLATFORM
    )
    .homeUri("http://example.com")
    .logoUri("http://example.com")
    .registry(Registry.FDX)
    .registeredEntityName("ABC")
    .registeredEntityId("ABC123")
    .build())
.url(new HateoasLink.Builder(
        "https://api.xyz.com/fdx/v6/consents/ConsentID-1/revocation"
    )
    .action(HttpActionType.GET)
    .rel("consent")
    .types(Arrays.asList(
            ContentTypes.ENUM_APPLICATIONJSON
        ))
    .build())
.build();

eventNotificationsController.publishNotificationAsync(xFapiInteractionId, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Notifications

Get Notifications

```java
CompletableFuture<ApiResponse<NotificationsEntity>> getNotificationsAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final Integer limit,
    final String offset,
    final String dataRecipientId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `dataRecipientId` | `String` | Query, Optional | ID of Data Recipient (DR), omit for all DRs of a Data Access Platform<br><br>**Constraints**: *Maximum Length*: `256` |

## Server

`Server.EVENTNOTIFICATIONS`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`NotificationsEntity`](../../doc/models/notifications-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

eventNotificationsController.getNotificationsAsync(xFapiInteractionId, fdxApiActorType, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "notifications": [
    {
      "notificationId": "0a318518-ca16-4e66-1234",
      "type": "RISK",
      "sentOn": "2021-07-15T14:46:41.375Z",
      "category": "FRAUD",
      "severity": "EMERGENCY",
      "priority": "HIGH",
      "publisher": {
        "name": "XYZ Inc",
        "type": "DATA_ACCESS_PLATFORM",
        "homeUri": "http://example.com",
        "logoUri": "http://example.com",
        "registry": "FDX",
        "registeredEntityName": "XYZ",
        "registeredEntityId": "xyz1234"
      },
      "subscriber": {
        "name": "ABC Inc",
        "type": "DATA_ACCESS_PLATFORM",
        "homeUri": "http://example.com",
        "logoUri": "http://example.com",
        "registry": "FDX",
        "registeredEntityName": "ABC",
        "registeredEntityId": "ABC123"
      },
      "notificationPayload": {
        "id": "0a318518-ca16-4e66-be76-865a632ea771",
        "idType": "ACCOUNT"
      },
      "url": {
        "href": "https://api.xyz.com/fdx/v4/notifications?dataRecipientId=FIREFLY",
        "action": "GET",
        "rel": "notification",
        "types": [
          "application/json"
        ]
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

