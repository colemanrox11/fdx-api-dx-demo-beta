
# Payment Entity Error Exception

Represents a payment

*This model accepts additional fields of type Object.*

## Structure

`PaymentEntityErrorException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FromAccountId` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` | String getFromAccountId() | setFromAccountId(String fromAccountId) |
| `ToPayeeId` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` | String getToPayeeId() | setToPayeeId(String toPayeeId) |
| `Amount` | `double` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` | double getAmount() | setAmount(double amount) |
| `MerchantAccountId` | `String` | Optional | User's account identifier with the merchant | String getMerchantAccountId() | setMerchantAccountId(String merchantAccountId) |
| `DueDate` | `LocalDate` | Required | Date that the funds are scheduled to be delivered | LocalDate getDueDate() | setDueDate(LocalDate dueDate) |
| `PaymentId` | `String` | Required | Uniquely identifies a payment. Used within the API to reference a payment<br><br>**Constraints**: *Maximum Length*: `256` | String getPaymentId() | setPaymentId(String paymentId) |
| `RecurringPaymentId` | `String` | Optional | The recurring payment that spawned this payment. Null if payment is not associated with a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` | String getRecurringPaymentId() | setRecurringPaymentId(String recurringPaymentId) |
| `ScheduledTimestamp` | `LocalDateTime` | Optional | When the payment was scheduled | LocalDateTime getScheduledTimestamp() | setScheduledTimestamp(LocalDateTime scheduledTimestamp) |
| `ProcessedTimestamp` | `LocalDateTime` | Optional | When the payment was processed | LocalDateTime getProcessedTimestamp() | setProcessedTimestamp(LocalDateTime processedTimestamp) |
| `FailedTimestamp` | `LocalDateTime` | Optional | When the payment failed. Includes when the payment was determined to lack sufficient funds | LocalDateTime getFailedTimestamp() | setFailedTimestamp(LocalDateTime failedTimestamp) |
| `CancelledTimestamp` | `LocalDateTime` | Optional | When the payment was cancelled | LocalDateTime getCancelledTimestamp() | setCancelledTimestamp(LocalDateTime cancelledTimestamp) |
| `StartedProcessingTimestamp` | `LocalDateTime` | Optional | When the payment execution started | LocalDateTime getStartedProcessingTimestamp() | setStartedProcessingTimestamp(LocalDateTime startedProcessingTimestamp) |
| `Status` | [`PaymentStatus3`](../../doc/models/payment-status-3.md) | Required | Defines the status of the payment | PaymentStatus3 getStatus() | setStatus(PaymentStatus3 status) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to related payment entities | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "fromAccountId": "fromAccountId0",
  "toPayeeId": "toPayeeId4",
  "amount": 117.88,
  "dueDate": "2021-07-15",
  "paymentId": "paymentId8",
  "scheduledTimestamp": "07/15/2021 14:46:41",
  "processedTimestamp": "07/15/2021 14:46:41",
  "failedTimestamp": "07/15/2021 14:46:41",
  "cancelledTimestamp": "07/15/2021 14:46:41",
  "startedProcessingTimestamp": "07/15/2021 14:46:41",
  "status": "NOFUNDS",
  "merchantAccountId": "merchantAccountId4",
  "recurringPaymentId": "recurringPaymentId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

