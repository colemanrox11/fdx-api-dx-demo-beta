
# Insurance Transaction Entity

An insurance transaction type

*This model accepts additional fields of type Object.*

## Structure

`InsuranceTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionType` | [`InsuranceTransactionType`](../../doc/models/insurance-transaction-type.md) | Optional | The type of an insurance transaction | InsuranceTransactionType getTransactionType() | setTransactionType(InsuranceTransactionType transactionType) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountCategory": "Insurance Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "ADJUSTMENT"
}
```

