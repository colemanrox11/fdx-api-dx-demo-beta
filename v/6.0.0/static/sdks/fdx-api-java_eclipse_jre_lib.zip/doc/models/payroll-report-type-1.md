
# Payroll Report Type 1

The type of report

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollReportType1`

## Fields

| Name |
|  --- |
| `Voe` |
| `Voie` |

