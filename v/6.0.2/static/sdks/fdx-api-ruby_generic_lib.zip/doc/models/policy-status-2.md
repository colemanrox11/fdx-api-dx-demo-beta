
# Policy Status 2

The status of an insurance policy account

*This model accepts additional fields of type Object.*

## Enumeration

`PolicyStatus2`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `DEATH_CLAIM_PAID` |
| `DEATH_CLAIM_PENDING` |
| `EXPIRED` |
| `GRACE_PERIOD` |
| `LAPSE_PENDING` |
| `TERMINATED` |
| `WAIVER` |

