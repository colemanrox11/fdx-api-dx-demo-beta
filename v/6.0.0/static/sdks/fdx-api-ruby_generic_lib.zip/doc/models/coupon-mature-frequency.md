
# Coupon Mature Frequency

The frequency of a bond's coupon maturity

*This model accepts additional fields of type Object.*

## Enumeration

`CouponMatureFrequency`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `MONTHLY` |
| `OTHER` |
| `QUARTERLY` |
| `SEMIANNUAL` |

