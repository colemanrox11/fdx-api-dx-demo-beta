
# Compounding Period

Interest compounding Period

*This model accepts additional fields of type Object.*

## Enumeration

`CompoundingPeriod`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

