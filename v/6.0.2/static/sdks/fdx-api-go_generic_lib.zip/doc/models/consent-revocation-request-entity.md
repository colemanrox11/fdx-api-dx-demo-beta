
# Consent Revocation Request Entity

Details of request to revoke consent grant

*This model accepts additional fields of type interface{}.*

## Structure

`ConsentRevocationRequestEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reason` | [`*models.ConsentUpdateReason1`](../../doc/models/consent-update-reason-1.md) | Optional | The reason for consent revocation |
| `Initiator` | [`*models.PartyType2`](../../doc/models/party-type-2.md) | Optional | The party initiating revocation |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "reason": "BUSINESS_RULE",
  "initiator": "MERCHANT",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

