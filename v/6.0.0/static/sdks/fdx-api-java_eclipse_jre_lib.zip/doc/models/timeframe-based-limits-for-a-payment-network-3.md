
# Timeframe Based Limits for a Payment Network 3

The transfer limits for the current year

*This model accepts additional fields of type Object.*

## Structure

`TimeframeBasedLimitsForAPaymentNetwork3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ResetsOn` | `LocalDateTime` | Optional | Date/time at which this timeframe will reset next | LocalDateTime getResetsOn() | setResetsOn(LocalDateTime resetsOn) |
| `TransferMaxAmount` | `Double` | Optional | Maximum limit of funds that can be transferred to/from the account in this timeframe | Double getTransferMaxAmount() | setTransferMaxAmount(Double transferMaxAmount) |
| `TransferRemainingAmount` | `Double` | Optional | Remaining value of the maximum limit of funds that can be transferred to/from the account in this timeframe | Double getTransferRemainingAmount() | setTransferRemainingAmount(Double transferRemainingAmount) |
| `MaxOccurrence` | `Integer` | Optional | Maximum number of transfers that can be made in this direction for this timeframe | Integer getMaxOccurrence() | setMaxOccurrence(Integer maxOccurrence) |
| `RemainingOccurrence` | `Integer` | Optional | Remaining number of transfers that can be made in this direction for this timeframe | Integer getRemainingOccurrence() | setRemainingOccurrence(Integer remainingOccurrence) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "resetsOn": "2016-03-13T12:52:32.123Z",
  "transferMaxAmount": 178.46,
  "transferRemainingAmount": 13.92,
  "maxOccurrence": 240,
  "remainingOccurrence": 150,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

