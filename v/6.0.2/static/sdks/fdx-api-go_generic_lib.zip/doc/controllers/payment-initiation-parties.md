# Payment Initiation Parties

```go
paymentInitiationPartiesController := client.PaymentInitiationPartiesController()
```

## Class Name

`PaymentInitiationPartiesController`

## Methods

* [Create Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#create-payment-initiation-party)
* [List Payment Initiation Parties](../../doc/controllers/payment-initiation-parties.md#list-payment-initiation-parties)
* [Get Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#get-payment-initiation-party)
* [Update Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#update-payment-initiation-party)
* [Delete Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#delete-payment-initiation-party)
* [Create Payment Method](../../doc/controllers/payment-initiation-parties.md#create-payment-method)
* [Get Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#get-payment-method-registration)
* [Delete Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#delete-payment-method-registration)
* [Update Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#update-payment-method-registration)


# Create Payment Initiation Party

Create a payment initiation party associated with a customer profile

```go
CreatePaymentInitiationParty(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PaymentInitiationPartyEntity) (
    models.ApiResponse[models.PaymentInitiationPartyCreateResponseEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentInitiationPartyCreateResponseEntity](../../doc/models/payment-initiation-party-create-response-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

idempotencyKey := "idempotency-key4"

fdxApiActorType := models.FdxApiActorType_Batch

body := models.PaymentInitiationPartyEntity{
    Name:                       "name6",
    Type:                       models.PartyType_Merchant,
    ExpiresTimestamp:           models.ToPointer(parseTime(time.RFC3339, "07/15/2021 14:46:41", func(err error) { log.Fatalln(err) })),
}

apiResponse, err := paymentInitiationPartiesController.CreatePaymentInitiationParty(ctx, xFapiInteractionId, idempotencyKey, &fdxApiActorType, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# List Payment Initiation Parties

Retrieve the payment initiation parties associated with a customer profile

```go
ListPaymentInitiationParties(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    offset *string,
    limit *int) (
    models.ApiResponse[models.PaymentInitiationPartiesEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentInitiationPartiesEntity](../../doc/models/payment-initiation-parties-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch





apiResponse, err := paymentInitiationPartiesController.ListPaymentInitiationParties(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment Initiation Party

Retrieve the payment initiation party details by ID

```go
GetPaymentInitiationParty(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PaymentInitiationPartyEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentInitiationPartyEntity](../../doc/models/payment-initiation-party-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := paymentInitiationPartiesController.GetPaymentInitiationParty(ctx, xFapiInteractionId, paymentInitiationPartyId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment Initiation Party

Update the payment initiation party associated with a customer profile

```go
UpdatePaymentInitiationParty(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PaymentInitiationPartyEntity) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

idempotencyKey := "idempotency-key4"

fdxApiActorType := models.FdxApiActorType_Batch

body := models.PaymentInitiationPartyEntity{
    Name:                       "name6",
    Type:                       models.PartyType_Merchant,
    ExpiresTimestamp:           models.ToPointer(parseTime(time.RFC3339, "07/15/2021 14:46:41", func(err error) { log.Fatalln(err) })),
}

resp, err := paymentInitiationPartiesController.UpdatePaymentInitiationParty(ctx, xFapiInteractionId, paymentInitiationPartyId, idempotencyKey, &fdxApiActorType, &body)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payment Initiation Party

Remove the payment initiation party associated with a customer profile

```go
DeletePaymentInitiationParty(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    fdxApiActorType *models.FdxApiActorType) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

fdxApiActorType := models.FdxApiActorType_Batch

resp, err := paymentInitiationPartiesController.DeletePaymentInitiationParty(ctx, xFapiInteractionId, paymentInitiationPartyId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Create Payment Method

Registration of a payment initiation party to a payment method

```go
CreatePaymentMethod(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PaymentInitiationPartyToPaymentMethodEntity) (
    models.ApiResponse[models.PaymentInitiationPartyMethodCreateResponseEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentInitiationPartyMethodCreateResponseEntity](../../doc/models/payment-initiation-party-method-create-response-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

idempotencyKey := "idempotency-key4"

fdxApiActorType := models.FdxApiActorType_Batch



apiResponse, err := paymentInitiationPartiesController.CreatePaymentMethod(ctx, xFapiInteractionId, paymentInitiationPartyId, idempotencyKey, &fdxApiActorType, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment Method Registration

Retrieve the details of a payment method registered with a payment initiation party

```go
GetPaymentMethodRegistration(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    paymentMethodRegistrationId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.PaymentInitiationPartyToPaymentMethodEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `paymentMethodRegistrationId` | `string` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PaymentInitiationPartyToPaymentMethodEntity](../../doc/models/payment-initiation-party-to-payment-method-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

paymentMethodRegistrationId := "paymentMethodRegistrationId4"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := paymentInitiationPartiesController.GetPaymentMethodRegistration(ctx, xFapiInteractionId, paymentInitiationPartyId, paymentMethodRegistrationId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payment Method Registration

Remove the registered payment method from a payment initiation party

```go
DeletePaymentMethodRegistration(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    paymentMethodRegistrationId string,
    fdxApiActorType *models.FdxApiActorType) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `paymentMethodRegistrationId` | `string` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

paymentMethodRegistrationId := "paymentMethodRegistrationId4"

fdxApiActorType := models.FdxApiActorType_Batch

resp, err := paymentInitiationPartiesController.DeletePaymentMethodRegistration(ctx, xFapiInteractionId, paymentInitiationPartyId, paymentMethodRegistrationId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment Method Registration

Update the payment method registration associated with payment initiation party

```go
UpdatePaymentMethodRegistration(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    paymentInitiationPartyId string,
    paymentMethodRegistrationId string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.PaymentInitiationPartyToPaymentMethodEntity) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `string` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `paymentMethodRegistrationId` | `string` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

paymentInitiationPartyId := "paymentInitiationPartyId8"

paymentMethodRegistrationId := "paymentMethodRegistrationId4"

fdxApiActorType := models.FdxApiActorType_Batch



resp, err := paymentInitiationPartiesController.UpdatePaymentMethodRegistration(ctx, xFapiInteractionId, paymentInitiationPartyId, paymentMethodRegistrationId, &fdxApiActorType, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

