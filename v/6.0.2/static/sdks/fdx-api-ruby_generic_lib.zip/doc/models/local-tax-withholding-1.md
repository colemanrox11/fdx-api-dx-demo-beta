
# Local Tax Withholding 1

Amount of local income tax withheld, if any

*This model accepts additional fields of type Object.*

## Structure

`LocalTaxWithholding1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_withheld` | `Float` | Optional | Amount of local income tax withheld |
| `locality_name` | `String` | Optional | Locality name |
| `income` | `Float` | Optional | Income amount for local tax purposes |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 15.4,
  "localityName": "localityName2",
  "income": 207.06,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

