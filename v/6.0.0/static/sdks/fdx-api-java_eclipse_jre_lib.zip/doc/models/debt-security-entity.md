
# Debt Security Entity

An investment in a debt security

*This model accepts additional fields of type Object.*

## Structure

`DebtSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParValue` | `Double` | Optional | Par value amount | Double getParValue() | setParValue(Double parValue) |
| `DebtType` | [`DebtType2`](../../doc/models/debt-type-2.md) | Optional | Debt type. One of COUPON, ZERO | DebtType2 getDebtType() | setDebtType(DebtType2 debtType) |
| `DebtClass` | [`DebtClass2`](../../doc/models/debt-class-2.md) | Optional | Classification of debt. One of TREASURY, MUNICIPAL, CORPORATE, OTHER | DebtClass2 getDebtClass() | setDebtClass(DebtClass2 debtClass) |
| `CouponRate` | `Double` | Optional | Bond coupon rate for next closest call date | Double getCouponRate() | setCouponRate(Double couponRate) |
| `CouponDate` | `LocalDate` | Optional | Maturity date for next coupon | LocalDate getCouponDate() | setCouponDate(LocalDate couponDate) |
| `CouponMatureFrequency` | [`CouponMatureFrequency2`](../../doc/models/coupon-mature-frequency-2.md) | Optional | When coupons mature. One of MONTHLY, QUARTERLY,  SEMIANNUAL, ANNUAL, OTHER | CouponMatureFrequency2 getCouponMatureFrequency() | setCouponMatureFrequency(CouponMatureFrequency2 couponMatureFrequency) |
| `CallPrice` | `Double` | Optional | Bond call price | Double getCallPrice() | setCallPrice(Double callPrice) |
| `YieldToCall` | `Double` | Optional | Yield to next call | Double getYieldToCall() | setYieldToCall(Double yieldToCall) |
| `CallDate` | `LocalDate` | Optional | Next call date | LocalDate getCallDate() | setCallDate(LocalDate callDate) |
| `CallType` | [`CallType2`](../../doc/models/call-type-2.md) | Optional | Type of next call. One of CALL, PUT, PREFUND, MATURITY | CallType2 getCallType() | setCallType(CallType2 callType) |
| `YieldToMaturity` | `Double` | Optional | Yield to maturity | Double getYieldToMaturity() | setYieldToMaturity(Double yieldToMaturity) |
| `BondMaturityDate` | `LocalDate` | Optional | Bond maturity date | LocalDate getBondMaturityDate() | setBondMaturityDate(LocalDate bondMaturityDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "couponDate": "2021-07-15",
  "callDate": "2021-07-15",
  "bondMaturityDate": "2021-07-15",
  "securityCategory": "Debt Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parValue": 174.38,
  "debtType": "COUPON",
  "debtClass": "OTHER",
  "couponRate": 72.78
}
```

