
# Portion Entity

An asset allocation with class and percentage

*This model accepts additional fields of type Object.*

## Structure

`PortionEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetClass` | [`AssetClass2`](../../doc/models/asset-class-2.md) | Optional | The asset class for this allocation | AssetClass2 getAssetClass() | setAssetClass(AssetClass2 assetClass) |
| `Percent` | `Double` | Optional | The percentage of this allocation | Double getPercent() | setPercent(Double percent) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "assetClass": "MONEYMARKET",
  "percent": 142.7,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

