
# Consent Grant Status 1

The status of the consent = REVOKED

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentGrantStatus1`

## Fields

| Name |
|  --- |
| `Active` |
| `Expired` |
| `Revoked` |

