
# Form W2

Wage and Tax Statement, from Employer (boxes b-c as issuer) to Employee (boxes a, e-f as recipient)

*This model accepts additional fields of type Object.*

## Structure

`FormW2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxYear` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | Integer getTaxYear() | setTaxYear(Integer taxYear) |
| `Corrected` | `Boolean` | Optional | True to indicate this is a corrected tax form | Boolean getCorrected() | setCorrected(Boolean corrected) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the source account. Not the account number<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `TaxFormId` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted.<br><br>**Constraints**: *Maximum Length*: `256` | String getTaxFormId() | setTaxFormId(String taxFormId) |
| `TaxFormDate` | `LocalDate` | Optional | Date of production or delivery of the tax form | LocalDate getTaxFormDate() | setTaxFormDate(LocalDate taxFormDate) |
| `AdditionalInformation` | `String` | Optional | Additional explanation text or content about this tax form | String getAdditionalInformation() | setAdditionalInformation(String additionalInformation) |
| `TaxFormType` | [`TypeFormType1`](../../doc/models/type-form-type-1.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | TypeFormType1 getTaxFormType() | setTaxFormType(TypeFormType1 taxFormType) |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty8 getIssuer() | setIssuer(TaxParty8 issuer) |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty1 getRecipient() | setRecipient(TaxParty1 recipient) |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | List<TaxFormAttribute> getAttributes() | setAttributes(List<TaxFormAttribute> attributes) |
| `Error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this form | Error1 getError() | setError(Error1 error) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `ControlNumber` | `String` | Optional | Control number | String getControlNumber() | setControlNumber(String controlNumber) |
| `Wages` | `Double` | Optional | Box 1, Wages, tips, other compensation | Double getWages() | setWages(Double wages) |
| `FederalTaxWithheld` | `Double` | Optional | Box 2, Federal income tax withheld | Double getFederalTaxWithheld() | setFederalTaxWithheld(Double federalTaxWithheld) |
| `SocialSecurityWages` | `Double` | Optional | Box 3, Social security wages | Double getSocialSecurityWages() | setSocialSecurityWages(Double socialSecurityWages) |
| `SocialSecurityTaxWithheld` | `Double` | Optional | Box 4, Social security tax withheld | Double getSocialSecurityTaxWithheld() | setSocialSecurityTaxWithheld(Double socialSecurityTaxWithheld) |
| `MedicareWages` | `Double` | Optional | Box 5, Medicare wages and tips | Double getMedicareWages() | setMedicareWages(Double medicareWages) |
| `MedicareTaxWithheld` | `Double` | Optional | Box 6, Medicare tax withheld | Double getMedicareTaxWithheld() | setMedicareTaxWithheld(Double medicareTaxWithheld) |
| `SocialSecurityTips` | `Double` | Optional | Box 7, Social security tips | Double getSocialSecurityTips() | setSocialSecurityTips(Double socialSecurityTips) |
| `AllocatedTips` | `Double` | Optional | Box 8, Allocated tips | Double getAllocatedTips() | setAllocatedTips(Double allocatedTips) |
| `DependentCareBenefit` | `Double` | Optional | Box 10, Dependent care benefits | Double getDependentCareBenefit() | setDependentCareBenefit(Double dependentCareBenefit) |
| `NonQualifiedPlan` | `Double` | Optional | Box 11, Nonqualified plans | Double getNonQualifiedPlan() | setNonQualifiedPlan(Double nonQualifiedPlan) |
| `Codes` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Box 12, Codes and amounts | List<CodeAndAmount> getCodes() | setCodes(List<CodeAndAmount> codes) |
| `Statutory` | `Boolean` | Optional | Box 13, Statutory employee | Boolean getStatutory() | setStatutory(Boolean statutory) |
| `RetirementPlan` | `Boolean` | Optional | Box 13, Retirement plan | Boolean getRetirementPlan() | setRetirementPlan(Boolean retirementPlan) |
| `ThirdPartySickPay` | `Boolean` | Optional | Box 13, Third-party sick pay | Boolean getThirdPartySickPay() | setThirdPartySickPay(Boolean thirdPartySickPay) |
| `EsppQualified` | `Double` | Optional | Employee Stock Purchase Plan Qualified Disposition amount | Double getEsppQualified() | setEsppQualified(Double esppQualified) |
| `EsppNonQualified` | `Double` | Optional | Employee Stock Purchase Plan Nonqualified Disposition amount | Double getEsppNonQualified() | setEsppNonQualified(Double esppNonQualified) |
| `Other` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Box 14, Other descriptions and amounts | List<DescriptionAndAmount> getOther() | setOther(List<DescriptionAndAmount> other) |
| `StateAndLocal` | [`List<StateAndLocalTaxWithholding>`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 15-20, State and Local tax withholding | List<StateAndLocalTaxWithholding> getStateAndLocal() | setStateAndLocal(List<StateAndLocalTaxWithholding> stateAndLocal) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId4",
  "taxFormId": "taxFormId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

