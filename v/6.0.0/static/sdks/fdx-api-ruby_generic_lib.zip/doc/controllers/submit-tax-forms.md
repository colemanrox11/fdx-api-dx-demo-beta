# Submit Tax Forms

```ruby
submit_tax_forms_controller = client.submit_tax_forms
```

## Class Name

`SubmitTaxFormsController`

## Methods

* [Create Tax Form](../../doc/controllers/submit-tax-forms.md#create-tax-form)
* [Update Tax Form](../../doc/controllers/submit-tax-forms.md#update-tax-form)


# Create Tax Form

Submit the data for a specific tax document

```ruby
def create_tax_form(authorization,
                    x_fapi_interaction_id,
                    fdx_api_actor_type: nil,
                    body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`TaxStatement1`](../../doc/models/tax-statement-1.md) | Body, Optional | - |

## Server

`Server::USTAX`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TaxStatement2`](../../doc/models/tax-statement-2.md).

## Example Usage

```ruby
authorization = 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw'

x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

body = TaxStatement1.new(
  tax_year: 2023
)

result = submit_tax_forms_controller.create_tax_form(
  authorization,
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Tax Form type is not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Tax Form

Update tax document. Allows you to upload and replace binaries or json document

```ruby
def update_tax_form(tax_form_id,
                    authorization,
                    x_fapi_interaction_id,
                    fdx_api_actor_type: nil,
                    body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_form_id` | `String` | Template, Required | The unique ID for this tax form or tax statement<br><br>**Constraints**: *Maximum Length*: `256` |
| `authorization` | `String` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`TaxStatement6`](../../doc/models/tax-statement-6.md) | Body, Optional | - |

## Server

`Server::USTAX`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
tax_form_id = 'taxFormId2'

authorization = 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw'

x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

body = TaxStatement6.new(
  tax_year: 2023
)

result = submit_tax_forms_controller.update_tax_form(
  tax_form_id,
  authorization,
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 415 | Server does not support the content type uploaded | [`ErrorException`](../../doc/models/error-exception.md) |

