
# Consent Revocation Request Entity

Details of request to revoke consent grant

*This model accepts additional fields of type Object.*

## Structure

`ConsentRevocationRequestEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reason` | [`ConsentUpdateReason1`](../../doc/models/consent-update-reason-1.md) | Optional | The reason for consent revocation |
| `initiator` | [`PartyType2`](../../doc/models/party-type-2.md) | Optional | The party initiating revocation |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "reason": "BUSINESS_RULE",
  "initiator": "MERCHANT",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

