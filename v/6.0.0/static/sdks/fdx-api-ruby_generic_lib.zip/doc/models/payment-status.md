
# Payment Status

Defines the payment lifecycle.

* `CANCELLED`: Payment was cancelled by the user
* `FAILED`: Payment failed for reasons other than "No Funds"
  For example: fraud, invalid payee, source account was closed etc.
* `NOFUNDS`: Payment failed because of the lack of funds
* `PROCESSED`: The payment has been executed by the payment service provider
* `PROCESSING`: Payment is in the process of being executed by the payment service provider
* `SCHEDULED`: Payment has been scheduled

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentStatus`

## Fields

| Name |
|  --- |
| `CANCELLED` |
| `FAILED` |
| `NOFUNDS` |
| `PROCESSED` |
| `PROCESSING` |
| `SCHEDULED` |

