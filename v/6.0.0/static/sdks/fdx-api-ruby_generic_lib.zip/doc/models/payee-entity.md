
# Payee Entity

Payee to whom funds can be transferred. Can be extended to support additional types of payees

*This model accepts additional fields of type Object.*

## Structure

`PayeeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `merchant` | [`MerchantEntity1`](../../doc/models/merchant-entity-1.md) | Required | When payee is a merchant, typically a business from which goods or services are rendered, this field will be populated |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "merchant": {
    "status": "ACTIVE",
    "expiresTimestamp": "07/15/2021 14:46:41",
    "displayName": "displayName2",
    "name": {
      "first": "first6",
      "middle": "middle6",
      "last": "last0",
      "suffix": "suffix0",
      "prefix": "prefix8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "address": {
      "line1": "line18",
      "line2": "line20",
      "line3": "line38",
      "city": "city6",
      "region": "region2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "phone": {
      "type": "BUSINESS",
      "country": "country4",
      "number": "number8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "merchantAccountIds": [
      "merchantAccountIds6"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

