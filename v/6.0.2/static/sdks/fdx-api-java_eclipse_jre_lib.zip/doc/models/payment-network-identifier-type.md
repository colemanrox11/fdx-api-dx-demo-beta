
# Payment Network Identifier Type

Suggested values for Payment Initiation Identifier Type

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentNetworkIdentifierType`

## Fields

| Name |
|  --- |
| `AccountNumber` |
| `TokenizedAccountNumber` |

