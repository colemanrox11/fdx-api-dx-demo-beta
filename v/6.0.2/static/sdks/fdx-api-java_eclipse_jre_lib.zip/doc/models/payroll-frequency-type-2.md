
# Payroll Frequency Type 2

The frequency of payments

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollFrequencyType2`

## Fields

| Name |
|  --- |
| `Annually` |
| `BiWeekly` |
| `Daily` |
| `Every26Weeks` |
| `Every4Weeks` |
| `Every52Weeks` |
| `Monthly` |
| `Quarterly` |
| `SemiAnnually` |
| `SemiMonthly` |
| `Weekly` |

