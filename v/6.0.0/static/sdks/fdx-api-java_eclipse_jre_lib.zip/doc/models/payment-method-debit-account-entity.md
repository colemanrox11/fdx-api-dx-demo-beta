
# Payment Method Debit Account Entity

A payment initiation party's payment method that debits an account

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodDebitAccountEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountRegistrationId` | `String` | Optional | Unique identifier of the registration of the sending account to the<br>payment method associated with a particular payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountRegistrationId() | setAccountRegistrationId(String accountRegistrationId) |
| `SendingAccount` | [`PaymentGenericAccountEntity2`](../../doc/models/payment-generic-account-entity-2.md) | Optional | Sending account details | PaymentGenericAccountEntity2 getSendingAccount() | setSendingAccount(PaymentGenericAccountEntity2 sendingAccount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountRegistrationId": "accountRegistrationId0",
  "sendingAccount": {
    "accountNumber": "accountNumber0",
    "accountType": "ROLLOVER",
    "name": "name2",
    "currencyCode": "VUV",
    "id": {
      "iban2007Id": "iban2007Id4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

