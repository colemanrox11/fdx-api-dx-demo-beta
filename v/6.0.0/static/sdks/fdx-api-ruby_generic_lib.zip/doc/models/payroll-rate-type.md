
# Payroll Rate Type

Specifies whether the employee's pay is ANNUAL, DAILY, HOURLY, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollRateType`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `DAILY` |
| `HOURLY` |
| `OTHER` |

