
# Payment Entity Error Exception

Represents a payment

*This model accepts additional fields of type Object.*

## Structure

`PaymentEntityErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `from_account_id` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `to_payee_id` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `amount` | `Float` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` |
| `merchant_account_id` | `String` | Optional | User's account identifier with the merchant |
| `due_date` | `Date` | Required | Date that the funds are scheduled to be delivered |
| `payment_id` | `String` | Required | Uniquely identifies a payment. Used within the API to reference a payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `recurring_payment_id` | `String` | Optional | The recurring payment that spawned this payment. Null if payment is not associated with a recurring payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `scheduled_timestamp` | `DateTime` | Optional | When the payment was scheduled |
| `processed_timestamp` | `DateTime` | Optional | When the payment was processed |
| `failed_timestamp` | `DateTime` | Optional | When the payment failed. Includes when the payment was determined to lack sufficient funds |
| `cancelled_timestamp` | `DateTime` | Optional | When the payment was cancelled |
| `started_processing_timestamp` | `DateTime` | Optional | When the payment execution started |
| `status` | [`PaymentStatus3`](../../doc/models/payment-status-3.md) | Required | Defines the status of the payment |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to related payment entities |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "fromAccountId": "fromAccountId0",
  "toPayeeId": "toPayeeId4",
  "amount": 117.88,
  "dueDate": "2021-07-15",
  "paymentId": "paymentId8",
  "scheduledTimestamp": "07/15/2021 14:46:41",
  "processedTimestamp": "07/15/2021 14:46:41",
  "failedTimestamp": "07/15/2021 14:46:41",
  "cancelledTimestamp": "07/15/2021 14:46:41",
  "startedProcessingTimestamp": "07/15/2021 14:46:41",
  "status": "NOFUNDS",
  "merchantAccountId": "merchantAccountId4",
  "recurringPaymentId": "recurringPaymentId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

