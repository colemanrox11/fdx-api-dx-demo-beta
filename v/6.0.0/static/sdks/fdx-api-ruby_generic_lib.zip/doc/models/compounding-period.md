
# Compounding Period

Interest compounding Period

*This model accepts additional fields of type Object.*

## Enumeration

`CompoundingPeriod`

## Fields

| Name |
|  --- |
| `ANNUALLY` |
| `BIWEEKLY` |
| `DAILY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `SEMIMONTHLY` |
| `WEEKLY` |

