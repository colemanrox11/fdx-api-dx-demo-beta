
# Synchronizable Array Links Entity

Resource URLs for retrieving changes, next or previous datasets

*This model accepts additional fields of type Object.*

## Structure

`SynchronizableArrayLinksEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Next` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Resource URL for retrieving next dataset | HateoasLink getNext() | setNext(HateoasLink next) |
| `Prev` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Resource URL for retrieving previous dataset | HateoasLink getPrev() | setPrev(HateoasLink prev) |
| `Updates` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Resource URL for retrieving updates since last request | HateoasLink getUpdates() | setUpdates(HateoasLink updates) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "next": {
    "href": "href4",
    "action": "DELETE",
    "rel": "rel8",
    "types": [
      "image/png"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "prev": {
    "href": "href8",
    "action": "GET",
    "rel": "rel2",
    "types": [
      "image/tiff"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "updates": {
    "href": "href2",
    "action": "PATCH",
    "rel": "rel6",
    "types": [
      "image/jpeg"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

