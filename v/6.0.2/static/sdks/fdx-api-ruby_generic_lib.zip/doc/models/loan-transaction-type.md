
# Loan Transaction Type

Defines the type of a loan transaction:

* `ADJUSTMENT`: Adjustment or correction
* `DOUBLE_UP_PAYMENT`: Additional payment beyond the required payment to reduce the principal
* `FEE`: Fee charge. For example, a late payment fee
* `INTEREST`: Interest charge
* `LUMP_SUM_PAYMENT`: A single payment of money, as opposed to a series of payments made over time
* `PAYMENT`: Required payment that satisfies the minimum payment (e.g. principal + interest for mortgages)
* `PAYOFF`: Payment that satisfies the terms of the mortgage loan and completely pays off the debt
* `SKIP_PAYMENT`: Payment that satisfies deferral of a required payment

*This model accepts additional fields of type Object.*

## Enumeration

`LoanTransactionType`

## Fields

| Name |
|  --- |
| `ADJUSTMENT` |
| `DOUBLE_UP_PAYMENT` |
| `FEE` |
| `INTEREST` |
| `LUMP_SUM_PAYMENT` |
| `PAYMENT` |
| `PAYOFF` |
| `SKIP_PAYMENT` |

