# Account Information

```java
AccountInformationController accountInformationController = client.getAccountInformationController();
```

## Class Name

`AccountInformationController`

## Methods

* [Search for Accounts](../../doc/controllers/account-information.md#search-for-accounts)
* [Get Account](../../doc/controllers/account-information.md#get-account)


# Search for Accounts

Return information for all of the customer's consented accounts or just those accounts identified in the `accountIds` request parameter. Use `ResultTypeQuery` parameter value of `lightweight` to retrieve minimal descriptive information and the `accountId` for each account. The `accountId` can then be used in the `getAccount` operation's path `/accounts/{accountId}` to retrieve full details about each account

```java
CompletableFuture<ApiResponse<AccountsEntity>> searchForAccountsAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final List<String> accountIds,
    final List<LocalDate> startTime,
    final List<LocalDate> endTime,
    final ResultType resultType,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `accountIds` | `List<String>` | Query, Optional | Comma separated list of account ids |
| `startTime` | `List<LocalDate>` | Query, Optional | Start time for use in retrieval of transactions |
| `endTime` | `List<LocalDate>` | Query, Optional | End time for use in retrieval of transactions |
| `resultType` | [`ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `ResultType.LIGHTWEIGHT` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`AccountsEntity`](../../doc/models/accounts-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
ResultType resultType = ResultType.LIGHTWEIGHT;

accountInformationController.searchForAccountsAsync(xFapiInteractionId, fdxApiActorType, null, null, null, resultType, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "2",
    "total": 3
  },
  "links": {
    "next": {
      "href": "/accounts?offSet=2&limit=10"
    }
  },
  "accounts": [
    {
      "accountCategory": "DEPOSIT_ACCOUNT",
      "accountId": "10001",
      "nickname": "My Checking Acc XXXX3223",
      "status": "OPEN",
      "balanceAsOf": "2017-11-05T13:15:30.751Z",
      "currentBalance": 13300.35,
      "openingDayBalance": 500
    },
    {
      "accountCategory": "DEPOSIT_ACCOUNT",
      "accountId": "10002",
      "nickname": "My Checking Acc XXXX4443",
      "status": "OPEN",
      "balanceAsOf": "2017-11-05T13:15:30.751Z",
      "currentBalance": 332.22,
      "openingDayBalance": 100.0
    },
    {
      "accountCategory": "LOAN_ACCOUNT",
      "accountId": "20001",
      "nickname": "My Mortgage Acc XXXX9979",
      "status": "OPEN",
      "balanceAsOf": "2017-11-05T13:15:30.751Z",
      "principalBalance": 133000.35,
      "loanTerm": 30,
      "nextPaymentDate": "2017-12-01",
      "nextPaymentAmount": 2333.32
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Account

Retrieve full details about the account identified by `{accountId}` parameter

```java
CompletableFuture<ApiResponse<AccountWithDetails>> getAccountAsync(
    final UUID xFapiInteractionId,
    final String accountId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `String` | Template, Required | Account Identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `AccountWithDetails`.

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String accountId = "accountId0";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

accountInformationController.getAccountAsync(xFapiInteractionId, accountId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    result.getResult().match(new AccountWithDetails.Cases<Void>() {
        @Override
        public Void annuityAccountEntity(AnnuityAccountEntity annuityAccountEntity) {
            System.out.println(annuityAccountEntity);
            return null;
        }

        @Override
        public Void commercialAccountEntity(CommercialAccountEntity commercialAccountEntity) {
            System.out.println(commercialAccountEntity);
            return null;
        }

        @Override
        public Void depositAccountEntity(DepositAccountEntity depositAccountEntity) {
            System.out.println(depositAccountEntity);
            return null;
        }

        @Override
        public Void digitalWalletAccountEntity(DigitalWalletAccountEntity digitalWalletAccountEntity) {
            System.out.println(digitalWalletAccountEntity);
            return null;
        }

        @Override
        public Void insuranceAccountEntity(InsuranceAccountEntity insuranceAccountEntity) {
            System.out.println(insuranceAccountEntity);
            return null;
        }

        @Override
        public Void investmentAccountEntity(InvestmentAccountEntity investmentAccountEntity) {
            System.out.println(investmentAccountEntity);
            return null;
        }

        @Override
        public Void lineOfCreditAccountEntity(LineOfCreditAccountEntity lineOfCreditAccountEntity) {
            System.out.println(lineOfCreditAccountEntity);
            return null;
        }

        @Override
        public Void loanAccountEntity(LoanAccountEntity loanAccountEntity) {
            System.out.println(loanAccountEntity);
            return null;
        }
    });
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response

```
{
  "accountCategory": "LOAN_ACCOUNT",
  "accountId": "12345678",
  "accountType": "LOAN",
  "displayName": "XXXXX4567",
  "status": "OPEN",
  "description": "30 Year Mortgage",
  "nickname": "My Home Mortgage",
  "currency": {
    "currencyCode": "USD"
  },
  "interestRate": 4,
  "loanTerm": 0,
  "totalNumberOfPayments": 0
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

