# Personal Information

```ruby
personal_information_controller = client.personal_information
```

## Class Name

`PersonalInformationController`

## Methods

* [Get Account Contact](../../doc/controllers/personal-information.md#get-account-contact)
* [Get Customers](../../doc/controllers/personal-information.md#get-customers)
* [Get Customer Info](../../doc/controllers/personal-information.md#get-customer-info)
* [Get Customer](../../doc/controllers/personal-information.md#get-customer)


# Get Account Contact

Get contact information on the account

```ruby
def get_account_contact(x_fapi_interaction_id,
                        account_id,
                        fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `account_id` | `String` | Template, Required | Account Identifier |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`AccountContactEntity`](../../doc/models/account-contact-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

account_id = 'accountId0'

fdx_api_actor_type = FdxApiActorType::BATCH

result = personal_information_controller.get_account_contact(
  x_fapi_interaction_id,
  account_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Customers

Retrieve account holders related to permissioned accounts

```ruby
def get_customers(x_fapi_interaction_id,
                  fdx_api_actor_type: nil,
                  offset: nil,
                  limit: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server::CUSTOMER`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`CustomersEntity`](../../doc/models/customers-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = personal_information_controller.get_customers(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get Customer Info

Get information about the customer within the authorization scope

```ruby
def get_customer_info(x_fapi_interaction_id,
                      fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::CUSTOMER`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`CustomerEntity`](../../doc/models/customer-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = personal_information_controller.get_customer_info(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```


# Get Customer

Retrieve customer information by customer id

```ruby
def get_customer(x_fapi_interaction_id,
                 customer_id,
                 fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `customer_id` | `String` | Template, Required | Customer Identifier |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::CUSTOMER`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`CustomerEntity`](../../doc/models/customer-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

customer_id = 'customerId6'

fdx_api_actor_type = FdxApiActorType::BATCH

result = personal_information_controller.get_customer(
  x_fapi_interaction_id,
  customer_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Customer with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

