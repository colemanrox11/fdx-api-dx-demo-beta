
# Payment Method Entity 2

Payment method details

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodEntity2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentMethodId` | `String` | Optional | Unique identifier of the payment method | String getPaymentMethodId() | setPaymentMethodId(String paymentMethodId) |
| `ExternalLocalInstrument1Code` | `String` | Optional | Unique identifier code of the payment method rail as documented<br>internally to the FI. This is aligned with ISO 20022 pain.001,<br>transaction level | String getExternalLocalInstrument1Code() | setExternalLocalInstrument1Code(String externalLocalInstrument1Code) |
| `ExternalClearingSystemIdentification1Code` | `String` | Optional | Unique identifier code of the external clearing system.<br>This is aligned with ISO 20022 pacs.008 group level. It can be<br>used to send the payment rail for the payment. ISO has already<br>listed codes in the fields which indicates the payment rail like<br>"ACH" for ACH, "ACS" for EFT Payments, "LVT" for Canada LVTS,<br>"LYX" for Lynx Canada, etc. | String getExternalClearingSystemIdentification1Code() | setExternalClearingSystemIdentification1Code(String externalClearingSystemIdentification1Code) |
| `ExternalClearingSystemIdentification1Proprietary` | `String` | Optional | For few examples where the payment rail is not part of the ISO 20022 scope | String getExternalClearingSystemIdentification1Proprietary() | setExternalClearingSystemIdentification1Proprietary(String externalClearingSystemIdentification1Proprietary) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "paymentMethodId": "paymentMethodId6",
  "externalLocalInstrument1Code": "externalLocalInstrument1Code2",
  "externalClearingSystemIdentification1Code": "externalClearingSystemIdentification1Code4",
  "externalClearingSystemIdentification1Proprietary": "externalClearingSystemIdentification1Proprietary2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

