
# Loan Payment Frequency

The frequency of payments on a loan

*This model accepts additional fields of type Object.*

## Enumeration

`LoanPaymentFrequency`

## Fields

| Name |
|  --- |
| `Annually` |
| `Bimonthly` |
| `Biweekly` |
| `Fourweeks` |
| `Monthly` |
| `Other` |
| `Quarterly` |
| `Semiannually` |
| `Twicemonthly` |
| `Weekly` |

