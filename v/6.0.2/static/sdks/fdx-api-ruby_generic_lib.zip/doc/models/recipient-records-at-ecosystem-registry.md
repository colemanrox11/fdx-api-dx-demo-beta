
# Recipient Records at Ecosystem Registry

Recipient records at Ecosystem Registry. Properties in this structure use 'snake_case' names to match the properties in [IETF RFC 7591](https://datatracker.ietf.org/doc/rfc7591/).

*This model accepts additional fields of type Object.*

## Structure

`RecipientRecordsAtEcosystemRegistry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets |
| `links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets |
| `recipients` | [`Array<RecipientRecordAtEcosystemRegistry>`](../../doc/models/recipient-record-at-ecosystem-registry.md) | Required | Recipients retrieved by the operation |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "recipients": [
    {
      "client_name": "client_name0",
      "description": "description6",
      "redirect_uris": [
        "redirect_uris9"
      ],
      "logo_uri": "logo_uri2",
      "client_uri": "client_uri4",
      "contacts": [
        "contacts3"
      ],
      "scope": "scope6",
      "recipient_id": "recipient_id4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

