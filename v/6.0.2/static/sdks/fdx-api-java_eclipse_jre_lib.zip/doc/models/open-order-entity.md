
# Open Order Entity

An open investment transaction order

*This model accepts additional fields of type Object.*

## Structure

`OpenOrderEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `OrderId` | `String` | Optional | Long-term persistent identity of the order. Id for this order transaction<br><br>**Constraints**: *Maximum Length*: `256` | String getOrderId() | setOrderId(String orderId) |
| `SecurityId` | `String` | Optional | Unique identifier of security | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | [`SecurityIdType1`](../../doc/models/security-id-type-1.md) | Optional | CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN | SecurityIdType1 getSecurityIdType() | setSecurityIdType(SecurityIdType1 securityIdType) |
| `Symbol` | `String` | Optional | Market symbol | String getSymbol() | setSymbol(String symbol) |
| `Description` | `String` | Optional | Description of order | String getDescription() | setDescription(String description) |
| `Units` | `Double` | Optional | Number of units (shares or bonds etc.) | Double getUnits() | setUnits(Double units) |
| `OrderType` | [`OrderType2`](../../doc/models/order-type-2.md) | Optional | Type of order. One of BUY, SELL, BUYTOCOVER, BUYTOOPEN, SELLTOCOVER, SELLTOOPEN,  SELLSHORT, SELLCLOSE | OrderType2 getOrderType() | setOrderType(OrderType2 orderType) |
| `OrderDate` | `LocalDate` | Optional | Order date | LocalDate getOrderDate() | setOrderDate(LocalDate orderDate) |
| `UnitPrice` | `Double` | Optional | Unit price | Double getUnitPrice() | setUnitPrice(Double unitPrice) |
| `UnitType` | [`UnitType3`](../../doc/models/unit-type-3.md) | Optional | Type of unit. One of SHARES, CURRENCY | UnitType3 getUnitType() | setUnitType(UnitType3 unitType) |
| `OrderDuration` | [`OrderDuration2`](../../doc/models/order-duration-2.md) | Optional | This order is good for DAY, GOODTILLCANCEL, IMMEDIATE | OrderDuration2 getOrderDuration() | setOrderDuration(OrderDuration2 orderDuration) |
| `SubAccount` | [`SubAccountType4`](../../doc/models/sub-account-type-4.md) | Optional | CASH, MARGIN, SHORT, OTHER | SubAccountType4 getSubAccount() | setSubAccount(SubAccountType4 subAccount) |
| `LimitPrice` | `Double` | Optional | Limit price | Double getLimitPrice() | setLimitPrice(Double limitPrice) |
| `StopPrice` | `Double` | Optional | Stop price | Double getStopPrice() | setStopPrice(Double stopPrice) |
| `Inv401KSource` | [`Investment401KSourceType1`](../../doc/models/investment-401-k-source-type-1.md) | Optional | For 401(k) accounts, source of money for this order. PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST. Default if not present is OTHERNONVEST | Investment401KSourceType1 getInv401KSource() | setInv401KSource(Investment401KSourceType1 inv401KSource) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "orderDate": "2021-07-15",
  "orderId": "orderId6",
  "securityId": "securityId8",
  "securityIdType": "SEDOL",
  "symbol": "symbol2",
  "description": "description4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

