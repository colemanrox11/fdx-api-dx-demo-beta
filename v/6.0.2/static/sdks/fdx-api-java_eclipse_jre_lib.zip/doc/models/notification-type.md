
# Notification Type

Type of notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationType`

## Fields

| Name |
|  --- |
| `Balance` |
| `ConsentRevoked` |
| `ConsentUpdated` |
| `Custom` |
| `PlannedOutage` |
| `Risk` |
| `Service` |

