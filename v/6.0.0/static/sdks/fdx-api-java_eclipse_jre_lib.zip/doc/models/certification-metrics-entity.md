
# Certification Metrics Entity

Response object for /certification-metrics API

*This model accepts additional fields of type Object.*

## Structure

`CertificationMetricsEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Metrics` | [`List<CertificationMetricEntity>`](../../doc/models/certification-metric-entity.md) | Optional | Zero or more certification performance metrics | List<CertificationMetricEntity> getMetrics() | setMetrics(List<CertificationMetricEntity> metrics) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "metrics": [
    {
      "reportStartTimestamp": "2016-03-13T12:52:32.123Z",
      "reportEndTimestamp": "2016-03-13T12:52:32.123Z",
      "metricsName": "metricsName2",
      "operationIds": [
        "getRecipient",
        "deleteRecipient",
        "createRecipient"
      ],
      "responseTimeAverage": 109.04,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "reportStartTimestamp": "2016-03-13T12:52:32.123Z",
      "reportEndTimestamp": "2016-03-13T12:52:32.123Z",
      "metricsName": "metricsName2",
      "operationIds": [
        "getRecipient",
        "deleteRecipient",
        "createRecipient"
      ],
      "responseTimeAverage": 109.04,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

