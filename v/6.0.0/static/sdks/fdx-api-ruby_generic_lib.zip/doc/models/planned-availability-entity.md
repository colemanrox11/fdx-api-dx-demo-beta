
# Planned Availability Entity

Provider's plan for API availability

*This model accepts additional fields of type Object.*

## Structure

`PlannedAvailabilityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`AvailabilityStatus1`](../../doc/models/availability-status-1.md) | Optional | API availability status for this time period |
| `description` | `String` | Optional | Description of API availability status |
| `start_time` | `DateTime` | Optional | Start time for this status period |
| `end_time` | `DateTime` | Optional | End time for this status period |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "startTime": "07/15/2021 14:46:41",
  "endTime": "07/15/2021 14:46:41",
  "status": "ALIVE",
  "description": "description0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

