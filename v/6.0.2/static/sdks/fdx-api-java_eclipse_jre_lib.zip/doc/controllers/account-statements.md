# Account Statements

```java
AccountStatementsController accountStatementsController = client.getAccountStatementsController();
```

## Class Name

`AccountStatementsController`

## Methods

* [Search for Account Statements](../../doc/controllers/account-statements.md#search-for-account-statements)
* [Get Account Statement](../../doc/controllers/account-statements.md#get-account-statement)


# Search for Account Statements

Get account statements. Example: GET /accounts/{accountId}/statements?startTime=value1&endTime=value2

```java
CompletableFuture<ApiResponse<AnArrayOfStatements>> searchForAccountStatementsAsync(
    final UUID xFapiInteractionId,
    final String accountId,
    final FdxApiActorType fdxApiActorType,
    final LocalDate startTime,
    final LocalDate endTime,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `String` | Template, Required | Account Identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `startTime` | `LocalDate` | Query, Optional | Start time for use in retrieval of elements (ISO 8601) |
| `endTime` | `LocalDate` | Query, Optional | End time for use in retrieval of elements (ISO 8601) |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`AnArrayOfStatements`](../../doc/models/an-array-of-statements.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String accountId = "accountId0";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
LocalDate startTime = DateTimeHelper.fromSimpleDate("2021-07-15");
LocalDate endTime = DateTimeHelper.fromSimpleDate("2021-07-15");

accountStatementsController.searchForAccountStatementsAsync(xFapiInteractionId, accountId, fdxApiActorType, startTime, endTime, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "2",
    "total": 3
  },
  "links": {
    "next": {
      "href": "/accounts/1111/statements?offSet=2&limit=10"
    }
  },
  "statements": [
    {
      "accountId": "10001",
      "statementId": "40004"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Account Statement

Gets an account statement image file. Use [HTTP Accept request-header](https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html) to specify desired content types. See ContentTypes definition for typical values

```java
CompletableFuture<ApiResponse<DynamicResponse>> getAccountStatementAsync(
    final UUID xFapiInteractionId,
    final String accountId,
    final String statementId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `String` | Template, Required | Account Identifier |
| `statementId` | `String` | Template, Required | Statement Identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type `DynamicResponse`.

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String accountId = "accountId0";
String statementId = "statementId6";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

accountStatementsController.getAccountStatementAsync(xFapiInteractionId, accountId, statementId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Statement is processing and is not yet available | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | When account is present with no statements in it | [`ErrorException`](../../doc/models/error-exception.md) |
| 406 | Content Type not Supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

