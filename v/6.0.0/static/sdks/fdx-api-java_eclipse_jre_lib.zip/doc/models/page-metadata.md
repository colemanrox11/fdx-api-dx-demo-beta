
# Page Metadata

Offset IDs for navigating result sets

*This model accepts additional fields of type Object.*

## Structure

`PageMetadata`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextOffset` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific | String getNextOffset() | setNextOffset(String nextOffset) |
| `PrevOffset` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific | String getPrevOffset() | setPrevOffset(String prevOffset) |
| `TotalElements` | `Integer` | Optional | Total number of elements | Integer getTotalElements() | setTotalElements(Integer totalElements) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "nextOffset": "2",
  "prevOffset": "1",
  "totalElements": 3,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

