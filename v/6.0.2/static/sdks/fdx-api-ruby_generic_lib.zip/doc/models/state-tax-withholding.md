
# State Tax Withholding

Income in a state and its tax withholding

*This model accepts additional fields of type Object.*

## Structure

`StateTaxWithholding`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `tax_withheld` | `Float` | Optional | Amount of state income tax withheld |
| `tax_id` | `String` | Optional | Filer's state tax id |
| `income` | `Float` | Optional | Income amount for state tax purposes |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "taxWithheld": 48.38,
  "taxId": "taxId0",
  "income": 15.96,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

