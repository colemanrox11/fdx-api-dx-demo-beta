
# Payment Method Id

FI's unique identifier for the method of payment

*This model accepts additional fields of type Object.*

## Structure

`PaymentMethodId`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PaymentMethodId` | `String` | Optional | Unique identifier of the payment method | String getPaymentMethodId() | setPaymentMethodId(String paymentMethodId) |
| `ExternalLocalInstrument1Code` | `String` | Optional | Unique identifier code of the payment method rail as documented<br>internally to the FI. This is aligned with ISO 20022 pain.001,<br>transaction level | String getExternalLocalInstrument1Code() | setExternalLocalInstrument1Code(String externalLocalInstrument1Code) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "paymentMethodId": "paymentMethodId8",
  "externalLocalInstrument1Code": "externalLocalInstrument1Code4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

