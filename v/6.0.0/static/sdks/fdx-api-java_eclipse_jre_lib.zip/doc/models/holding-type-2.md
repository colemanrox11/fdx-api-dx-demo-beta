
# Holding Type 2

ANNUITY, BOND, CD, DIGITALASSET, MUTUALFUND, OPTION, OTHER, STOCK

*This model accepts additional fields of type Object.*

## Enumeration

`HoldingType2`

## Fields

| Name |
|  --- |
| `Annuity` |
| `Bond` |
| `Cd` |
| `Digitalasset` |
| `Mutualfund` |
| `Option` |
| `Other` |
| `Stock` |

