
# Merchant for Update Entity

Merchant's fields to be updated. Describes the fields that can be updated by the client. Supported fields could be server dependent

*This model accepts additional fields of type Object.*

## Structure

`MerchantForUpdateEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DisplayName` | `String` | Optional | User defined name for the merchant. Used by the customer to identify the merchant. Not used by the system to process payments | String getDisplayName() | setDisplayName(String displayName) |
| `Name` | [`CustomerNameEntity`](../../doc/models/customer-name-entity.md) | Optional | Name of the merchant used to execute the payment | CustomerNameEntity getName() | setName(CustomerNameEntity name) |
| `Address` | [`DeliveryAddress1`](../../doc/models/delivery-address-1.md) | Optional | Address of the merchant used to execute the payment | DeliveryAddress1 getAddress() | setAddress(DeliveryAddress1 address) |
| `Phone` | [`TelephoneNumber`](../../doc/models/telephone-number.md) | Optional | Phone number of the merchant used to execute the payment | TelephoneNumber getPhone() | setPhone(TelephoneNumber phone) |
| `MerchantAccountIds` | `List<String>` | Optional | Account identifier(s) the customer has with the merchant | List<String> getMerchantAccountIds() | setMerchantAccountIds(List<String> merchantAccountIds) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "displayName": "displayName4",
  "name": {
    "first": "first6",
    "middle": "middle6",
    "last": "last0",
    "suffix": "suffix0",
    "prefix": "prefix8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "address": {
    "line1": "line18",
    "line2": "line20",
    "line3": "line38",
    "city": "city6",
    "region": "region2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "phone": {
    "type": "BUSINESS",
    "country": "country4",
    "number": "number8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "merchantAccountIds": [
    "merchantAccountIds0",
    "merchantAccountIds1",
    "merchantAccountIds2"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

