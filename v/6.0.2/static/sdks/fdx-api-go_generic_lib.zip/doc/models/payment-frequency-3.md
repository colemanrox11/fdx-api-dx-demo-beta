
# Payment Frequency 3

ANNUALLY, BIWEEKLY, DAILY, MONTHLY, SEMIANNUALLY, SEMIMONTHLY, WEEKLY

*This model accepts additional fields of type interface{}.*

## Enumeration

`PaymentFrequency3`

## Fields

| Name |
|  --- |
| `Annually` |
| `Biweekly` |
| `Daily` |
| `Monthly` |
| `Semiannually` |
| `Semimonthly` |
| `Weekly` |

