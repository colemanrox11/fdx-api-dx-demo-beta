# Submit Tax Forms

```java
SubmitTaxFormsController submitTaxFormsController = client.getSubmitTaxFormsController();
```

## Class Name

`SubmitTaxFormsController`

## Methods

* [Create Tax Form](../../doc/controllers/submit-tax-forms.md#create-tax-form)
* [Update Tax Form](../../doc/controllers/submit-tax-forms.md#update-tax-form)


# Create Tax Form

Submit the data for a specific tax document

```java
CompletableFuture<ApiResponse<TaxStatement2>> createTaxFormAsync(
    final String authorization,
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final TaxStatement1 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `authorization` | `String` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`TaxStatement1`](../../doc/models/tax-statement-1.md) | Body, Optional | - |

## Server

`Server.USTAX`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TaxStatement2`](../../doc/models/tax-statement-2.md).

## Example Usage

```java
String authorization = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
TaxStatement1 body = new TaxStatement1.Builder()
    .taxYear(2023)
    .build();

submitTaxFormsController.createTaxFormAsync(authorization, xFapiInteractionId, fdxApiActorType, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Tax Form type is not supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Tax Form

Update tax document. Allows you to upload and replace binaries or json document

```java
CompletableFuture<ApiResponse<Void>> updateTaxFormAsync(
    final String taxFormId,
    final String authorization,
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final TaxStatement6 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `taxFormId` | `String` | Template, Required | The unique ID for this tax form or tax statement<br><br>**Constraints**: *Maximum Length*: `256` |
| `authorization` | `String` | Header, Required | The [Authorization HTTP request header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization) provides credentials to allow access to a protected resources |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`TaxStatement6`](../../doc/models/tax-statement-6.md) | Body, Optional | - |

## Server

`Server.USTAX`

## Response Type

`void`

## Example Usage

```java
String taxFormId = "taxFormId2";
String authorization = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkZEWCBUYXggVEYgUnVsZXMiLCJpYXQiOjE1MTYyMzkwMjJ9.SZGaxSt9EXqK1GbYTckZbygBDiqS1KaZybzzqf2VxOw";
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
TaxStatement6 body = new TaxStatement6.Builder()
    .taxYear(2023)
    .build();

submitTaxFormsController.updateTaxFormAsync(taxFormId, authorization, xFapiInteractionId, fdxApiActorType, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 415 | Server does not support the content type uploaded | [`ErrorException`](../../doc/models/error-exception.md) |

