
# Reward Program Membership Entity

Details of a single membership in a reward programs

*This model accepts additional fields of type Object.*

## Structure

`RewardProgramMembershipEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_ids` | `Array<String>` | Optional | accountIds associated to the reward program<br><br>**Constraints**: *Unique Items Required*, *Maximum Length*: `256` |
| `customer_id` | `String` | Optional | Long-term persistent identity of the associated Customer<br><br>**Constraints**: *Maximum Length*: `256` |
| `member_id` | `String` | Optional | Long term persistent identity of the program member<br><br>**Constraints**: *Maximum Length*: `256` |
| `member_number` | `String` | Optional | Reward program membership number |
| `member_tier` | `String` | Optional | If the reward program is tiered, member's current tier |
| `business_or_consumer` | [`BusinessOrConsumerType1`](../../doc/models/business-or-consumer-type-1.md) | Optional | BUSINESS or CONSUMER membership |
| `balances` | [`Array<RewardBalanceEntity>`](../../doc/models/reward-balance-entity.md) | Optional | Array of balances<br><br>**Constraints**: *Minimum Items*: `1` |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountIds": [
    "accountIds1"
  ],
  "customerId": "customerId0",
  "memberId": "memberId6",
  "memberNumber": "memberNumber0",
  "memberTier": "memberTier0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

