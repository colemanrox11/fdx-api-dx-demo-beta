
# Customer Entity

Represents a customer

*This model accepts additional fields of type Object.*

## Structure

`CustomerEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `emails` | `Array<String>` | Optional | Array of the contact email addresses |
| `addresses` | [`Array<DeliveryAddress>`](../../doc/models/delivery-address.md) | Optional | Array of the contact physical addresses |
| `telephones` | [`Array<TelephoneNumber>`](../../doc/models/telephone-number.md) | Optional | Array of the contact telephone numbers |
| `date_of_birth` | `Date` | Optional | The person's date of birth |
| `tax_id` | `String` | Optional | Country specific Tax Id associated with this customer (SIN or NAS in Canada, SSN or TIN in US, etc.) |
| `tax_id_country` | [`Iso3166CountryCode`](../../doc/models/iso-3166-country-code.md) | Optional | Country originating the Customer's taxId element |
| `government_id` | `String` | Optional | A federal (such as passport) or state (such as driver's license) issued identifier |
| `customer_id` | `String` | Optional | Long-term persistent identity of the customer. This identity must be unique to the owning institution<br><br>**Constraints**: *Maximum Length*: `256` |
| `type` | [`BusinessOrConsumerType`](../../doc/models/business-or-consumer-type.md) | Optional | Type of entity. One of BUSINESS or CONSUMER |
| `name` | [`CustomerNameEntity`](../../doc/models/customer-name-entity.md) | Optional | The customer's name |
| `business_customer` | [`BusinessCustomerEntity`](../../doc/models/business-customer-entity.md) | Optional | The business customer information, only used if 'type' is 'BUSINESS'. |
| `customer_start_date` | `Date` | Optional | The customer's start date at the financial institution |
| `last_activity_date` | `Date` | Optional | The customer's date of last account activity at the financial institution |
| `accounts` | [`Array<CustomerToAccountRelationshipEntity>`](../../doc/models/customer-to-account-relationship-entity.md) | Optional | List of accounts related to this customer |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "dateOfBirth": "2021-07-15",
  "customerStartDate": "2021-07-15",
  "lastActivityDate": "2021-07-15",
  "emails": [
    "emails9",
    "emails0"
  ],
  "addresses": [
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "telephones": [
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "taxId": "taxId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

