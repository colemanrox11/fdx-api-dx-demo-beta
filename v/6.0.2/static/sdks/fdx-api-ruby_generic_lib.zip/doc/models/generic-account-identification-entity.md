
# Generic Account Identification Entity

Generic account identifier entity

*This model accepts additional fields of type Object.*

## Structure

`GenericAccountIdentificationEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_id` | `String` | Optional | Account identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `issuer_name` | `String` | Optional | Name of the issuer |
| `id_scheme` | [External Account Id Scheme entity](../../doc/models/external-account-id-scheme-entity.md) \| [Proprietary Account Id Scheme entity](../../doc/models/proprietary-account-id-scheme-entity.md) \| nil | Optional | This is a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountId": "accountId4",
  "issuerName": "issuerName8",
  "idScheme": {
    "idCode": "idCode2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

