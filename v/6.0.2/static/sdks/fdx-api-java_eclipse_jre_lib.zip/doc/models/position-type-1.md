
# Position Type 1

LONG, SHORT

*This model accepts additional fields of type Object.*

## Enumeration

`PositionType1`

## Fields

| Name |
|  --- |
| `MLong` |
| `MShort` |

