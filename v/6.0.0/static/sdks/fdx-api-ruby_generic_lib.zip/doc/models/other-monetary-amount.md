
# Other Monetary Amount

A monetary amount with its source name and its currency code

*This model accepts additional fields of type Object.*

## Structure

`OtherMonetaryAmount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `Float` | Required | The monetary amount |
| `currency` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | Currency code of the monetary amount |
| `name` | `String` | Optional | The source name of this monetary amount |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "amount": 203.16,
  "currency": "QAR",
  "name": "name4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

