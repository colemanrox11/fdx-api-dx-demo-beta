
# Employment Type 2

The employee's employment type, CONTRACTED, FULL-TIME, OTHER, PART-TIME, SEASONAL, TEMPORARY

*This model accepts additional fields of type Object.*

## Enumeration

`EmploymentType2`

## Fields

| Name |
|  --- |
| `CONTRACTED` |
| `FULL_TIME` |
| `OTHER` |
| `PART_TIME` |
| `SEASONAL` |
| `TEMPORARY` |

