
# Operation Entity

Definition of a supported API for the /capability response object

*This model accepts additional fields of type Object.*

## Structure

`OperationEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Id` | [`FdxResourceOperationId1`](../../doc/models/fdx-resource-operation-id-1.md) | Optional | Operation ID (e.g. name) of this API | FdxResourceOperationId1 getId() | setId(FdxResourceOperationId1 id) |
| `Availability` | [`AvailabilityEntity1`](../../doc/models/availability-entity-1.md) | Optional | Whether and how this API is currently supported | AvailabilityEntity1 getAvailability() | setAvailability(AvailabilityEntity1 availability) |
| `AlsoSupported` | [`List<FdxResourceOperationId>`](../../doc/models/fdx-resource-operation-id.md) | Optional | Additional FDX API endpoints supported at this API, e.g. Transactions within Accounts, or TxImages within Transactions | List<FdxResourceOperationId> getAlsoSupported() | setAlsoSupported(List<FdxResourceOperationId> alsoSupported) |
| `Version` | `String` | Optional | Data provider's implementation version number for this operation, which is unrelated to the FDX API version | String getVersion() | setVersion(String version) |
| `FdxVersions` | [`List<FdxVersion>`](../../doc/models/fdx-version.md) | Optional | FDX schema versions supported at this endpoint | List<FdxVersion> getFdxVersions() | setFdxVersions(List<FdxVersion> fdxVersions) |
| `CutOffTime` | `LocalDateTime` | Optional | Cut off time for same-day execution of activity request submitted to this API. Alternatively, the as-of time when EOD account balances are typically set | LocalDateTime getCutOffTime() | setCutOffTime(LocalDateTime cutOffTime) |
| `Link` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | General HATEOAS link for this API, specifying supported action (GET, POST, etc) and contentTypes (application/json, image/png, etc), but without any path parameter values | HateoasLink getLink() | setLink(HateoasLink link) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "cutOffTime": "07/15/2021 14:46:41",
  "id": "createRecipient",
  "availability": {
    "status": "ALIVE",
    "description": "description0",
    "operationId": "getPaymentInitiationParty",
    "plannedAvailability": [
      {
        "status": "MAINTENANCE",
        "description": "description6",
        "startTime": "2016-03-13T12:52:32.123Z",
        "endTime": "2016-03-13T12:52:32.123Z",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "alsoSupported": [
    "deletePaymentMethodRegistration",
    "getPayee"
  ],
  "version": "version4",
  "fdxVersions": [
    "V5.2.0",
    "V5.2.1",
    "V5.2.2"
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

