
# Recipient Record at Ecosystem Registry

Record of Recipient at the Ecosystem Registry. Properties in this structure use 'snake_case' names to match the properties in [IETF RFC 7591](https://datatracker.ietf.org/doc/rfc7591/).

*This model accepts additional fields of type Object.*

## Structure

`RecipientRecordAtEcosystemRegistry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_name` | `String` | Required | The Data Recipient or Data Recipient Application name displayed by Data Provider during the consent Flow as well as in the Consent Dashboard<br><br>**Constraints**: *Maximum Length*: `256` |
| `description` | `String` | Optional | A short description of the Data Recipient application |
| `redirect_uris` | `Array<String>` | Required | An array of eligible Redirect URI targets |
| `logo_uri` | `String` | Optional | Data Recipient Logo URL location |
| `client_uri` | `String` | Optional | The URI which provides additional information about the Data Recipient |
| `contacts` | `Array<String>` | Optional | Array of strings representing ways to contact individuals responsible for the Data Recipient application |
| `scope` | `String` | Optional | String form field with a list of data clusters |
| `duration_type` | [`Array<ConsentDurationType>`](../../doc/models/consent-duration-type.md) | Optional | The duration of consent for the Data Recipient consumers |
| `duration_period` | `Integer` | Optional | The maximum consent duration in days for duration_type TIME_BOUND for the Data Recipient, effective from the date of consent |
| `lookback_period` | `Integer` | Optional | The maximum number of days allowed for Data Recipient to obtain in transaction history, effective from the current date |
| `registry_references` | [`Array<RegistryReference>`](../../doc/models/registry-reference.md) | Optional | An array of external registries containing registered entity name, registered entity id and registry fields for the registries where the data recipient is registered |
| `intermediaries` | [`Array<Intermediary>`](../../doc/models/intermediary.md) | Optional | An array of the intermediaries for this data recipient |
| `recipient_id` | `String` | Required | Recipient Id at ecosystem registry |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "client_name": "client_name8",
  "description": "description4",
  "redirect_uris": [
    "redirect_uris7",
    "redirect_uris8",
    "redirect_uris9"
  ],
  "logo_uri": "logo_uri0",
  "client_uri": "client_uri2",
  "contacts": [
    "contacts1",
    "contacts2",
    "contacts3"
  ],
  "scope": "scope2",
  "recipient_id": "recipient_id4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

