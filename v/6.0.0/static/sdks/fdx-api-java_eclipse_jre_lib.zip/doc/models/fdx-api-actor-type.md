
# Fdx Api Actor Type

Indicates whether a customer is present and has requested the operation (USER), or if a batch job has requested the operation (BATCH)

*This model accepts additional fields of type Object.*

## Enumeration

`FdxApiActorType`

## Fields

| Name |
|  --- |
| `Batch` |
| `User` |

