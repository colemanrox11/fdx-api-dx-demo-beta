
# Party Type 1

The party initiating consent revocation

*This model accepts additional fields of type Object.*

## Enumeration

`PartyType1`

## Fields

| Name |
|  --- |
| `DATA_ACCESS_PLATFORM` |
| `DATA_PROVIDER` |
| `DATA_RECIPIENT` |
| `INDIVIDUAL` |
| `MERCHANT` |
| `VENDOR` |

