
# Party Status 3

Defines the Merchant's lifecycle

*This model accepts additional fields of type Object.*

## Enumeration

`PartyStatus3`

## Fields

| Name |
|  --- |
| `Active` |
| `Deleted` |
| `Pending` |
| `Rejected` |

