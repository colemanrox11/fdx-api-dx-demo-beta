# Internal Transfers

```java
InternalTransfersController internalTransfersController = client.getInternalTransfersController();
```

## Class Name

`InternalTransfersController`

## Methods

* [Search for Transfers](../../doc/controllers/internal-transfers.md#search-for-transfers)
* [Request Account Transfer](../../doc/controllers/internal-transfers.md#request-account-transfer)
* [Get Transfer](../../doc/controllers/internal-transfers.md#get-transfer)
* [Cancel Transfer](../../doc/controllers/internal-transfers.md#cancel-transfer)


# Search for Transfers

Search for transfers

```java
CompletableFuture<ApiResponse<TransfersEntity>> searchForTransfersAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final String updatedSince,
    final String offset,
    final Integer limit,
    final LocalDate searchStartTransferDate,
    final LocalDate searchEndTransferDate,
    final List<String> searchFromAccountIds,
    final List<String> searchToAccountIds,
    final List<PaymentStatus> searchStatuses,
    final List<String> searchTransferIds)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `String` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |
| `searchStartTransferDate` | `LocalDate` | Query, Optional | Start time for use in retrieval of transfers by transfer date |
| `searchEndTransferDate` | `LocalDate` | Query, Optional | End time for use in retrieval of transfers by transfer date |
| `searchFromAccountIds` | `List<String>` | Query, Optional | Search for transfers by source account |
| `searchToAccountIds` | `List<String>` | Query, Optional | Search for transfers by source account |
| `searchStatuses` | [`List<PaymentStatus>`](../../doc/models/payment-status.md) | Query, Optional | Search for transfers by source account |
| `searchTransferIds` | `List<String>` | Query, Optional | Search for transfers by id |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TransfersEntity`](../../doc/models/transfers-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
LocalDate searchStartTransferDate = DateTimeHelper.fromSimpleDate("2021-07-15");
LocalDate searchEndTransferDate = DateTimeHelper.fromSimpleDate("2021-07-15");
internalTransfersController.searchForTransfersAsync(xFapiInteractionId, fdxApiActorType, null, null, null, searchStartTransferDate, searchEndTransferDate, null, null, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Request Account Transfer

Create a transfer between accounts

```java
CompletableFuture<ApiResponse<TransferEntity>> requestAccountTransferAsync(
    final UUID xFapiInteractionId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final TransferForCreateEntity1 body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`TransferForCreateEntity1`](../../doc/models/transfer-for-create-entity-1.md) | Body, Optional | Data of the transfer request |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TransferEntity`](../../doc/models/transfer-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String idempotencyKey = "idempotency-key4";
TransferForCreateEntity1 body = new TransferForCreateEntity1.Builder()
    .transferId("MY-TRANSFER-ID")
    .fromAccountId("ACCOUNT-123")
    .toAccountId("ACCOUNT-456")
    .amount(100D)
    .memo("FDX Transfer Example")
    .paymentDetails(new PaymentDetailsEntity.Builder()
        .principalAmount(75D)
        .interestAmount(10D)
        .insuranceAmount(5D)
        .escrowAmount(5D)
        .pmiAmount(5D)
        .feesAmount(0D)
        .build())
    .build();

internalTransfersController.requestAccountTransferAsync(xFapiInteractionId, idempotencyKey, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Source account does not have sufficient funds | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Account not authorized for transfer | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested transfer is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate transfer request | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Transfer

Get a transfer been accounts

```java
CompletableFuture<ApiResponse<TransferEntity>> getTransferAsync(
    final UUID xFapiInteractionId,
    final String transferId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `transferId` | `String` | Template, Required | Transfer identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TransferEntity`](../../doc/models/transfer-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String transferId = "transferId8";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

internalTransfersController.getTransferAsync(xFapiInteractionId, transferId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```


# Cancel Transfer

Cancel a transfer between accounts

```java
CompletableFuture<ApiResponse<TransferEntity>> cancelTransferAsync(
    final UUID xFapiInteractionId,
    final String transferId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `transferId` | `String` | Template, Required | Transfer identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TransferEntity`](../../doc/models/transfer-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String transferId = "transferId8";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

internalTransfersController.cancelTransferAsync(xFapiInteractionId, transferId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```

