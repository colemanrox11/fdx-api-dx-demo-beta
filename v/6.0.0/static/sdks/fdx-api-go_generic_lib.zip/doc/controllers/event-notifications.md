# Event Notifications

```go
eventNotificationsController := client.EventNotificationsController()
```

## Class Name

`EventNotificationsController`

## Methods

* [Create Notification Subscription](../../doc/controllers/event-notifications.md#create-notification-subscription)
* [Get Notification Subscription](../../doc/controllers/event-notifications.md#get-notification-subscription)
* [Delete Notification Subscription](../../doc/controllers/event-notifications.md#delete-notification-subscription)
* [Publish Notification](../../doc/controllers/event-notifications.md#publish-notification)
* [Get Notifications](../../doc/controllers/event-notifications.md#get-notifications)


# Create Notification Subscription

Creates notification subscription entry on the server

```go
CreateNotificationSubscription(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    body *models.NotificationSubscriptionEntity) (
    models.ApiResponse[models.NotificationSubscriptionEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.NotificationSubscriptionEntity`](../../doc/models/notification-subscription-entity.md) | Body, Optional | Notification subscription |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.NotificationSubscriptionEntity](../../doc/models/notification-subscription-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")



body := models.NotificationSubscriptionEntity{
    Type:                  models.NotificationType_ConsentRevoked,
    Category:              models.NotificationCategory1_Consent,
    CallbackUrl:           "https://abc.com/notification",
    Subscriber:            models.PartyEntity{
        Name:                  "ABC Inc",
        Type:                  models.PartyType_DataAccessPlatform,
        HomeUri:               models.ToPointer("https://abc.com/logo"),
        LogoUri:               models.ToPointer("https://abc.com/logo"),
        Registry:              models.ToPointer(models.Registry_Fdx),
        RegisteredEntityName:  models.ToPointer("ABC"),
        RegisteredEntityId:    models.ToPointer("ABC123"),
    },
    EffectiveDate:         models.ToPointer(parseTime(models.DEFAULT_DATE, "2021-11-24", func(err error) { log.Fatalln(err) })),
    SubscriptionId:        models.ToPointer("GUID-SubscriptionId1"),
}

apiResponse, err := eventNotificationsController.CreateNotificationSubscription(ctx, xFapiInteractionId, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "type": "CONSENT_REVOKED",
  "category": "CONSENT",
  "callbackUrl": "https://abc.com/notification",
  "subscriber": {
    "name": "ABC Inc",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "https://abc.com/logo",
    "logoUri": "https://abc.com/logo",
    "registry": "FDX",
    "registeredEntityName": "ABC",
    "registeredEntityId": "ABC123"
  },
  "effectiveDate": "2021-11-24",
  "subscriptionId": "GUID-SubscriptionId2"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Notification Subscription

Call to get notification subscription

```go
GetNotificationSubscription(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    subscriptionId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.NotificationSubscriptionEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `subscriptionId` | `string` | Template, Required | ID of notification subscription<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.NotificationSubscriptionEntity](../../doc/models/notification-subscription-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

subscriptionId := "subscriptionId0"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := eventNotificationsController.GetNotificationSubscription(ctx, xFapiInteractionId, subscriptionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "type": "CONSENT_REVOKED",
  "category": "CONSENT",
  "callbackUrl": "https://abc.com/notification",
  "subscriber": {
    "name": "ABC Inc",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "https://abc.com/logo",
    "logoUri": "https://abc.com/logo",
    "registry": "FDX",
    "registeredEntityName": "ABC",
    "registeredEntityId": "ABC123"
  },
  "effectiveDate": "2021-11-24",
  "subscriptionId": "GUID-SubscriptionId2"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Notification Subscription

Delete a notification subscription

```go
DeleteNotificationSubscription(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    subscriptionId string,
    fdxApiActorType *models.FdxApiActorType) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `subscriptionId` | `string` | Template, Required | ID of notification subscription<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

subscriptionId := "subscriptionId0"

fdxApiActorType := models.FdxApiActorType_Batch

resp, err := eventNotificationsController.DeleteNotificationSubscription(ctx, xFapiInteractionId, subscriptionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad Request | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Publish Notification

Publish Notification

```go
PublishNotification(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    body *models.NotificationEntity) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.NotificationEntity`](../../doc/models/notification-entity.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")



body := models.NotificationEntity{
    NotificationId:        "req123456-GUID",
    Type:                  models.NotificationType_ConsentRevoked,
    SentOn:                parseTime(time.RFC3339, "2021-07-15T14:46:41.375Z", func(err error) { log.Fatalln(err) }),
    Category:              models.NotificationCategory1_Security,
    Severity:              models.ToPointer(models.NotificationSeverity2_Emergency),
    Priority:              models.ToPointer(models.NotificationPriority2_High),
    Publisher:             models.PartyEntity{
        Name:                  "XYZ Inc",
        Type:                  models.PartyType_DataAccessPlatform,
        HomeUri:               models.ToPointer("http://example.com"),
        LogoUri:               models.ToPointer("http://example.com"),
        Registry:              models.ToPointer(models.Registry_Fdx),
        RegisteredEntityName:  models.ToPointer("XYZ"),
        RegisteredEntityId:    models.ToPointer("xyz1234"),
    },
    Subscriber:            models.ToPointer(models.PartyEntity{
        Name:                  "ABC Inc",
        Type:                  models.PartyType_DataAccessPlatform,
        HomeUri:               models.ToPointer("http://example.com"),
        LogoUri:               models.ToPointer("http://example.com"),
        Registry:              models.ToPointer(models.Registry_Fdx),
        RegisteredEntityName:  models.ToPointer("ABC"),
        RegisteredEntityId:    models.ToPointer("ABC123"),
    }),
    NotificationPayload:   models.NotificationPayloadEntity2{
        Id:                    models.ToPointer("ConsentID-1"),
        IdType:                models.ToPointer(models.NotificationPayloadIdType2_Consent),
        CustomFields:          models.ToPointer(models.FiAttributeEntity{
            Name:                  models.ToPointer("INITIATOR"),
            Value:                 models.ToPointer("INDIVIDUAL"),
        }),
    },
    Url:                   models.ToPointer(models.HateoasLink{
        Href:                  "https://api.xyz.com/fdx/v6/consents/ConsentID-1/revocation",
        Action:                models.ToPointer(models.HttpActionType_Get),
        Rel:                   models.ToPointer("consent"),
        Types:                 []models.ContentTypes{
            models.ContentTypes_EnumApplicationjson,
        },
    }),
}

resp, err := eventNotificationsController.PublishNotification(ctx, xFapiInteractionId, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Notifications

Get Notifications

```go
GetNotifications(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    limit *int,
    offset *string,
    dataRecipientId *string) (
    models.ApiResponse[models.NotificationsEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `dataRecipientId` | `*string` | Query, Optional | ID of Data Recipient (DR), omit for all DRs of a Data Access Platform<br><br>**Constraints**: *Maximum Length*: `256` |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.NotificationsEntity](../../doc/models/notifications-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch







apiResponse, err := eventNotificationsController.GetNotifications(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "notifications": [
    {
      "notificationId": "0a318518-ca16-4e66-1234",
      "type": "RISK",
      "sentOn": "2021-07-15T14:46:41.375Z",
      "category": "FRAUD",
      "severity": "EMERGENCY",
      "priority": "HIGH",
      "publisher": {
        "name": "XYZ Inc",
        "type": "DATA_ACCESS_PLATFORM",
        "homeUri": "http://example.com",
        "logoUri": "http://example.com",
        "registry": "FDX",
        "registeredEntityName": "XYZ",
        "registeredEntityId": "xyz1234"
      },
      "subscriber": {
        "name": "ABC Inc",
        "type": "DATA_ACCESS_PLATFORM",
        "homeUri": "http://example.com",
        "logoUri": "http://example.com",
        "registry": "FDX",
        "registeredEntityName": "ABC",
        "registeredEntityId": "ABC123"
      },
      "notificationPayload": {
        "id": "0a318518-ca16-4e66-be76-865a632ea771",
        "idType": "ACCOUNT"
      },
      "url": {
        "href": "https://api.xyz.com/fdx/v4/notifications?dataRecipientId=FIREFLY",
        "action": "GET",
        "rel": "notification",
        "types": [
          "application/json"
        ]
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 405 | Method Not Allowed | [`ErrorException`](../../doc/models/error-exception.md) |
| 429 | Too Many Requests | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

