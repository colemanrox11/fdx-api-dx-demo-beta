
# Loan Payment Frequency 2

WEEKLY, BIWEEKLY, TWICEMONTHLY, MONTHLY, FOURWEEKS, BIMONTHLY, QUARTERLY, SEMIANNUALLY, ANNUALLY, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`LoanPaymentFrequency2`

## Fields

| Name |
|  --- |
| `Annually` |
| `Bimonthly` |
| `Biweekly` |
| `Fourweeks` |
| `Monthly` |
| `Other` |
| `Quarterly` |
| `Semiannually` |
| `Twicemonthly` |
| `Weekly` |

