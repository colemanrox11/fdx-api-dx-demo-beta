
# Notification Payload Id Type 2

Type of entity causing origination of the notification with the given ID

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationPayloadIdType2`

## Fields

| Name |
|  --- |
| `ACCOUNT` |
| `CONSENT` |
| `CUSTOMER` |
| `MAINTENANCE` |
| `PARTY` |

