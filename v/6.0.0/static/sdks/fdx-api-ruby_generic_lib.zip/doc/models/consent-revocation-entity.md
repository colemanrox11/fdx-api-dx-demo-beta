
# Consent Revocation Entity

Details of request to revoke consent grant

*This model accepts additional fields of type Object.*

## Structure

`ConsentRevocationEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | [`ConsentGrantStatus1`](../../doc/models/consent-grant-status-1.md) | Optional | The status of the consent = REVOKED |
| `reason` | [`ConsentUpdateReason1`](../../doc/models/consent-update-reason-1.md) | Optional | The reason for consent revocation |
| `initiator` | [`PartyType1`](../../doc/models/party-type-1.md) | Optional | The party initiating consent revocation |
| `updated_time` | `DateTime` | Optional | When the consent grant was revoked |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "updatedTime": "07/15/2021 14:46:41",
  "status": "EXPIRED",
  "reason": "BUSINESS_RULE",
  "initiator": "MERCHANT",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

