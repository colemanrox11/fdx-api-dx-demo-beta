
# Resource List Entity

Response object for /resources API

*This model accepts additional fields of type Object.*

## Structure

`ResourceListEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets |
| `links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets |
| `resources` | [`Array<ResourceEntity>`](../../doc/models/resource-entity.md) | Optional | Zero or more Resources |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "resources": [
    {
      "resourceId": "resourceId0",
      "status": "RETIRED",
      "description": "description0",
      "links": [
        {
          "href": "href6",
          "action": "PATCH",
          "rel": "rel0",
          "types": [
            "application/json",
            "application/pdf"
          ],
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "resourceId": "resourceId0",
      "status": "RETIRED",
      "description": "description0",
      "links": [
        {
          "href": "href6",
          "action": "PATCH",
          "rel": "rel0",
          "types": [
            "application/json",
            "application/pdf"
          ],
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

