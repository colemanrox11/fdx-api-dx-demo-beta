
# Branch Entity 1

Branch details associated with this account

*This model accepts additional fields of type Object.*

## Structure

`BranchEntity1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `branch_id` | `String` | Optional | Branch number |
| `name` | `String` | Optional | Name of the branch |
| `locations` | [`Array<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Location of the branch |
| `financial_institution` | [`FinancialInstitutionEntity2`](../../doc/models/financial-institution-entity-2.md) | Optional | Financial institution associated with the branch |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "branchId": "branchId2",
  "name": "name0",
  "locations": [
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "financialInstitution": {
    "name": "name0",
    "fiId": {
      "bicFIDec2014Id": "bicFIDec2014Id2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "locations": [
      {
        "type": "HOME",
        "address": {
          "emailAddressText": "emailAddressText4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "HOME",
        "address": {
          "emailAddressText": "emailAddressText4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

