
# Asset Class

The class of an investment asset

*This model accepts additional fields of type Object.*

## Enumeration

`AssetClass`

## Fields

| Name |
|  --- |
| `Domesticbond` |
| `Intlbond` |
| `Intlstock` |
| `Largestock` |
| `Moneymarket` |
| `Other` |
| `Smallstock` |

