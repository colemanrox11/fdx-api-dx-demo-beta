
# Line Item Entity

A line item within a transaction

*This model accepts additional fields of type Object.*

## Structure

`LineItemEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Description` | `String` | Optional | The description of the line item | String getDescription() | setDescription(String description) |
| `Amount` | `Double` | Optional | The amount of money attributable to this line item | Double getAmount() | setAmount(Double amount) |
| `CheckNumber` | `Integer` | Optional | Check number | Integer getCheckNumber() | setCheckNumber(Integer checkNumber) |
| `Memo` | `String` | Optional | Secondary item description<br><br>**Constraints**: *Maximum Length*: `255` | String getMemo() | setMemo(String memo) |
| `Reference` | `String` | Optional | A reference number | String getReference() | setReference(String reference) |
| `ImageIds` | `List<String>` | Optional | Array of image identifiers (unique to transaction) used to retrieve images of check or transaction receipt | List<String> getImageIds() | setImageIds(List<String> imageIds) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links (unique to this Transaction) used to retrieve images of checks or transaction receipts, or invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "description": "description4",
  "amount": 66.76,
  "checkNumber": 104,
  "memo": "memo8",
  "reference": "reference0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

