
# Held in Account 2

Sub-account CASH, MARGIN, SHORT, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`HeldInAccount2`

## Fields

| Name |
|  --- |
| `CASH` |
| `MARGIN` |
| `OTHER` |
| `SHORT` |

