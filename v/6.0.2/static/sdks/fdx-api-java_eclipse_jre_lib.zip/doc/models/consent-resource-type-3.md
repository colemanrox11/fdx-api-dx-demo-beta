
# Consent Resource Type 3

Type of resource to be permissioned

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentResourceType3`

## Fields

| Name |
|  --- |
| `Account` |
| `Customer` |
| `Document` |

