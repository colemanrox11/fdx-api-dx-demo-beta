# Payroll Information

```ruby
payroll_information_controller = client.payroll_information
```

## Class Name

`PayrollInformationController`

## Methods

* [Get Payroll Reports](../../doc/controllers/payroll-information.md#get-payroll-reports)
* [Get Payroll Report](../../doc/controllers/payroll-information.md#get-payroll-report)


# Get Payroll Reports

Search for the employee's latest payroll report

```ruby
def get_payroll_reports(x_fapi_interaction_id,
                        report_type,
                        fdx_api_actor_type: nil,
                        result_type: ResultType::LIGHTWEIGHT)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `report_type` | [`PayrollReportType`](../../doc/models/payroll-report-type.md) | Query, Required | Whether to retrieve Verification of Employment ("VOE") or Verification of Income and Employment ("VOIE") reports |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `result_type` | [`ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `ResultType::LIGHTWEIGHT` |

## Server

`Server::PAYROLL`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayrollReportListEntity`](../../doc/models/payroll-report-list-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

report_type = PayrollReportType::VOE

fdx_api_actor_type = FdxApiActorType::BATCH

result_type = ResultType::LIGHTWEIGHT

result = payroll_information_controller.get_payroll_reports(
  x_fapi_interaction_id,
  report_type,
  fdx_api_actor_type: fdx_api_actor_type,
  result_type: result_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payroll Report

Retrieve the employee's specified payroll report

```ruby
def get_payroll_report(report_id,
                       x_fapi_interaction_id,
                       fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `report_id` | `String` | Template, Required | Specific reportId to retrieve<br><br>**Constraints**: *Maximum Length*: `256` |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::PAYROLL`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayrollReportEntity`](../../doc/models/payroll-report-entity.md).

## Example Usage

```ruby
report_id = 'reportId6'

x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payroll_information_controller.get_payroll_report(
  report_id,
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Required input data not sent | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payroll Report with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

