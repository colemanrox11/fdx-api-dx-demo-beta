
# Coverage Month 3

Month of coverage

*This model accepts additional fields of type Object.*

## Enumeration

`CoverageMonth3`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `JANUARY` |
| `FEBRUARY` |
| `MARCH` |
| `APRIL` |
| `MAY` |
| `JUNE` |
| `JULY` |
| `AUGUST` |
| `SEPTEMBER` |
| `OCTOBER` |
| `NOVEMBER` |
| `DECEMBER` |

