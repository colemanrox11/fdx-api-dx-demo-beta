
# Getting Started with FDX API

## Introduction

Financial Data Exchange V6.2.0 Consent API

### Requirements

The SDK requires **Go version 1.18 or above**.

## Building

### Install Dependencies

Resolve all the SDK dependencies, using the `go get` command.

## Installation

The following section explains how to use the fdxApi library in a new project.

### 1. Add SDK as a Dependency to the Application

- Add the following lines to your application's `go.mod` file:

```go
replace fdxApi => ".\\fdx-api-go_generic_lib" // local path to the SDK

require fdxApi v0.0.0
```

- Resolve the dependencies in the updated `go.mod` file, using the `go get` command.

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](doc/auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| taxBasicAuthCredentials | [`TaxBasicAuthCredentials`](doc/auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |

The API client can be initialized as follows:

```go
package main

import (
    "fdxApi"
)

func main() {
    client := fdxApi.NewClient(
    fdxApi.CreateConfiguration(
            fdxApi.WithHttpConfiguration(
                fdxApi.CreateHttpConfiguration(
                    fdxApi.WithTimeout(0),
                ),
            ),
            fdxApi.WithEnvironment(fdxApi.PRODUCTION),
            fdxApi.WithBearerAuthCredentials(
                fdxApi.NewBearerAuthCredentials("AccessToken"),
            ),
            fdxApi.WithTaxBasicAuthCredentials(
                fdxApi.NewTaxBasicAuthCredentials(
                    "Username",
                    "Password",
                ),
            ),
            fdxApi.WithLoggerConfiguration(
                fdxApi.WithLevel("info"),
                fdxApi.WithRequestConfiguration(
                    fdxApi.WithRequestBody(true),
                ),
                fdxApi.WithResponseConfiguration(
                    fdxApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## Authorization

This API uses the following authentication schemes.

* [`bearerAuth (OAuth 2 Bearer token)`](doc/auth/oauth-2-bearer-token.md)
* [`TaxBasicAuth (Basic Authentication)`](doc/auth/basic-authentication.md)

## List of APIs

* [User Consent](doc/controllers/user-consent.md)
* [Account Information](doc/controllers/account-information.md)
* [Account Statements](doc/controllers/account-statements.md)
* [Account Transactions](doc/controllers/account-transactions.md)
* [Money Movement](doc/controllers/money-movement.md)
* [Personal Information](doc/controllers/personal-information.md)
* [Reward Program Categories](doc/controllers/reward-program-categories.md)
* [Reward Program Information](doc/controllers/reward-program-information.md)
* [Event Notifications](doc/controllers/event-notifications.md)
* [Fraud Notification](doc/controllers/fraud-notification.md)
* [Internal Transfers](doc/controllers/internal-transfers.md)
* [Payee Management](doc/controllers/payee-management.md)
* [Payment Initiation Parties](doc/controllers/payment-initiation-parties.md)
* [Recurring Payments](doc/controllers/recurring-payments.md)
* [Payroll Information](doc/controllers/payroll-information.md)
* [Submit Tax Forms](doc/controllers/submit-tax-forms.md)
* [Tax Forms](doc/controllers/tax-forms.md)
* [Resource Information](doc/controllers/resource-information.md)
* [Meta](doc/controllers/meta.md)
* [Payments](doc/controllers/payments.md)
* [Recipients](doc/controllers/recipients.md)

## SDK Infrastructure

### Configuration

* [HttpConfiguration](doc/http-configuration.md)
* [LoggerConfiguration](doc/logger-configuration.md)
* [RequestLoggerConfiguration](doc/request-logger-configuration.md)
* [ResponseLoggerConfiguration](doc/response-logger-configuration.md)
* [RetryConfiguration](doc/retry-configuration.md)

### Utilities

* [ApiResponse](doc/api-response.md)

