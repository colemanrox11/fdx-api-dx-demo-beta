
# Fi Portion Entity

Financial Institution-specific asset allocation

*This model accepts additional fields of type Object.*

## Structure

`FiPortionEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AssetClass` | `String` | Optional | Financial Institution-specific asset class | String getAssetClass() | setAssetClass(String assetClass) |
| `Percent` | `Double` | Optional | Percentage of asset class that falls under this asset | Double getPercent() | setPercent(Double percent) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "assetClass": "assetClass0",
  "percent": 210.02,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

