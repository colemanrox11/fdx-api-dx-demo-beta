
# Unit Type

The units of an investment transaction

*This model accepts additional fields of type Object.*

## Enumeration

`UnitType`

## Fields

| Name |
|  --- |
| `CURRENCY` |
| `SHARES` |

