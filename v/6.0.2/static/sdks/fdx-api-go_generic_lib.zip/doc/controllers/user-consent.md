# User Consent

```go
userConsentController := client.UserConsentController()
```

## Class Name

`UserConsentController`

## Methods

* [Get Consent Grant](../../doc/controllers/user-consent.md#get-consent-grant)
* [Revoke Consent Grant](../../doc/controllers/user-consent.md#revoke-consent-grant)
* [Get Consent Revocation](../../doc/controllers/user-consent.md#get-consent-revocation)


# Get Consent Grant

Get a Consent Grant

```go
GetConsentGrant(
    ctx context.Context,
    consentId string,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.ConsentGrantEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consentId` | `string` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ConsentGrantEntity](../../doc/models/consent-grant-entity.md).

## Example Usage

```go
ctx := context.Background()

consentId := "9585694d3ae58863"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := userConsentController.GetConsentGrant(ctx, consentId, xFapiInteractionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "id": "9585694d3ae58863",
  "status": "ACTIVE",
  "parties": [
    {
      "name": "Seedling App",
      "type": "DATA_RECIPIENT",
      "homeUri": "https://www.seedling.com",
      "logoUri": "https://www.seedling.com/assets/seedling-logo.png",
      "registry": "FDX",
      "registeredEntityName": "Oak Tree Holdings, Inc",
      "registeredEntityId": "5493001052I34KDC1O18"
    },
    {
      "name": "Midwest Primary Bank, NA",
      "type": "DATA_PROVIDER",
      "homeUri": "https://www.midwest.com",
      "logoUri": "https://www.midwest.com/81d88112572c.jpg",
      "registry": "GLEIF",
      "registeredEntityName": "Midwest Primary Bank, NA",
      "registeredEntityId": "549300ATG070THRDJ595"
    }
  ],
  "createdTime": "2021-07-03T21:28:10.375Z",
  "expirationTime": "2021-07-03T22:28:10.374Z",
  "durationType": "ONE_TIME",
  "lookbackPeriod": 60,
  "resources": [
    {
      "resourceType": "ACCOUNT",
      "resourceId": "b14e1e714693bc00",
      "dataClusters": [
        "ACCOUNT_DETAILED",
        "TRANSACTIONS",
        "STATEMENTS"
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |


# Revoke Consent Grant

Revoke a Consent Grant

```go
RevokeConsentGrant(
    ctx context.Context,
    consentId string,
    xFapiInteractionId uuid.UUID,
    body models.ConsentRevocationRequestEntity,
    fdxApiActorType *models.FdxApiActorType) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consentId` | `string` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `body` | [`models.ConsentRevocationRequestEntity`](../../doc/models/consent-revocation-request-entity.md) | Body, Required | Reason and initiator of revocation |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

consentId := "9585694d3ae58863"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

body := models.ConsentRevocationRequestEntity{
    Reason:                models.ToPointer(models.ConsentUpdateReason1_BusinessRule),
    Initiator:             models.ToPointer(models.PartyType2_DataAccessPlatform),
}



resp, err := userConsentController.RevokeConsentGrant(ctx, consentId, xFapiInteractionId, body, nil)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | Forbidden, server understands the request but refuses to authorize it | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Conflict with current state of target resource | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Consent Revocation

Retrieve Consent Revocation record

```go
GetConsentRevocation(
    ctx context.Context,
    consentId string,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.ConsentRevocationListEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consentId` | `string` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ConsentRevocationListEntity](../../doc/models/consent-revocation-list-entity.md).

## Example Usage

```go
ctx := context.Background()

consentId := "9585694d3ae58863"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := userConsentController.GetConsentRevocation(ctx, consentId, xFapiInteractionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

