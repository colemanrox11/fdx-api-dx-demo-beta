
# Consent Grant Entity

Record of user consent

*This model accepts additional fields of type Object.*

## Structure

`ConsentGrantEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | The persistent identifier of the consent<br><br>**Constraints**: *Maximum Length*: `256` |
| `status` | [`ConsentGrantStatus3`](../../doc/models/consent-grant-status-3.md) | Optional | The current status of the consent |
| `parties` | [`Array<PartyEntity>`](../../doc/models/party-entity.md) | Optional | The non-end user parties participating in the Consent Grant |
| `created_time` | `DateTime` | Optional | When the consent was initially granted |
| `expiration_time` | `DateTime` | Optional | When the consent grant will become expired |
| `updated_time` | `DateTime` | Optional | When the consent grant was updated |
| `duration_type` | [`ConsentDurationType`](../../doc/models/consent-duration-type.md) | Optional | The type of duration of the consent |
| `duration_period` | `Integer` | Optional | The consent duration in days from day of original grant |
| `lookback_period` | `Integer` | Optional | Period, in days, for which historical data may be requested; measured from request time, not grant time |
| `resources` | [`Array<ConsentGrantResourceEntity>`](../../doc/models/consent-grant-resource-entity.md) | Optional | The permissioned resource entities |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links for related Consent Grant records |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "createdTime": "07/15/2021 14:46:41",
  "expirationTime": "07/15/2021 14:46:41",
  "updatedTime": "07/15/2021 14:46:41",
  "id": "id6",
  "status": "ACTIVE",
  "parties": [
    {
      "name": "name2",
      "type": "MERCHANT",
      "homeUri": "homeUri4",
      "logoUri": "logoUri0",
      "registry": "FDX",
      "registeredEntityName": "registeredEntityName0",
      "registeredEntityId": "registeredEntityId8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

