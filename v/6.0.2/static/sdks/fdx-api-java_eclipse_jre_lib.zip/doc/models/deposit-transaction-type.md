
# Deposit Transaction Type

The type of a deposit transaction

*This model accepts additional fields of type Object.*

## Enumeration

`DepositTransactionType`

## Fields

| Name |
|  --- |
| `Adjustment` |
| `Atmdeposit` |
| `Atmwithdrawal` |
| `Billpayment` |
| `Check` |
| `Deposit` |
| `Directdeposit` |
| `Dividend` |
| `Fee` |
| `Interest` |
| `Poscredit` |
| `Posdebit` |
| `Transfer` |
| `Withdrawal` |

