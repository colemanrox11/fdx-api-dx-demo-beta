
# Unit Type 3

Type of unit. One of SHARES, CURRENCY

*This model accepts additional fields of type Object.*

## Enumeration

`UnitType3`

## Fields

| Name |
|  --- |
| `CURRENCY` |
| `SHARES` |

