
# Asset Class 2

The asset class for this allocation

*This model accepts additional fields of type Object.*

## Enumeration

`AssetClass2`

## Fields

| Name |
|  --- |
| `Domesticbond` |
| `Intlbond` |
| `Intlstock` |
| `Largestock` |
| `Moneymarket` |
| `Other` |
| `Smallstock` |

