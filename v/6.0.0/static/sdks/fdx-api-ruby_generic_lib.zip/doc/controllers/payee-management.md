# Payee Management

```ruby
payee_management_controller = client.payee_management
```

## Class Name

`PayeeManagementController`

## Methods

* [Search for Payees](../../doc/controllers/payee-management.md#search-for-payees)
* [Create Payee](../../doc/controllers/payee-management.md#create-payee)
* [Get Payee](../../doc/controllers/payee-management.md#get-payee)
* [Update Payee](../../doc/controllers/payee-management.md#update-payee)
* [Delete Payee](../../doc/controllers/payee-management.md#delete-payee)


# Search for Payees

Search for payees

```ruby
def search_for_payees(x_fapi_interaction_id,
                      fdx_api_actor_type: nil,
                      updated_since: nil,
                      offset: nil,
                      limit: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updated_since` | `String` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayeesEntity`](../../doc/models/payees-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payee_management_controller.search_for_payees(
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "next-offset-123-xyz",
    "prevOffset": "prev-offset-456-abc",
    "totalElements": 100
  },
  "updates": {
    "nextUpdateId": "next-update-id-456-krl"
  },
  "links": {
    "next": {
      "href": "/payees?offset=next-offset-123-xyz"
    },
    "prev": {
      "href": "/payees?offset=prev-offset-456-abc"
    },
    "updates": {
      "href": "/payees?updatedSince=next-update-id-456-krl"
    }
  },
  "payees": [
    {
      "merchant": {
        "displayName": "My Cell Phone Biller",
        "name": {
          "company": "US Cellular"
        },
        "address": {
          "line1": "10 Cellular way",
          "city": "New York",
          "region": "NY",
          "postalCode": "10001"
        },
        "phone": {
          "type": "CELL",
          "country": "+1",
          "number": "2013329944"
        },
        "payeeId": "payee-1001",
        "merchantAccountIds": [
          "999900008888"
        ],
        "status": "ACTIVE",
        "expiresTimestamp": "2025-03-15T13:29:19+0000"
      }
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Create Payee

Create a payee

```ruby
def create_payee(x_fapi_interaction_id,
                 idempotency_key,
                 fdx_api_actor_type: nil,
                 body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `idempotency_key` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PayeeForUpdateEntity1`](../../doc/models/payee-for-update-entity-1.md) | Body, Optional | - |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

idempotency_key = 'idempotency-key4'

body = PayeeForUpdateEntity1.new(
  merchant: MerchantForUpdateEntity1.new(
    display_name: 'My Cell Phone Biller',
    name: CustomerNameEntity.new(
      first: 'Junie',
      middle: 'B',
      last: 'Jones',
      suffix: 'Jr',
      prefix: 'Ms',
      company: 'US Cellular'
    ),
    address: DeliveryAddress1.new(
      line1: '10 Cellular way',
      city: 'New York',
      region: 'NY',
      postal_code: '10001'
    ),
    phone: TelephoneNumber.new(
      type: TelephoneNumberType::BUSINESS,
      country: '+1',
      number: '2013329944'
    ),
    merchant_account_ids: [
      '999900008888'
    ]
  )
)

result = payee_management_controller.create_payee(
  x_fapi_interaction_id,
  idempotency_key,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 409 | Duplicate Request | [`PayeeEntityErrorException`](../../doc/models/payee-entity-error-exception.md) |


# Get Payee

Get a payee

```ruby
def get_payee(x_fapi_interaction_id,
              payee_id,
              fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payee_id` | `String` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payee_id = 'payeeId8'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payee_management_controller.get_payee(
  x_fapi_interaction_id,
  payee_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payee

Used to update an existing payee. The payee type must match the existing payee. This call updates the payee's fields to the values provided. If a field is not provided, the payee's field is not updated

```ruby
def update_payee(x_fapi_interaction_id,
                 payee_id,
                 idempotency_key,
                 fdx_api_actor_type: nil,
                 body: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payee_id` | `String` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotency_key` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PayeeForUpdateEntity`](../../doc/models/payee-for-update-entity.md) | Body, Optional | - |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payee_id = 'payeeId8'

idempotency_key = 'idempotency-key4'

body = PayeeForUpdateEntity.new(
  merchant: MerchantForUpdateEntity1.new(
    display_name: 'My Business Cell Phone Biller'
  )
)

result = payee_management_controller.update_payee(
  x_fapi_interaction_id,
  payee_id,
  idempotency_key,
  body: body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "displayName": "My Cell Phone Biller",
    "name": {
      "company": "US Cellular"
    },
    "address": {
      "line1": "10 Cellular way",
      "city": "New York",
      "region": "NY",
      "postalCode": "10001"
    },
    "phone": {
      "type": "CELL",
      "country": "+1",
      "number": "2013329944"
    },
    "payeeId": "payee-1001",
    "merchantAccountIds": [
      "999900008888"
    ],
    "status": "ACTIVE",
    "expiresTimestamp": "2025-03-15T13:29:19+0000"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate Request | [`PayeeEntityErrorException`](../../doc/models/payee-entity-error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payee

Delete a payee

```ruby
def delete_payee(x_fapi_interaction_id,
                 payee_id,
                 fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `payee_id` | `String` | Template, Required | Payee Identifier. Uniquely identifies a payee<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PayeeEntity`](../../doc/models/payee-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

payee_id = 'payeeId8'

fdx_api_actor_type = FdxApiActorType::BATCH

result = payee_management_controller.delete_payee(
  x_fapi_interaction_id,
  payee_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "merchant": {
    "status": "DELETED"
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Payee cannot be modified or deleted | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Payee with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

