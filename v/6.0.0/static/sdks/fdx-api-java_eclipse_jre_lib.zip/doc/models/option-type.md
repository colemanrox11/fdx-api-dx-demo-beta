
# Option Type

The type of a stock option

*This model accepts additional fields of type Object.*

## Enumeration

`OptionType`

## Fields

| Name |
|  --- |
| `Call` |
| `Put` |

