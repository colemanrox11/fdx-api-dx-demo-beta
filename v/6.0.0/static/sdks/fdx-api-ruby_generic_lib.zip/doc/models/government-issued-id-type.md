
# Government Issued Id Type

Government Issued ID Type

*This model accepts additional fields of type Object.*

## Enumeration

`GovernmentIssuedIdType`

## Fields

| Name |
|  --- |
| `DRIVERLICENSE` |
| `PASSPORT` |

