
# Payment Network Type 2

Type of Canadian or U.S. payment network, CA_ACSS, CA_LVTS, US_ACH, US_CHIPS, US_FEDWIRE, US_RTP

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentNetworkType2`

## Fields

| Name |
|  --- |
| `CA_ACSS` |
| `CA_LVTS` |
| `US_ACH` |
| `US_CHIPS` |
| `US_FEDNOW` |
| `US_FEDWIRE` |
| `US_RTP` |

