
# Time and Occurrence Based Transfer Limits 3

Limits for outgoing transfers from the account

*This model accepts additional fields of type Object.*

## Structure

`TimeAndOccurrenceBasedTransferLimits3`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Day` | [`TimeframeBasedLimitsForAPaymentNetwork5`](../../doc/models/timeframe-based-limits-for-a-payment-network-5.md) | Optional | The transfer limits for the current day | TimeframeBasedLimitsForAPaymentNetwork5 getDay() | setDay(TimeframeBasedLimitsForAPaymentNetwork5 day) |
| `Week` | [`TimeframeBasedLimitsForAPaymentNetwork1`](../../doc/models/timeframe-based-limits-for-a-payment-network-1.md) | Optional | The transfer limits for the current week | TimeframeBasedLimitsForAPaymentNetwork1 getWeek() | setWeek(TimeframeBasedLimitsForAPaymentNetwork1 week) |
| `Month` | [`TimeframeBasedLimitsForAPaymentNetwork2`](../../doc/models/timeframe-based-limits-for-a-payment-network-2.md) | Optional | The transfer limits for the current month | TimeframeBasedLimitsForAPaymentNetwork2 getMonth() | setMonth(TimeframeBasedLimitsForAPaymentNetwork2 month) |
| `Year` | [`TimeframeBasedLimitsForAPaymentNetwork3`](../../doc/models/timeframe-based-limits-for-a-payment-network-3.md) | Optional | The transfer limits for the current year | TimeframeBasedLimitsForAPaymentNetwork3 getYear() | setYear(TimeframeBasedLimitsForAPaymentNetwork3 year) |
| `Transaction` | [`OccurrenceBasedLimitsForAPaymentNetwork2`](../../doc/models/occurrence-based-limits-for-a-payment-network-2.md) | Optional | The transfer limits taking effect from all the timeframe limits | OccurrenceBasedLimitsForAPaymentNetwork2 getTransaction() | setTransaction(OccurrenceBasedLimitsForAPaymentNetwork2 transaction) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "day": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 108.3,
    "transferRemainingAmount": 199.76,
    "maxOccurrence": 168,
    "remainingOccurrence": 46,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "week": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 238.72,
    "transferRemainingAmount": 74.18,
    "maxOccurrence": 102,
    "remainingOccurrence": 32,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "month": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 46.02,
    "transferRemainingAmount": 137.48,
    "maxOccurrence": 172,
    "remainingOccurrence": 218,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "year": {
    "resetsOn": "2016-03-13T12:52:32.123Z",
    "transferMaxAmount": 25.7,
    "transferRemainingAmount": 117.16,
    "maxOccurrence": 156,
    "remainingOccurrence": 234,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "transaction": {
    "transferMaxAmount": 238.5,
    "transferRemainingAmount": 73.96,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

