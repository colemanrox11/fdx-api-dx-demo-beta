
# Payment for Update Entity

Payment entity used for creation and update of a payment

*This model accepts additional fields of type Object.*

## Structure

`PaymentForUpdateEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `from_account_id` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `to_payee_id` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` |
| `amount` | `Float` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` |
| `merchant_account_id` | `String` | Optional | User's account identifier with the merchant |
| `due_date` | `Date` | Required | Date that the funds are scheduled to be delivered |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "fromAccountId": "fromAccountId2",
  "toPayeeId": "toPayeeId6",
  "amount": 148.8,
  "dueDate": "2021-07-15",
  "merchantAccountId": "merchantAccountId6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

