
# Transactions Entity

Optionally paginated array of transactions

*This model accepts additional fields of type Object.*

## Structure

`TransactionsEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets | PageMetadata getPage() | setPage(PageMetadata page) |
| `Links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets | PageMetadataLinks getLinks() | setLinks(PageMetadataLinks links) |
| `Transactions` | [`List<TransactionsEntityTransactions>`](../../doc/models/containers/transactions-entity-transactions.md) | Optional | This is List of a container for any-of cases. | List<TransactionsEntityTransactions> getTransactions() | setTransactions(List<TransactionsEntityTransactions> transactions) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "transactions": [
    {
      "accountCategory": "Commercial Transaction entity",
      "accountId": "accountId4",
      "transactionId": "transactionId4",
      "referenceTransactionId": "referenceTransactionId4",
      "postedTimestamp": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      },
      "immediateAvailableBalance": 89.1,
      "nextDayAvailableBalance": 186.56,
      "twoDaysPlusAvailableBalance": 86.66,
      "referenceBankId": "referenceBankId4",
      "referenceBranchId": "referenceBranchId8"
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

