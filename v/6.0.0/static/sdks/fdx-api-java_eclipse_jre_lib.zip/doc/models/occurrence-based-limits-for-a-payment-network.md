
# Occurrence Based Limits for a Payment Network

This provides the occurrence-based limits applied to the account within the payment network

*This model accepts additional fields of type Object.*

## Structure

`OccurrenceBasedLimitsForAPaymentNetwork`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransferMaxAmount` | `Double` | Optional | Maximum limit of funds that can be transferred to/from the account using the timeframe limits | Double getTransferMaxAmount() | setTransferMaxAmount(Double transferMaxAmount) |
| `TransferRemainingAmount` | `Double` | Optional | Remaining value of the maximum limit of funds that can be transferred to/from the account using the timeframe limits | Double getTransferRemainingAmount() | setTransferRemainingAmount(Double transferRemainingAmount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "transferMaxAmount": 142.14,
  "transferRemainingAmount": 233.6,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

