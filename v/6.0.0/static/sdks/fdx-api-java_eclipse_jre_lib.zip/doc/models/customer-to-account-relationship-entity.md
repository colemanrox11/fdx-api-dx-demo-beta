
# Customer to Account Relationship Entity

Describes an account related to a customer

*This model accepts additional fields of type Object.*

## Structure

`CustomerToAccountRelationshipEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountId` | `String` | Optional | Account ID of the related account<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to the account, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `Relationship` | [`AccountHolderRelationship`](../../doc/models/account-holder-relationship.md) | Optional | Type of relationship to the account | AccountHolderRelationship getRelationship() | setRelationship(AccountHolderRelationship relationship) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountId": "accountId4",
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "relationship": "FOR_BENEFIT_OF_SECONDARY_JOINT_RESTRICTED",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

