
# Portion Entity

An asset allocation with class and percentage

*This model accepts additional fields of type Object.*

## Structure

`PortionEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `asset_class` | [`AssetClass2`](../../doc/models/asset-class-2.md) | Optional | The asset class for this allocation |
| `percent` | `Float` | Optional | The percentage of this allocation |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "assetClass": "MONEYMARKET",
  "percent": 142.7,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

