# Account Transactions

```ruby
account_transactions_controller = client.account_transactions
```

## Class Name

`AccountTransactionsController`

## Methods

* [Get Account Transaction Images](../../doc/controllers/account-transactions.md#get-account-transaction-images)
* [Search for Account Transactions](../../doc/controllers/account-transactions.md#search-for-account-transactions)


# Get Account Transaction Images

Get account transaction image

```ruby
def get_account_transaction_images(x_fapi_interaction_id,
                                   account_id,
                                   image_id,
                                   fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `account_id` | `String` | Template, Required | Account Identifier |
| `image_id` | `String` | Template, Required | Image Identifier |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server::CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type `Mixed`.

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

account_id = 'accountId0'

image_id = 'imageId4'

fdx_api_actor_type = FdxApiActorType::BATCH

result = account_transactions_controller.get_account_transaction_images(
  x_fapi_interaction_id,
  account_id,
  image_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Account or image with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 406 | Content Type not Supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Search for Account Transactions

Search for account transactions. Example: /accounts/{accountId}/transactions?startTime=value1&endTime=value2

```ruby
def search_for_account_transactions(x_fapi_interaction_id,
                                    account_id,
                                    fdx_api_actor_type: nil,
                                    start_time: nil,
                                    end_time: nil,
                                    offset: nil,
                                    limit: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `account_id` | `String` | Template, Required | Account Identifier |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `start_time` | `Date` | Query, Optional | Start time for use in retrieval of elements (ISO 8601) |
| `end_time` | `Date` | Query, Optional | End time for use in retrieval of elements (ISO 8601) |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server::CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TransactionsEntity`](../../doc/models/transactions-entity.md).

## Example Usage

```ruby
x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

account_id = 'accountId0'

fdx_api_actor_type = FdxApiActorType::BATCH

start_time = Date.iso8601('2021-07-15')

end_time = Date.iso8601('2021-07-15')

result = account_transactions_controller.search_for_account_transactions(
  x_fapi_interaction_id,
  account_id,
  fdx_api_actor_type: fdx_api_actor_type,
  start_time: start_time,
  end_time: end_time
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "2",
    "total": 3
  },
  "links": {
    "next": {
      "href": "/accounts/33333/transactions?offSet=2&limit=10"
    }
  },
  "transactions": [
    {
      "accountCategory": "DEPOSIT_ACCOUNT",
      "accountId": "10001",
      "transactionId": "20002",
      "postedTimestamp": "2017-11-05T13:15:30.751Z",
      "description": "Direct deposit from XYZ Corp",
      "debitCreditMemo": "CREDIT",
      "amount": 1200.42,
      "payee": "XYZ Corp"
    },
    {
      "accountCategory": "DEPOSIT_ACCOUNT",
      "accountId": "10001",
      "transactionId": "20002",
      "postedTimestamp": "2017-11-05T13:15:31.751Z",
      "description": "Withdrawal from ATM",
      "debitCreditMemo": "DEBIT",
      "amount": 1200.42,
      "payee": "Account Owner"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

