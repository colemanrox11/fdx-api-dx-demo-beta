
# Loan Transaction Type 2

PAYMENT, FEE, ADJUSTMENT, INTEREST

*This model accepts additional fields of type Object.*

## Enumeration

`LoanTransactionType2`

## Fields

| Name |
|  --- |
| `ADJUSTMENT` |
| `DOUBLE_UP_PAYMENT` |
| `FEE` |
| `INTEREST` |
| `LUMP_SUM_PAYMENT` |
| `PAYMENT` |
| `PAYOFF` |
| `SKIP_PAYMENT` |

