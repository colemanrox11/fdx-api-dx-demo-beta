
# Updates Metadata Entity 2

Update IDs for retrieving updates since query

*This model accepts additional fields of type Object.*

## Structure

`UpdatesMetadataEntity2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextUpdateId` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific<br><br>**Constraints**: *Maximum Length*: `256` | String getNextUpdateId() | setNextUpdateId(String nextUpdateId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "nextUpdateId": "nextUpdateId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

