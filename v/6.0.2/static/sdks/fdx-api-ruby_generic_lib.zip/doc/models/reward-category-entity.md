
# Reward Category Entity

Reward category used to calculate rewards on a transaction

*This model accepts additional fields of type Object.*

## Structure

`RewardCategoryEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reward_program_id` | `String` | Optional | Long term persistent identity of the reward program<br><br>**Constraints**: *Maximum Length*: `256` |
| `category_name` | `String` | Optional | Reward category name |
| `category_id` | `String` | Optional | Long term persistent identity of the reward category<br><br>**Constraints**: *Maximum Length*: `256` |
| `multiplier` | `Float` | Optional | Factor used to calculate rewards accrued<br><br>**Constraints**: `>= 0` |
| `description` | `String` | Optional | Description of the reward category |
| `fi_attributes` | [`Array<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of FI-specific attributes |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "rewardProgramId": "rewardProgramId0",
  "categoryName": "categoryName4",
  "categoryId": "categoryId6",
  "multiplier": 61.1,
  "description": "description6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

