
# Reward Programs Entity

An optionally paginated array of reward programs

*This model accepts additional fields of type Object.*

## Structure

`RewardProgramsEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets | PageMetadata getPage() | setPage(PageMetadata page) |
| `Links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets | PageMetadataLinks getLinks() | setLinks(PageMetadataLinks links) |
| `RewardPrograms` | [`List<RewardProgramEntity>`](../../doc/models/reward-program-entity.md) | Optional | Array of reward programs | List<RewardProgramEntity> getRewardPrograms() | setRewardPrograms(List<RewardProgramEntity> rewardPrograms) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "rewardPrograms": [
    {
      "rewardProgramId": "rewardProgramId8",
      "programName": "programName0",
      "programUrl": "programUrl2",
      "memberships": [
        {
          "accountIds": [
            "accountIds7",
            "accountIds8"
          ],
          "customerId": "customerId6",
          "memberId": "memberId2",
          "memberNumber": "memberNumber6",
          "memberTier": "memberTier6",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "accountIds": [
            "accountIds7",
            "accountIds8"
          ],
          "customerId": "customerId6",
          "memberId": "memberId2",
          "memberNumber": "memberNumber6",
          "memberTier": "memberTier6",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "fiAttributes": [
        {
          "name": "name6",
          "value": "value8",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "name": "name6",
          "value": "value8",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "name": "name6",
          "value": "value8",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "rewardProgramId": "rewardProgramId8",
      "programName": "programName0",
      "programUrl": "programUrl2",
      "memberships": [
        {
          "accountIds": [
            "accountIds7",
            "accountIds8"
          ],
          "customerId": "customerId6",
          "memberId": "memberId2",
          "memberNumber": "memberNumber6",
          "memberTier": "memberTier6",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "accountIds": [
            "accountIds7",
            "accountIds8"
          ],
          "customerId": "customerId6",
          "memberId": "memberId2",
          "memberNumber": "memberNumber6",
          "memberTier": "memberTier6",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "fiAttributes": [
        {
          "name": "name6",
          "value": "value8",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "name": "name6",
          "value": "value8",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "name": "name6",
          "value": "value8",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

