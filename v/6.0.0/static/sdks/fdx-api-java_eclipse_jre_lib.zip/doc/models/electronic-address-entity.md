
# Electronic Address Entity

Electronic address details

*This model accepts additional fields of type Object.*

## Structure

`ElectronicAddressEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EmailAddressText` | `String` | Optional | Value of the email address | String getEmailAddressText() | setEmailAddressText(String emailAddressText) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "emailAddressText": "emailAddressText4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

