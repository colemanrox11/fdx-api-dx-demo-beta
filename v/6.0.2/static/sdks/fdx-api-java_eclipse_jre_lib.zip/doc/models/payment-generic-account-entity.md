
# Payment Generic Account Entity

Payment Generic Account information

*This model accepts additional fields of type Object.*

## Structure

`PaymentGenericAccountEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `AccountNumber` | `String` | Optional | Unique identifier of the account number<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `AccountType` | [`AccountType`](../../doc/models/account-type.md) | Optional | Account type | AccountType getAccountType() | setAccountType(AccountType accountType) |
| `Name` | `String` | Optional | Account name | String getName() | setName(String name) |
| `CurrencyCode` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | ISO 4217 currency code | Iso4217CurrencyCode getCurrencyCode() | setCurrencyCode(Iso4217CurrencyCode currencyCode) |
| `Id` | [`PaymentGenericAccountEntityId`](../../doc/models/containers/payment-generic-account-entity-id.md) | Optional | This is a container for any-of cases. | PaymentGenericAccountEntityId getId() | setId(PaymentGenericAccountEntityId id) |
| `Branch` | [`BranchEntity1`](../../doc/models/branch-entity-1.md) | Optional | Branch details associated with this account | BranchEntity1 getBranch() | setBranch(BranchEntity1 branch) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountNumber": "accountNumber0",
  "accountType": "SPECIFIEDPENSIONPLAN",
  "name": "name2",
  "currencyCode": "PGK",
  "id": {
    "iban2007Id": "iban2007Id4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

