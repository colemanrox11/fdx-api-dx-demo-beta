
# Debt Class

The classification of a debt instrument

*This model accepts additional fields of type Object.*

## Enumeration

`DebtClass`

## Fields

| Name |
|  --- |
| `Corporate` |
| `Municipal` |
| `Other` |
| `Treasury` |

