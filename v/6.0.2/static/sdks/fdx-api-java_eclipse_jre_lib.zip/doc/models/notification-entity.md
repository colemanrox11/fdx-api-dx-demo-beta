
# Notification Entity

Provides the base fields of a notification. Clients will read the `type` property to determine the expected notification payload

*This model accepts additional fields of type Object.*

## Structure

`NotificationEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NotificationId` | `String` | Required | Id of notification | String getNotificationId() | setNotificationId(String notificationId) |
| `Type` | [`NotificationType`](../../doc/models/notification-type.md) | Required | Type of notification | NotificationType getType() | setType(NotificationType type) |
| `SentOn` | `LocalDateTime` | Required | Time notification was sent | LocalDateTime getSentOn() | setSentOn(LocalDateTime sentOn) |
| `Category` | [`NotificationCategory1`](../../doc/models/notification-category-1.md) | Required | Category of notification | NotificationCategory1 getCategory() | setCategory(NotificationCategory1 category) |
| `Severity` | [`NotificationSeverity2`](../../doc/models/notification-severity-2.md) | Optional | Notification severity | NotificationSeverity2 getSeverity() | setSeverity(NotificationSeverity2 severity) |
| `Priority` | [`NotificationPriority2`](../../doc/models/notification-priority-2.md) | Optional | Notification priority | NotificationPriority2 getPriority() | setPriority(NotificationPriority2 priority) |
| `Publisher` | [`PartyEntity`](../../doc/models/party-entity.md) | Required | Publisher of notification | PartyEntity getPublisher() | setPublisher(PartyEntity publisher) |
| `Subscriber` | [`PartyEntity`](../../doc/models/party-entity.md) | Optional | Subscriber to this notification | PartyEntity getSubscriber() | setSubscriber(PartyEntity subscriber) |
| `NotificationPayload` | [`NotificationPayloadEntity2`](../../doc/models/notification-payload-entity-2.md) | Required | Notification-specific key-value paired data | NotificationPayloadEntity2 getNotificationPayload() | setNotificationPayload(NotificationPayloadEntity2 notificationPayload) |
| `Url` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | URL to retrieve further details related to notification | HateoasLink getUrl() | setUrl(HateoasLink url) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "notificationId": "notificationId4",
  "type": "SERVICE",
  "sentOn": "07/15/2021 14:46:41",
  "category": "SECURITY",
  "publisher": {
    "name": "name2",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "homeUri6",
    "logoUri": "logoUri0",
    "registry": "ICANN",
    "registeredEntityName": "registeredEntityName0",
    "registeredEntityId": "registeredEntityId8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "notificationPayload": {
    "id": "id0",
    "idType": "PARTY",
    "customFields": {
      "name": "name0",
      "value": "value2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "severity": "WARNING",
  "priority": "HIGH",
  "subscriber": {
    "name": "name0",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "homeUri4",
    "logoUri": "logoUri8",
    "registry": "FDX",
    "registeredEntityName": "registeredEntityName8",
    "registeredEntityId": "registeredEntityId0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "url": {
    "href": "href6",
    "action": "POST",
    "rel": "rel0",
    "types": [
      "image/png",
      "image/tiff",
      "application/json"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

