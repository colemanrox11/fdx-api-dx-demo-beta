
# Vesting Entity

Represents the vesting of ownership of an investment account

*This model accepts additional fields of type Object.*

## Structure

`VestingEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `vesting_date` | `Date` | Optional | Vesting date |
| `symbol` | `String` | Optional | Security symbol |
| `strike_price` | `Float` | Optional | Strike price |
| `vesting_percentage` | `Float` | Optional | Vesting percentage |
| `other_vest_amount` | `Float` | Optional | Other vested amount |
| `other_vest_percentage` | `Float` | Optional | Other vested percentage |
| `vested_balance` | `Float` | Optional | Vested balance |
| `un_vested_balance` | `Float` | Optional | Unvested balance |
| `vested_quantity` | `Float` | Optional | Vested quantity |
| `un_vested_quantity` | `Float` | Optional | Unvested quantity |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "vestingDate": "2021-07-15",
  "symbol": "symbol2",
  "strikePrice": 29.46,
  "vestingPercentage": 3.96,
  "otherVestAmount": 120.96,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

