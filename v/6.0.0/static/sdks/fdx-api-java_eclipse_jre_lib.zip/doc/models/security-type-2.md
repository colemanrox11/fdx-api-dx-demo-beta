
# Security Type 2

BOND, DEBT, DIGITALASSET, MUTUALFUND, OPTION, OTHER, STOCK, SWEEP

*This model accepts additional fields of type Object.*

## Enumeration

`SecurityType2`

## Fields

| Name |
|  --- |
| `Bond` |
| `Debt` |
| `Digitalasset` |
| `Mutualfund` |
| `Option` |
| `Other` |
| `Stock` |
| `Sweep` |

