
# Unit Type 1

SHARES, CURRENCY

*This model accepts additional fields of type Object.*

## Enumeration

`UnitType1`

## Fields

| Name |
|  --- |
| `Currency` |
| `Shares` |

