
# Asset Transfer Type

The possible values for type of asset transfer

*This model accepts additional fields of type Object.*

## Enumeration

`AssetTransferType`

## Fields

| Name |
|  --- |
| `CaAton` |
| `UsAcats` |
| `UsDtc` |

