# Resource Information

```go
resourceInformationController := client.ResourceInformationController()
```

## Class Name

`ResourceInformationController`

## Methods

* [Get Resources](../../doc/controllers/resource-information.md#get-resources)
* [Get Resource](../../doc/controllers/resource-information.md#get-resource)


# Get Resources

Retrieve all the resources

```go
GetResources(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    resultType *models.ResultType,
    offset *string,
    limit *int) (
    models.ApiResponse[models.ResourceListEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `resultType` | [`*models.ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `"lightweight"` |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ResourceListEntity](../../doc/models/resource-list-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

resultType := models.ResultType_Lightweight





apiResponse, err := resourceInformationController.GetResources(ctx, xFapiInteractionId, &fdxApiActorType, &resultType, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Resource

Retrieve the details of the identified resource

```go
GetResource(
    ctx context.Context,
    resourceId string,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.ResourceEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resourceId` | `string` | Template, Required | Specific resourceId for which to retrieve details<br><br>**Constraints**: *Maximum Length*: `256` |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.ResourceEntity](../../doc/models/resource-entity.md).

## Example Usage

```go
ctx := context.Background()

resourceId := "resourceId0"

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := resourceInformationController.GetResource(ctx, resourceId, xFapiInteractionId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Required input data not sent | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Resource with provided ID was not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

