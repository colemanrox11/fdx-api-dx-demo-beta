# Fraud Notification

```java
FraudNotificationController fraudNotificationController = client.getFraudNotificationController();
```

## Class Name

`FraudNotificationController`


# Report Suspected Fraud Incident

Notify Data Provider of suspected fraud

```java
CompletableFuture<ApiResponse<Void>> reportSuspectedFraudIncidentAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final SuspectedFraudIncidentEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`SuspectedFraudIncidentEntity`](../../doc/models/suspected-fraud-incident-entity.md) | Body, Optional | - |

## Server

`Server.FRAUD`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
SuspectedFraudIncidentEntity body = new SuspectedFraudIncidentEntity.Builder()
    .type("RISK")
    .suspectedIncidentId("0a318518-ca16-4e66-be76-865a632ea771")
    .reporter(new PartyEntity.Builder(
        "ABC Inc",
        PartyType.DATA_ACCESS_PLATFORM
    )
    .homeUri("http://example.com")
    .logoUri("http://example.com")
    .registry(Registry.FDX)
    .registeredEntityName("ABC")
    .registeredEntityId("ABC123")
    .build())
    .build();

fraudNotificationController.reportSuspectedFraudIncidentAsync(xFapiInteractionId, null, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

