
# Deposit Transaction Type 2

CHECK, WITHDRAWAL, TRANSFER, POSDEBIT, ATMWITHDRAWAL, BILLPAYMENT, FEE, DEPOSIT, ADJUSTMENT, INTEREST, DIVIDEND, DIRECTDEPOSIT, ATMDEPOSIT, POSCREDIT

*This model accepts additional fields of type Object.*

## Enumeration

`DepositTransactionType2`

## Fields

| Name |
|  --- |
| `ADJUSTMENT` |
| `ATMDEPOSIT` |
| `ATMWITHDRAWAL` |
| `BILLPAYMENT` |
| `CHECK` |
| `DEPOSIT` |
| `DIRECTDEPOSIT` |
| `DIVIDEND` |
| `FEE` |
| `INTEREST` |
| `POSCREDIT` |
| `POSDEBIT` |
| `TRANSFER` |
| `WITHDRAWAL` |

