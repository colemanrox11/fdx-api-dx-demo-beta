
# Stock Security Entity

A stock security

*This model accepts additional fields of type Object.*

## Structure

`StockSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `UnitsStreet` | `Double` | Optional | The units in the FI's street name as a positive quantity | Double getUnitsStreet() | setUnitsStreet(Double unitsStreet) |
| `UnitsUser` | `Double` | Optional | The units in user's name directly as a positive quantity | Double getUnitsUser() | setUnitsUser(Double unitsUser) |
| `ReinvestDividends` | `Boolean` | Optional | Selection to reinvest dividends | Boolean getReinvestDividends() | setReinvestDividends(Boolean reinvestDividends) |
| `StockType` | [`StockType2`](../../doc/models/stock-type-2.md) | Optional | COMMON, PREFERRED, CONVERTIBLE, OTHER | StockType2 getStockType() | setStockType(StockType2 stockType) |
| `Yield` | `Double` | Optional | The current yield | Double getYield() | setYield(Double yield) |
| `YieldAsOfDate` | `LocalDate` | Optional | Yield as-of date | LocalDate getYieldAsOfDate() | setYieldAsOfDate(LocalDate yieldAsOfDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "yieldAsOfDate": "2021-07-15",
  "securityCategory": "Stock Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "unitsStreet": 42.06,
  "unitsUser": 168.02,
  "reinvestDividends": false,
  "stockType": "COMMON",
  "yield": 135.68
}
```

