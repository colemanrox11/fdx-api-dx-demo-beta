
# Notification Entity

Provides the base fields of a notification. Clients will read the `type` property to determine the expected notification payload

*This model accepts additional fields of type Object.*

## Structure

`NotificationEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `notification_id` | `String` | Required | Id of notification |
| `type` | [`NotificationType`](../../doc/models/notification-type.md) | Required | Type of notification |
| `sent_on` | `DateTime` | Required | Time notification was sent |
| `category` | [`NotificationCategory1`](../../doc/models/notification-category-1.md) | Required | Category of notification |
| `severity` | [`NotificationSeverity2`](../../doc/models/notification-severity-2.md) | Optional | Notification severity |
| `priority` | [`NotificationPriority2`](../../doc/models/notification-priority-2.md) | Optional | Notification priority |
| `publisher` | [`PartyEntity`](../../doc/models/party-entity.md) | Required | Publisher of notification |
| `subscriber` | [`PartyEntity`](../../doc/models/party-entity.md) | Optional | Subscriber to this notification |
| `notification_payload` | [`NotificationPayloadEntity2`](../../doc/models/notification-payload-entity-2.md) | Required | Notification-specific key-value paired data |
| `url` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | URL to retrieve further details related to notification |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "notificationId": "notificationId4",
  "type": "SERVICE",
  "sentOn": "07/15/2021 14:46:41",
  "category": "SECURITY",
  "publisher": {
    "name": "name2",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "homeUri6",
    "logoUri": "logoUri0",
    "registry": "ICANN",
    "registeredEntityName": "registeredEntityName0",
    "registeredEntityId": "registeredEntityId8",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "notificationPayload": {
    "id": "id0",
    "idType": "PARTY",
    "customFields": {
      "name": "name0",
      "value": "value2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "severity": "WARNING",
  "priority": "HIGH",
  "subscriber": {
    "name": "name0",
    "type": "DATA_ACCESS_PLATFORM",
    "homeUri": "homeUri4",
    "logoUri": "logoUri8",
    "registry": "FDX",
    "registeredEntityName": "registeredEntityName8",
    "registeredEntityId": "registeredEntityId0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "url": {
    "href": "href6",
    "action": "POST",
    "rel": "rel0",
    "types": [
      "image/png",
      "image/tiff",
      "application/json"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

