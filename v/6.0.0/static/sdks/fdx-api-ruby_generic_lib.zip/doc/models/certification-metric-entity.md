
# Certification Metric Entity

A single certification performance metric

*This model accepts additional fields of type Object.*

## Structure

`CertificationMetricEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `report_start_timestamp` | `DateTime` | Optional | When the reported metrics period began |
| `report_end_timestamp` | `DateTime` | Optional | When the reported metrics period ended |
| `metrics_name` | `String` | Optional | Any provider descriptive name for the measurement. Optional, can be omitted if operationIds are returned |
| `operation_ids` | [`Array<FdxResourceOperationId>`](../../doc/models/fdx-resource-operation-id.md) | Optional | One or more Operation IDs for which these metrics apply. Optional, can be omitted if metricsName is returned |
| `response_time_average` | `Float` | Optional | The self-reported average response time in milliseconds for all combined data responses |
| `average_up_time` | `Float` | Optional | See the Certification Performance section that describes how this measurement will be calculated, defines the % of availability during the measurement |
| `report_timestamp` | `DateTime` | Optional | Time when these performance and availability metrics were created |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "reportStartTimestamp": "07/15/2021 14:46:41",
  "reportEndTimestamp": "07/15/2021 14:46:41",
  "reportTimestamp": "07/15/2021 14:46:41",
  "metricsName": "metricsName2",
  "operationIds": [
    "getPaymentsForRecurringPayment",
    "getRecurringPayment"
  ],
  "responseTimeAverage": 130.24,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

