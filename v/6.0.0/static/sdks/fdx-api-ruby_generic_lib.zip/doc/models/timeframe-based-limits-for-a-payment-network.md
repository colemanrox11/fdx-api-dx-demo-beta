
# Timeframe Based Limits for a Payment Network

This provides the time-based limits applied to the account within the payment network

*This model accepts additional fields of type Object.*

## Structure

`TimeframeBasedLimitsForAPaymentNetwork`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resets_on` | `DateTime` | Optional | Date/time at which this timeframe will reset next |
| `transfer_max_amount` | `Float` | Optional | Maximum limit of funds that can be transferred to/from the account in this timeframe |
| `transfer_remaining_amount` | `Float` | Optional | Remaining value of the maximum limit of funds that can be transferred to/from the account in this timeframe |
| `max_occurrence` | `Integer` | Optional | Maximum number of transfers that can be made in this direction for this timeframe |
| `remaining_occurrence` | `Integer` | Optional | Remaining number of transfers that can be made in this direction for this timeframe |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "resetsOn": "2016-03-13T12:52:32.123Z",
  "transferMaxAmount": 33.26,
  "transferRemainingAmount": 124.72,
  "maxOccurrence": 168,
  "remainingOccurrence": 222,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

