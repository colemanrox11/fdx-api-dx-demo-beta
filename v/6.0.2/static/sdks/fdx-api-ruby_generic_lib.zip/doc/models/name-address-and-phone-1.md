
# Name Address and Phone 1

Issuer's information contact name, street address, city or town, state or province, country, ZIP or foreign postal code, and telephone no. (if different from ISSUER)

*This model accepts additional fields of type Object.*

## Structure

`NameAddressAndPhone1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `line_1` | `String` | Optional | Address line 1<br><br>**Constraints**: *Maximum Length*: `64` |
| `line_2` | `String` | Optional | Address line 2<br><br>**Constraints**: *Maximum Length*: `64` |
| `line_3` | `String` | Optional | Address line 3<br><br>**Constraints**: *Maximum Length*: `64` |
| `city` | `String` | Optional | City<br><br>**Constraints**: *Maximum Length*: `64` |
| `region` | `String` | Optional | State, Province, Territory, Canton or Prefecture. From [Universal Postal Union](https://www.upu.int/en/Postal-Solutions/Programmes-Services/Addressing-Solutions#addressing-s42-standard) as of 2-26-2020, [S42 International Address Standards](https://www.upu.int/UPU/media/upu/documents/PostCode/S42_International-Addressing-Standards.pdf). For U.S. addresses can be 2-character code from '#/components/schemas/StateCode'<br><br>**Constraints**: *Maximum Length*: `64` |
| `postal_code` | `String` | Optional | Postal code<br><br>**Constraints**: *Maximum Length*: `16` |
| `country` | [`Iso3166CountryCode`](../../doc/models/iso-3166-country-code.md) | Optional | Country code |
| `name_1` | `String` | Optional | Name line 1<br><br>**Constraints**: *Maximum Length*: `64` |
| `name_2` | `String` | Optional | Name line 2<br><br>**Constraints**: *Maximum Length*: `64` |
| `phone` | [`TelephoneNumberPlusExtension2`](../../doc/models/telephone-number-plus-extension-2.md) | Optional | Phone number |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "line1": "line16",
  "line2": "line28",
  "line3": "line36",
  "city": "city4",
  "region": "region0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

