# Payment Initiation Parties

```java
PaymentInitiationPartiesController paymentInitiationPartiesController = client.getPaymentInitiationPartiesController();
```

## Class Name

`PaymentInitiationPartiesController`

## Methods

* [Create Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#create-payment-initiation-party)
* [List Payment Initiation Parties](../../doc/controllers/payment-initiation-parties.md#list-payment-initiation-parties)
* [Get Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#get-payment-initiation-party)
* [Update Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#update-payment-initiation-party)
* [Delete Payment Initiation Party](../../doc/controllers/payment-initiation-parties.md#delete-payment-initiation-party)
* [Create Payment Method](../../doc/controllers/payment-initiation-parties.md#create-payment-method)
* [Get Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#get-payment-method-registration)
* [Delete Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#delete-payment-method-registration)
* [Update Payment Method Registration](../../doc/controllers/payment-initiation-parties.md#update-payment-method-registration)


# Create Payment Initiation Party

Create a payment initiation party associated with a customer profile

```java
CompletableFuture<ApiResponse<PaymentInitiationPartyCreateResponseEntity>> createPaymentInitiationPartyAsync(
    final UUID xFapiInteractionId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final PaymentInitiationPartyEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaymentInitiationPartyCreateResponseEntity`](../../doc/models/payment-initiation-party-create-response-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String idempotencyKey = "idempotency-key4";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
PaymentInitiationPartyEntity body = new PaymentInitiationPartyEntity.Builder(
    "name6",
    PartyType.MERCHANT
)
.expiresTimestamp(DateTimeHelper.fromRfc8601DateTime("07/15/2021 14:46:41"))
.build();

paymentInitiationPartiesController.createPaymentInitiationPartyAsync(xFapiInteractionId, idempotencyKey, fdxApiActorType, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# List Payment Initiation Parties

Retrieve the payment initiation parties associated with a customer profile

```java
CompletableFuture<ApiResponse<PaymentInitiationPartiesEntity>> listPaymentInitiationPartiesAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaymentInitiationPartiesEntity`](../../doc/models/payment-initiation-parties-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

paymentInitiationPartiesController.listPaymentInitiationPartiesAsync(xFapiInteractionId, fdxApiActorType, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment Initiation Party

Retrieve the payment initiation party details by ID

```java
CompletableFuture<ApiResponse<PaymentInitiationPartyEntity>> getPaymentInitiationPartyAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

paymentInitiationPartiesController.getPaymentInitiationPartyAsync(xFapiInteractionId, paymentInitiationPartyId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment Initiation Party

Update the payment initiation party associated with a customer profile

```java
CompletableFuture<ApiResponse<Void>> updatePaymentInitiationPartyAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final PaymentInitiationPartyEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyEntity`](../../doc/models/payment-initiation-party-entity.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
String idempotencyKey = "idempotency-key4";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
PaymentInitiationPartyEntity body = new PaymentInitiationPartyEntity.Builder(
    "name6",
    PartyType.MERCHANT
)
.expiresTimestamp(DateTimeHelper.fromRfc8601DateTime("07/15/2021 14:46:41"))
.build();

paymentInitiationPartiesController.updatePaymentInitiationPartyAsync(xFapiInteractionId, paymentInitiationPartyId, idempotencyKey, fdxApiActorType, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payment Initiation Party

Remove the payment initiation party associated with a customer profile

```java
CompletableFuture<ApiResponse<Void>> deletePaymentInitiationPartyAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

paymentInitiationPartiesController.deletePaymentInitiationPartyAsync(xFapiInteractionId, paymentInitiationPartyId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Create Payment Method

Registration of a payment initiation party to a payment method

```java
CompletableFuture<ApiResponse<PaymentInitiationPartyMethodCreateResponseEntity>> createPaymentMethodAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final String idempotencyKey,
    final FdxApiActorType fdxApiActorType,
    final PaymentInitiationPartyToPaymentMethodEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `idempotencyKey` | `String` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaymentInitiationPartyMethodCreateResponseEntity`](../../doc/models/payment-initiation-party-method-create-response-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
String idempotencyKey = "idempotency-key4";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
paymentInitiationPartiesController.createPaymentMethodAsync(xFapiInteractionId, paymentInitiationPartyId, idempotencyKey, fdxApiActorType, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Payment Method Registration

Retrieve the details of a payment method registered with a payment initiation party

```java
CompletableFuture<ApiResponse<PaymentInitiationPartyToPaymentMethodEntity>> getPaymentMethodRegistrationAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final String paymentMethodRegistrationId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `paymentMethodRegistrationId` | `String` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
String paymentMethodRegistrationId = "paymentMethodRegistrationId4";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

paymentInitiationPartiesController.getPaymentMethodRegistrationAsync(xFapiInteractionId, paymentInitiationPartyId, paymentMethodRegistrationId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Delete Payment Method Registration

Remove the registered payment method from a payment initiation party

```java
CompletableFuture<ApiResponse<Void>> deletePaymentMethodRegistrationAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final String paymentMethodRegistrationId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `paymentMethodRegistrationId` | `String` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.MONEYMOVEMENT`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
String paymentMethodRegistrationId = "paymentMethodRegistrationId4";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

paymentInitiationPartiesController.deletePaymentMethodRegistrationAsync(xFapiInteractionId, paymentInitiationPartyId, paymentMethodRegistrationId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Update Payment Method Registration

Update the payment method registration associated with payment initiation party

```java
CompletableFuture<ApiResponse<Void>> updatePaymentMethodRegistrationAsync(
    final UUID xFapiInteractionId,
    final String paymentInitiationPartyId,
    final String paymentMethodRegistrationId,
    final FdxApiActorType fdxApiActorType,
    final PaymentInitiationPartyToPaymentMethodEntity body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `paymentInitiationPartyId` | `String` | Template, Required | This is an unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `paymentMethodRegistrationId` | `String` | Template, Required | Registration identifier between a payment initiation party and a payment method<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`PaymentInitiationPartyToPaymentMethodEntity`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Body, Optional | - |

## Server

`Server.MONEYMOVEMENT`

## Response Type

`void`

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String paymentInitiationPartyId = "paymentInitiationPartyId8";
String paymentMethodRegistrationId = "paymentMethodRegistrationId4";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
paymentInitiationPartiesController.updatePaymentMethodRegistrationAsync(xFapiInteractionId, paymentInitiationPartyId, paymentMethodRegistrationId, fdxApiActorType, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

