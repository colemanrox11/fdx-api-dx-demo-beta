
# Tax Refund Direct Deposit

IRS Form 8888 Direct Deposit Information

*This model accepts additional fields of type Object.*

## Structure

`TaxRefundDirectDeposit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `institution_name` | `String` | Optional | Name of institution |
| `rtn` | `String` | Optional | Routing transit number |
| `account_number` | `String` | Optional | Account number |
| `account_nick_name` | `String` | Optional | Account nickname |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "institutionName": "institutionName6",
  "rtn": "rtn0",
  "accountNumber": "accountNumber4",
  "accountNickName": "accountNickName4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

