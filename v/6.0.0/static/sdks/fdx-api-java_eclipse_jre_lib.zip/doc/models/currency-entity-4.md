
# Currency Entity 4

Account currency

*This model accepts additional fields of type Object.*

## Structure

`CurrencyEntity4`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CurrencyRate` | `Double` | Optional | Currency rate between original and converted currency | Double getCurrencyRate() | setCurrencyRate(Double currencyRate) |
| `CurrencyCode` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | ISO 4217 currency code | Iso4217CurrencyCode getCurrencyCode() | setCurrencyCode(Iso4217CurrencyCode currencyCode) |
| `OriginalCurrencyCode` | [`Iso4217CurrencyCode1`](../../doc/models/iso-4217-currency-code-1.md) | Optional | Original ISO 4217 currency code | Iso4217CurrencyCode1 getOriginalCurrencyCode() | setOriginalCurrencyCode(Iso4217CurrencyCode1 originalCurrencyCode) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "currencyRate": 245.5,
  "currencyCode": "GIP",
  "originalCurrencyCode": "XXX",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

