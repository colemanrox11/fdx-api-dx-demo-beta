
# Account Status

The status of an account

*This model accepts additional fields of type Object.*

## Enumeration

`AccountStatus`

## Fields

| Name |
|  --- |
| `Closed` |
| `Delinquent` |
| `Negativecurrentbalance` |
| `Open` |
| `Paid` |
| `Pendingclose` |
| `Pendingopen` |
| `Restricted` |

