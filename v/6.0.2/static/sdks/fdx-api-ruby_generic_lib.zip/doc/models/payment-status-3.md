
# Payment Status 3

Defines the status of the payment

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentStatus3`

## Fields

| Name |
|  --- |
| `CANCELLED` |
| `FAILED` |
| `NOFUNDS` |
| `PROCESSED` |
| `PROCESSING` |
| `SCHEDULED` |

