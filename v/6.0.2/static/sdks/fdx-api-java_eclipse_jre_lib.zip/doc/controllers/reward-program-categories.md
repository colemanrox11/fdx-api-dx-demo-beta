# Reward Program Categories

```java
RewardProgramCategoriesController rewardProgramCategoriesController = client.getRewardProgramCategoriesController();
```

## Class Name

`RewardProgramCategoriesController`


# Get Reward Program Categories

Get reward categories

```java
CompletableFuture<ApiResponse<RewardCategoriesEntity>> getRewardProgramCategoriesAsync(
    final UUID xFapiInteractionId,
    final String rewardProgramId,
    final FdxApiActorType fdxApiActorType,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `rewardProgramId` | `String` | Template, Required | Reward Program Identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RewardCategoriesEntity`](../../doc/models/reward-categories-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String rewardProgramId = "rewardProgramId6";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

rewardProgramCategoriesController.getRewardProgramCategoriesAsync(xFapiInteractionId, rewardProgramId, fdxApiActorType, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "categories": [
    {
      "categoryName": "Amusement Park",
      "categoryId": 100,
      "multiplier": 1,
      "description": "The Amusement Park category, including zoos, circuses and aquariums, covers establishments that operate parks or carnivals and offer mechanical rides and games and/or live animal shows."
    },
    {
      "categoryName": "Dining/Restaurant",
      "categoryId": 101,
      "multiplier": 2,
      "description": "Merchants in the Dining/Restaurant category range from fast food restaurants to fine dining establishments. They fall into the Dining category if they primarily prepare food and drinks for immediate consumption on the premises or for take-out. Dining merchants include bars, cocktail lounges, nightclubs, taverns and fast-food restaurants. Some merchants that sell food and drinks are located within larger establishments that sell other goods and services and may not be not included in this category. For example a department store or hotel restaurant, theme park cafes or discount store food counter would not be categorized under Dining."
    },
    {
      "categoryName": "Entertainment",
      "categoryId": 102,
      "multiplier": 2,
      "description": "Entertainment includes purchases made at sports promoters, movie theaters, theatrical promoters, amusement parks, tourist attractions, record stores and video rentals."
    },
    {
      "categoryName": "Hotels",
      "categoryId": 103,
      "multiplier": 5,
      "description": "Hotels include businesses that provide sleeping or meeting room accommodations. Some goods and services that appear on a hotel bill are included. Often restaurants in hotels are categorized as a hotel purchase."
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Request is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

