
# Statement Entity

An account statement

*This model accepts additional fields of type Object.*

## Structure

`StatementEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_id` | `String` | Optional | Corresponds to accountId in Account entity<br><br>**Constraints**: *Maximum Length*: `256` |
| `statement_id` | `String` | Optional | Long-term persistent identity of the statement<br><br>**Constraints**: *Maximum Length*: `256` |
| `statement_date` | `Date` | Optional | Date of the statement |
| `description` | `String` | Optional | Description of statement |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | The links to retrieve this account statement, or to invoke other APIs |
| `status` | [`DocumentStatus2`](../../doc/models/document-status-2.md) | Optional | Availability status of statement |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "statementDate": "2021-07-15",
  "accountId": "accountId8",
  "statementId": "statementId2",
  "description": "description8",
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

