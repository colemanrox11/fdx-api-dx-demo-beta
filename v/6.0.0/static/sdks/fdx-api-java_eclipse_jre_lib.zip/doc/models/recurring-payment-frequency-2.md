
# Recurring Payment Frequency 2

Defines how often the payment repeats

*This model accepts additional fields of type Object.*

## Enumeration

`RecurringPaymentFrequency2`

## Fields

| Name |
|  --- |
| `Weekly` |
| `Biweekly` |
| `Twicemonthly` |
| `Monthly` |
| `Fourweeks` |
| `Bimonthly` |
| `Quarterly` |
| `Semiannually` |
| `Annually` |

