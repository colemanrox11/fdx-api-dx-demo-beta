
# Debt Class

The classification of a debt instrument

*This model accepts additional fields of type Object.*

## Enumeration

`DebtClass`

## Fields

| Name |
|  --- |
| `CORPORATE` |
| `MUNICIPAL` |
| `OTHER` |
| `TREASURY` |

