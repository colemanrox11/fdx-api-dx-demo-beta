
# Payment Details Entity

Breakdown of payment details

*This model accepts additional fields of type Object.*

## Structure

`PaymentDetailsEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `principal_amount` | `Float` | Optional | The amount of payment applied to principal |
| `interest_amount` | `Float` | Optional | The amount of payment applied to interest |
| `insurance_amount` | `Float` | Optional | The amount of payment applied to life/health/accident insurance on the loan |
| `escrow_amount` | `Float` | Optional | The amount of payment applied to escrow |
| `pmi_amount` | `Float` | Optional | The amount of payment applied to PMI |
| `fees_amount` | `Float` | Optional | The amount of payment applied to fees |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "principalAmount": 241.1,
  "interestAmount": 61.42,
  "insuranceAmount": 189.54,
  "escrowAmount": 210.84,
  "pmiAmount": 88.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

