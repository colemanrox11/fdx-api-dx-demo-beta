
# Debt Security Entity

An investment in a debt security

*This model accepts additional fields of type Object.*

## Structure

`DebtSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `par_value` | `Float` | Optional | Par value amount |
| `debt_type` | [`DebtType2`](../../doc/models/debt-type-2.md) | Optional | Debt type. One of COUPON, ZERO |
| `debt_class` | [`DebtClass2`](../../doc/models/debt-class-2.md) | Optional | Classification of debt. One of TREASURY, MUNICIPAL, CORPORATE, OTHER |
| `coupon_rate` | `Float` | Optional | Bond coupon rate for next closest call date |
| `coupon_date` | `Date` | Optional | Maturity date for next coupon |
| `coupon_mature_frequency` | [`CouponMatureFrequency2`](../../doc/models/coupon-mature-frequency-2.md) | Optional | When coupons mature. One of MONTHLY, QUARTERLY,  SEMIANNUAL, ANNUAL, OTHER |
| `call_price` | `Float` | Optional | Bond call price |
| `yield_to_call` | `Float` | Optional | Yield to next call |
| `call_date` | `Date` | Optional | Next call date |
| `call_type` | [`CallType2`](../../doc/models/call-type-2.md) | Optional | Type of next call. One of CALL, PUT, PREFUND, MATURITY |
| `yield_to_maturity` | `Float` | Optional | Yield to maturity |
| `bond_maturity_date` | `Date` | Optional | Bond maturity date |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "couponDate": "2021-07-15",
  "callDate": "2021-07-15",
  "bondMaturityDate": "2021-07-15",
  "securityCategory": "Debt Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parValue": 174.38,
  "debtType": "COUPON",
  "debtClass": "OTHER",
  "couponRate": 72.78
}
```

