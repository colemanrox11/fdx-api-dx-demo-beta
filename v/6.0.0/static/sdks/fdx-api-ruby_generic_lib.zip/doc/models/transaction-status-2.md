
# Transaction Status 2

PENDING, MEMO, POSTED, AUTHORIZATION

*This model accepts additional fields of type Object.*

## Enumeration

`TransactionStatus2`

## Fields

| Name |
|  --- |
| `AUTHORIZATION` |
| `MEMO` |
| `PENDING` |
| `POSTED` |

