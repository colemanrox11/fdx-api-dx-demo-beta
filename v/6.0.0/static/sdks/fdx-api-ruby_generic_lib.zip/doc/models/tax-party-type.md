
# Tax Party Type

Whether the tax legal entity is a business or an individual

*This model accepts additional fields of type Object.*

## Enumeration

`TaxPartyType`

## Fields

| Name |
|  --- |
| `BUSINESS` |
| `INDIVIDUAL` |

