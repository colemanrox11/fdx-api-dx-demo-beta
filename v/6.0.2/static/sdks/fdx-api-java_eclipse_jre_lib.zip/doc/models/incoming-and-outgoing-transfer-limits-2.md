
# Incoming and Outgoing Transfer Limits 2

The amount limits for transfers

*This model accepts additional fields of type Object.*

## Structure

`IncomingAndOutgoingTransferLimits2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Out` | [`TimeAndOccurrenceBasedTransferLimits3`](../../doc/models/time-and-occurrence-based-transfer-limits-3.md) | Optional | Limits for outgoing transfers from the account | TimeAndOccurrenceBasedTransferLimits3 getOut() | setOut(TimeAndOccurrenceBasedTransferLimits3 out) |
| `In` | [`TimeAndOccurrenceBasedTransferLimits1`](../../doc/models/time-and-occurrence-based-transfer-limits-1.md) | Optional | Limits for incoming transfers to the account | TimeAndOccurrenceBasedTransferLimits1 getIn() | setIn(TimeAndOccurrenceBasedTransferLimits1 in) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "out": {
    "day": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 108.3,
      "transferRemainingAmount": 199.76,
      "maxOccurrence": 168,
      "remainingOccurrence": 46,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "week": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 238.72,
      "transferRemainingAmount": 74.18,
      "maxOccurrence": 102,
      "remainingOccurrence": 32,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "month": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 46.02,
      "transferRemainingAmount": 137.48,
      "maxOccurrence": 172,
      "remainingOccurrence": 218,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "year": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 25.7,
      "transferRemainingAmount": 117.16,
      "maxOccurrence": 156,
      "remainingOccurrence": 234,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "transaction": {
      "transferMaxAmount": 238.5,
      "transferRemainingAmount": 73.96,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "in": {
    "day": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 108.3,
      "transferRemainingAmount": 199.76,
      "maxOccurrence": 168,
      "remainingOccurrence": 46,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "week": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 238.72,
      "transferRemainingAmount": 74.18,
      "maxOccurrence": 102,
      "remainingOccurrence": 32,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "month": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 46.02,
      "transferRemainingAmount": 137.48,
      "maxOccurrence": 172,
      "remainingOccurrence": 218,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "year": {
      "resetsOn": "2016-03-13T12:52:32.123Z",
      "transferMaxAmount": 25.7,
      "transferRemainingAmount": 117.16,
      "maxOccurrence": 156,
      "remainingOccurrence": 234,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "transaction": {
      "transferMaxAmount": 238.5,
      "transferRemainingAmount": 73.96,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

