
# Payment Frequency

The frequency of payments

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentFrequency`

## Fields

| Name |
|  --- |
| `ANNUALLY` |
| `BIWEEKLY` |
| `DAILY` |
| `MONTHLY` |
| `SEMIANNUALLY` |
| `SEMIMONTHLY` |
| `WEEKLY` |

