
# Generic Financial Institution Id Entity

Generic financial institution identifier entity

*This model accepts additional fields of type Object.*

## Structure

`GenericFinancialInstitutionIdEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `fi_id` | `String` | Optional | Financial institution identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `issuer_name` | `String` | Optional | Issuer name |
| `id_scheme` | [External Financial Institution Id Scheme entity](../../doc/models/external-financial-institution-id-scheme-entity.md) \| [Proprietary Financial Institution Id Scheme entity](../../doc/models/proprietary-financial-institution-id-scheme-entity.md) \| nil | Optional | This is a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "fiId": "fiId4",
  "issuerName": "issuerName0",
  "idScheme": {
    "idCode": "idCode6",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

