
# Employer Entity 1

The employer for the job/position

*This model accepts additional fields of type Object.*

## Structure

`EmployerEntity1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `employer_id` | `String` | Optional | Provider's long-term persistent id for the employer<br><br>**Constraints**: *Maximum Length*: `256` |
| `name` | [`BusinessName`](../../doc/models/business-name.md) | Required | The employer's name |
| `dbas` | `Array<String>` | Optional | Array of Doing Business As names for this employer |
| `tax_id` | `String` | Optional | Country specific Tax Id associated with this employer (FEIN in USA or BN in Canada) |
| `tax_id_country` | [`Iso3166CountryCode`](../../doc/models/iso-3166-country-code.md) | Optional | Country originating the employer's taxId element |
| `contacts` | [`ContactsEntity`](../../doc/models/contacts-entity.md) | Optional | Employer's various contact information |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "employerId": "employerId0",
  "name": {
    "name1": "name10",
    "name2": "name24",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "dbas": [
    "dbas7",
    "dbas8"
  ],
  "taxId": "taxId4",
  "taxIdCountry": "TL",
  "contacts": {
    "emails": [
      "emails7",
      "emails8",
      "emails9"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

