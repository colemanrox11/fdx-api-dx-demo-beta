
# External Financial Institution Id Scheme Entity

External financial institution identification scheme

*This model accepts additional fields of type Object.*

## Structure

`ExternalFinancialInstitutionIdSchemeEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `IdCode` | `String` | Optional | Identification code<br><br>**Constraints**: *Maximum Length*: `256` | String getIdCode() | setIdCode(String idCode) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "idCode": "idCode6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

