
# Secured 2

How the option is secured. One of NAKED, COVERED

*This model accepts additional fields of type Object.*

## Enumeration

`Secured2`

## Fields

| Name |
|  --- |
| `COVERED` |
| `NAKED` |

