
# Consent Update Reason 1

The reason for consent revocation

*This model accepts additional fields of type Object.*

## Enumeration

`ConsentUpdateReason1`

## Fields

| Name |
|  --- |
| `BUSINESS_RULE` |
| `USER_ACTION` |

