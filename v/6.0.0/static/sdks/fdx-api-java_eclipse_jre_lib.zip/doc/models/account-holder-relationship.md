
# Account Holder Relationship

Type of relationship to the account

*This model accepts additional fields of type Object.*

## Enumeration

`AccountHolderRelationship`

## Fields

| Name |
|  --- |
| `AuthorizedUser` |
| `Business` |
| `ForBenefitOf` |
| `ForBenefitOfPrimary` |
| `ForBenefitOfPrimaryJointRestricted` |
| `ForBenefitOfSecondary` |
| `ForBenefitOfSecondaryJointRestricted` |
| `ForBenefitOfSoleOwnerRestricted` |
| `PowerOfAttorney` |
| `Primary` |
| `PrimaryBorrower` |
| `PrimaryJoint` |
| `PrimaryJointTenants` |
| `Secondary` |
| `SecondaryBorrower` |
| `SecondaryJoint` |
| `SecondaryJointTenants` |
| `SoleOwner` |
| `Trustee` |
| `UniformTransferToMinor` |

