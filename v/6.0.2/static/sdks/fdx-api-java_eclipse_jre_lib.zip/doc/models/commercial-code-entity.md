
# Commercial Code Entity

The code for a specific treasury management defined field.
The [X9 BTRS/BTR3 standard](https://x9.org/standards/btrs/) (formerly named BAI2) for corporate and treasury data elements is proposed to provide the basis of (or starting point for) representing summary, account, and transaction codes for the Corp/Treasury Entity, subject to any necessary modifications useful to the members of the FDX consortium and users of the API specification

*This model accepts additional fields of type Object.*

## Structure

`CommercialCodeEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TreasuryManagementType`](../../doc/models/treasury-management-type.md) | Optional | The source of Treasury Management account definition; one of BAI, BTRS, ISO, SWIFT | TreasuryManagementType getType() | setType(TreasuryManagementType type) |
| `Code` | `String` | Optional | The code of the Treasury Management defined field | String getCode() | setCode(String code) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "ISO",
  "code": "code2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

