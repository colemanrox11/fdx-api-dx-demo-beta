
# Synchronizable Array Entity

Base class for results that can be synchronized over time. A synchronizable array is also paginated

*This model accepts additional fields of type Object.*

## Structure

`SynchronizableArrayEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets | PageMetadata getPage() | setPage(PageMetadata page) |
| `Updates` | [`UpdatesMetadataEntity2`](../../doc/models/updates-metadata-entity-2.md) | Optional | Update IDs for retrieving updates since query | UpdatesMetadataEntity2 getUpdates() | setUpdates(UpdatesMetadataEntity2 updates) |
| `Links` | [`SynchronizableArrayLinksEntity2`](../../doc/models/synchronizable-array-links-entity-2.md) | Optional | Resource URLs for navigating result sets | SynchronizableArrayLinksEntity2 getLinks() | setLinks(SynchronizableArrayLinksEntity2 links) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "updates": {
    "nextUpdateId": "nextUpdateId4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "updates": {
      "href": "href2",
      "action": "PATCH",
      "rel": "rel6",
      "types": [
        "image/jpeg"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

