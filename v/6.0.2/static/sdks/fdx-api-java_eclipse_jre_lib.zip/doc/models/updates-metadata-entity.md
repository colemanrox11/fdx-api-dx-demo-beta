
# Updates Metadata Entity

Change IDs for synchronizable result sets

*This model accepts additional fields of type Object.*

## Structure

`UpdatesMetadataEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `NextUpdateId` | `String` | Optional | Opaque identifier. Does not need to be numeric or have any specific pattern. Implementation specific<br><br>**Constraints**: *Maximum Length*: `256` | String getNextUpdateId() | setNextUpdateId(String nextUpdateId) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "nextUpdateId": "nextUpdateId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

