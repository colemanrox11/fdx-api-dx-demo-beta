
# Debit Credit Memo

The posting type of a transaction

*This model accepts additional fields of type Object.*

## Enumeration

`DebitCreditMemo`

## Fields

| Name |
|  --- |
| `Credit` |
| `Debit` |
| `Memo` |

