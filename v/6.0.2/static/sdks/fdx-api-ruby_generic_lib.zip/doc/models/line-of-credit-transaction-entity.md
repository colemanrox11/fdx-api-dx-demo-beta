
# Line of Credit Transaction Entity

A line of credit transaction

*This model accepts additional fields of type Object.*

## Structure

`LineOfCreditTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_type` | [`LineOfCreditTransactionType2`](../../doc/models/line-of-credit-transaction-type-2.md) | Optional | CHECK, WITHDRAWAL, PAYMENT, FEE, ADJUSTMENT, INTEREST, PURCHASE |
| `check_number` | `Integer` | Optional | Check number |
| `payment_details` | [`PaymentDetailsEntity`](../../doc/models/payment-details-entity.md) | Optional | Breakdown of payment details |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountCategory": "Line of Credit Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "FEE",
  "checkNumber": 8,
  "paymentDetails": {
    "principalAmount": 147.58,
    "interestAmount": 32.1,
    "insuranceAmount": 96.02,
    "escrowAmount": 117.32,
    "pmiAmount": 250.6,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  }
}
```

