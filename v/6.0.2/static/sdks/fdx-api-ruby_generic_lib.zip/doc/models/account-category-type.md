
# Account Category Type

The category of account

*This model accepts additional fields of type Object.*

## Enumeration

`AccountCategoryType`

## Fields

| Name |
|  --- |
| `ANNUITY_ACCOUNT` |
| `COMMERCIAL_ACCOUNT` |
| `DEPOSIT_ACCOUNT` |
| `DIGITAL_WALLET` |
| `INSURANCE_ACCOUNT` |
| `INVESTMENT_ACCOUNT` |
| `LOAN_ACCOUNT` |
| `LOC_ACCOUNT` |

