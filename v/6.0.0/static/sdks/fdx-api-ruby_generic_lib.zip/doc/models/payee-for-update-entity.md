
# Payee for Update Entity

Payee's fields to be updated

*This model accepts additional fields of type Object.*

## Structure

`PayeeForUpdateEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `merchant` | [`MerchantForUpdateEntity1`](../../doc/models/merchant-for-update-entity-1.md) | Required | When payee is a merchant, typically a business from which goods or services are rendered, this field will be populated |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "merchant": {
    "displayName": "displayName2",
    "name": {
      "first": "first6",
      "middle": "middle6",
      "last": "last0",
      "suffix": "suffix0",
      "prefix": "prefix8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "address": {
      "line1": "line18",
      "line2": "line20",
      "line3": "line38",
      "city": "city6",
      "region": "region2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "phone": {
      "type": "BUSINESS",
      "country": "country4",
      "number": "number8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "merchantAccountIds": [
      "merchantAccountIds6"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

