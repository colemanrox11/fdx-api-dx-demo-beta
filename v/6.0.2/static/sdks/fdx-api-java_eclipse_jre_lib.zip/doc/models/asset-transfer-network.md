
# Asset Transfer Network

Information required to facilitate asset transfer from this account

*This model accepts additional fields of type Object.*

## Structure

`AssetTransferNetwork`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Identifier` | `String` | Optional | The number used to identify the account within the asset transfer network. If identifierType is ACCOUNT_NUMBER, this is the account number; if identifierType is TOKENIZED_ACCOUNT_NUMBER, this is a tokenized account number | String getIdentifier() | setIdentifier(String identifier) |
| `IdentifierType` | [`PaymentNetworkIdentifierType1`](../../doc/models/payment-network-identifier-type-1.md) | Optional | Type of identifier | PaymentNetworkIdentifierType1 getIdentifierType() | setIdentifierType(PaymentNetworkIdentifierType1 identifierType) |
| `InstitutionName` | `String` | Optional | The name of the institution holding the account | String getInstitutionName() | setInstitutionName(String institutionName) |
| `InstitutionId` | `String` | Optional | Institution identifier used by the asset transfer network ie. the Depository Trust and Clearing Corporation code for the institution holding the account | String getInstitutionId() | setInstitutionId(String institutionId) |
| `Type` | [`AssetTransferType2`](../../doc/models/asset-transfer-type-2.md) | Optional | Type of asset transfer | AssetTransferType2 getType() | setType(AssetTransferType2 type) |
| `JointAccount` | `Boolean` | Optional | Whether this account has joint owners | Boolean getJointAccount() | setJointAccount(Boolean jointAccount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "identifier": "identifier0",
  "identifierType": "ACCOUNT_NUMBER",
  "institutionName": "institutionName0",
  "institutionId": "institutionId6",
  "type": "CA_ATON",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

