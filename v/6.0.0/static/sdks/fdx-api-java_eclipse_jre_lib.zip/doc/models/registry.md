
# Registry

The registry containing the party's registration with name and id: FDX, GLEIF, ICANN, PRIVATE

*This model accepts additional fields of type Object.*

## Enumeration

`Registry`

## Fields

| Name |
|  --- |
| `Fdx` |
| `Gleif` |
| `Icann` |
| `Private` |

