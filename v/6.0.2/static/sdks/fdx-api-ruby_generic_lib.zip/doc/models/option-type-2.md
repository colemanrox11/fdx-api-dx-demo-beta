
# Option Type 2

Option type. One of PUT, CALL

*This model accepts additional fields of type Object.*

## Enumeration

`OptionType2`

## Fields

| Name |
|  --- |
| `CALL` |
| `PUT` |

