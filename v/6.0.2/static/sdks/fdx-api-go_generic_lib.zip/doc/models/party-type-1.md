
# Party Type 1

The party initiating consent revocation

*This model accepts additional fields of type interface{}.*

## Enumeration

`PartyType1`

## Fields

| Name |
|  --- |
| `DataAccessPlatform` |
| `DataProvider` |
| `DataRecipient` |
| `Individual` |
| `Merchant` |
| `Vendor` |

