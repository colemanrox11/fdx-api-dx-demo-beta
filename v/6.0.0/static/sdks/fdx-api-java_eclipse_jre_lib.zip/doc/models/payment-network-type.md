
# Payment Network Type

Suggested values for Payment Network Type.

| Value | Description |
|-----|-----|
| CA_ACSS | Automated Clearing House Settlement System |
| CA_LVTS | Large-Value Transfer System |
| US_ACH | Automated Clearing House |
| US_CHIPS | Clearinghouse Interbank Payments System |
| US_FEDNOW | Federal Reserve Instant Payment System |
| US_FEDWIRE | Fedwire Funds Service |
| US_RTP | US Real Time Payments System |

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentNetworkType`

## Fields

| Name |
|  --- |
| `CaAcss` |
| `CaLvts` |
| `UsAch` |
| `UsChips` |
| `UsFednow` |
| `UsFedwire` |
| `UsRtp` |

