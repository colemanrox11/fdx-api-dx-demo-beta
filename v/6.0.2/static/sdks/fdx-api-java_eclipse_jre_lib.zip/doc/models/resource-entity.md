
# Resource Entity

Details of resource entity

*This model accepts additional fields of type Object.*

## Structure

`ResourceEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ResourceId` | `String` | Optional | Long-term persistent identifier for the Resource<br><br>**Constraints**: *Maximum Length*: `256` | String getResourceId() | setResourceId(String resourceId) |
| `Status` | [`ResourceStatus2`](../../doc/models/resource-status-2.md) | Optional | Status of Resource | ResourceStatus2 getStatus() | setStatus(ResourceStatus2 status) |
| `Description` | `String` | Optional | Description of resource | String getDescription() | setDescription(String description) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this resource, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "resourceId": "resourceId6",
  "status": "IN_PROGRESS",
  "description": "description6",
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

