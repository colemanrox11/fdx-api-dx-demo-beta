
# Security Type

The type of a security

| Value | Description |
|-----|-----|
| BOND | Debt security as a loan to a government, agency or company, repaid with interest |
| DEBT | Any type of security that must be paid back in full along with interest |
| DIGITALASSET | Digital representation of an asset or right that is stored and transferred on a digital network such as the internet or a blockchain |
| MUTUALFUND | Pooled collection of assets invested in stocks, bonds, and other securities |
| OPTION | The right to buy a specific number of stock shares at a pre-set price |
| OTHER | Another type of security not listed here |
| STOCK | A share in the ownership of a company |
| SWEEP | Interest-earning account used to collect low- or non-interest-earning cash at close of day |

*This model accepts additional fields of type Object.*

## Enumeration

`SecurityType`

## Fields

| Name |
|  --- |
| `BOND` |
| `DEBT` |
| `DIGITALASSET` |
| `MUTUALFUND` |
| `OPTION` |
| `OTHER` |
| `STOCK` |
| `SWEEP` |

