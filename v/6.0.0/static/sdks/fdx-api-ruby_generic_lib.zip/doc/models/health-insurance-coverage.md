
# Health Insurance Coverage

Used on Form 1095-A Part III

*This model accepts additional fields of type Object.*

## Structure

`HealthInsuranceCoverage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enrollment_premium` | `Float` | Optional | Monthly enrollment premiums |
| `slcsp_premium` | `Float` | Optional | Monthly second lowest cost silver plan (SLCSP) premium |
| `advance_premium_tax_credit_payment` | `Float` | Optional | Monthly advance payment of premium tax credit |
| `month` | [`CoverageMonth3`](../../doc/models/coverage-month-3.md) | Optional | Month of coverage |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "enrollmentPremium": 139.74,
  "slcspPremium": 163.34,
  "advancePremiumTaxCreditPayment": 197.06,
  "month": "MAY",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

