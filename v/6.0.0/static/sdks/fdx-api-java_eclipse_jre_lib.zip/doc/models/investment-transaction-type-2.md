
# Investment Transaction Type 2

PURCHASED, SOLD, PURCHASEDTOCOVER, ADJUSTMENT, PURCHASETOOPEN, PURCHASETOCLOSE, SOLDTOOPEN, SOLDTOCLOSE, INTEREST, MARGININTEREST, REINVESTOFINCOME, RETURNOFCAPITAL, TRANSFER, CONTRIBUTION, FEE, OPTIONEXERCISE, OPTIONEXPIRATION, DIVIDEND, DIVIDENDREINVEST, SPLIT, CLOSURE, INCOME, EXPENSE, CLOSUREOPT, INVEXPENSE, JRNLSEC, JRNLFUND, OTHER, DIV, SRVCHG, DEP, DEPOSIT, ATM, POS, XFER, CHECK, PAYMENT, CASH, DIRECTDEP, DIRECTDEBIT, REPEATPMT

*This model accepts additional fields of type Object.*

## Enumeration

`InvestmentTransactionType2`

## Fields

| Name |
|  --- |
| `Adjustment` |
| `Airdrop` |
| `Atm` |
| `Cash` |
| `Check` |
| `Closure` |
| `Closureopt` |
| `Contribution` |
| `Dep` |
| `Deposit` |
| `Directdebit` |
| `Directdep` |
| `Div` |
| `Dividend` |
| `Dividendreinvest` |
| `Expense` |
| `Fee` |
| `Forked` |
| `Income` |
| `Interest` |
| `Invexpense` |
| `Jrnlfund` |
| `Jrnlsec` |
| `Margininterest` |
| `Mined` |
| `Optionexercise` |
| `Optionexpiration` |
| `Other` |
| `Payment` |
| `Pos` |
| `Purchased` |
| `Purchasedtocover` |
| `Purchasetoclose` |
| `Purchasetoopen` |
| `Reinvestofincome` |
| `Repeatpmt` |
| `Returnofcapital` |
| `Sold` |
| `Soldtoclose` |
| `Soldtoopen` |
| `Split` |
| `Srvchg` |
| `Staked` |
| `Transfer` |
| `Withdrawal` |
| `Xfer` |

