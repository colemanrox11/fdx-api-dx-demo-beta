
# Transaction Reward Entity

Rewards earned on a transaction

*This model accepts additional fields of type Object.*

## Structure

`TransactionRewardEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CategoryId` | `String` | Optional | Long term persistent identity of the reward category. This ID is mapped to a category definition returned by calling the getRewardProgramCategories operation<br><br>**Constraints**: *Maximum Length*: `256` | String getCategoryId() | setCategoryId(String categoryId) |
| `Accrued` | `Double` | Optional | Reward units accrued on this transaction | Double getAccrued() | setAccrued(Double accrued) |
| `Adjusted` | `Double` | Optional | Reward units adjusted on this transaction | Double getAdjusted() | setAdjusted(Double adjusted) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "categoryId": "categoryId4",
  "accrued": 156.12,
  "adjusted": 104.46,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

