
# Month Abbreviation 1

Month

*This model accepts additional fields of type Object.*

## Enumeration

`MonthAbbreviation1`

## Fields

| Name |
|  --- |
| `JAN` |
| `FEB` |
| `MAR` |
| `APR` |
| `MAY` |
| `JUN` |
| `JUL` |
| `AUG` |
| `SEP` |
| `OCT` |
| `NOV` |
| `DEC` |

