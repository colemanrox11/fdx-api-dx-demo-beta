
# Payment Details Entity

Breakdown of payment details

*This model accepts additional fields of type Object.*

## Structure

`PaymentDetailsEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `PrincipalAmount` | `Double` | Optional | The amount of payment applied to principal | Double getPrincipalAmount() | setPrincipalAmount(Double principalAmount) |
| `InterestAmount` | `Double` | Optional | The amount of payment applied to interest | Double getInterestAmount() | setInterestAmount(Double interestAmount) |
| `InsuranceAmount` | `Double` | Optional | The amount of payment applied to life/health/accident insurance on the loan | Double getInsuranceAmount() | setInsuranceAmount(Double insuranceAmount) |
| `EscrowAmount` | `Double` | Optional | The amount of payment applied to escrow | Double getEscrowAmount() | setEscrowAmount(Double escrowAmount) |
| `PmiAmount` | `Double` | Optional | The amount of payment applied to PMI | Double getPmiAmount() | setPmiAmount(Double pmiAmount) |
| `FeesAmount` | `Double` | Optional | The amount of payment applied to fees | Double getFeesAmount() | setFeesAmount(Double feesAmount) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "principalAmount": 241.1,
  "interestAmount": 61.42,
  "insuranceAmount": 189.54,
  "escrowAmount": 210.84,
  "pmiAmount": 88.12,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

