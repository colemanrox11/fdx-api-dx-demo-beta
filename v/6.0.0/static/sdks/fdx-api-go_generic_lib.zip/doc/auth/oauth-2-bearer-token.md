
# OAuth 2 Bearer token



Documentation for accessing and setting credentials for bearerAuth.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| accessToken | `string` | The OAuth 2.0 Access Token to use for API requests. | `WithAccessToken` | `AccessToken()` |



**Note:** Required auth credentials can be set using `WithBearerAuthCredentials()` by providing a credentials instance with `NewBearerAuthCredentials()` in the configuration initialization and accessed using the `BearerAuthCredentials()` method in the configuration instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```go
package main

import (
    "fdxApi"
)

func main() {
    client := fdxApi.NewClient(
    fdxApi.CreateConfiguration(
            fdxApi.WithBearerAuthCredentials(
                fdxApi.NewBearerAuthCredentials("AccessToken"),
            ),
        ),
    )
}
```


