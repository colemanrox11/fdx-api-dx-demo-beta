
# Holding Sub Type 2

MONEYMARKET, CASH

*This model accepts additional fields of type Object.*

## Enumeration

`HoldingSubType2`

## Fields

| Name |
|  --- |
| `CASH` |
| `MONEYMARKET` |

