
# Mutual Fund Security Entity

A mutual fund

*This model accepts additional fields of type Object.*

## Structure

`MutualFundSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mutual_fund_type` | [`MutualFundType2`](../../doc/models/mutual-fund-type-2.md) | Optional | Mutual fund type. One of OPENEND, CLOSEEND, OTHER |
| `units_street` | `Float` | Optional | Units in the FI's street name, positive quantity |
| `units_user` | `Float` | Optional | Units in user's name directly, positive  quantity |
| `reinvest_dividends` | `TrueClass \| FalseClass` | Optional | Reinvest dividends |
| `reinvest_capital_gains` | `TrueClass \| FalseClass` | Optional | Reinvest capital gains |
| `myield` | `Float` | Optional | Current yield reported as portion of the fund's assets |
| `yield_as_of_date` | `Date` | Optional | As-of date for yield value |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "yieldAsOfDate": "2021-07-15",
  "securityCategory": "Mutual Fund Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "mutualFundType": "OTHER",
  "unitsStreet": 19.58,
  "unitsUser": 190.5,
  "reinvestDividends": false,
  "reinvestCapitalGains": false
}
```

