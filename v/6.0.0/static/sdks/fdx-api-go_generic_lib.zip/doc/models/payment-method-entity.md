
# Payment Method Entity

A method of payment, also known as a payment type or payment rail

*This model accepts additional fields of type interface{}.*

## Structure

`PaymentMethodEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentMethodId` | `*string` | Optional | Unique identifier of the payment method |
| `ExternalLocalInstrument1Code` | `*string` | Optional | Unique identifier code of the payment method rail as documented<br>internally to the FI. This is aligned with ISO 20022 pain.001,<br>transaction level |
| `ExternalClearingSystemIdentification1Code` | `*string` | Optional | Unique identifier code of the external clearing system.<br>This is aligned with ISO 20022 pacs.008 group level. It can be<br>used to send the payment rail for the payment. ISO has already<br>listed codes in the fields which indicates the payment rail like<br>"ACH" for ACH, "ACS" for EFT Payments, "LVT" for Canada LVTS,<br>"LYX" for Lynx Canada, etc. |
| `ExternalClearingSystemIdentification1Proprietary` | `*string` | Optional | For few examples where the payment rail is not part of the ISO 20022 scope |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "paymentMethodId": "paymentMethodId8",
  "externalLocalInstrument1Code": "externalLocalInstrument1Code4",
  "externalClearingSystemIdentification1Code": "externalClearingSystemIdentification1Code2",
  "externalClearingSystemIdentification1Proprietary": "externalClearingSystemIdentification1Proprietary4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

