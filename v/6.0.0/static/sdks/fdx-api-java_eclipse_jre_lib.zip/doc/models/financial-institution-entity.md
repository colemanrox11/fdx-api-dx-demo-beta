
# Financial Institution Entity

Details of the Financial Institution that is owning the destination account

*This model accepts additional fields of type Object.*

## Structure

`FinancialInstitutionEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the financial institution | String getName() | setName(String name) |
| `FiId` | [`FinancialInstitutionEntityFiId`](../../doc/models/containers/financial-institution-entity-fi-id.md) | Optional | This is a container for any-of cases. | FinancialInstitutionEntityFiId getFiId() | setFiId(FinancialInstitutionEntityFiId fiId) |
| `Locations` | [`List<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Location of the financial institution | List<PaymentDeliveryAddressEntity> getLocations() | setLocations(List<PaymentDeliveryAddressEntity> locations) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "name": "name0",
  "fiId": {
    "bicFIDec2014Id": "bicFIDec2014Id2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "locations": [
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

