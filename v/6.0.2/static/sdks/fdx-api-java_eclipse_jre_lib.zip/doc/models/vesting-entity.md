
# Vesting Entity

Represents the vesting of ownership of an investment account

*This model accepts additional fields of type Object.*

## Structure

`VestingEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `VestingDate` | `LocalDate` | Optional | Vesting date | LocalDate getVestingDate() | setVestingDate(LocalDate vestingDate) |
| `Symbol` | `String` | Optional | Security symbol | String getSymbol() | setSymbol(String symbol) |
| `StrikePrice` | `Double` | Optional | Strike price | Double getStrikePrice() | setStrikePrice(Double strikePrice) |
| `VestingPercentage` | `Double` | Optional | Vesting percentage | Double getVestingPercentage() | setVestingPercentage(Double vestingPercentage) |
| `OtherVestAmount` | `Double` | Optional | Other vested amount | Double getOtherVestAmount() | setOtherVestAmount(Double otherVestAmount) |
| `OtherVestPercentage` | `Double` | Optional | Other vested percentage | Double getOtherVestPercentage() | setOtherVestPercentage(Double otherVestPercentage) |
| `VestedBalance` | `Double` | Optional | Vested balance | Double getVestedBalance() | setVestedBalance(Double vestedBalance) |
| `UnVestedBalance` | `Double` | Optional | Unvested balance | Double getUnVestedBalance() | setUnVestedBalance(Double unVestedBalance) |
| `VestedQuantity` | `Double` | Optional | Vested quantity | Double getVestedQuantity() | setVestedQuantity(Double vestedQuantity) |
| `UnVestedQuantity` | `Double` | Optional | Unvested quantity | Double getUnVestedQuantity() | setUnVestedQuantity(Double unVestedQuantity) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "vestingDate": "2021-07-15",
  "symbol": "symbol2",
  "strikePrice": 29.46,
  "vestingPercentage": 3.96,
  "otherVestAmount": 120.96,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

