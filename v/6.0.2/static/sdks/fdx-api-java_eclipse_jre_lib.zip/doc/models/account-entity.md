
# Account Entity

An abstract account entity that concrete account entities extend

*This model accepts additional fields of type Object.*

## Structure

`AccountEntity`

## Inherits From

[`AccountDescriptorEntity`](../../doc/models/account-descriptor-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ParentAccountId` | `String` | Optional | Long-term persistent identity of the parent account. This is used to group accounts<br><br>**Constraints**: *Maximum Length*: `256` | String getParentAccountId() | setParentAccountId(String parentAccountId) |
| `LineOfBusiness` | `String` | Optional | The line of business, such as consumer, consumer joint, small business, corporate, etc. | String getLineOfBusiness() | setLineOfBusiness(String lineOfBusiness) |
| `RoutingTransitNumber` | `String` | Optional | The routing transit number (RTN) associated with the account number at the owning institution. This also serves as the 3-digit Institution (FID) and 5-digit Transit numbers for Canadian institutions, including leading zeroes | String getRoutingTransitNumber() | setRoutingTransitNumber(String routingTransitNumber) |
| `BalanceType` | [`BalanceType2`](../../doc/models/balance-type-2.md) | Optional | ASSET (positive transaction amount increases balance), LIABILITY (positive transaction amount decreases balance) | BalanceType2 getBalanceType() | setBalanceType(BalanceType2 balanceType) |
| `Contact` | [`AccountContactEntity2`](../../doc/models/account-contact-entity-2.md) | Optional | Contact information associated with this account | AccountContactEntity2 getContact() | setContact(AccountContactEntity2 contact) |
| `InterestRate` | `Double` | Optional | Interest Rate of Account | Double getInterestRate() | setInterestRate(Double interestRate) |
| `InterestRateType` | [`InterestRateType2`](../../doc/models/interest-rate-type-2.md) | Optional | FIXED or VARIABLE | InterestRateType2 getInterestRateType() | setInterestRateType(InterestRateType2 interestRateType) |
| `InterestRateAsOf` | `LocalDateTime` | Optional | Date of account's interest rate | LocalDateTime getInterestRateAsOf() | setInterestRateAsOf(LocalDateTime interestRateAsOf) |
| `PriorInterestRate` | `Double` | Optional | Previous Interest Rate of Account | Double getPriorInterestRate() | setPriorInterestRate(Double priorInterestRate) |
| `InterestRateIndex` | `String` | Optional | Variable rate index name such as EONIA, EURIBOR, EURREPO, FEFUND, LIBOR, PRIME, SOFR, SONIA, etc. | String getInterestRateIndex() | setInterestRateIndex(String interestRateIndex) |
| `EarlyPenaltyFlag` | `Boolean` | Optional | Flag that indicates if there is an early penalty for withdrawal/payoff | Boolean getEarlyPenaltyFlag() | setEarlyPenaltyFlag(Boolean earlyPenaltyFlag) |
| `TransferIn` | `Boolean` | Optional | Account is eligible for incoming transfers | Boolean getTransferIn() | setTransferIn(Boolean transferIn) |
| `TransferOut` | `Boolean` | Optional | Account is eligible for outgoing transfers | Boolean getTransferOut() | setTransferOut(Boolean transferOut) |
| `BillPayStatus` | [`AccountBillPayStatus2`](../../doc/models/account-bill-pay-status-2.md) | Optional | Defines account's ability to participate in bill payments | AccountBillPayStatus2 getBillPayStatus() | setBillPayStatus(AccountBillPayStatus2 billPayStatus) |
| `MicrNumber` | `String` | Optional | MICR Number<br><br>**Constraints**: *Maximum Length*: `64` | String getMicrNumber() | setMicrNumber(String micrNumber) |
| `LastActivityDate` | `LocalDate` | Optional | Date that last transaction occurred on account | LocalDate getLastActivityDate() | setLastActivityDate(LocalDate lastActivityDate) |
| `RewardProgramId` | `String` | Optional | Long-term persistent identity of rewards program associated with this account<br><br>**Constraints**: *Maximum Length*: `256` | String getRewardProgramId() | setRewardProgramId(String rewardProgramId) |
| `TransactionsIncluded` | `Boolean` | Optional | Default is false. If present and true, a call to retrieve transactions will not return any further details about this account. This is an optimization that allows an FDX API server to return transactions and account details in a single call | Boolean getTransactionsIncluded() | setTransactionsIncluded(Boolean transactionsIncluded) |
| `Domicile` | [`DomicileEntity1`](../../doc/models/domicile-entity-1.md) | Optional | The country and region of the account's legal jurisdiction | DomicileEntity1 getDomicile() | setDomicile(DomicileEntity1 domicile) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "accountCategory": "Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  }
}
```

