
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | `Environment` | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |
| taxBasicAuthCredentials | [`TaxBasicAuthCredentials`](auth/basic-authentication.md) | The Credentials Setter for Basic Authentication |

The API client can be initialized as follows:

```go
package main

import (
    "fdxApi"
)

func main() {
    client := fdxApi.NewClient(
    fdxApi.CreateConfiguration(
            fdxApi.WithHttpConfiguration(
                fdxApi.CreateHttpConfiguration(
                    fdxApi.WithTimeout(0),
                ),
            ),
            fdxApi.WithEnvironment(fdxApi.PRODUCTION),
            fdxApi.WithBearerAuthCredentials(
                fdxApi.NewBearerAuthCredentials("AccessToken"),
            ),
            fdxApi.WithTaxBasicAuthCredentials(
                fdxApi.NewTaxBasicAuthCredentials(
                    "Username",
                    "Password",
                ),
            ),
            fdxApi.WithLoggerConfiguration(
                fdxApi.WithLevel("info"),
                fdxApi.WithRequestConfiguration(
                    fdxApi.WithRequestBody(true),
                ),
                fdxApi.WithResponseConfiguration(
                    fdxApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## FDX API Client

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

## Controllers

| Name | Description |
|  --- | --- |
| UserConsentController() | Gets UserConsentController |
| AccountInformationController() | Gets AccountInformationController |
| AccountStatementsController() | Gets AccountStatementsController |
| AccountTransactionsController() | Gets AccountTransactionsController |
| MoneyMovementController() | Gets MoneyMovementController |
| PersonalInformationController() | Gets PersonalInformationController |
| RewardProgramCategoriesController() | Gets RewardProgramCategoriesController |
| RewardProgramInformationController() | Gets RewardProgramInformationController |
| EventNotificationsController() | Gets EventNotificationsController |
| FraudNotificationController() | Gets FraudNotificationController |
| MetaController() | Gets MetaController |
| InternalTransfersController() | Gets InternalTransfersController |
| PayeeManagementController() | Gets PayeeManagementController |
| PaymentInitiationPartiesController() | Gets PaymentInitiationPartiesController |
| PaymentsController() | Gets PaymentsController |
| RecurringPaymentsController() | Gets RecurringPaymentsController |
| PayrollInformationController() | Gets PayrollInformationController |
| RecipientsController() | Gets RecipientsController |
| SubmitTaxFormsController() | Gets SubmitTaxFormsController |
| TaxFormsController() | Gets TaxFormsController |
| ResourceInformationController() | Gets ResourceInformationController |

