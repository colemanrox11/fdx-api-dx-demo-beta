
# Form 1099 Int

Interest Income, from PAYER (1st-2nd boxes as issuer) to RECIPIENT (3rd-4th boxes)

*This model accepts additional fields of type Object.*

## Structure

`Form1099Int`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TaxYear` | `Integer` | Optional | Year for which taxes are being paid<br><br>**Constraints**: `>= 2018`, `<= 2050` | Integer getTaxYear() | setTaxYear(Integer taxYear) |
| `Corrected` | `Boolean` | Optional | True to indicate this is a corrected tax form | Boolean getCorrected() | setCorrected(Boolean corrected) |
| `AccountId` | `String` | Optional | Long-term persistent identity of the source account. Not the account number<br><br>**Constraints**: *Maximum Length*: `256` | String getAccountId() | setAccountId(String accountId) |
| `TaxFormId` | `String` | Optional | Long-term persistent id for this tax form. Depending upon the data provider, this may be the same id as the enclosing tax statement id, or this may be a different id, or this id may be omitted.<br><br>**Constraints**: *Maximum Length*: `256` | String getTaxFormId() | setTaxFormId(String taxFormId) |
| `TaxFormDate` | `LocalDate` | Optional | Date of production or delivery of the tax form | LocalDate getTaxFormDate() | setTaxFormDate(LocalDate taxFormDate) |
| `AdditionalInformation` | `String` | Optional | Additional explanation text or content about this tax form | String getAdditionalInformation() | setAdditionalInformation(String additionalInformation) |
| `TaxFormType` | [`TypeFormType1`](../../doc/models/type-form-type-1.md) | Optional | Enumerated name of the tax form entity e.g. "TaxW2" | TypeFormType1 getTaxFormType() | setTaxFormType(TypeFormType1 taxFormType) |
| `Issuer` | [`TaxParty8`](../../doc/models/tax-party-8.md) | Optional | Issuer's name, address, phone, and TIN. Issuer data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty8 getIssuer() | setIssuer(TaxParty8 issuer) |
| `Recipient` | [`TaxParty1`](../../doc/models/tax-party-1.md) | Optional | Recipient's name, address, phone, and TIN. Recipient data need only be transmitted on enclosing TaxStatement, if it is the same on all its included tax forms. | TaxParty1 getRecipient() | setRecipient(TaxParty1 recipient) |
| `Attributes` | [`List<TaxFormAttribute>`](../../doc/models/tax-form-attribute.md) | Optional | Additional attributes for this tax form when defined fields are not available. Some specific additional attributes already defined by providers: Fields required by [IRS FIRE](https://www.irs.gov/e-file-providers/filing-information-returns-electronically-fire): Name Control, Type of Identification Number (EIN, SSN, ITIN, ATIN). (ATIN is tax ID number for pending adoptions.) Tax form provider field for taxpayer notification: Recipient Email Address. | List<TaxFormAttribute> getAttributes() | setAttributes(List<TaxFormAttribute> attributes) |
| `Error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this form | Error1 getError() | setError(Error1 error) |
| `Links` | [`List<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this form as data or image, or to invoke other APIs | List<HateoasLink> getLinks() | setLinks(List<HateoasLink> links) |
| `ForeignAccountTaxCompliance` | `Boolean` | Optional | FATCA filing requirement | Boolean getForeignAccountTaxCompliance() | setForeignAccountTaxCompliance(Boolean foreignAccountTaxCompliance) |
| `AccountNumber` | `String` | Optional | Account number | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `PayerRtn` | `String` | Optional | Payer's RTN | String getPayerRtn() | setPayerRtn(String payerRtn) |
| `InterestIncome` | `Double` | Optional | Box 1, Interest income | Double getInterestIncome() | setInterestIncome(Double interestIncome) |
| `EarlyWithdrawalPenalty` | `Double` | Optional | Box 2, Early withdrawal penalty | Double getEarlyWithdrawalPenalty() | setEarlyWithdrawalPenalty(Double earlyWithdrawalPenalty) |
| `UsBondInterest` | `Double` | Optional | Box 3, Interest on U.S. Savings Bonds and Treasury obligations | Double getUsBondInterest() | setUsBondInterest(Double usBondInterest) |
| `FederalTaxWithheld` | `Double` | Optional | Box 4, Federal income tax withheld | Double getFederalTaxWithheld() | setFederalTaxWithheld(Double federalTaxWithheld) |
| `InvestmentExpenses` | `Double` | Optional | Box 5, Investment expenses | Double getInvestmentExpenses() | setInvestmentExpenses(Double investmentExpenses) |
| `ForeignTaxPaid` | `Double` | Optional | Box 6, Foreign tax paid | Double getForeignTaxPaid() | setForeignTaxPaid(Double foreignTaxPaid) |
| `ForeignCountry` | `String` | Optional | Box 7, Foreign country or U.S. possession | String getForeignCountry() | setForeignCountry(String foreignCountry) |
| `TaxExemptInterest` | `Double` | Optional | Box 8, Tax-exempt interest | Double getTaxExemptInterest() | setTaxExemptInterest(Double taxExemptInterest) |
| `SpecifiedPabInterest` | `Double` | Optional | Box 9, Specified private activity bond interest | Double getSpecifiedPabInterest() | setSpecifiedPabInterest(Double specifiedPabInterest) |
| `MarketDiscount` | `Double` | Optional | Box 10, Market discount | Double getMarketDiscount() | setMarketDiscount(Double marketDiscount) |
| `BondPremium` | `Double` | Optional | Box 11, Bond premium | Double getBondPremium() | setBondPremium(Double bondPremium) |
| `UsBondPremium` | `Double` | Optional | Box 12, Bond premium on Treasury obligations | Double getUsBondPremium() | setUsBondPremium(Double usBondPremium) |
| `TaxExemptBondPremium` | `Double` | Optional | Box 13, Bond premium on tax-exempt bond | Double getTaxExemptBondPremium() | setTaxExemptBondPremium(Double taxExemptBondPremium) |
| `CusipNumber` | `String` | Optional | Box 14, Tax-exempt bond CUSIP no. | String getCusipNumber() | setCusipNumber(String cusipNumber) |
| `StateAndLocal` | [`List<StateAndLocalTaxWithholding>`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 15-17, State and Local tax withholding | List<StateAndLocalTaxWithholding> getStateAndLocal() | setStateAndLocal(List<StateAndLocalTaxWithholding> stateAndLocal) |
| `ForeignIncomes` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Supplemental foreign income amount information (description is country) | List<DescriptionAndAmount> getForeignIncomes() | setForeignIncomes(List<DescriptionAndAmount> foreignIncomes) |
| `StateTaxExemptIncome` | [`List<DescriptionAndAmount>`](../../doc/models/description-and-amount.md) | Optional | Supplemental tax-exempt income by state (description is state) | List<DescriptionAndAmount> getStateTaxExemptIncome() | setStateTaxExemptIncome(List<DescriptionAndAmount> stateTaxExemptIncome) |
| `SecondTinNotice` | `Boolean` | Optional | Second TIN Notice | Boolean getSecondTinNotice() | setSecondTinNotice(Boolean secondTinNotice) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "taxYear": 2023,
  "taxFormDate": "2021-07-15",
  "attributes": [
    {
      "name": "nameControl",
      "value": "WILC"
    },
    {
      "name": "recipientIdType",
      "value": "EIN",
      "code": "1"
    },
    {
      "name": "recipientIdType",
      "value": "SSN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ITIN",
      "code": "2"
    },
    {
      "name": "recipientIdType",
      "value": "ATIN",
      "code": "2"
    }
  ],
  "corrected": false,
  "accountId": "accountId2",
  "taxFormId": "taxFormId0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

