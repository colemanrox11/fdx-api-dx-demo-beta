
# Digital Wallet Transaction Entity

A transaction on a digital wallet account

*This model accepts additional fields of type Object.*

## Structure

`DigitalWalletTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionType` | [`DigitalWalletTransactionType2`](../../doc/models/digital-wallet-transaction-type-2.md) | Optional | ADJUSTMENT, BILL_PAYMENT, CREDIT, DEBIT, DEPOSIT, DIRECT_DEPOSIT, DIVIDEND, FEE, INTEREST, MERCHANT_PAYMENT, MERCHANT_REFUND, TRANSFER_IN, TRANSFER_OUT, WITHDRAWAL | DigitalWalletTransactionType2 getTransactionType() | setTransactionType(DigitalWalletTransactionType2 transactionType) |
| `Payee` | `String` | Optional | Payee name<br><br>**Constraints**: *Maximum Length*: `255` | String getPayee() | setPayee(String payee) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountCategory": "Digital Wallet Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "DIVIDEND",
  "payee": "payee4"
}
```

