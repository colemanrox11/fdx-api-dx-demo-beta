
# Notification Payload Id Type

Type of entity causing origination of a notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationPayloadIdType`

## Fields

| Name |
|  --- |
| `ACCOUNT` |
| `CONSENT` |
| `CUSTOMER` |
| `MAINTENANCE` |
| `PARTY` |

