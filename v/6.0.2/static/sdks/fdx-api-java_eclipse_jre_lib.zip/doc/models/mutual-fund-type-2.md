
# Mutual Fund Type 2

Mutual fund type. One of OPENEND, CLOSEEND, OTHER

*This model accepts additional fields of type Object.*

## Enumeration

`MutualFundType2`

## Fields

| Name |
|  --- |
| `Closeend` |
| `Openend` |
| `Other` |

