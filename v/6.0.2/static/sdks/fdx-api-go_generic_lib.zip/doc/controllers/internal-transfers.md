# Internal Transfers

```go
internalTransfersController := client.InternalTransfersController()
```

## Class Name

`InternalTransfersController`

## Methods

* [Search for Transfers](../../doc/controllers/internal-transfers.md#search-for-transfers)
* [Request Account Transfer](../../doc/controllers/internal-transfers.md#request-account-transfer)
* [Get Transfer](../../doc/controllers/internal-transfers.md#get-transfer)
* [Cancel Transfer](../../doc/controllers/internal-transfers.md#cancel-transfer)


# Search for Transfers

Search for transfers

```go
SearchForTransfers(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    updatedSince *string,
    offset *string,
    limit *int,
    searchStartTransferDate *time.Time,
    searchEndTransferDate *time.Time,
    searchFromAccountIds []string,
    searchToAccountIds []string,
    searchStatuses []models.PaymentStatus,
    searchTransferIds []string) (
    models.ApiResponse[models.TransfersEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `updatedSince` | `*string` | Query, Optional | Return items that have been created or updated since the nextUpdateId<br><br>**Constraints**: *Maximum Length*: `256` |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |
| `searchStartTransferDate` | `*time.Time` | Query, Optional | Start time for use in retrieval of transfers by transfer date |
| `searchEndTransferDate` | `*time.Time` | Query, Optional | End time for use in retrieval of transfers by transfer date |
| `searchFromAccountIds` | `[]string` | Query, Optional | Search for transfers by source account |
| `searchToAccountIds` | `[]string` | Query, Optional | Search for transfers by source account |
| `searchStatuses` | [`[]models.PaymentStatus`](../../doc/models/payment-status.md) | Query, Optional | Search for transfers by source account |
| `searchTransferIds` | `[]string` | Query, Optional | Search for transfers by id |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.TransfersEntity](../../doc/models/transfers-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch







searchStartTransferDate := parseTime(time.RFC3339, "2021-07-15", func(err error) { log.Fatalln(err) })

searchEndTransferDate := parseTime(time.RFC3339, "2021-07-15", func(err error) { log.Fatalln(err) })









apiResponse, err := internalTransfersController.SearchForTransfers(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil, nil, &searchStartTransferDate, &searchEndTransferDate, nil, nil, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Request Account Transfer

Create a transfer between accounts

```go
RequestAccountTransfer(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    idempotencyKey string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.TransferForCreateEntity1) (
    models.ApiResponse[models.TransferEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `idempotencyKey` | `string` | Header, Required | Used to de-duplicate requests<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.TransferForCreateEntity1`](../../doc/models/transfer-for-create-entity-1.md) | Body, Optional | Data of the transfer request |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.TransferEntity](../../doc/models/transfer-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

idempotencyKey := "idempotency-key4"



body := models.TransferForCreateEntity1{
    TransferId:            models.ToPointer("MY-TRANSFER-ID"),
    FromAccountId:         models.ToPointer("ACCOUNT-123"),
    ToAccountId:           models.ToPointer("ACCOUNT-456"),
    Amount:                models.ToPointer(float64(100)),
    Memo:                  models.ToPointer("FDX Transfer Example"),
    PaymentDetails:        models.ToPointer(models.PaymentDetailsEntity{
        PrincipalAmount:       models.ToPointer(float64(75)),
        InterestAmount:        models.ToPointer(float64(10)),
        InsuranceAmount:       models.ToPointer(float64(5)),
        EscrowAmount:          models.ToPointer(float64(5)),
        PmiAmount:             models.ToPointer(float64(5)),
        FeesAmount:            models.ToPointer(float64(0)),
    }),
}

apiResponse, err := internalTransfersController.RequestAccountTransfer(ctx, xFapiInteractionId, idempotencyKey, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Source account does not have sufficient funds | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Account not authorized for transfer | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Requested transfer is invalid | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Duplicate transfer request | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Transfer

Get a transfer been accounts

```go
GetTransfer(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    transferId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.TransferEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `transferId` | `string` | Template, Required | Transfer identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.TransferEntity](../../doc/models/transfer-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

transferId := "transferId8"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := internalTransfersController.GetTransfer(ctx, xFapiInteractionId, transferId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```


# Cancel Transfer

Cancel a transfer between accounts

```go
CancelTransfer(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    transferId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.TransferEntity],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `transferId` | `string` | Template, Required | Transfer identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.TransferEntity](../../doc/models/transfer-entity.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

transferId := "transferId8"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := internalTransfersController.CancelTransfer(ctx, xFapiInteractionId, transferId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "transferId": "MY-TRANSFER-ID",
  "fromAccountId": "ACCOUNT-123",
  "toAccountId": "ACCOUNT-456",
  "amount": 100,
  "memo": "FDX Transfer Example",
  "paymentDetails": {
    "principalAmount": 75,
    "interestAmount": 10,
    "insuranceAmount": 5,
    "escrowAmount": 5,
    "pmiAmount": 5,
    "feesAmount": 0
  },
  "referenceId": "FI-TRANSFER-ID",
  "status": "SCHEDULED",
  "transferTime": "2021-03-14T13:15:30.751Z"
}
```

