
# Proprietary Financial Institution Id Scheme Entity

Proprietary financial institution identification scheme, as per ISO 20022 v1.

*This model accepts additional fields of type Object.*

## Structure

`ProprietaryFinancialInstitutionIdSchemeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | This property is related to the name of the identification scheme,<br>in the proprietary system, as per ISO 20022 v1 |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

