
# Availability List Entity

Response object for /availability API

*This model accepts additional fields of type Object.*

## Structure

`AvailabilityListEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `availability` | [`Array<AvailabilityEntity>`](../../doc/models/availability-entity.md) | Optional | Zero or more API availability metrics |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "availability": [
    {
      "status": "ALIVE",
      "description": "description0",
      "operationId": "getPaymentInitiationParty",
      "plannedAvailability": [
        {
          "status": "MAINTENANCE",
          "description": "description6",
          "startTime": "2016-03-13T12:52:32.123Z",
          "endTime": "2016-03-13T12:52:32.123Z",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "status": "ALIVE",
      "description": "description0",
      "operationId": "getPaymentInitiationParty",
      "plannedAvailability": [
        {
          "status": "MAINTENANCE",
          "description": "description6",
          "startTime": "2016-03-13T12:52:32.123Z",
          "endTime": "2016-03-13T12:52:32.123Z",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "status": "ALIVE",
      "description": "description0",
      "operationId": "getPaymentInitiationParty",
      "plannedAvailability": [
        {
          "status": "MAINTENANCE",
          "description": "description6",
          "startTime": "2016-03-13T12:52:32.123Z",
          "endTime": "2016-03-13T12:52:32.123Z",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

