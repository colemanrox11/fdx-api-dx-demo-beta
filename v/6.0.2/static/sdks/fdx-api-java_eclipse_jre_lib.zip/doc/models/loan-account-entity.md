
# Loan Account Entity

A loan account type

*This model accepts additional fields of type Object.*

## Structure

`LoanAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BalanceAsOf` | `LocalDateTime` | Optional | As-of date for balances | LocalDateTime getBalanceAsOf() | setBalanceAsOf(LocalDateTime balanceAsOf) |
| `PrincipalBalance` | `Double` | Optional | Principal balance of loan | Double getPrincipalBalance() | setPrincipalBalance(Double principalBalance) |
| `EscrowBalance` | `Double` | Optional | Escrow balance of loan | Double getEscrowBalance() | setEscrowBalance(Double escrowBalance) |
| `OriginalPrincipal` | `Double` | Optional | Original principal of loan | Double getOriginalPrincipal() | setOriginalPrincipal(Double originalPrincipal) |
| `OriginatingDate` | `LocalDate` | Optional | Loan origination date | LocalDate getOriginatingDate() | setOriginatingDate(LocalDate originatingDate) |
| `LoanTerm` | `Integer` | Optional | Term of loan in months | Integer getLoanTerm() | setLoanTerm(Integer loanTerm) |
| `TotalNumberOfPayments` | `Integer` | Optional | Total number of payments | Integer getTotalNumberOfPayments() | setTotalNumberOfPayments(Integer totalNumberOfPayments) |
| `NextPaymentAmount` | `Double` | Optional | Amount of next payment | Double getNextPaymentAmount() | setNextPaymentAmount(Double nextPaymentAmount) |
| `NextPaymentDate` | `LocalDate` | Optional | Date of next payment | LocalDate getNextPaymentDate() | setNextPaymentDate(LocalDate nextPaymentDate) |
| `PaymentFrequency` | [`PaymentFrequency1`](../../doc/models/payment-frequency-1.md) | Optional | DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY | PaymentFrequency1 getPaymentFrequency() | setPaymentFrequency(PaymentFrequency1 paymentFrequency) |
| `CompoundingPeriod` | [`CompoundingPeriod2`](../../doc/models/compounding-period-2.md) | Optional | DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY | CompoundingPeriod2 getCompoundingPeriod() | setCompoundingPeriod(CompoundingPeriod2 compoundingPeriod) |
| `PayOffAmount` | `Double` | Optional | Payoff amount | Double getPayOffAmount() | setPayOffAmount(Double payOffAmount) |
| `LastPaymentAmount` | `Double` | Optional | Last payment amount | Double getLastPaymentAmount() | setLastPaymentAmount(Double lastPaymentAmount) |
| `LastPaymentDate` | `LocalDate` | Optional | Last payment date | LocalDate getLastPaymentDate() | setLastPaymentDate(LocalDate lastPaymentDate) |
| `MaturityDate` | `LocalDate` | Optional | Maturity date | LocalDate getMaturityDate() | setMaturityDate(LocalDate maturityDate) |
| `InterestPaidYearToDate` | `Double` | Optional | Interest paid year to date | Double getInterestPaidYearToDate() | setInterestPaidYearToDate(Double interestPaidYearToDate) |
| `Transactions` | [`List<LoanTransactionEntity>`](../../doc/models/loan-transaction-entity.md) | Optional | Transactions on the loan account | List<LoanTransactionEntity> getTransactions() | setTransactions(List<LoanTransactionEntity> transactions) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "balanceAsOf": "07/15/2021 14:46:41",
  "originatingDate": "2021-07-15",
  "nextPaymentDate": "2021-07-15",
  "lastPaymentDate": "2021-07-15",
  "maturityDate": "2021-07-15",
  "accountCategory": "Loan Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "principalBalance": 32.64,
  "escrowBalance": 61.1,
  "originalPrincipal": 9.42
}
```

