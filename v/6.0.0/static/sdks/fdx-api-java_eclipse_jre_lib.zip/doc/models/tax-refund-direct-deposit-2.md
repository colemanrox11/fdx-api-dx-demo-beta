
# Tax Refund Direct Deposit 2

Tax refund direct deposit information

*This model accepts additional fields of type Object.*

## Structure

`TaxRefundDirectDeposit2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `InstitutionName` | `String` | Optional | Name of institution | String getInstitutionName() | setInstitutionName(String institutionName) |
| `Rtn` | `String` | Optional | Routing transit number | String getRtn() | setRtn(String rtn) |
| `AccountNumber` | `String` | Optional | Account number | String getAccountNumber() | setAccountNumber(String accountNumber) |
| `AccountNickName` | `String` | Optional | Account nickname | String getAccountNickName() | setAccountNickName(String accountNickName) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "institutionName": "institutionName0",
  "rtn": "rtn6",
  "accountNumber": "accountNumber0",
  "accountNickName": "accountNickName8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

