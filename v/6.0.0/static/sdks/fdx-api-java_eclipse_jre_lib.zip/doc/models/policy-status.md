
# Policy Status

The status of an insurance policy account.

| Value | Description |
|-----|-----|
| ACTIVE | At least one component of the insurance policy is in force |
| DEATH_CLAIM_PAID | Benefits for a death claim have been settled with the insured |
| DEATH_CLAIM_PENDING | A death claim has been submitted but not yet settled |
| EXPIRED | Nonpayment of premium has exhausted the policy's Grace Period |
| GRACE_PERIOD | A premium is due but before lapse in coverage begins |
| LAPSE_PENDING | After the Grace Period has been exhausted but before final expiration; during Lapse Pending, policy reinstatement may still be possible |
| TERMINATED | Either the insurance company or the insured cancel the coverage of a cancellable insurance policy |
| WAIVER | A premium payment is waived under certain conditions due to a payer benefit clause |

*This model accepts additional fields of type Object.*

## Enumeration

`PolicyStatus`

## Fields

| Name |
|  --- |
| `Active` |
| `DeathClaimPaid` |
| `DeathClaimPending` |
| `Expired` |
| `GracePeriod` |
| `LapsePending` |
| `Terminated` |
| `Waiver` |

