
# Investment Account Entity

An investment account type and information such as balances, transactions, holdings and privileges

*This model accepts additional fields of type Object.*

## Structure

`InvestmentAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `BalanceAsOf` | `LocalDateTime` | Optional | As-of date for balances | LocalDateTime getBalanceAsOf() | setBalanceAsOf(LocalDateTime balanceAsOf) |
| `AllowedCheckWriting` | `Boolean` | Optional | Check writing privileges | Boolean getAllowedCheckWriting() | setAllowedCheckWriting(Boolean allowedCheckWriting) |
| `AllowedOptionTrade` | `Boolean` | Optional | Allowed to trade options | Boolean getAllowedOptionTrade() | setAllowedOptionTrade(Boolean allowedOptionTrade) |
| `CurrentValue` | `Double` | Optional | Total current value of all investments | Double getCurrentValue() | setCurrentValue(Double currentValue) |
| `Holdings` | [`List<HoldingEntity>`](../../doc/models/holding-entity.md) | Optional | Holdings in the investment account | List<HoldingEntity> getHoldings() | setHoldings(List<HoldingEntity> holdings) |
| `OpenOrders` | [`List<OpenOrderEntity>`](../../doc/models/open-order-entity.md) | Optional | Open orders in the investment account | List<OpenOrderEntity> getOpenOrders() | setOpenOrders(List<OpenOrderEntity> openOrders) |
| `Contribution` | [`List<ContributionEntity>`](../../doc/models/contribution-entity.md) | Optional | Describes how new contributions are distributed among the available securities | List<ContributionEntity> getContribution() | setContribution(List<ContributionEntity> contribution) |
| `Vesting` | [`List<VestingEntity>`](../../doc/models/vesting-entity.md) | Optional | Provides the past, present, and future vesting schedule and percentages | List<VestingEntity> getVesting() | setVesting(List<VestingEntity> vesting) |
| `InvestmentLoans` | [`List<InvestmentLoanEntity>`](../../doc/models/investment-loan-entity.md) | Optional | Investment loans in the account | List<InvestmentLoanEntity> getInvestmentLoans() | setInvestmentLoans(List<InvestmentLoanEntity> investmentLoans) |
| `AvailableCashBalance` | `Double` | Optional | Cash balance across all sub-accounts. Should include sweep funds | Double getAvailableCashBalance() | setAvailableCashBalance(Double availableCashBalance) |
| `Margin` | `Boolean` | Optional | Margin trading is allowed | Boolean getMargin() | setMargin(Boolean margin) |
| `MarginBalance` | `Double` | Optional | Margin balance | Double getMarginBalance() | setMarginBalance(Double marginBalance) |
| `ShortBalance` | `Double` | Optional | Short balance | Double getShortBalance() | setShortBalance(Double shortBalance) |
| `RolloverAmount` | `Double` | Optional | Rollover amount | Double getRolloverAmount() | setRolloverAmount(Double rolloverAmount) |
| `EmployerName` | `String` | Optional | Name of the employer in investment 401k Plan | String getEmployerName() | setEmployerName(String employerName) |
| `BrokerId` | `String` | Optional | Unique identifier FI | String getBrokerId() | setBrokerId(String brokerId) |
| `PlanId` | `String` | Optional | Plan number for Investment 401k plan | String getPlanId() | setPlanId(String planId) |
| `CalendarYearFor401K` | `Integer` | Optional | The calendar year for this 401k account | Integer getCalendarYearFor401K() | setCalendarYearFor401K(Integer calendarYearFor401K) |
| `BalanceList` | [`List<InvestmentBalanceEntity>`](../../doc/models/investment-balance-entity.md) | Optional | List of balances. Aggregate of name value pairs | List<InvestmentBalanceEntity> getBalanceList() | setBalanceList(List<InvestmentBalanceEntity> balanceList) |
| `DailyChange` | `Double` | Optional | Daily change | Double getDailyChange() | setDailyChange(Double dailyChange) |
| `PercentageChange` | `Double` | Optional | Percentage change | Double getPercentageChange() | setPercentageChange(Double percentageChange) |
| `Transactions` | [`List<InvestmentTransactionEntity>`](../../doc/models/investment-transaction-entity.md) | Optional | Transactions on the investment account | List<InvestmentTransactionEntity> getTransactions() | setTransactions(List<InvestmentTransactionEntity> transactions) |
| `PensionSource` | [`List<PensionSourceEntity>`](../../doc/models/pension-source-entity.md) | Optional | Pension sources in the investment account | List<PensionSourceEntity> getPensionSource() | setPensionSource(List<PensionSourceEntity> pensionSource) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "balanceAsOf": "07/15/2021 14:46:41",
  "accountCategory": "Investment Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "allowedCheckWriting": false,
  "allowedOptionTrade": false,
  "currentValue": 30.32,
  "holdings": [
    {
      "holdingId": "holdingId6",
      "securityIds": [
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "id": "id6",
          "idType": "CINS",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "holdingName": "holdingName2",
      "holdingType": "MUTUALFUND",
      "holdingSubType": "CASH",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ]
}
```

