# Meta

API management and metrics

```java
MetaController metaController = client.getMetaController();
```

## Class Name

`MetaController`

## Methods

* [Get Availability](../../doc/controllers/meta.md#get-availability)
* [Get Capability](../../doc/controllers/meta.md#get-capability)
* [Get Certification Metrics](../../doc/controllers/meta.md#get-certification-metrics)


# Get Availability

Get information about this API's availability

```java
CompletableFuture<ApiResponse<AvailabilityListEntity>> getAvailabilityAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final FdxResourceOperationId operationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operationId` | [`FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |

## Server

`Server.META`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`AvailabilityListEntity`](../../doc/models/availability-list-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

metaController.getAvailabilityAsync(xFapiInteractionId, fdxApiActorType, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get Capability

Get information about this API's capability

```java
CompletableFuture<ApiResponse<CapabilityEntity>> getCapabilityAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final FdxResourceOperationId operationId,
    final FdxVersion fdxVersion,
    final ResultType resultType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operationId` | [`FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |
| `fdxVersion` | [`FdxVersion`](../../doc/models/fdx-version.md) | Query, Optional | Specific FDX version for which to get the capability. Optional |
| `resultType` | [`ResultType`](../../doc/models/result-type.md) | Query, Optional | Flag to indicate if you want a lightweight array of metadata (AccountDescriptor or Tax or Operations) or full item details (Account or a Tax subclass or Availability details). If set to 'lightweight', should only return the fields associated with the metadata entity. This field is not required, defaults to lightweight<br><br>**Default**: `ResultType.LIGHTWEIGHT` |

## Server

`Server.META`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`CapabilityEntity`](../../doc/models/capability-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;
ResultType resultType = ResultType.LIGHTWEIGHT;

metaController.getCapabilityAsync(xFapiInteractionId, fdxApiActorType, null, null, resultType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```


# Get Certification Metrics

Get certification performance metrics for this implementer's APIs

```java
CompletableFuture<ApiResponse<CertificationMetricsEntity>> getCertificationMetricsAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final FdxResourceOperationId operationId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `operationId` | [`FdxResourceOperationId`](../../doc/models/fdx-resource-operation-id.md) | Query, Optional | Specific operationId for which to get the metrics. Optional |

## Server

`Server.META`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`CertificationMetricsEntity`](../../doc/models/certification-metrics-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

metaController.getCertificationMetricsAsync(xFapiInteractionId, fdxApiActorType, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

