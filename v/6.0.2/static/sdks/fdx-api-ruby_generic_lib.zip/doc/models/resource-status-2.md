
# Resource Status 2

Status of Resource

*This model accepts additional fields of type Object.*

## Enumeration

`ResourceStatus2`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `IN_PROGRESS` |
| `RETIRED` |

