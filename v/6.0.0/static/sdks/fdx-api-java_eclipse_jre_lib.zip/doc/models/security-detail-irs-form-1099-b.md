
# Security Detail Irs Form 1099 B

Tax information for a single security transaction

*This model accepts additional fields of type Object.*

## Structure

`SecurityDetailIrsForm1099B`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CheckboxOnForm8949` | `String` | Optional | Applicable checkbox on Form 8949 | String getCheckboxOnForm8949() | setCheckboxOnForm8949(String checkboxOnForm8949) |
| `SecurityName` | `String` | Optional | Security name | String getSecurityName() | setSecurityName(String securityName) |
| `NumberOfShares` | `Double` | Optional | Number of shares | Double getNumberOfShares() | setNumberOfShares(Double numberOfShares) |
| `SaleDescription` | `String` | Optional | Box 1a, Description of property | String getSaleDescription() | setSaleDescription(String saleDescription) |
| `DateAcquired` | `LocalDate` | Optional | Box 1b, Date acquired | LocalDate getDateAcquired() | setDateAcquired(LocalDate dateAcquired) |
| `VariousDatesAcquired` | `Boolean` | Optional | Box 1b, Date acquired Various | Boolean getVariousDatesAcquired() | setVariousDatesAcquired(Boolean variousDatesAcquired) |
| `DateOfSale` | `LocalDate` | Optional | Box 1c, Date sold or disposed | LocalDate getDateOfSale() | setDateOfSale(LocalDate dateOfSale) |
| `SalesPrice` | `Double` | Optional | Box 1d, Proceeds (not price per share) | Double getSalesPrice() | setSalesPrice(Double salesPrice) |
| `AccruedMarketDiscount` | `Double` | Optional | Box 1f, Accrued market discount | Double getAccruedMarketDiscount() | setAccruedMarketDiscount(Double accruedMarketDiscount) |
| `AdjustmentCodes` | [`List<CodeAndAmount>`](../../doc/models/code-and-amount.md) | Optional | Other adjustments (code and amount) | List<CodeAndAmount> getAdjustmentCodes() | setAdjustmentCodes(List<CodeAndAmount> adjustmentCodes) |
| `CostBasis` | `Double` | Optional | Box 1e, Cost or other basis | Double getCostBasis() | setCostBasis(Double costBasis) |
| `CorrectedCostBasis` | `Double` | Optional | Corrected cost basis. May be supplied in lieu of adjustmentCode code B. If both adjustmentCodes and correctedCostBasis are supplied, costBasis plus adjustmentCode B should equal correctedCostBasis | Double getCorrectedCostBasis() | setCorrectedCostBasis(Double correctedCostBasis) |
| `WashSaleLossDisallowed` | `Double` | Optional | Box 1g, Wash sale loss disallowed | Double getWashSaleLossDisallowed() | setWashSaleLossDisallowed(Double washSaleLossDisallowed) |
| `LongOrShort` | [`PositionType`](../../doc/models/position-type.md) | Optional | Box 2, LONG or SHORT | PositionType getLongOrShort() | setLongOrShort(PositionType longOrShort) |
| `Ordinary` | `Boolean` | Optional | Box 2, Ordinary | Boolean getOrdinary() | setOrdinary(Boolean ordinary) |
| `Collectible` | `Boolean` | Optional | Box 3, Collectibles | Boolean getCollectible() | setCollectible(Boolean collectible) |
| `Qof` | `Boolean` | Optional | Box 3, Qualified Opportunity Fund (QOF) | Boolean getQof() | setQof(Boolean qof) |
| `FederalTaxWithheld` | `Double` | Optional | Box 4, Federal income tax withheld | Double getFederalTaxWithheld() | setFederalTaxWithheld(Double federalTaxWithheld) |
| `NoncoveredSecurity` | `Boolean` | Optional | Box 5, Noncovered security | Boolean getNoncoveredSecurity() | setNoncoveredSecurity(Boolean noncoveredSecurity) |
| `GrossOrNet` | [`SaleProceedsType2`](../../doc/models/sale-proceeds-type-2.md) | Optional | Box 6, Reported to IRS: GROSS or NET | SaleProceedsType2 getGrossOrNet() | setGrossOrNet(SaleProceedsType2 grossOrNet) |
| `LossNotAllowed` | `Boolean` | Optional | Box 7, Loss not allowed based on proceeds | Boolean getLossNotAllowed() | setLossNotAllowed(Boolean lossNotAllowed) |
| `BasisReported` | `Boolean` | Optional | Box 12, Basis reported to IRS | Boolean getBasisReported() | setBasisReported(Boolean basisReported) |
| `StateAndLocal` | [`List<StateAndLocalTaxWithholding>`](../../doc/models/state-and-local-tax-withholding.md) | Optional | Boxes 14-16, State and Local tax withholding | List<StateAndLocalTaxWithholding> getStateAndLocal() | setStateAndLocal(List<StateAndLocalTaxWithholding> stateAndLocal) |
| `Cusip` | `String` | Optional | CUSIP number | String getCusip() | setCusip(String cusip) |
| `ForeignAccountTaxCompliance` | `Boolean` | Optional | Foreign account tax compliance | Boolean getForeignAccountTaxCompliance() | setForeignAccountTaxCompliance(Boolean foreignAccountTaxCompliance) |
| `ExpiredOption` | [`ExpiredOptionType2`](../../doc/models/expired-option-type-2.md) | Optional | To indicate gain or loss resulted from option expiration. If salesPrice (1d, proceeds) is zero, use PURCHASED. If costBasis (1e) is zero, use GRANTED | ExpiredOptionType2 getExpiredOption() | setExpiredOption(ExpiredOptionType2 expiredOption) |
| `InvestmentSaleType` | [`InvestmentSaleType`](../../doc/models/investment-sale-type.md) | Optional | Type of investment sale | InvestmentSaleType getInvestmentSaleType() | setInvestmentSaleType(InvestmentSaleType investmentSaleType) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "dateAcquired": "2021-07-15",
  "dateOfSale": "2021-07-15",
  "checkboxOnForm8949": "checkboxOnForm89498",
  "securityName": "securityName6",
  "numberOfShares": 126.44,
  "saleDescription": "saleDescription4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

