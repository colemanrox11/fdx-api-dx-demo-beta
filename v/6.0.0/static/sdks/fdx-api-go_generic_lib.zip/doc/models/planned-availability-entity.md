
# Planned Availability Entity

Provider's plan for API availability

*This model accepts additional fields of type interface{}.*

## Structure

`PlannedAvailabilityEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | [`*models.AvailabilityStatus1`](../../doc/models/availability-status-1.md) | Optional | API availability status for this time period |
| `Description` | `*string` | Optional | Description of API availability status |
| `StartTime` | `*time.Time` | Optional | Start time for this status period |
| `EndTime` | `*time.Time` | Optional | End time for this status period |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "startTime": "07/15/2021 14:46:41",
  "endTime": "07/15/2021 14:46:41",
  "status": "ALIVE",
  "description": "description0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

