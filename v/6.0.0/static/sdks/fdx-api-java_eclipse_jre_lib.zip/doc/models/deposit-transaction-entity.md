
# Deposit Transaction Entity

A transaction on a deposit account type

*This model accepts additional fields of type Object.*

## Structure

`DepositTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionType` | [`DepositTransactionType2`](../../doc/models/deposit-transaction-type-2.md) | Optional | CHECK, WITHDRAWAL, TRANSFER, POSDEBIT, ATMWITHDRAWAL, BILLPAYMENT, FEE, DEPOSIT, ADJUSTMENT, INTEREST, DIVIDEND, DIRECTDEPOSIT, ATMDEPOSIT, POSCREDIT | DepositTransactionType2 getTransactionType() | setTransactionType(DepositTransactionType2 transactionType) |
| `Payee` | `String` | Optional | Payee name<br><br>**Constraints**: *Maximum Length*: `255` | String getPayee() | setPayee(String payee) |
| `CheckNumber` | `Integer` | Optional | Check number | Integer getCheckNumber() | setCheckNumber(Integer checkNumber) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "accountCategory": "Deposit Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "postedTimestamp": "2016-03-13T12:52:32.123Z",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "ADJUSTMENT",
  "payee": "payee6",
  "checkNumber": 204
}
```

