
# Month Abbreviation

Used by MonthAmount

*This model accepts additional fields of type Object.*

## Enumeration

`MonthAbbreviation`

## Fields

| Name |
|  --- |
| `Jan` |
| `Feb` |
| `Mar` |
| `Apr` |
| `May` |
| `Jun` |
| `Jul` |
| `Aug` |
| `Sep` |
| `Oct` |
| `Nov` |
| `Dec` |

