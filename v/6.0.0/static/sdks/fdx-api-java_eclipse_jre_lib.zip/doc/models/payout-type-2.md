
# Payout Type 2

Indicates type of payout such as immediate or deferred

*This model accepts additional fields of type Object.*

## Enumeration

`PayoutType2`

## Fields

| Name |
|  --- |
| `Deferred` |
| `Immediate` |

