
# Active Inactive Status

Specifies the employment status of ACTIVE or INACTIVE

*This model accepts additional fields of type Object.*

## Enumeration

`ActiveInactiveStatus`

## Fields

| Name |
|  --- |
| `Active` |
| `Inactive` |

