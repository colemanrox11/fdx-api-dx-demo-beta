
# Sweep Security Entity

A sweep security

*This model accepts additional fields of type Object.*

## Structure

`SweepSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CurrentBalance` | `Double` | Optional | Balance of funds in account | Double getCurrentBalance() | setCurrentBalance(Double currentBalance) |
| `AvailableBalance` | `Double` | Optional | Balance of funds available for use | Double getAvailableBalance() | setAvailableBalance(Double availableBalance) |
| `BalanceAsOf` | `LocalDateTime` | Optional | As-of date of balances | LocalDateTime getBalanceAsOf() | setBalanceAsOf(LocalDateTime balanceAsOf) |
| `Checks` | `Boolean` | Optional | Whether or not checks can be written on the account | Boolean getChecks() | setChecks(Boolean checks) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "balanceAsOf": "07/15/2021 14:46:41",
  "securityCategory": "Sweep Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "currentBalance": 211.94,
  "availableBalance": 78.44,
  "checks": false
}
```

