
# Investment 401 K Source Type 4

Source for money for this security. One of PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST

*This model accepts additional fields of type Object.*

## Enumeration

`Investment401KSourceType4`

## Fields

| Name |
|  --- |
| `Aftertax` |
| `Match` |
| `Othernonvest` |
| `Othervest` |
| `Pretax` |
| `Profitsharing` |
| `Rollover` |

