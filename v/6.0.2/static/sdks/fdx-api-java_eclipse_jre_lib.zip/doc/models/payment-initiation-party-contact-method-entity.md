
# Payment Initiation Party Contact Method Entity

A contact method for a payment initiation party.

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyContactMethodEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`ContactPreferencesType2`](../../doc/models/contact-preferences-type-2.md) | Optional | Type of the contact preference | ContactPreferencesType2 getType() | setType(ContactPreferencesType2 type) |
| `Address` | [`PaymentInitiationPartyContactMethodEntityAddress`](../../doc/models/containers/payment-initiation-party-contact-method-entity-address.md) | Optional | This is a container for any-of cases. | PaymentInitiationPartyContactMethodEntityAddress getAddress() | setAddress(PaymentInitiationPartyContactMethodEntityAddress address) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "FAX",
  "address": {
    "emailAddressText": "emailAddressText4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

