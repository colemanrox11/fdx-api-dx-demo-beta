
# Direct Deposit Entity

Direct deposit details

*This model accepts additional fields of type Object.*

## Structure

`DirectDepositEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DirectDepositId` | `String` | Optional | Unique identifier of the direct deposit configuration<br><br>**Constraints**: *Maximum Length*: `256` | String getDirectDepositId() | setDirectDepositId(String directDepositId) |
| `RegistrationTypeCode` | `String` | Optional | Type code of a registration for a direct deposit account | String getRegistrationTypeCode() | setRegistrationTypeCode(String registrationTypeCode) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "directDepositId": "directDepositId2",
  "registrationTypeCode": "registrationTypeCode0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

