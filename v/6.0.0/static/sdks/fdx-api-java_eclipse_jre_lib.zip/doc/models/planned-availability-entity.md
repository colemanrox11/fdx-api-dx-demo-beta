
# Planned Availability Entity

Provider's plan for API availability

*This model accepts additional fields of type Object.*

## Structure

`PlannedAvailabilityEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`AvailabilityStatus1`](../../doc/models/availability-status-1.md) | Optional | API availability status for this time period | AvailabilityStatus1 getStatus() | setStatus(AvailabilityStatus1 status) |
| `Description` | `String` | Optional | Description of API availability status | String getDescription() | setDescription(String description) |
| `StartTime` | `LocalDateTime` | Optional | Start time for this status period | LocalDateTime getStartTime() | setStartTime(LocalDateTime startTime) |
| `EndTime` | `LocalDateTime` | Optional | End time for this status period | LocalDateTime getEndTime() | setEndTime(LocalDateTime endTime) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "startTime": "07/15/2021 14:46:41",
  "endTime": "07/15/2021 14:46:41",
  "status": "ALIVE",
  "description": "description0",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

