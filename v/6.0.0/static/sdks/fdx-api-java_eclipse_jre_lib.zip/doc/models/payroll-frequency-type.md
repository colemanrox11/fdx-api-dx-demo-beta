
# Payroll Frequency Type

The frequency of employee payments

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollFrequencyType`

## Fields

| Name |
|  --- |
| `Annually` |
| `BiWeekly` |
| `Daily` |
| `Every26Weeks` |
| `Every4Weeks` |
| `Every52Weeks` |
| `Monthly` |
| `Quarterly` |
| `SemiAnnually` |
| `SemiMonthly` |
| `Weekly` |

