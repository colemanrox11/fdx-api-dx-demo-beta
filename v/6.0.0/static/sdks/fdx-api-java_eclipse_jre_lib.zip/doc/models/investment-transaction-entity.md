
# Investment Transaction Entity

Specific transaction information

*This model accepts additional fields of type Object.*

## Structure

`InvestmentTransactionEntity`

## Inherits From

[`Transaction`](../../doc/models/transaction.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `TransactionType` | [`InvestmentTransactionType2`](../../doc/models/investment-transaction-type-2.md) | Optional | PURCHASED, SOLD, PURCHASEDTOCOVER, ADJUSTMENT, PURCHASETOOPEN, PURCHASETOCLOSE, SOLDTOOPEN, SOLDTOCLOSE, INTEREST, MARGININTEREST, REINVESTOFINCOME, RETURNOFCAPITAL, TRANSFER, CONTRIBUTION, FEE, OPTIONEXERCISE, OPTIONEXPIRATION, DIVIDEND, DIVIDENDREINVEST, SPLIT, CLOSURE, INCOME, EXPENSE, CLOSUREOPT, INVEXPENSE, JRNLSEC, JRNLFUND, OTHER, DIV, SRVCHG, DEP, DEPOSIT, ATM, POS, XFER, CHECK, PAYMENT, CASH, DIRECTDEP, DIRECTDEBIT, REPEATPMT | InvestmentTransactionType2 getTransactionType() | setTransactionType(InvestmentTransactionType2 transactionType) |
| `Shares` | `Double` | Optional | Required for stock, mutual funds. Number of shares (with decimals). Negative numbers indicate securities are being removed from the account | Double getShares() | setShares(Double shares) |
| `FaceValue` | `Double` | Optional | Cash value for bonds | Double getFaceValue() | setFaceValue(Double faceValue) |
| `Price` | `Double` | Optional | Unit purchase price | Double getPrice() | setPrice(Double price) |
| `SecurityId` | `String` | Optional | Unique identifier of security | String getSecurityId() | setSecurityId(String securityId) |
| `SecurityIdType` | [`SecurityIdType1`](../../doc/models/security-id-type-1.md) | Optional | CINS, CMC, CME, CUSIP, ISIN, ITSA, NASDAQ, SEDOL, SICC, VALOR, WKN | SecurityIdType1 getSecurityIdType() | setSecurityIdType(SecurityIdType1 securityIdType) |
| `SecurityType` | [`SecurityType2`](../../doc/models/security-type-2.md) | Optional | BOND, DEBT, DIGITALASSET, MUTUALFUND, OPTION, OTHER, STOCK, SWEEP | SecurityType2 getSecurityType() | setSecurityType(SecurityType2 securityType) |
| `Symbol` | `String` | Optional | Ticker symbol | String getSymbol() | setSymbol(String symbol) |
| `Markup` | `Double` | Optional | Portion of unit price that is attributed to the dealer markup | Double getMarkup() | setMarkup(Double markup) |
| `Commission` | `Double` | Optional | Transaction commission | Double getCommission() | setCommission(Double commission) |
| `Taxes` | `Double` | Optional | Taxes on the trade | Double getTaxes() | setTaxes(Double taxes) |
| `Fees` | `Double` | Optional | Fees applied to the trade | Double getFees() | setFees(Double fees) |
| `Load` | `Double` | Optional | Load on the transaction | Double getLoad() | setLoad(Double load) |
| `Inv401KSource` | [`Investment401KSourceType2`](../../doc/models/investment-401-k-source-type-2.md) | Optional | Source of money. One of PRETAX, AFTERTAX, MATCH, PROFITSHARING, ROLLOVER, OTHERVEST, OTHERNONVEST | Investment401KSourceType2 getInv401KSource() | setInv401KSource(Investment401KSourceType2 inv401KSource) |
| `ConfirmationNumber` | `String` | Optional | Confirmation number of the transaction | String getConfirmationNumber() | setConfirmationNumber(String confirmationNumber) |
| `FractionalCash` | `Double` | Optional | Cash for fractional units (used for stock splits) | Double getFractionalCash() | setFractionalCash(Double fractionalCash) |
| `IncomeType` | [`IncomeType2`](../../doc/models/income-type-2.md) | Optional | Type of investment income. One of CGLONG (capital gains-long term), CGSHORT (capital gains-short term), MISC | IncomeType2 getIncomeType() | setIncomeType(IncomeType2 incomeType) |
| `OldUnits` | `Double` | Optional | Number of shares before split | Double getOldUnits() | setOldUnits(Double oldUnits) |
| `SplitRatioNumerator` | `Double` | Optional | Split ratio numerator | Double getSplitRatioNumerator() | setSplitRatioNumerator(Double splitRatioNumerator) |
| `SplitRatioDenominator` | `Double` | Optional | Split ratio denominator | Double getSplitRatioDenominator() | setSplitRatioDenominator(Double splitRatioDenominator) |
| `NewUnits` | `Double` | Optional | Number of shares after split | Double getNewUnits() | setNewUnits(Double newUnits) |
| `SubAccountSec` | [`SubAccountType1`](../../doc/models/sub-account-type-1.md) | Optional | Sub-account security Type. One of CASH, MARGIN, SHORT, OTHERS | SubAccountType1 getSubAccountSec() | setSubAccountSec(SubAccountType1 subAccountSec) |
| `SubAccountFund` | [`SubAccountType2`](../../doc/models/sub-account-type-2.md) | Optional | From which account money came in. One of CASH, MARGIN, SHORT, OTHERS | SubAccountType2 getSubAccountFund() | setSubAccountFund(SubAccountType2 subAccountFund) |
| `LoanId` | `String` | Optional | For 401k accounts only. This indicates the transaction was due to a loan or a loan repayment | String getLoanId() | setLoanId(String loanId) |
| `LoanPrincipal` | `Double` | Optional | How much loan pre-payment is principal | Double getLoanPrincipal() | setLoanPrincipal(Double loanPrincipal) |
| `LoanInterest` | `Double` | Optional | How much loan pre-payment is interest | Double getLoanInterest() | setLoanInterest(Double loanInterest) |
| `PayrollDate` | `LocalDate` | Optional | The date for the 401k transaction was obtained in payroll | LocalDate getPayrollDate() | setPayrollDate(LocalDate payrollDate) |
| `PriorYearContrib` | `Boolean` | Optional | Indicates this buy was made using prior year's contribution | Boolean getPriorYearContrib() | setPriorYearContrib(Boolean priorYearContrib) |
| `Withholding` | `Double` | Optional | Federal tax withholding | Double getWithholding() | setWithholding(Double withholding) |
| `TaxExempt` | `Boolean` | Optional | Tax-exempt transaction | Boolean getTaxExempt() | setTaxExempt(Boolean taxExempt) |
| `Gain` | `Double` | Optional | For sales | Double getGain() | setGain(Double gain) |
| `StateWithholding` | `Double` | Optional | State tax withholding | Double getStateWithholding() | setStateWithholding(Double stateWithholding) |
| `Penalty` | `Double` | Optional | Indicates amount withheld due to a penalty | Double getPenalty() | setPenalty(Double penalty) |
| `RunningBalance` | `Double` | Optional | Running balance of the position | Double getRunningBalance() | setRunningBalance(Double runningBalance) |
| `UnitPrice` | `Double` | Optional | Price per commonly-quoted unit. Does not include markup/markdown, unitprice. Share price for stocks, mutual funds, and others. Percentage of par for bonds. Per share (not contract) for options | Double getUnitPrice() | setUnitPrice(Double unitPrice) |
| `Units` | `Double` | Optional | For security-based actions other than stock splits, quantity. Shares for stocks, mutual funds, and others. Face value for bonds. Contracts for options | Double getUnits() | setUnits(Double units) |
| `UnitType` | [`UnitType1`](../../doc/models/unit-type-1.md) | Optional | SHARES, CURRENCY | UnitType1 getUnitType() | setUnitType(UnitType1 unitType) |
| `TransactionReason` | [`TransactionReason2`](../../doc/models/transaction-reason-2.md) | Optional | Reason for this transaction; CALL (the debt was called), SELL (the debt was sold), MATURITY (the debt reached maturity) | TransactionReason2 getTransactionReason() | setTransactionReason(TransactionReason2 transactionReason) |
| `AccruedInterest` | `Double` | Optional | Accrued interest | Double getAccruedInterest() | setAccruedInterest(Double accruedInterest) |
| `TransferAction` | [`InvestmentTransferActionDirection2`](../../doc/models/investment-transfer-action-direction-2.md) | Optional | Transfer direction | InvestmentTransferActionDirection2 getTransferAction() | setTransferAction(InvestmentTransferActionDirection2 transferAction) |
| `PositionType` | [`PositionType1`](../../doc/models/position-type-1.md) | Optional | LONG, SHORT | PositionType1 getPositionType() | setPositionType(PositionType1 positionType) |
| `DigitalUnits` | `String` | Optional | Full precision unit number, unlimited digits after decimal point | String getDigitalUnits() | setDigitalUnits(String digitalUnits) |
| `SettlementTimestamp` | `LocalDateTime` | Optional | When the trade settled | LocalDateTime getSettlementTimestamp() | setSettlementTimestamp(LocalDateTime settlementTimestamp) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "postedTimestamp": "07/15/2021 14:46:41",
  "transactionTimestamp": "07/15/2021 14:46:41",
  "payrollDate": "2021-07-15",
  "settlementTimestamp": "07/15/2021 14:46:41",
  "accountCategory": "Investment Transaction entity",
  "accountId": "accountId4",
  "transactionId": "transactionId4",
  "referenceTransactionId": "referenceTransactionId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "transactionType": "ADJUSTMENT",
  "shares": 55.78,
  "faceValue": 10.94,
  "price": 166.68,
  "securityId": "securityId0"
}
```

