
# Payment Network Identifier Type

Suggested values for Payment Initiation Identifier Type

*This model accepts additional fields of type Object.*

## Enumeration

`PaymentNetworkIdentifierType`

## Fields

| Name |
|  --- |
| `ACCOUNT_NUMBER` |
| `TOKENIZED_ACCOUNT_NUMBER` |

