
# Business Customer Entity

The business customer information, only used if 'type' is 'BUSINESS'.

*This model accepts additional fields of type Object.*

## Structure

`BusinessCustomerEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name of business customer |
| `registered_agents` | [`Array<CustomerNameEntity1>`](../../doc/models/customer-name-entity-1.md) | Optional | A list of registered agents who act on behalf of the business customer |
| `registered_id` | `String` | Optional | The registered tax identification number (TIN) or other identifier of business customer |
| `industry_code` | [`IndustryCode`](../../doc/models/industry-code.md) | Optional | Industry code and type |
| `domicile` | [`DomicileEntity`](../../doc/models/domicile-entity.md) | Optional | The country and region of the business customer's location |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name0",
  "registeredAgents": [
    {
      "first": "first6",
      "middle": "middle6",
      "last": "last0",
      "suffix": "suffix0",
      "prefix": "prefix8",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "registeredId": "registeredId6",
  "industryCode": {
    "type": "SIC",
    "code": "code0",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "domicile": {
    "region": "region2",
    "country": "EC",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

