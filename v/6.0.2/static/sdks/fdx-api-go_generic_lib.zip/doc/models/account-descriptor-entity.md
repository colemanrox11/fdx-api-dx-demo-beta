
# Account Descriptor Entity

This descriptor provides minimal information about the account for use in lightweight arrays

*This model accepts additional fields of type interface{}.*

## Structure

`AccountDescriptorEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountCategory` | `*string` | Optional | - |
| `AccountId` | `*string` | Optional | Long-term persistent identity of the account, though not an account number. This identity must be unique to the owning institution<br><br>**Constraints**: *Maximum Length*: `256` |
| `Error` | [`*models.Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this account |
| `AccountType` | [`*models.AccountType`](../../doc/models/account-type.md) | Optional | Account type |
| `AccountNumber` | `*string` | Optional | Full account number for the end user for this account at the owning institution. If not masked this is sensitive data which should only be exchanged if encrypted. For detailed information on implementing encryption see "Part 4 End to End Encryption" of the FDX API Security Model document in the Security section of the latest FDX Release download |
| `AccountNumberDisplay` | `*string` | Optional | Account display number for the end user's handle at the owning institution. This is to be displayed by the Interface Provider |
| `ProductName` | `*string` | Optional | Marketed product name for this account. Used in UIs to assist in account selection |
| `Nickname` | `*string` | Optional | Name given by the user. Used in UIs to assist in account selection |
| `Status` | [`*models.AccountStatus2`](../../doc/models/account-status-2.md) | Optional | Account status. Suggested values are: OPEN, CLOSED, PENDINGOPEN, PENDINGCLOSE, PAID, DELINQUENT, NEGATIVECURRENTBALANCE, RESTRICTED |
| `Description` | `*string` | Optional | Description of account |
| `AccountOpenDate` | `*time.Time` | Optional | Account opening date |
| `AccountCloseDate` | `*time.Time` | Optional | Account closing date |
| `Currency` | [`*models.CurrencyEntity4`](../../doc/models/currency-entity-4.md) | Optional | Account currency |
| `FiAttributes` | [`[]models.FiAttributeEntity`](../../doc/models/fi-attribute-entity.md) | Optional | Array of Financial institution-specific attributes |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13T12:52:32.123Z",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13T12:52:32.123Z",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "balanceAsOf": "2016-03-13T12:52:32.123Z",
  "principalBalance": 32.64,
  "escrowBalance": 61.1,
  "originalPrincipal": 9.42,
  "originatingDate": "2016-03-13T12:52:32.123Z"
}
```

