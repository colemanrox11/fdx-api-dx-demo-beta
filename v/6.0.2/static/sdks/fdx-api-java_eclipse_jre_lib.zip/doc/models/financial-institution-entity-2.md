
# Financial Institution Entity 2

Financial institution associated with the branch

*This model accepts additional fields of type Object.*

## Structure

`FinancialInstitutionEntity2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Name of the financial institution | String getName() | setName(String name) |
| `FiId` | [`FinancialInstitutionEntity2FiId`](../../doc/models/containers/financial-institution-entity-2-fi-id.md) | Optional | This is a container for any-of cases. | FinancialInstitutionEntity2FiId getFiId() | setFiId(FinancialInstitutionEntity2FiId fiId) |
| `Locations` | [`List<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Location of the financial institution | List<PaymentDeliveryAddressEntity> getLocations() | setLocations(List<PaymentDeliveryAddressEntity> locations) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "name": "name6",
  "fiId": {
    "bicFIDec2014Id": "bicFIDec2014Id2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "locations": [
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

