
# Policy Status 2

The status of an insurance policy account

*This model accepts additional fields of type Object.*

## Enumeration

`PolicyStatus2`

## Fields

| Name |
|  --- |
| `Active` |
| `DeathClaimPaid` |
| `DeathClaimPending` |
| `Expired` |
| `GracePeriod` |
| `LapsePending` |
| `Terminated` |
| `Waiver` |

