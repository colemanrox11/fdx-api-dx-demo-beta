
# Resource Entity

Details of resource entity

*This model accepts additional fields of type Object.*

## Structure

`ResourceEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resource_id` | `String` | Optional | Long-term persistent identifier for the Resource<br><br>**Constraints**: *Maximum Length*: `256` |
| `status` | [`ResourceStatus2`](../../doc/models/resource-status-2.md) | Optional | Status of Resource |
| `description` | `String` | Optional | Description of resource |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this resource, or to invoke other APIs |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "resourceId": "resourceId6",
  "status": "IN_PROGRESS",
  "description": "description6",
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

