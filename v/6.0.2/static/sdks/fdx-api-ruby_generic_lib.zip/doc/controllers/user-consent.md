# User Consent

```ruby
user_consent_controller = client.user_consent
```

## Class Name

`UserConsentController`

## Methods

* [Get Consent Grant](../../doc/controllers/user-consent.md#get-consent-grant)
* [Revoke Consent Grant](../../doc/controllers/user-consent.md#revoke-consent-grant)
* [Get Consent Revocation](../../doc/controllers/user-consent.md#get-consent-revocation)


# Get Consent Grant

Get a Consent Grant

```ruby
def get_consent_grant(consent_id,
                      x_fapi_interaction_id,
                      fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consent_id` | `String` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ConsentGrantEntity`](../../doc/models/consent-grant-entity.md).

## Example Usage

```ruby
consent_id = '9585694d3ae58863'

x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = user_consent_controller.get_consent_grant(
  consent_id,
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Example Response *(as JSON)*

```json
{
  "id": "9585694d3ae58863",
  "status": "ACTIVE",
  "parties": [
    {
      "name": "Seedling App",
      "type": "DATA_RECIPIENT",
      "homeUri": "https://www.seedling.com",
      "logoUri": "https://www.seedling.com/assets/seedling-logo.png",
      "registry": "FDX",
      "registeredEntityName": "Oak Tree Holdings, Inc",
      "registeredEntityId": "5493001052I34KDC1O18"
    },
    {
      "name": "Midwest Primary Bank, NA",
      "type": "DATA_PROVIDER",
      "homeUri": "https://www.midwest.com",
      "logoUri": "https://www.midwest.com/81d88112572c.jpg",
      "registry": "GLEIF",
      "registeredEntityName": "Midwest Primary Bank, NA",
      "registeredEntityId": "549300ATG070THRDJ595"
    }
  ],
  "createdTime": "2021-07-03T21:28:10.375Z",
  "expirationTime": "2021-07-03T22:28:10.374Z",
  "durationType": "ONE_TIME",
  "lookbackPeriod": 60,
  "resources": [
    {
      "resourceType": "ACCOUNT",
      "resourceId": "b14e1e714693bc00",
      "dataClusters": [
        "ACCOUNT_DETAILED",
        "TRANSACTIONS",
        "STATEMENTS"
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |


# Revoke Consent Grant

Revoke a Consent Grant

```ruby
def revoke_consent_grant(consent_id,
                         x_fapi_interaction_id,
                         body,
                         fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consent_id` | `String` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `body` | [`ConsentRevocationRequestEntity`](../../doc/models/consent-revocation-request-entity.md) | Body, Required | Reason and initiator of revocation |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```ruby
consent_id = '9585694d3ae58863'

x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

body = ConsentRevocationRequestEntity.new(
  reason: ConsentUpdateReason1::BUSINESS_RULE,
  initiator: PartyType2::DATA_ACCESS_PLATFORM
)

result = user_consent_controller.revoke_consent_grant(
  consent_id,
  x_fapi_interaction_id,
  body
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Input sent by client does not satisfy API specification | [`ErrorException`](../../doc/models/error-exception.md) |
| 401 | Request lacks valid authentication credentials for the target resource | [`ErrorException`](../../doc/models/error-exception.md) |
| 403 | Forbidden, server understands the request but refuses to authorize it | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Data not found for request parameters | [`ErrorException`](../../doc/models/error-exception.md) |
| 409 | Conflict with current state of target resource | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Consent Revocation

Retrieve Consent Revocation record

```ruby
def get_consent_revocation(consent_id,
                           x_fapi_interaction_id,
                           fdx_api_actor_type: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consent_id` | `String` | Template, Required | Consent Identifier<br><br>**Constraints**: *Maximum Length*: `256` |
| `x_fapi_interaction_id` | `UUID \| String` | Header, Required | Unique identifier for this interaction |
| `fdx_api_actor_type` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`ConsentRevocationListEntity`](../../doc/models/consent-revocation-list-entity.md).

## Example Usage

```ruby
consent_id = '9585694d3ae58863'

x_fapi_interaction_id = 'c770aef3-6784-41f7-8e0e-ff5f97bddb3a'

fdx_api_actor_type = FdxApiActorType::BATCH

result = user_consent_controller.get_consent_revocation(
  consent_id,
  x_fapi_interaction_id,
  fdx_api_actor_type: fdx_api_actor_type
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

