
# Consent Revocation Entity

Details of request to revoke consent grant

*This model accepts additional fields of type Object.*

## Structure

`ConsentRevocationEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`ConsentGrantStatus1`](../../doc/models/consent-grant-status-1.md) | Optional | The status of the consent = REVOKED | ConsentGrantStatus1 getStatus() | setStatus(ConsentGrantStatus1 status) |
| `Reason` | [`ConsentUpdateReason1`](../../doc/models/consent-update-reason-1.md) | Optional | The reason for consent revocation | ConsentUpdateReason1 getReason() | setReason(ConsentUpdateReason1 reason) |
| `Initiator` | [`PartyType1`](../../doc/models/party-type-1.md) | Optional | The party initiating consent revocation | PartyType1 getInitiator() | setInitiator(PartyType1 initiator) |
| `UpdatedTime` | `LocalDateTime` | Optional | When the consent grant was revoked | LocalDateTime getUpdatedTime() | setUpdatedTime(LocalDateTime updatedTime) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "updatedTime": "07/15/2021 14:46:41",
  "status": "EXPIRED",
  "reason": "BUSINESS_RULE",
  "initiator": "MERCHANT",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

