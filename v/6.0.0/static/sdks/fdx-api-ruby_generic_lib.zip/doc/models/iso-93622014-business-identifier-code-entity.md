
# Iso 93622014 Business Identifier Code Entity

[ISO 9362:2014](https://www.swift.com/standards/data-standards/bic-business-identifier-code)
Business Identifier Code for Financial Institutions
(see [whitepaper](https://www.swift.com/swift-resource/14256/download))
Deprecated and superceded by `Iso9362BusinessIdCode2022` (ISO 9362:2022). BICFIDec2014Identifier will be
removed after multi-year transition from 9362:2014

*This model accepts additional fields of type Object.*

## Structure

`Iso93622014BusinessIdentifierCodeEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `bic_fi_dec_2014_id` | `String` | Optional | Business identifier code of the financial institution |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "bicFIDec2014Id": "bicFIDec2014Id2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

