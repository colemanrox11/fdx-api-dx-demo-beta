
# Recurring Payment for Update Entity 1

The data of the Recurring Payment to be scheduled

*This model accepts additional fields of type Object.*

## Structure

`RecurringPaymentForUpdateEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Frequency` | [`RecurringPaymentFrequency2`](../../doc/models/recurring-payment-frequency-2.md) | Required | Defines how often the payment repeats | RecurringPaymentFrequency2 getFrequency() | setFrequency(RecurringPaymentFrequency2 frequency) |
| `Duration` | [`RecurringPaymentDurationEntity2`](../../doc/models/recurring-payment-duration-entity-2.md) | Optional | Defines how long the payment repeats for | RecurringPaymentDurationEntity2 getDuration() | setDuration(RecurringPaymentDurationEntity2 duration) |
| `FromAccountId` | `String` | Required | ID of the account used to source funds for payment<br><br>**Constraints**: *Maximum Length*: `256` | String getFromAccountId() | setFromAccountId(String fromAccountId) |
| `ToPayeeId` | `String` | Required | ID of the payee to receive funds for the payment<br><br>**Constraints**: *Maximum Length*: `256` | String getToPayeeId() | setToPayeeId(String toPayeeId) |
| `Amount` | `double` | Required | Amount for the payment. Must be positive<br><br>**Constraints**: `>= 0` | double getAmount() | setAmount(double amount) |
| `MerchantAccountId` | `String` | Optional | User's account identifier with the merchant | String getMerchantAccountId() | setMerchantAccountId(String merchantAccountId) |
| `DueDate` | `LocalDate` | Required | Date that the funds are scheduled to be delivered | LocalDate getDueDate() | setDueDate(LocalDate dueDate) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "frequency": "BIMONTHLY",
  "fromAccountId": "fromAccountId4",
  "toPayeeId": "toPayeeId8",
  "amount": 227.92,
  "dueDate": "2021-07-15",
  "duration": {
    "type": "NOEND",
    "numberOfTimes": 181.2,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "merchantAccountId": "merchantAccountId8",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

