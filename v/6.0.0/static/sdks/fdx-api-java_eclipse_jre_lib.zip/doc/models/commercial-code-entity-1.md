
# Commercial Code Entity 1

The code for a specific treasury management defined field

*This model accepts additional fields of type Object.*

## Structure

`CommercialCodeEntity1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | [`TreasuryManagementType`](../../doc/models/treasury-management-type.md) | Optional | The source of Treasury Management account definition; one of BAI, BTRS, ISO, SWIFT | TreasuryManagementType getType() | setType(TreasuryManagementType type) |
| `Code` | `String` | Optional | The code of the Treasury Management defined field | String getCode() | setCode(String code) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "type": "ISO",
  "code": "code4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

