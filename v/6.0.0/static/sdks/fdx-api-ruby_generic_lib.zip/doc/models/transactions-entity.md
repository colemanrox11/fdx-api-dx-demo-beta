
# Transactions Entity

Optionally paginated array of transactions

*This model accepts additional fields of type Object.*

## Structure

`TransactionsEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets |
| `links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets |
| `transactions` | Array[[Commercial Transaction entity](../../doc/models/commercial-transaction-entity.md) \| [Deposit Transaction entity](../../doc/models/deposit-transaction-entity.md) \| [Digital Wallet Transaction entity](../../doc/models/digital-wallet-transaction-entity.md) \| [Insurance Transaction entity](../../doc/models/insurance-transaction-entity.md) \| [Investment Transaction entity](../../doc/models/investment-transaction-entity.md) \| [Line of Credit Transaction entity](../../doc/models/line-of-credit-transaction-entity.md) \| [Loan Transaction entity](../../doc/models/loan-transaction-entity.md)] \| nil | Optional | This is Array of a container for any-of cases. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "transactions": [
    {
      "accountCategory": "Commercial Transaction entity",
      "accountId": "accountId4",
      "transactionId": "transactionId4",
      "referenceTransactionId": "referenceTransactionId4",
      "postedTimestamp": "2016-03-13T12:52:32.123Z",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      },
      "immediateAvailableBalance": 89.1,
      "nextDayAvailableBalance": 186.56,
      "twoDaysPlusAvailableBalance": 86.66,
      "referenceBankId": "referenceBankId4",
      "referenceBranchId": "referenceBranchId8"
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

