
# Payroll Report Entity

An employee's Payroll Report

*This model accepts additional fields of type Object.*

## Structure

`PayrollReportEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `report_id` | `String` | Required | The report identification number<br><br>**Constraints**: *Maximum Length*: `256` |
| `report_type` | [`PayrollReportType1`](../../doc/models/payroll-report-type-1.md) | Required | The type of report |
| `generation_date` | `Date` | Required | The generation date of the report |
| `data_as_of` | `Date` | Optional | The data in the report is as of this date. |
| `employee` | [`EmployeeEntity1`](../../doc/models/employee-entity-1.md) | Required | The employee |
| `employment` | [`Employment1`](../../doc/models/employment-1.md) | Required | The employee's employment |
| `incomes` | [`Array<Income>`](../../doc/models/income.md) | Optional | The employee's year to date income amounts for current and previous years omitted for Verification of Employment requests (VOE), included for Verification of Income and Employment requests (VOI / VOIE) |
| `links` | [`Array<HateoasLink>`](../../doc/models/hateoas-link.md) | Optional | Links to retrieve this payroll report, or to invoke related APIs |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "reportId": "reportId4",
  "reportType": "VOE",
  "generationDate": "2021-07-15",
  "dataAsOf": "2021-07-15",
  "employee": {
    "dateOfBirth": "2021-07-15",
    "name": {
      "first": "first6",
      "middle": "middle6",
      "last": "last0",
      "suffix": "suffix0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "emails": [
      "emails7"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "taxId": "taxId4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "employment": {
    "employer": {
      "employerId": "employerId2",
      "name": {
        "name1": "name10",
        "name2": "name24",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "dbas": [
        "dbas1"
      ],
      "taxId": "taxId8",
      "taxIdCountry": "SK",
      "contacts": {
        "emails": [
          "emails7",
          "emails8",
          "emails9"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "originalHireDate": "2021-07-15",
    "mostRecentHireDate": "2021-07-15",
    "endDate": "2021-07-15",
    "status": "ACTIVE",
    "jobTitle": "jobTitle6",
    "supplementalStatus": "VACATION",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "incomes": [
    {
      "baseRate": {
        "rate": {
          "amount": 238.12,
          "currency": "JPY",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "rateType": "HOURLY",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "payrollFrequency": "SEMI_MONTHLY",
      "latestPayDate": "2016-03-13",
      "latestPayPeriodEndDate": "2016-03-13",
      "annualPay": {
        "year": 218,
        "grossPay": {
          "total": {
            "amount": 71.32,
            "currency": "DOP",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          "base": {
            "amount": 221.48,
            "currency": "TJS",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          "bonus": {
            "amount": 28.78,
            "currency": "MMK",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          "commission": {
            "amount": 19.08,
            "currency": "ISK",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          "overtime": {
            "amount": 44.08,
            "currency": "XTS",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          "otherEarnings": [
            {
              "amount": 117.02,
              "currency": "MDL",
              "name": "name0",
              "exampleAdditionalProperty": {
                "key1": "val1",
                "key2": "val2"
              }
            },
            {
              "amount": 117.02,
              "currency": "MDL",
              "name": "name0",
              "exampleAdditionalProperty": {
                "key1": "val1",
                "key2": "val2"
              }
            }
          ],
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "netPay": {
          "amount": 9.88,
          "currency": "BBD",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "links": [
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "href": "href6",
      "action": "PATCH",
      "rel": "rel0",
      "types": [
        "application/json",
        "application/pdf"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

