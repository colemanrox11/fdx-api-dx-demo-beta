
# Account Contact Entity

Contact information for the account

*This model accepts additional fields of type Object.*

## Structure

`AccountContactEntity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Emails` | `List<String>` | Optional | Array of the contact email addresses | List<String> getEmails() | setEmails(List<String> emails) |
| `Addresses` | [`List<DeliveryAddress>`](../../doc/models/delivery-address.md) | Optional | Array of the contact physical addresses | List<DeliveryAddress> getAddresses() | setAddresses(List<DeliveryAddress> addresses) |
| `Telephones` | [`List<TelephoneNumber>`](../../doc/models/telephone-number.md) | Optional | Array of the contact telephone numbers | List<TelephoneNumber> getTelephones() | setTelephones(List<TelephoneNumber> telephones) |
| `Holders` | [`List<AccountHolderEntity>`](../../doc/models/account-holder-entity.md) | Optional | Owners of the account | List<AccountHolderEntity> getHolders() | setHolders(List<AccountHolderEntity> holders) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "emails": [
    "emails1"
  ],
  "addresses": [
    {
      "line1": "line16",
      "line2": "line28",
      "line3": "line36",
      "city": "city4",
      "region": "region0",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "telephones": [
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "type": "FAX",
      "country": "country0",
      "number": "number4",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "holders": [
    {
      "emails": [
        "emails5",
        "emails6"
      ],
      "addresses": [
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "telephones": [
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "dateOfBirth": "2016-03-13",
      "taxId": "taxId2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "emails": [
        "emails5",
        "emails6"
      ],
      "addresses": [
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        },
        {
          "line1": "line16",
          "line2": "line28",
          "line3": "line36",
          "city": "city4",
          "region": "region0",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "telephones": [
        {
          "type": "FAX",
          "country": "country0",
          "number": "number4",
          "exampleAdditionalProperty": {
            "key1": "val1",
            "key2": "val2"
          }
        }
      ],
      "dateOfBirth": "2016-03-13",
      "taxId": "taxId2",
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

