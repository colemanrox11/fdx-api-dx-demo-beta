
# Page Metadata Links 1

Links used to paginate results

*This model accepts additional fields of type Object.*

## Structure

`PageMetadataLinks1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mnext` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Resource URL for retrieving next dataset |
| `prev` | [`HateoasLink`](../../doc/models/hateoas-link.md) | Optional | Resource URL for retrieving previous dataset |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "next": {
    "href": "href4",
    "action": "DELETE",
    "rel": "rel8",
    "types": [
      "image/png"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "prev": {
    "href": "href8",
    "action": "GET",
    "rel": "rel2",
    "types": [
      "image/tiff"
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

