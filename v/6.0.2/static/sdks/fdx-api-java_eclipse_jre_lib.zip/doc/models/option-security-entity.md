
# Option Security Entity

An option

*This model accepts additional fields of type Object.*

## Structure

`OptionSecurityEntity`

## Inherits From

[`SecurityEntity`](../../doc/models/security-entity.md)

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Secured` | [`Secured2`](../../doc/models/secured-2.md) | Optional | How the option is secured. One of NAKED, COVERED | Secured2 getSecured() | setSecured(Secured2 secured) |
| `OptionType` | [`OptionType2`](../../doc/models/option-type-2.md) | Optional | Option type. One of PUT, CALL | OptionType2 getOptionType() | setOptionType(OptionType2 optionType) |
| `StrikePrice` | `Double` | Optional | Strike price / Unit price | Double getStrikePrice() | setStrikePrice(Double strikePrice) |
| `ExpireDate` | `LocalDate` | Optional | Expiration date of option | LocalDate getExpireDate() | setExpireDate(LocalDate expireDate) |
| `SharesPerContract` | `Double` | Optional | Shares per contract | Double getSharesPerContract() | setSharesPerContract(Double sharesPerContract) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example (as JSON)

```json
{
  "expireDate": "2021-07-15",
  "securityCategory": "Option Security entity",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "secured": "COVERED",
  "optionType": "CALL",
  "strikePrice": 190.26,
  "sharesPerContract": 151.06
}
```

