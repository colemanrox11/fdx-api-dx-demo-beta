# Account Statements

```go
accountStatementsController := client.AccountStatementsController()
```

## Class Name

`AccountStatementsController`

## Methods

* [Search for Account Statements](../../doc/controllers/account-statements.md#search-for-account-statements)
* [Get Account Statement](../../doc/controllers/account-statements.md#get-account-statement)


# Search for Account Statements

Get account statements. Example: GET /accounts/{accountId}/statements?startTime=value1&endTime=value2

```go
SearchForAccountStatements(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    accountId string,
    fdxApiActorType *models.FdxApiActorType,
    startTime *time.Time,
    endTime *time.Time,
    offset *string,
    limit *int) (
    models.ApiResponse[models.AnArrayOfStatements],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `string` | Template, Required | Account Identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `startTime` | `*time.Time` | Query, Optional | Start time for use in retrieval of elements (ISO 8601) |
| `endTime` | `*time.Time` | Query, Optional | End time for use in retrieval of elements (ISO 8601) |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.AnArrayOfStatements](../../doc/models/an-array-of-statements.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

accountId := "accountId0"

fdxApiActorType := models.FdxApiActorType_Batch

startTime := parseTime(time.RFC3339, "2021-07-15", func(err error) { log.Fatalln(err) })

endTime := parseTime(time.RFC3339, "2021-07-15", func(err error) { log.Fatalln(err) })





apiResponse, err := accountStatementsController.SearchForAccountStatements(ctx, xFapiInteractionId, accountId, &fdxApiActorType, &startTime, &endTime, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "2",
    "total": 3
  },
  "links": {
    "next": {
      "href": "/accounts/1111/statements?offSet=2&limit=10"
    }
  },
  "statements": [
    {
      "accountId": "10001",
      "statementId": "40004"
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Start or end date value is not in the ISO 8601 format | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | Account with id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |


# Get Account Statement

Gets an account statement image file. Use [HTTP Accept request-header](https://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html) to specify desired content types. See ContentTypes definition for typical values

```go
GetAccountStatement(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    accountId string,
    statementId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[interface{}],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `accountId` | `string` | Template, Required | Account Identifier |
| `statementId` | `string` | Template, Required | Statement Identifier |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type interface{}.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

accountId := "accountId0"

statementId := "statementId6"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := accountStatementsController.GetAccountStatement(ctx, xFapiInteractionId, accountId, statementId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Statement is processing and is not yet available | [`ErrorException`](../../doc/models/error-exception.md) |
| 404 | When account is present with no statements in it | [`ErrorException`](../../doc/models/error-exception.md) |
| 406 | Content Type not Supported | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

