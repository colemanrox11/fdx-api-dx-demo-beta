
# Order Type

The type of the order

*This model accepts additional fields of type interface{}.*

## Enumeration

`OrderType`

## Fields

| Name |
|  --- |
| `Buy` |
| `Buytocover` |
| `Buytoopen` |
| `Sell` |
| `Sellclose` |
| `Sellshort` |
| `Selltocover` |
| `Selltoopen` |

