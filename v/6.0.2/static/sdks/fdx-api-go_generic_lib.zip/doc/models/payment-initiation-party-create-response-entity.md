
# Payment Initiation Party Create Response Entity

Entity that stores FI payment initiation party details. Each payment
initiation party  will have a separate entry per FI customer, e.g. we
might have multiple payment initiation parties that represent the same
physical person, nevertheless since they are registered for separate
customers then they will have separate entries.

*This model accepts additional fields of type interface{}.*

## Structure

`PaymentInitiationPartyCreateResponseEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentInitiationPartyId` | `*string` | Optional | Unique identifier of a payment initiation party<br><br>**Constraints**: *Maximum Length*: `256` |
| `AdditionalProperties` | `map[string]interface{}` | Optional | - |

## Example (as JSON)

```json
{
  "paymentInitiationPartyId": "paymentInitiationPartyId2",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

