# Reward Program Information

```java
RewardProgramInformationController rewardProgramInformationController = client.getRewardProgramInformationController();
```

## Class Name

`RewardProgramInformationController`

## Methods

* [Search Reward Programs](../../doc/controllers/reward-program-information.md#search-reward-programs)
* [Get Reward Program](../../doc/controllers/reward-program-information.md#get-reward-program)


# Search Reward Programs

Query all reward programs

```java
CompletableFuture<ApiResponse<RewardProgramsEntity>> searchRewardProgramsAsync(
    final UUID xFapiInteractionId,
    final FdxApiActorType fdxApiActorType,
    final String offset,
    final Integer limit)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `String` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `Integer` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RewardProgramsEntity`](../../doc/models/reward-programs-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

rewardProgramInformationController.searchRewardProgramsAsync(xFapiInteractionId, fdxApiActorType, null, null).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "rewardPrograms": [
    {
      "programName": "Marriott Bonvoy",
      "rewardProgramId": "4FRCCQvGW0GZEMtsOQWlkQ",
      "programUrl": "https://www.marriott.com/loyalty.mi",
      "memberships": [
        {
          "accountIds": [
            "af0f8e58-9649-4c29-bab2-0295d522cd6f",
            "e75e31eb-bf04-4d87-9f20-4554f63a639e"
          ],
          "businessOrConsumer": "CONSUMER",
          "customerId": "kBA5C3d7cBK9DuRngsQRwt6Ydo80bjYDR7n4O5yCKshizuS7hOZJ4cAevBne",
          "memberId": "5ee28848b4f242a6b7a41e0daa03a824",
          "memberNumber": "1783949940",
          "memberTier": "Gold",
          "balances": [
            {
              "name": "Points",
              "type": "POINTS",
              "balance": 900,
              "accruedYtd": 1000,
              "redeemedYtd": 200,
              "qualifying": false
            },
            {
              "name": "Promotional",
              "type": "POINTS",
              "balance": 900,
              "accrued": 1000,
              "redeemed": 200,
              "qualifying": false
            }
          ]
        }
      ]
    },
    {
      "programName": "United MileagePlus®",
      "rewardProgramId": "GY4cHWCPxkqgkY61h4BKdQ",
      "programUrl": "https://www.united.com/en/us/fly/mileageplus.html",
      "memberships": [
        {
          "accountIds": [
            "b4ef4572-452d-41bd-9d2d-1b29dafe63f0"
          ],
          "businessOrConsumer": "BUSINESS",
          "customerId": "kBA5C3d7cBK9DuRngsQRwt6Ydo80bjYDR7n4O5yCKshizuS7hOZJ4cAevBne",
          "memberId": "b6b319dd3e2c4592847ad6ee32d518bc",
          "memberNumber": "9394970669",
          "balances": [
            {
              "name": "Miles",
              "type": "MILES",
              "balance": 900,
              "accrued": 1000,
              "redeemed": 200,
              "qualifying": false
            }
          ]
        }
      ]
    },
    {
      "programName": "Starbucks Rewards",
      "rewardProgramId": "iqOtPUEYb0Go6SCL8As4fQ",
      "programUrl": "https://www.starbucks.com/rewards",
      "memberships": [
        {
          "accountIds": [
            "89cf3262-ff38-4f6a-afbc-aafc50cac751"
          ],
          "businessOrConsumer": "CONSUMER",
          "customerId": "kBA5C3d7cBK9DuRngsQRwt6Ydo80bjYDR7n4O5yCKshizuS7hOZJ4cAevBne",
          "memberId": "95c1aeacd85e4783950a9c2d6e76efa9",
          "memberNumber": "7417973194",
          "balances": [
            {
              "name": "Stars",
              "type": "POINTS",
              "balance": 900,
              "accrued": 1000,
              "redeemed": 200,
              "qualifying": false
            }
          ]
        }
      ]
    }
  ]
}
```


# Get Reward Program

Get a specific reward program

```java
CompletableFuture<ApiResponse<RewardProgramEntity>> getRewardProgramAsync(
    final UUID xFapiInteractionId,
    final String rewardProgramId,
    final FdxApiActorType fdxApiActorType)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `UUID` | Header, Required | Unique identifier for this interaction |
| `rewardProgramId` | `String` | Template, Required | Reward Program Identifier |
| `fdxApiActorType` | [`FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Server

`Server.CORE`

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`RewardProgramEntity`](../../doc/models/reward-program-entity.md).

## Example Usage

```java
UUID xFapiInteractionId = UUID.fromString("c770aef3-6784-41f7-8e0e-ff5f97bddb3a");
String rewardProgramId = "rewardProgramId6";
FdxApiActorType fdxApiActorType = FdxApiActorType.BATCH;

rewardProgramInformationController.getRewardProgramAsync(xFapiInteractionId, rewardProgramId, fdxApiActorType).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Example Response *(as JSON)*

```json
{
  "programName": "Discover Cashback Bonus",
  "rewardProgramId": "ywX9ME0FXUa6Mtj0xkOgtA",
  "programUrl": "https://www.discover.com/credit-cards/cashback-bonus/",
  "memberships": [
    {
      "accountIds": [
        "af0f8e58-9649-4c29-bab2-0295d522cd6f",
        "e75e31eb-bf04-4d87-9f20-4554f63a639e"
      ],
      "businessOrConsumer": "CONSUMER",
      "customerId": "kBA5C3d7cBK9DuRngsQRwt6Ydo80bjYDR7n4O5yCKshizuS7hOZJ4cAevBne",
      "memberId": "b0a853a278804e1694d3104709cbfb58",
      "memberNumber": "6137299224",
      "memberTier": "Gold",
      "balances": [
        {
          "name": "Cashback",
          "type": "CASHBACK",
          "balance": 101.95,
          "accruedYtd": 4500.1,
          "redeemedYtd": 234.45,
          "qualifying": false
        },
        {
          "name": "Cashback Match",
          "type": "CASHBACK",
          "balance": 401.95,
          "accruedYtd": 500.1,
          "redeemedYtd": 134.45,
          "qualifying": false
        }
      ]
    }
  ]
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 404 | Reward program Id not found | [`ErrorException`](../../doc/models/error-exception.md) |
| 500 | Catch-all exception where request was not processed due to an internal outage/issue. Consider other more specific errors before using this error | [`ErrorException`](../../doc/models/error-exception.md) |
| 501 | Error when FdxVersion in Header is not one of those implemented at backend | [`ErrorException`](../../doc/models/error-exception.md) |
| 503 | System is down for maintenance | [`ErrorException`](../../doc/models/error-exception.md) |

