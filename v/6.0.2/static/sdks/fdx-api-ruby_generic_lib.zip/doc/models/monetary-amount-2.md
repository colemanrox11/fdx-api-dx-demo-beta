
# Monetary Amount 2

Base pay part of Gross pay for covered period

*This model accepts additional fields of type Object.*

## Structure

`MonetaryAmount2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `amount` | `Float` | Required | The monetary amount |
| `currency` | [`Iso4217CurrencyCode`](../../doc/models/iso-4217-currency-code.md) | Optional | Currency code of the monetary amount |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "amount": 86.48,
  "currency": "PGK",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

