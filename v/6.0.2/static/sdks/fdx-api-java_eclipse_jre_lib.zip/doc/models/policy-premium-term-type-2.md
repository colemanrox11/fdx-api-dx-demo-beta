
# Policy Premium Term Type 2

The payment term for the premium

*This model accepts additional fields of type Object.*

## Enumeration

`PolicyPremiumTermType2`

## Fields

| Name |
|  --- |
| `Annual` |
| `Monthly` |

