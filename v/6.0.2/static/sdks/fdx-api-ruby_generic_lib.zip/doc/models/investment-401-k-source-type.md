
# Investment 401 K Source Type

The source of a 401k investment

*This model accepts additional fields of type Object.*

## Enumeration

`Investment401KSourceType`

## Fields

| Name |
|  --- |
| `AFTERTAX` |
| `MATCH` |
| `OTHERNONVEST` |
| `OTHERVEST` |
| `PRETAX` |
| `PROFITSHARING` |
| `ROLLOVER` |

