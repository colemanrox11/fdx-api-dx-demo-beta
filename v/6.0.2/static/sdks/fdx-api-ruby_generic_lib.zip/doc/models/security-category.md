
# Security Category

The type of security

*This model accepts additional fields of type Object.*

## Enumeration

`SecurityCategory`

## Fields

| Name |
|  --- |
| `DEBT_SECURITY` |
| `MUTUAL_FUND_SECURITY` |
| `OPTION_SECURITY` |
| `OTHER_SECURITY` |
| `STOCK_SECURITY` |
| `SWEEP_SECURITY` |

