
# Notification Category 1

Category of notification

*This model accepts additional fields of type Object.*

## Enumeration

`NotificationCategory1`

## Fields

| Name |
|  --- |
| `CONSENT` |
| `FRAUD` |
| `MAINTENANCE` |
| `NEW_DATA` |
| `SECURITY` |

