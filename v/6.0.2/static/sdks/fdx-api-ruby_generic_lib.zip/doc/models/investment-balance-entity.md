
# Investment Balance Entity

A point-in-time balance of the investment account

*This model accepts additional fields of type Object.*

## Structure

`InvestmentBalanceEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `balance_name` | `String` | Optional | Name of the balance |
| `balance_description` | `String` | Optional | Description of balance |
| `balance_type` | [`InvestmentBalanceType2`](../../doc/models/investment-balance-type-2.md) | Optional | AMOUNT, PERCENTAGE |
| `balance_value` | `Float` | Optional | Value of named balance |
| `balance_date` | `Date` | Optional | Date as of this balance |
| `currency` | [`CurrencyEntity2`](../../doc/models/currency-entity-2.md) | Optional | Currency if different from that of account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "balanceDate": "2021-07-15",
  "balanceName": "balanceName0",
  "balanceDescription": "balanceDescription4",
  "balanceType": "AMOUNT",
  "balanceValue": 27.2,
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

