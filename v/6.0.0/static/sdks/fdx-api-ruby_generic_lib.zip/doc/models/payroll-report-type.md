
# Payroll Report Type

The type of payroll report, VOE - for Verification of Employment, VOIE - for Verification of Income and Employment

*This model accepts additional fields of type Object.*

## Enumeration

`PayrollReportType`

## Fields

| Name |
|  --- |
| `VOE` |
| `VOIE` |

