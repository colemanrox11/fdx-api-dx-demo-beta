
# Financial Institution Entity 2

Financial institution associated with the branch

*This model accepts additional fields of type Object.*

## Structure

`FinancialInstitutionEntity2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name of the financial institution |
| `fi_id` | [ISO 9362:2014 Business Identifier Code entity](../../doc/models/iso-93622014-business-identifier-code-entity.md) \| [ISO 9362:2022 Business Identifier Code entity](../../doc/models/iso-93622022-business-identifier-code-entity.md) \| [Generic Financial Institution Id entity](../../doc/models/generic-financial-institution-id-entity.md) \| nil | Optional | This is a container for any-of cases. |
| `locations` | [`Array<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Location of the financial institution |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name6",
  "fiId": {
    "bicFIDec2014Id": "bicFIDec2014Id2",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "locations": [
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "type": "HOME",
      "address": {
        "emailAddressText": "emailAddressText4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

