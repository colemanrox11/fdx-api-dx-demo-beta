
# Coverage Month 1

Month

*This model accepts additional fields of type Object.*

## Enumeration

`CoverageMonth1`

## Fields

| Name |
|  --- |
| `ANNUAL` |
| `JANUARY` |
| `FEBRUARY` |
| `MARCH` |
| `APRIL` |
| `MAY` |
| `JUNE` |
| `JULY` |
| `AUGUST` |
| `SEPTEMBER` |
| `OCTOBER` |
| `NOVEMBER` |
| `DECEMBER` |

