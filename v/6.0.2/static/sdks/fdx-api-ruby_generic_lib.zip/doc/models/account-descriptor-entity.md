
# Account Descriptor Entity

This descriptor provides minimal information about the account for use in lightweight arrays

*This model accepts additional fields of type Object.*

## Structure

`AccountDescriptorEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_category` | `String` | Optional | - |
| `account_id` | `String` | Optional | Long-term persistent identity of the account, though not an account number. This identity must be unique to the owning institution<br><br>**Constraints**: *Maximum Length*: `256` |
| `error` | [`Error1`](../../doc/models/error-1.md) | Optional | Present if an error was encountered while retrieving this account |
| `account_type` | [`AccountType`](../../doc/models/account-type.md) | Optional | Account type |
| `account_number` | `String` | Optional | Full account number for the end user for this account at the owning institution. If not masked this is sensitive data which should only be exchanged if encrypted. For detailed information on implementing encryption see "Part 4 End to End Encryption" of the FDX API Security Model document in the Security section of the latest FDX Release download |
| `account_number_display` | `String` | Optional | Account display number for the end user's handle at the owning institution. This is to be displayed by the Interface Provider |
| `product_name` | `String` | Optional | Marketed product name for this account. Used in UIs to assist in account selection |
| `nickname` | `String` | Optional | Name given by the user. Used in UIs to assist in account selection |
| `status` | [`AccountStatus2`](../../doc/models/account-status-2.md) | Optional | Account status. Suggested values are: OPEN, CLOSED, PENDINGOPEN, PENDINGCLOSE, PAID, DELINQUENT, NEGATIVECURRENTBALANCE, RESTRICTED |
| `description` | `String` | Optional | Description of account |
| `account_open_date` | `Date` | Optional | Account opening date |
| `account_close_date` | `Date` | Optional | Account closing date |
| `currency` | [`CurrencyEntity4`](../../doc/models/currency-entity-4.md) | Optional | Account currency |
| `fi_attributes` | [`Array<FiAttributeEntity>`](../../doc/models/fi-attribute-entity.md) | Optional | Array of Financial institution-specific attributes |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "balanceAsOf": "2016-03-13T12:52:32.123Z",
  "principalBalance": 32.64,
  "escrowBalance": 61.1,
  "originalPrincipal": 9.42,
  "originatingDate": "2016-03-13"
}
```

