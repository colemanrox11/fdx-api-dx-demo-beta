
# Payment Initiation Party Entity

Party details for FI payment initiation. Each payment initiation party
will have a separate entry per FI customer, for example we
might have multiple payment initiation parties that represent the same
physical person; since they are registered for separate
customers they will have separate entries.

*This model accepts additional fields of type Object.*

## Structure

`PaymentInitiationPartyEntity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Required | Human recognizable common name |
| `type` | [`PartyType`](../../doc/models/party-type.md) | Required | Extensible string enum identifying the type of the party |
| `home_uri` | `String` | Optional | URI for party, where an end user could learn more about the company or application involved in the data sharing chain |
| `logo_uri` | `String` | Optional | URI for a logo asset to be displayed to the end user |
| `registry` | [`Registry`](../../doc/models/registry.md) | Optional | The registry containing the party's registration with name and id: FDX, GLEIF, ICANN, PRIVATE |
| `registered_entity_name` | `String` | Optional | Registered name of party |
| `registered_entity_id` | `String` | Optional | Registered id of party |
| `party_groups` | [`Array<PartyGroupEntity>`](../../doc/models/party-group-entity.md) | Optional | The PartyGroups to which this initiation party belongs.<br>Optional, can be omitted if party belongs to no groups. |
| `payment_initiation_party_name` | [`PaymentInitiationPartyNameEntity1`](../../doc/models/payment-initiation-party-name-entity-1.md) | Optional | Name entity associated with the payment initiation party |
| `government_issued_party_ids` | [`Array<GovernmentIssuedPartyIdentificationEntity>`](../../doc/models/government-issued-party-identification-entity.md) | Optional | Government-issued identification documents that are<br>used to uniquely identify this payment initiation party |
| `payment_methods` | [`Array<PaymentInitiationPartyToPaymentMethodEntity>`](../../doc/models/payment-initiation-party-to-payment-method-entity.md) | Optional | Registrations between this payment initiation party and its payment methods |
| `locations` | [`Array<PaymentDeliveryAddressEntity>`](../../doc/models/payment-delivery-address-entity.md) | Optional | Delivery addresses associated with this payment initiation party |
| `expires_timestamp` | `DateTime` | Optional | Describes when the entity will be automatically deleted. The entity<br>will not go into the "DELETED" state. If this value is null or not<br>provided, the entity will not expire automatically |
| `status` | [`PartyStatus1`](../../doc/models/party-status-1.md) | Optional | Current status of the payment initiation party entry |
| `contact_preferences` | [`Array<PaymentInitiationPartyContactMethodEntity>`](../../doc/models/payment-initiation-party-contact-method-entity.md) | Optional | Contact methods for this payment initiation party |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "name": "name4",
  "type": "DATA_ACCESS_PLATFORM",
  "expiresTimestamp": "07/15/2021 14:46:41",
  "homeUri": "homeUri8",
  "logoUri": "logoUri2",
  "registry": "ICANN",
  "registeredEntityName": "registeredEntityName2",
  "registeredEntityId": "registeredEntityId4",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

