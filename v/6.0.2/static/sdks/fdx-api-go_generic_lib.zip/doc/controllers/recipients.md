# Recipients

Manage recipients

```go
recipientsController := client.RecipientsController()
```

## Class Name

`RecipientsController`

## Methods

* [Create Recipient](../../doc/controllers/recipients.md#create-recipient)
* [Get Recipient](../../doc/controllers/recipients.md#get-recipient)
* [Update Recipient](../../doc/controllers/recipients.md#update-recipient)
* [Delete Recipient](../../doc/controllers/recipients.md#delete-recipient)
* [Get Registry Recipients](../../doc/controllers/recipients.md#get-registry-recipients)
* [Get Registry Recipient](../../doc/controllers/recipients.md#get-registry-recipient)


# Create Recipient

Request to Register Recipient by Creating a Recipient Record

```go
CreateRecipient(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    body *models.RecipientRequest) (
    models.ApiResponse[models.RecipientProvider],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.RecipientRequest`](../../doc/models/recipient-request.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.RecipientProvider](../../doc/models/recipient-provider.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")



body := models.RecipientRequest{
    ClientName:            "My Example Client",
    Description:           models.ToPointer("Recipient Application servicing financial use case requiring permissioned data sharing"),
    RedirectUris:          []string{
        "https://partner.example/callback",
    },
    LogoUri:               models.ToPointer("https://client.example.org/logo.png"),
    ClientUri:             models.ToPointer("https://example.net/"),
    Contacts:              []string{
        "support@example.net",
    },
    Scope:                 models.ToPointer("ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS"),
    DurationType:          []models.ConsentDurationType{
        models.ConsentDurationType_TimeBound,
    },
    DurationPeriod:        models.ToPointer(365),
    LookbackPeriod:        models.ToPointer(365),
    RegistryReferences:    []models.RegistryReference{
        models.RegistryReference{
            RegisteredEntityName:  models.ToPointer("Official recipient name"),
            RegisteredEntityId:    models.ToPointer("4HCHXIURY78NNH6JH"),
            Registry:              models.ToPointer(models.Registry_Gleif),
        },
    },
    Intermediaries:        []models.Intermediary{
        models.Intermediary{
            Name:                  models.ToPointer("Data Access Platform Name"),
            Description:           models.ToPointer("Data Access Platform specializing in servicing permissioned data sharing for Data Recipients"),
            Uri:                   models.ToPointer("https://partner.example/"),
            LogoUri:               models.ToPointer("https://partner.example/logo.png"),
            Contacts:              []string{
                "support@partner.com",
            },
            RegistryReferences:    []models.RegistryReference{
                models.RegistryReference{
                    RegisteredEntityName:  models.ToPointer("Data Access Platform listed company Name"),
                    RegisteredEntityId:    models.ToPointer("JJH7776512TGMEJSG"),
                    Registry:              models.ToPointer(models.Registry_Fdx),
                },
            },
        },
        models.Intermediary{
            Name:                  models.ToPointer("Digital Service Provider Name"),
            Description:           models.ToPointer("Digital Service Provider to the Recipient"),
            Uri:                   models.ToPointer("https://sub-partner-one.example/"),
            LogoUri:               models.ToPointer("https://sub-partner-one.example/logo.png"),
            Contacts:              []string{
                "support@sub-partner-one.com",
            },
            RegistryReferences:    []models.RegistryReference{
                models.RegistryReference{
                    RegisteredEntityName:  models.ToPointer("Service Provider listed company Name"),
                    RegisteredEntityId:    models.ToPointer("9LUQNDG778LI9D1"),
                    Registry:              models.ToPointer(models.Registry_Gleif),
                },
            },
        },
    },
}

apiResponse, err := recipientsController.CreateRecipient(ctx, xFapiInteractionId, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "client_id": "V8tvEkZWhDAdxSaKGUJZ",
  "client_secret": "SpsuwZIxnp8bBEhp5sk1EKiIKTZ4X4DKU",
  "grant_types": [
    "authorization_code",
    "refresh_token"
  ],
  "token_endpoint_auth_method": "private_key_jwt",
  "registration_client_uri": "https://server.example.com/register/V8tvEkZWhDAdxSaKGUJZ",
  "status": "Approved",
  "registration_access_token": "V8tvEkZWhDAdxSaKGUJZ",
  "client_name": "My Example Client",
  "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
  "redirect_uris": [
    "https://partner.example/callback"
  ],
  "logo_uri": "https://client.example.org/logo.png",
  "client_uri": "https://example.net/",
  "contacts": [
    "support@example.net"
  ],
  "scope": "ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS",
  "duration_type": [
    "TIME_BOUND"
  ],
  "duration_period": 365,
  "lookback_period": 365,
  "registry_references": [
    {
      "registered_entity_name": "Official recipient name",
      "registered_entity_id": "4HCHXIURY78NNH6JH",
      "registry": "GLEIF"
    }
  ],
  "intermediaries": [
    {
      "name": "Data Access Platform Name",
      "description": "Data Access Platform specializing in servicing permissioned data sharing for Data Recipients",
      "uri": "https://partner.example/",
      "logo_uri": "https://partner.example/logo.png",
      "contacts": [
        "support@partner.com"
      ],
      "registry_references": [
        {
          "registered_entity_name": "Data Access Platform listed company Name",
          "registered_entity_id": "JJH7776512TGMEJSG",
          "registry": "FDX"
        }
      ]
    },
    {
      "name": "Digital Service Provider Name",
      "description": "Digital Service Provider to the Recipient",
      "uri": "https://sub-partner-one.example/",
      "logo_uri": "https://sub-partner-one.example/logo.png",
      "contacts": [
        "support@sub-partner-one.com"
      ],
      "registry_references": [
        {
          "registered_entity_name": "Service Provider listed company Name",
          "registered_entity_id": "9LUQNDG778LI9D1",
          "registry": "GLEIF"
        }
      ]
    }
  ]
}
```


# Get Recipient

Get a specific recipient data identified with clientId

```go
GetRecipient(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    clientId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.RecipientProvider],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `clientId` | `string` | Template, Required | Client Identifier. Uniquely identifies a Client<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.RecipientProvider](../../doc/models/recipient-provider.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

clientId := "clientId6"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := recipientsController.GetRecipient(ctx, xFapiInteractionId, clientId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Update Recipient

Update data for a specific recipient identified with clientId

```go
UpdateRecipient(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    clientId string,
    fdxApiActorType *models.FdxApiActorType,
    body *models.RecipientRequest) (
    models.ApiResponse[models.RecipientProvider],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `clientId` | `string` | Template, Required | Client Identifier. Uniquely identifies a Client<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `body` | [`*models.RecipientRequest`](../../doc/models/recipient-request.md) | Body, Optional | - |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.RecipientProvider](../../doc/models/recipient-provider.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

clientId := "clientId6"



body := models.RecipientRequest{
    ClientName:            "My Example Client",
    Description:           models.ToPointer("Recipient Application servicing financial use case requiring permissioned data sharing"),
    RedirectUris:          []string{
        "https://partner.example/callback",
    },
    LogoUri:               models.ToPointer("https://client.example.org/logo.png"),
    ClientUri:             models.ToPointer("https://example.net/"),
    Contacts:              []string{
        "support@example.net",
    },
    Scope:                 models.ToPointer("ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS"),
    DurationType:          []models.ConsentDurationType{
        models.ConsentDurationType_TimeBound,
    },
    DurationPeriod:        models.ToPointer(365),
    LookbackPeriod:        models.ToPointer(365),
    RegistryReferences:    []models.RegistryReference{
        models.RegistryReference{
            RegisteredEntityName:  models.ToPointer("Official recipient name"),
            RegisteredEntityId:    models.ToPointer("4HCHXIURY78NNH6JH"),
            Registry:              models.ToPointer(models.Registry_Gleif),
        },
    },
    Intermediaries:        []models.Intermediary{
        models.Intermediary{
            Name:                  models.ToPointer("Data Access Platform Name"),
            Description:           models.ToPointer("Data Access Platform specializing in servicing permissioned data sharing for Data Recipients"),
            Uri:                   models.ToPointer("https://partner.example/"),
            LogoUri:               models.ToPointer("https://partner.example/logo.png"),
            Contacts:              []string{
                "support@partner.com",
            },
            RegistryReferences:    []models.RegistryReference{
                models.RegistryReference{
                    RegisteredEntityName:  models.ToPointer("Data Access Platform listed company Name"),
                    RegisteredEntityId:    models.ToPointer("JJH7776512TGMEJSG"),
                    Registry:              models.ToPointer(models.Registry_Fdx),
                },
            },
        },
        models.Intermediary{
            Name:                  models.ToPointer("Digital Service Provider Name"),
            Description:           models.ToPointer("Digital Service Provider to the Recipient"),
            Uri:                   models.ToPointer("https://sub-partner-one.example/"),
            LogoUri:               models.ToPointer("https://sub-partner-one.example/logo.png"),
            Contacts:              []string{
                "support@sub-partner-one.com",
            },
            RegistryReferences:    []models.RegistryReference{
                models.RegistryReference{
                    RegisteredEntityName:  models.ToPointer("Service Provider listed company Name"),
                    RegisteredEntityId:    models.ToPointer("9LUQNDG778LI9D1"),
                    Registry:              models.ToPointer(models.Registry_Gleif),
                },
            },
        },
    },
}

apiResponse, err := recipientsController.UpdateRecipient(ctx, xFapiInteractionId, clientId, nil, &body)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```


# Delete Recipient

Delete data for a specific recipient identified with clientId

```go
DeleteRecipient(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    clientId string,
    fdxApiActorType *models.FdxApiActorType) (
    http.Response,
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `clientId` | `string` | Template, Required | Client Identifier. Uniquely identifies a Client<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance.

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

clientId := "clientId6"

fdxApiActorType := models.FdxApiActorType_Batch

resp, err := recipientsController.DeleteRecipient(ctx, xFapiInteractionId, clientId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    fmt.Println(resp.StatusCode)
}
```


# Get Registry Recipients

Get recipients

```go
GetRegistryRecipients(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    fdxApiActorType *models.FdxApiActorType,
    offset *string,
    limit *int) (
    models.ApiResponse[models.RecipientRecordsAtEcosystemRegistry],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |
| `offset` | `*string` | Query, Optional | Opaque cursor used by the provider to send the next set of records |
| `limit` | `*int` | Query, Optional | Number of elements that the consumer wishes to receive. Providers should implement reasonable default/maximum/minimum values based on their internal architecture and update their documentation accordingly |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.RecipientRecordsAtEcosystemRegistry](../../doc/models/recipient-records-at-ecosystem-registry.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

fdxApiActorType := models.FdxApiActorType_Batch





apiResponse, err := recipientsController.GetRegistryRecipients(ctx, xFapiInteractionId, &fdxApiActorType, nil, nil)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "page": {
    "nextOffset": "nextoffset",
    "prevOffset": "prevoffset",
    "total": 5000
  },
  "links": {
    "next": {
      "href": "/recipients?offset=nextoffset"
    },
    "prev": {
      "href": "/recipients?offset=prevoffset"
    }
  },
  "recipients": [
    {
      "recipient_id": "12345",
      "client_name": "My Example Client",
      "redirect_uris": [
        "https://partner.example/callback"
      ],
      "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
      "logo_uri": "https://client.example1.org/logo.png",
      "client_uri": "https://example1.net/",
      "contacts": [
        "support@example1.net"
      ],
      "scope": "ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS",
      "duration_type": [
        "TIME_BOUND"
      ],
      "duration_period": 365,
      "lookback_period": 365,
      "registry_references": [
        {
          "registered_entity_name": "Official recipient name",
          "registered_entity_id": "4HCHXIURY78NNH6JH",
          "registry": "GLEIF"
        }
      ]
    },
    {
      "recipient_id": "23456",
      "client_name": "Another Example Client",
      "redirect_uris": [
        "https://partner.example/callback"
      ],
      "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
      "logo_uri": "https://client.example2.org/logo.png",
      "client_uri": "https://example2.net/",
      "contacts": [
        "support@example2.net"
      ],
      "scope": "ACCOUNT_DETAILED INVESTMENTS",
      "duration_type": [
        "TIME_BOUND"
      ],
      "duration_period": 365,
      "lookback_period": 365,
      "registry_references": [
        {
          "registered_entity_name": "Official recipient name",
          "registered_entity_id": "8XKSJGEU2465KSOGI",
          "registry": "GLEIF"
        }
      ]
    }
  ]
}
```


# Get Registry Recipient

Get a specific recipient

```go
GetRegistryRecipient(
    ctx context.Context,
    xFapiInteractionId uuid.UUID,
    recipientId string,
    fdxApiActorType *models.FdxApiActorType) (
    models.ApiResponse[models.RecipientRecordAtEcosystemRegistry],
    error)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `xFapiInteractionId` | `uuid.UUID` | Header, Required | Unique identifier for this interaction |
| `recipientId` | `string` | Template, Required | Recipient Identifier. Uniquely identifies a Recipient<br><br>**Constraints**: *Maximum Length*: `256` |
| `fdxApiActorType` | [`*models.FdxApiActorType`](../../doc/models/fdx-api-actor-type.md) | Header, Optional | Identifies whether the customer is present (USER) or it is a BATCH operation |

## Response Type

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.RecipientRecordAtEcosystemRegistry](../../doc/models/recipient-record-at-ecosystem-registry.md).

## Example Usage

```go
ctx := context.Background()

xFapiInteractionId := uuid.MustParse("c770aef3-6784-41f7-8e0e-ff5f97bddb3a")

recipientId := "recipientId4"

fdxApiActorType := models.FdxApiActorType_Batch

apiResponse, err := recipientsController.GetRegistryRecipient(ctx, xFapiInteractionId, recipientId, &fdxApiActorType)
if err != nil {
    log.Fatalln(err)
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Example Response *(as JSON)*

```json
{
  "recipient_id": "12345",
  "client_name": "My Example Client",
  "redirect_uris": [
    "https://partner.example/callback"
  ],
  "description": "Recipient Application servicing financial use case requiring permissioned data sharing",
  "logo_uri": "https://client.example.org/logo.png",
  "client_uri": "https://example.net/",
  "contacts": [
    "support@example.net"
  ],
  "scope": "ACCOUNT_DETAILED TRANSACTIONS INVESTMENTS",
  "duration_type": [
    "TIME_BOUND"
  ],
  "duration_period": 365,
  "lookback_period": 365,
  "registry_references": [
    {
      "registered_entity_name": "Official recipient name",
      "registered_entity_id": "4HCHXIURY78NNH6JH",
      "registry": "GLEIF"
    }
  ]
}
```

