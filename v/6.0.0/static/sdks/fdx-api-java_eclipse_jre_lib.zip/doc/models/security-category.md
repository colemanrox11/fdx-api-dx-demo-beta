
# Security Category

The type of security

*This model accepts additional fields of type Object.*

## Enumeration

`SecurityCategory`

## Fields

| Name |
|  --- |
| `DebtSecurity` |
| `MutualFundSecurity` |
| `OptionSecurity` |
| `OtherSecurity` |
| `StockSecurity` |
| `SweepSecurity` |

