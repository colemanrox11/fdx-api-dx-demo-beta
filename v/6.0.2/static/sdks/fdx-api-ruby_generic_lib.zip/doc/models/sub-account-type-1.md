
# Sub Account Type 1

Sub-account security Type. One of CASH, MARGIN, SHORT, OTHERS

*This model accepts additional fields of type Object.*

## Enumeration

`SubAccountType1`

## Fields

| Name |
|  --- |
| `CASH` |
| `MARGIN` |
| `OTHER` |
| `SHORT` |

