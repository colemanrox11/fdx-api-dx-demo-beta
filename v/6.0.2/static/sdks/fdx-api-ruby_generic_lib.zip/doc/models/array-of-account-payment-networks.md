
# Array of Account Payment Networks

An optionally paginated array of payment networks supported by the account

*This model accepts additional fields of type Object.*

## Structure

`ArrayOfAccountPaymentNetworks`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page` | [`PageMetadata`](../../doc/models/page-metadata.md) | Optional | Offset IDs for navigating result sets |
| `links` | [`PageMetadataLinks`](../../doc/models/page-metadata-links.md) | Optional | Resource URLs for navigating result sets |
| `payment_networks` | [`Array<PaymentNetworkSupportedByAccount>`](../../doc/models/payment-network-supported-by-account.md) | Optional | Array of payment networks |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "page": {
    "nextOffset": "nextOffset4",
    "prevOffset": "prevOffset0",
    "totalElements": 88,
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "links": {
    "next": {
      "href": "href4",
      "action": "DELETE",
      "rel": "rel8",
      "types": [
        "image/png"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "prev": {
      "href": "href8",
      "action": "GET",
      "rel": "rel2",
      "types": [
        "image/tiff"
      ],
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "paymentNetworks": [
    {
      "bankId": "bankId0",
      "identifier": "identifier2",
      "identifierType": "ACCOUNT_NUMBER",
      "type": "US_RTP",
      "transferIn": false,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "bankId": "bankId0",
      "identifier": "identifier2",
      "identifierType": "ACCOUNT_NUMBER",
      "type": "US_RTP",
      "transferIn": false,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    },
    {
      "bankId": "bankId0",
      "identifier": "identifier2",
      "identifierType": "ACCOUNT_NUMBER",
      "type": "US_RTP",
      "transferIn": false,
      "exampleAdditionalProperty": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  ],
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

