
# Tax Party Type 2

Type of issuer or recipient legal entity, as "BUSINESS" or "INDIVIDUAL". Commonly BUSINESS for issuer and INDIVIDUAL for recipient

*This model accepts additional fields of type Object.*

## Enumeration

`TaxPartyType2`

## Fields

| Name |
|  --- |
| `BUSINESS` |
| `INDIVIDUAL` |

