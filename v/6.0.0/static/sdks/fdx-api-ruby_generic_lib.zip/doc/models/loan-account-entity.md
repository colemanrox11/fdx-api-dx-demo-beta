
# Loan Account Entity

A loan account type

*This model accepts additional fields of type Object.*

## Structure

`LoanAccountEntity`

## Inherits From

[`AccountEntity`](../../doc/models/account-entity.md)

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `balance_as_of` | `DateTime` | Optional | As-of date for balances |
| `principal_balance` | `Float` | Optional | Principal balance of loan |
| `escrow_balance` | `Float` | Optional | Escrow balance of loan |
| `original_principal` | `Float` | Optional | Original principal of loan |
| `originating_date` | `Date` | Optional | Loan origination date |
| `loan_term` | `Integer` | Optional | Term of loan in months |
| `total_number_of_payments` | `Integer` | Optional | Total number of payments |
| `next_payment_amount` | `Float` | Optional | Amount of next payment |
| `next_payment_date` | `Date` | Optional | Date of next payment |
| `payment_frequency` | [`PaymentFrequency1`](../../doc/models/payment-frequency-1.md) | Optional | DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY |
| `compounding_period` | [`CompoundingPeriod2`](../../doc/models/compounding-period-2.md) | Optional | DAILY, WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, SEMIANNUALLY, ANNUALLY |
| `pay_off_amount` | `Float` | Optional | Payoff amount |
| `last_payment_amount` | `Float` | Optional | Last payment amount |
| `last_payment_date` | `Date` | Optional | Last payment date |
| `maturity_date` | `Date` | Optional | Maturity date |
| `interest_paid_year_to_date` | `Float` | Optional | Interest paid year to date |
| `transactions` | [`Array<LoanTransactionEntity>`](../../doc/models/loan-transaction-entity.md) | Optional | Transactions on the loan account |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example (as JSON)

```json
{
  "accountOpenDate": "2021-07-15",
  "accountCloseDate": "2021-07-15",
  "interestRateAsOf": "07/15/2021 14:46:41",
  "lastActivityDate": "2021-07-15",
  "balanceAsOf": "07/15/2021 14:46:41",
  "originatingDate": "2021-07-15",
  "nextPaymentDate": "2021-07-15",
  "lastPaymentDate": "2021-07-15",
  "maturityDate": "2021-07-15",
  "accountCategory": "Loan Account entity",
  "accountId": "accountId6",
  "error": {
    "code": "code2",
    "message": "message4",
    "debugMessage": "debugMessage4",
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "accountType": "SPECIFIEDPENSIONPLAN",
  "accountNumber": "accountNumber6",
  "exampleAdditionalProperty": {
    "key1": "val1",
    "key2": "val2"
  },
  "parentAccountId": "parentAccountId8",
  "lineOfBusiness": "lineOfBusiness8",
  "routingTransitNumber": "routingTransitNumber0",
  "balanceType": "ASSET",
  "contact": {
    "emails": [
      "emails1",
      "emails2",
      "emails3"
    ],
    "addresses": [
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "line1": "line16",
        "line2": "line28",
        "line3": "line36",
        "city": "city4",
        "region": "region0",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "telephones": [
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "type": "FAX",
        "country": "country0",
        "number": "number4",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "holders": [
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      },
      {
        "emails": [
          "emails5",
          "emails6"
        ],
        "addresses": [
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          },
          {
            "line1": "line16",
            "line2": "line28",
            "line3": "line36",
            "city": "city4",
            "region": "region0",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "telephones": [
          {
            "type": "FAX",
            "country": "country0",
            "number": "number4",
            "exampleAdditionalProperty": {
              "key1": "val1",
              "key2": "val2"
            }
          }
        ],
        "dateOfBirth": "2016-03-13",
        "taxId": "taxId2",
        "exampleAdditionalProperty": {
          "key1": "val1",
          "key2": "val2"
        }
      }
    ],
    "exampleAdditionalProperty": {
      "key1": "val1",
      "key2": "val2"
    }
  },
  "principalBalance": 32.64,
  "escrowBalance": 61.1,
  "originalPrincipal": 9.42
}
```

